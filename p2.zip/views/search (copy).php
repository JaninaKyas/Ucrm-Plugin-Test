<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interferences recording</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">  
    <link rel="stylesheet" type="text/css" href="public/css/main.css">
  </head>
  <body>  
    <?php
      if (isset($_POST["search"])) {       
        $path = substr(__DIR__, 0, -6);
        require_once($path . '/model/get_custome_user_data.php');
        $customTable = new CustomTable();
        $result = $customTable->getUserByCustomerNumber($_POST['cusNrInput']);
      }
    ?>  
  
    <div id="title" style="margin-left: 50px;">
      <h3>Störungsaufnahme</h3>
    </div>
    
    <div id="main" style="background-color: #B8C402; margin: 0 50px 0 50px;">
      <form id="customSearch" method="post" class="pufferForm">
        <div class="row">
          <div id="customerNumber" class="form-group col-xs-6">
            <label for="cusNrLabel">Kundennummer</label>
            <input type="text" id="cusNrInput" name="cusNrInput" class="form-control" placeholder="Kundennummer" value="<?php if (array_key_exists('customer_number', $result) && !is_null($result['customer_number'])) { echo trim($result['customer_number']); } ?>"><br/> 
          </div>
          <div id="customerNumber" class="form-group col-xs-6">          
            <button class="btn btn-primary btn-md" type="submit" id="search" name="search" value="search" style="margin-top: 25px;">Lade Kunde</button>
          </div>
        </div>
      </form>

      <div class="row pufferRow">
        <div id="firstName" class="form-group col-xs-6">
          <label for="firstNameLabel">Vorname</label>
          <input type="text" id="firstInput" class="form-control" placeholder="Vorname" value="<?php if (array_key_exists('test_firstname', $result) && !is_null($result['test_firstname'])) { echo trim($result['test_firstname']); } ?>">    
        </div>
        <div id="lastName" class="form-group col-xs-6">
          <label for="lastNameLabel">Nachname</label>
          <input type="text" id="lastNameInput" class="form-control" placeholder="Nachname" value="<?php if (array_key_exists('test_name', $result) && !is_null($result['test_name'])) { echo trim($result['test_name']); } ?>">    
        </div>      
      </div>

      <div class="row pufferRow">          
        <div id="company" class="form-group col-md-12">
          <label for="companyLabel">Firma (falls Anfrage als Businesskunde)</label>
          <input type="text" id="companyInput" class="form-control" placeholder="Firma" value="<?php if (array_key_exists('test_company', $result) && !is_null($result['test_company'])) { echo trim($result['test_company']); } ?>"> 
        </div>      
      </div>
    </div>    
  </body>    
</html>
