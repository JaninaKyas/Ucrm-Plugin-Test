<?php

declare(strict_types = 1);

class CustomPlaces {
  function getAllPlaces(PDO $pdo): array {    
    $query = 'SELECT id, name, district FROM custom_places';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return ($result !== false) ? $result : [];
  }
}
