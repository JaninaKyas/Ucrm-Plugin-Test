<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class CustomerConnectionRequestsQueries {
    public function saveRequest(
	  $salut, $fName, $lName, $company, $street, $hNr, $plz, $place, $district, $phone, $mobil, $mail, $conKind,
	  $selTech, $isWishRecall, $recallTermin, $rate, $careTech, $isPhone, $isPorting, $careTermin, $message
	): bool {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = false;
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
		  
		  $query = '
		    INSERT INTO customer_connection_requests
            VALUES(
			  null,
			  \'' . $salut             . '\',
			  \'' . $fName             . '\',
			  \'' . $lName             . '\',
			  \'' . $company           . '\',
			  \'' . $street            . '\',
			  \'' . $hNr               . '\',
			  \'' . $plz               . '\',
			  \'' . $place             . '\',
			  \'' . $district          . '\',
			  \'' . $phone             . '\',
			  \'' . $mobil             . '\',
			  \'' . $mail              . '\',
			  \'' . $conKind           . '\',
			  \'' . $selTech           . '\',
			  \'' . $isWishRecall      . '\',
			  \'' . $recallTermin      . '\',
			  \'' . $rate              . '\',
			  \'' . $careTech          . '\',
			  \'' . $isPhone           . '\',
			  \'' . $isPorting         . '\',
			  \'' . $careTermin        . '\',
			  \'' . $message           . '\',
			   1, NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';
			

		  $returnValue = $connection->query($query);	
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>