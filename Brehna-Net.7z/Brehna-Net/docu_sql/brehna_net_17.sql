--
-- Tabellenstruktur für Tabelle `tariff_x_technology`
--

CREATE TABLE IF NOT EXISTS `tariff_x_technology` (
  `id`            INT(11)  UNSIGNED NOT NULL AUTO_INCREMENT,
  `tariff_id`     INT(11)  UNSIGNED NOT NULL,
  `technology_id` INT(11)  UNSIGNED NOT NULL,
  `createDate`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`    CHAR(50)          NOT NULL DEFAULT '',
  `updateDate`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`    CHAR(50)          NOT NULL DEFAULT '',
  `isDeleted`     TINYINT(1)        NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (tariff_id)     REFERENCES `tariff`(id),
  FOREIGN KEY (technology_id) REFERENCES `technology`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;