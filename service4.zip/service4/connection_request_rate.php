<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	$content = array();

    $address = $infos["postalAddress"];
    if ($infos["techAddress"]["street"]  != ""
	 && $infos["techAddress"]["hnr"]     != ""
	 && $infos["techAddress"]["zipcode"] != ""
	 && $infos["techAddress"]["place"]   != "") {
	  $address = $infos["techAddress"];
	}
	  
	require_once __DIR__ . "/model/tariff_queries.php";
	require_once __DIR__ . "/views/rates/tariff.php";
	 
	$tariffQueries = new TariffQueries();
	$ratesData     = $tariffQueries->getAllRates();
	  
	$tariffFormHtml = new Tariff($ratesData, $address);
		  
	$content["step4label"]   = "Tarifauswahl";
	$content["step4content"] = $tariffFormHtml->getTemplate();
	  
	echo json_encode($content);
  }
?>