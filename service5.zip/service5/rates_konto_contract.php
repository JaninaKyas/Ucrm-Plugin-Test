<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	require_once __DIR__ ."/model/contract_term_queries.php";
	require_once __DIR__ ."/model/numerically_queries.php";
	require_once __DIR__ ."/views/rates/rate_konto.php";
	  
	$contractTermQueries = new ContractTermQueries();
	$durations           = $contractTermQueries->getAllTermsPK();
	  
	$numericallyQueries  = new NumericallyQueries();
	$numData             = $numericallyQueries->getAllNumericallyPK();
	
	$rateKonto = new RateKonto($durations, $numData, $infos["customer"], $infos["postalAddress"]);
	  
	$content = array(
	  "step5content" => $rateKonto->buildRatesKontoTemplate()
	);

	echo json_encode($content);
  } 
?>