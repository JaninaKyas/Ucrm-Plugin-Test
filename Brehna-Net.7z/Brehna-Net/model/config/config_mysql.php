<?php

declare(strict_types = 1);

class ConfigDb {
  protected const DB_HOST     = 'Ykc5allXeG9iM04w';
  protected const DB_PORT     = 3306;
  protected const DB_NAME     = 'ZDJWaU1qQXlOMTlpYm1WMFgyUmk=';
  protected const DB_USER     = 'WW01bGRHUmlkWE5sY2c9PQ==';
  protected const DB_PASSWORD = 'ZHpGSGNHTTBQelk9';
  
  private function _decipherConstants(String $value) : String {
    return base64_decode(base64_decode($value));
  }
  
  public function getDbHost () : String {
    return $this->_decipherConstants(self::DB_HOST);
  }
  
  public function getDbPort () : int {
    return self::DB_PORT;  
  }
  
  public function getDbName () : String {
    return $this->_decipherConstants(self::DB_NAME);  
  }
  
  public function getDbUser () : String {
    return $this->_decipherConstants(self::DB_USER);  
  }
  
  public function getDbPassword () : String {
    return $this->_decipherConstants(self::DB_PASSWORD);  
  } 
}

?>