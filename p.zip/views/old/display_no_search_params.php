<div class="alert alert-warning alert-dismissible fade show">
  Es wurden ungültige Parameter angegeben. Bitte überprüfen Sie Ihre Angaben!
  <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
