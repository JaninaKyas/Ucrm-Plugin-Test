<div id="errorAdressNotFound">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Leider konnten wir die angegebene Adresse nicht finden.
    </div>
  </div>
</div>

<div id="errorNotChooseTariff" class="noDisplay">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Bitte wählen Sie einen Tarif aus.
    </div>
  </div>
</div>

<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views", "", __DIR__);

  require $dir . "/model/tariff_queries.php";
  require $dir . "/frontend/tariff_card.php";

  $tariffQueries = new TariffQueries();
  $tariffs = $tariffQueries->getAllTariffData();
?>

<div id="tariffCardBox" class="borderBox">
  <div id="cGroup1">
<?php	  
  for ($i=0; $i < 7; $i++) {
    $tariffCard = new TariffCard();
	$tariffCard->buildTariffCard(
	  $tariffs[$i]["id"],
	  $tariffs[$i]["name"],
	  $tariffs[$i]["techName"],
      $tariffs[$i]["downStream"],
      $tariffs[$i]["upStream"], 
      $tariffs[$i]["price"],
	  $tariffs[$i]["category"],
	  $tariffs[$i]["tOptions"],
      $tariffs[$i]["cClassType"],
	  "cGroup1-" . $tariffs[$i]["downStream"]
    );
  }
?>
  </div>
	
  <div id="cGroup2">
<?php
  for ($i=7; $i < 8; $i++) {
    $tariffCard = new TariffCard();
	$tariffCard->buildTariffCard(
	  $tariffs[$i]["id"],
	  $tariffs[$i]["name"],
	  $tariffs[$i]["techName"],
      $tariffs[$i]["downStream"],
      $tariffs[$i]["upStream"], 
      $tariffs[$i]["price"],
	  $tariffs[$i]["category"],
	  $tariffs[$i]["tOptions"],
      $tariffs[$i]["cClassType"],
	  "cGroup2-" . $tariffs[$i]["downStream"]
    );
  }
?>
  </div>
	
  <div id="cGroup3">
<?php
  for ($i=8; $i < 12; $i++) {
    $tariffCard = new TariffCard();
	$tariffCard->buildTariffCard(
	  $tariffs[$i]["id"],
	  $tariffs[$i]["name"],
	  $tariffs[$i]["techName"],
      $tariffs[$i]["downStream"],
      $tariffs[$i]["upStream"], 
      $tariffs[$i]["price"],
	  $tariffs[$i]["category"],
	  $tariffs[$i]["tOptions"],
      $tariffs[$i]["cClassType"],
	  "cGroup3-" . $tariffs[$i]["downStream"]
    );
  }
?>
  </div>
</div>

