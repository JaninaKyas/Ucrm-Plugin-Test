<form id="orderAuto" method="post">
  <div class="form-header d-flex mb-4">
	<span class="stepIndicator">Kundendaten</span>
	<span class="stepIndicator">Tarife</span>
	<span class="stepIndicator">Optionen</span>
	<span class="stepIndicator">Vertragslaufzeit</span>
	<span class="stepIndicator">Konto</span>
	<span class="stepIndicator">AGB</span>
	<span class="stepIndicator">Zusammenfassung</span>
  </div>   
	  
  <div class="step active"><?php require __DIR__ . "/views/customer_data.php"; ?></div>
  <div id="tariffResult" class="step"><?php require __DIR__ . "/views/tariff.php"; ?></div>
  <div class="step"><?php require __DIR__ . "/views/options.php"; ?></div>
  <div class="step"><?php require __DIR__ . "/views/contract_term.php"; ?></div>
  <div class="step"><?php require __DIR__ . "/views/bank_account.php"; ?></div>
  <div class="step"><?php require __DIR__ . "/views/agb.php"; ?></div>
  <div class="step"><?php require __DIR__ . "/views/summary.php"; ?></div>
  
  <div class="form-footer d-flex">
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Zurück</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Weiter</button>
  </div>
</form>