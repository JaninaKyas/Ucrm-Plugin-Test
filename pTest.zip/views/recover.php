<div class="borderStyle generally">

<div class="row puffer">
  <div class="col">
      <b>Wurde ein Neustart des Routers durchgeführt?</b>
  </div>
  
  <div class="col">
    <input type="radio" id="routerNYes" name="routerN" value="routerNYes" onClick="displayNewStart(1)"> Ja
  </div>
  
  <div class="col">
    <input type="radio" id="routerNNo"  name="routerN" value="routerNNo" onClick="displayNewStart(0)"> Nein
  </div>
</div>

<div id="newStart" class="displayBlock">

<div class="row puffer">
  <div class="col">
    <b>Bitte einen Neustart des Routers durchführen, in dem man wie folgt vorgeht:</b>
      <ul class="list-group">
        <li class="list-group-item">
          <h8>Mit dem Kunden</h8>
          <ul>
            <li>Bitte den Router von der Stromquelle trennen.</li>
            <li>Bitte min. 5 Minuten warten.</li>
            <li>Bitte den Router wieder mit der Stromquelle verbinden.</li>
            <li>Bitte ca. 5 Minuten warten.</li>
          </ul>
        </li>
        <br>
        <b>oder</b>
        <br>
        <li class="list-group-item">
          <h8>Mit dem Teamviewer</h8>
          <ul>
            <li>Bitte einen Webbrowser öffnen.</li>
            <li>Bitte die URL-Adresse <i>http://fritz.box</i> eingeben.</li>
            <li>Bitte links auf den Menüpunkt <i>System</i> klicken.</li>
            <li>Bitte links auf den Menüpunkt <i>Sicherung</i> klicken.</li>
            <li>Bitte im Reiter <i>Neustart</i> unten auf den Button <i>Neu starten</i>klicken.</li>
            <li>Bitte ca. 5 Minuten warten.</li>
          </ul>
        </li>
      </ul>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <b>Blinken alle LED's weiterhin?</b>
    </div>
  
    <div class="col">
      <input type="radio" id="routerBYes" name="routerB" value="routerBYes"> Ja
    </div>
  
    <div class="col">
      <input type="radio" id="routerBNo"  name="routerB" value="routerBNo"> Nein
    </div>
  </div>
  
</div>

</div>
<script>
  function displayNewStart(enable) {
    if (enable == 1) {
      document.getElementById("newStart").style.display = "block";
    } else {
      document.getElementById("newStart").style.display = "none";
    }
  }
</script>
