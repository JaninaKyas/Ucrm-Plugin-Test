<?php  
  declare(strict_types = 1);

  require __DIR__ . "/forms/customer.php";

  class ConnectionRequest {
	public $templateAttributes = array();
	public $templateValues     = array();
	  
	public function __construct($newTemplateAttributes, $newTemplateValues = array()) {
      $this->templateAttributes = $newTemplateAttributes;
	  $this->templateValues     = $newTemplateValues;
	}
	  
	public function getTemplateStep2(): string {
	  $customer = new Customer($this->templateAttributes, $this->templateValues);
	  $returnValue = $customer->buildCustomerTemplate();
	  return $returnValue;
	}
	  
	public function getRecallTemplate(): string {
	  return '
	    <div id="recallContainer">
	      <div class="row puffer">
		    <div class="col">
			  <span class="fontTitle">Rückruftermin</span>
			</div>
		  </div>
		
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">
			    Ich möchte einen Rückruf um mich telefonisch beraten zu lassen.*
			  </label>
			</div>
			
			<div class="col-2 topPuffer">
			  <input id="reAnswerYes" name="reAnswer" type="checkbox"> Ja
			</div>
			
			<div class="col-2 topPuffer">
			  <input id="reAnswerNo"  name="reAnswer" type="checkbox"> Nein
			</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Angabe Termin für Rückruf</label>
		      <input type="datetime-local" id="terminRecall" name="terminRecall" class="form-control">
			</div>
		  </div>
		</div>
	  ';
	}
  }
?>