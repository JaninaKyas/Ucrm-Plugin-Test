<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	require_once __DIR__ . "/views/glassFibre/glass_fibre_sepa.php";
	
	$gfsAGBTemplate = new GlassFibreSepa(array(), false);
	  
	$content = array(
	  "step7content" => $gfsAGBTemplate->buildAGBTemplate()
	);

	echo json_encode($content);
  } 
?>