<?php
  declare(strict_types = 1);

  class ConnectionData {
    public $templateData = array();
	public $defaultData  = array();
	  
	public function __construct($newTemplateData, $newDefaultData) {
	  $this->templateData = $newTemplateData;
	  $this->defaultData  = $newDefaultData;
	}
	  
	public function buildConnectionDataTemplate(): string {
	  return '<div class="fontTitle">Anschluss</div>
	    <div class="gfCdBlock">'
	    . $this->buildKindConnectionTemplate()            . '<hr>'
		. $this->buildHouseIntroductionTemplate()         . '<hr>'
		. $this->buildDesignatedHouseConnectionTemplate()
		. '</div>';
	}
	  
	private function buildKindConnectionTemplate(): string {
	  $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Typ der Anschlusstelle</label>
		  </div>
        </div>
		  
	    <div class="row puffer left">';
		
	  for ($i = 0; $i < 3; $i++) {
        $returnValue .= '<div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["cptData"][$i]["name"]        . '</span>
		</div>';
	  }
	
	  $returnValue .=  '</div><div class="row puffer left">
	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][3]["id"]   . '">
		  <span>' . $this->defaultData["cptData"][3]["name"]         . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["kindConnection"][1] . '"
				   name="' . $this->templateData["kindConnection"][1] . '"
				   placeholder="Anzahl Wohneinheiten">
		  </span>
		</div>

	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][4]["id"]   . '">
		  <span>' . $this->defaultData["cptData"][4]["name"]         . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["kindConnection"][2] . '"
				   name="' . $this->templateData["kindConnection"][2] . '"
				   placeholder="vorraussichtlicher Fertigstellungstermin">
		  </span>
		</div>
      </div>';
		
	  return $returnValue;
	}
	  
	private function buildHouseIntroductionTemplate(): string {
      $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Hauseinführung</label>
		  </div>
        </div>
		
		<div class="row puffer left">';
		
	  for ($i = 0; $i < 2; $i++) {
	    $returnValue .= '<div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["introHouse"][0] . '"
				 value="' . $this->defaultData["hitData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["hitData"][$i]["name"]        . '</span>
		  </div>';
	  }
		
	  $returnValue .=  '</div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["introHouse"][0]   . '"
				 value="' . $this->defaultData["hitData"][2]["id"] . '">
		  <span>' . $this->defaultData["hitData"][2]["name"]       . '</span>
		</div>
	  
	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["introHouse"][0]   . '"
				 value="' . $this->defaultData["hitData"][3]["id"] . '">
		  <span>' . $this->defaultData["hitData"][3]["name"]       . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["introHouse"][1] . '"
				   name="' . $this->templateData["introHouse"][1] . '">
		  </span>
		</div>
	  </div>';
		
	  return $returnValue;
	}
	  
	private function buildDesignatedHouseConnectionTemplate(): string {
      $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Beauftragter Hausanschluss</label>
		  </div>
        </div>
		
		<div class="row puffer left">
		  <div class="col">';
		
	 for ($i = 0; $i < 4; $i++) {
	   if ($i > 0) {
	     $returnValue .= '<br>';
	   }
		 
	   $returnValue .= '<input type="radio"
		        name="'  . $this->templateData["designConHouse"][0] . '"
			    value="' . $this->defaultData["chtData"][$i]["id"]  . '">
		 <span>' . $this->defaultData["chtData"][$i]["name"]        . '</span>
		 <br>
		 <span class="smFont">(' . $this->defaultData["chtData"][$i]["note"] . ')</span>';
		 
		 if ($i <= 2) {
		   $returnValue .= '<br>';
		 }
	 }
	
	 $returnValue .= '</div><div class="col price">';
		
	 for ($i = 0; $i < 4; $i++) {
	   if ($i > 0) {
	     $returnValue .= '<br>';
	   }
		 
	   $returnValue .= '<span>'
	     . number_format(floatval($this->defaultData["chtData"][$i]["price"]), 2, ',', ' ')
		 . ' €</span><br>';
		 
	   if ($i <= 2) {
		 $returnValue .= '<br>';
	   }
	 }
		
	 $returnValue .= '</div></div>
	 
		<div class="row puffer left">
		  <div class="col">';
	  
	  for ($i = 4; $i < 7; $i++) {
	    if ($i > 4) {
	      $returnValue .= '<br>';
	    }
		  
	    $returnValue .= '<input type="radio"
		         name="'  . $this->templateData["designConHouse"][0] . '"
		 	     value="' . $this->defaultData["chtData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["chtData"][$i]["name"]        . '</span>';
		
		if (!empty($this->defaultData["chtData"][$i]["note"])) {
		  $returnValue .= '<br><span class="smFont">('
		    . $this->defaultData["chtData"][$i]["note"] . ')</span>';
		}
		
		$j = $i - 3;
		$returnValue .= '<br>
		<input type="text"
		       id="' .   $this->templateData["designConHouse"][$j] . '"
			   name="' . $this->templateData["designConHouse"][$j] . '">';
	  }
		
	  $returnValue .= '</div><div class="col price">';
		
	  for ($i = 4; $i < 6; $i++) {
	    if ($i > 4) {
	      $returnValue .= '<br>';
	    }
		  
		if ($i === 5) {
		  $returnValue .= '<br><br>';   
		}
		  
        $returnValue .= '<span>'
	      . number_format(floatval($this->defaultData["chtData"][$i]["price"]), 2, ',', ' ')
		  . ' €</span><br>';
		  
	    if ($i < 6) {
		  $returnValue .= '<br>';
	    }
	  }
		
	  $returnValue .= '</div></div>';
		
	  return $returnValue;
	}
  }
?>