<?php

declare(strict_types = 1);

class CustomPlaces {
  function getAllPlaces(): array {    
    $pdo = require_once __DIR__ . '/connect_db.php';
    $query = 'SELECT id, name, district FROM custom_places';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $pdo = null; // close db connection

    return ($result !== false) ? $result : [];
  }
}
