let data             = {};
var choosenRateId    = 0;
var isFormConRequest = false;

const navigateToFormStep = (stepNumber) => {
  document.querySelectorAll(".form-step").forEach((formStepElement) => {
    formStepElement.classList.add("d-none");
  });

  document.querySelectorAll(".form-stepper-list").forEach((formStepHeader) => {
    formStepHeader.classList.add("form-stepper-unfinished");
    formStepHeader.classList.remove("form-stepper-active", "form-stepper-completed");
  });

  document.querySelector("#step-" + stepNumber).classList.remove("d-none");
  const formStepCircle = document.querySelector('li[step="' + stepNumber + '"]');

  formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-completed");
  formStepCircle.classList.add("form-stepper-active");

  for (let index = 0; index < stepNumber; index++) {
    const formStepCircle = document.querySelector('li[step="' + index + '"]');

    if (formStepCircle) {
      formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-active");
      formStepCircle.classList.add("form-stepper-completed");
    }
  }
};

document.querySelectorAll(".btn-navigate-form-step").forEach((formNavigationBtn) => {	
  formNavigationBtn.addEventListener("click", () => {
    const stepNumber    = parseInt(formNavigationBtn.getAttribute("step_number"));
	const stepDirection = parseInt(formNavigationBtn.getAttribute("step_direction"));
	const elementId     = formNavigationBtn.getAttribute("id");
	var   canChangeStep = true;
	
	// stepDirection === 1 -- forward; stepDirection === -1 -- backward
	if (stepDirection === 1) {
	  // step == 2
	  if (stepNumber === 2) {
	    canChangeStep = validateAvailibityForm();
		
        if (canChangeStep) {
		  executeAvailabilitySearch();
	    }
	  }
	} else {
      resetRequiredFields();

	  if (stepNumber === 1) {
	    document.getElementById("asbErrorMsg").style.display = "none";
	  }
	}
	
	if (canChangeStep) {
      navigateToFormStep(stepNumber);
	}
  });
});

function resetRequiredFields() {
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");
	
  for (i = 0; i < requiredInputs.length; i++) {
	requiredInputs[i].classList.remove("invalid");
  }
		  
  for (j = 0; j < requiredRadio.length; j++) {
	requiredRadio[j].parentNode.children[1].style.color = "#444";
  }
}

function validateAvailibityForm() {
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");
  var errorDiv       = document.getElementById("asbErrorMsg");

  for (i = 0; i < requiredInputs.length; i++) { 
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  returnValue = false;
	  requiredInputs[i].className += " invalid";
	}
  }

  for (j = 0; j < requiredRadio.length; j++) {	  
	if (!requiredRadio[j].checked) {
	  requiredRadio[j].parentNode.children[1].style.color = 'red';
	  returnValue = false;
	} else {
	  return true;
	}
  }

  errorDiv.classList.remove("d-none");
  if (returnValue == false) {
	errorDiv.style.display = "block";  
  } else {
    errorDiv.style.display = "none";
  }
	
  return returnValue;
}

function validateConRequest() {
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
	
  for (i = 0;i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }
console.log(returnValue);	
  return returnValue;
}

async function executeAvailabilitySearch() {	
  var url           = "https://neu.brehna.net/auftrag/rates.php";
  var checkedBoxes  = document.querySelectorAll('input[name=checkConTech]:checked');
  var conKind       = document.querySelectorAll('input[name=conKind]:checked');
  var step2Lable = document.getElementById("step2Lable");
  var step3Lable = document.getElementById("step3Lable");
	
  data = {
	"street"   : document.getElementById("asbStreet").value,
	"hNr"      : document.getElementById("asbHNr").value,
    "zipcode"  : document.getElementById("asbPlz").value,
	"place"    : document.getElementById("asbPlace").value,
    "district" : document.getElementById("asbDistrict").value,
	"conKind"  : conKind[0].value,
	"selTech"  : checkedBoxes[0].value
  }
  
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	  // display button "Weiter"
	  document.getElementById("disForward").style.display   = response["displayForward"];
	  // display button "Zurück" (bottom button)
	  document.getElementById("backBtnStep2").style.display = response["backBtnStep2"]
	  
	  switch(response["ident"]) {
	    case 1:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
	      displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;

		  break;
	    case 2:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "block";
		  document.getElementById("btnLable3").style.display = "none";
		  document.getElementById("btnLable4").style.display = "block";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;
			  
		  break;
	    case 3:  
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);
		
	      document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";
			
		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Rückruf");
			  
		  isFormConRequest = true;
			  
		  break;
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadStep3Content(elementId) {	
  var stepLabel  = document.getElementById("step2Lable").innerText;
  var step3      = document.getElementById("step3Result");
  var url        = '';

  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
	
  if (stepLabel == 'Tarife') {
    // path to "Auftragsbestellung"
    url = "https://neu.brehna.net/auftrag/rates_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'disForward') {
    // path to "Glasfaserhausanschluss"
    url = "https://neu.brehna.net/auftrag/glass_fibre_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'conAS') {
    // path to "Anschlussanfrage"
	url = "https://neu.brehna.net/auftrag/connection_request_customer.php";
  } else {
	// path to "Anschlussanfrage" -- recall
    url      = "https://neu.brehna.net/auftrag/recall.php";
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	if (response) {		
      // remove all children from parent
	  removeChildren(step3);
	  // display form
	  setStepProgressbarLable(step3, response["step3"]);

	  // display 
	  if ("displayTechAddress" in response) {
	    document.getElementById("techAddress").style.display = response["displayTechAddress"];
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

function setChangeBorderColor(divId, newRateId) {
  choosenRateId  = newRateId;
  var tariffDivs = document.getElementsByClassName("row borderBox");
	
  // reset the border to default
  for (i = 0; i < tariffDivs.length; i++) {
    tariffDivs[i].style.border = "1px solid #F0F0F0";
  }

  // set border to active
  document.getElementById(divId).style.border = "3px solid #b8c402";
}

function displayStep2Content(content) {	
  var step = document.getElementById("ratesResult");

  // remove children from parent element
  removeChildren(step);

  // inserts elements inside the element, before its first child
  setStepProgressbarLable(step, content);
}

function removeChildren(parent) {
  while(parent.hasChildNodes()) {
	parent.removeChild(parent.lastChild);
  }
}

function setStepProgressbarLable(parent, child) {
  parent.insertAdjacentHTML('afterbegin', child);
}

function forwardStep3(event, lable = "disForward") {	
  if (validateConRequest()) {
    navigateToFormStep(3);
    loadStep3Content(lable);
  } else {
	event = event || window.event;
    event.preventDefault();
	event.stopPropagation();
  }
	
  return validateConRequest();
}

function backwardStep1() {
  navigateToFormStep(1);
  document.getElementById("asbErrorMsg").style.display = "none";
  resetRequiredFields();
}

function showHideAddress() {	  
  isConAdressChecked = document.getElementById("displayAdressAS").checked;
  document.getElementById("connectionAS").style.display = "none";

  if (isConAdressChecked) {
    document.getElementById("connectionAS").style.display = "block";
  }
}

function displayTechAddress() {
  var isCheckedDiffAddress = document.getElementById("caDiffAddress").checked;
  document.getElementById("techAddress").style.display = "none";
	
  if (isCheckedDiffAddress) {
	document.getElementById("techAddress").style.display = "block";
  }
}