<div id="errorNotConfirm" class="noDisplay">
  <div class="row puffer errorBox">
    <div class="errorBoxContent2">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Eine weitere Bearbeitung Ihres Auftrages kann nur mit Ihrer Zustimmung zum Datenschutz und den AGB erfolgen.
		<br><span class="errorSpanLeft1">Bitte stimmen Sie diesen zu.</span>
    </div>
  </div>
</div>

<div id="contractCondition" class="borderBox">
  <div id="contractConditionMain" class="borderBox">
    <div class="row puffer">
      <div class="col">
	    <span class="spanNewline">
	      <strong>AGB</strong>
	    </span>
	    <br>
	    <span id="pkAgb1" class="spanNewline noDisplay">
	      Die aktuellen AGB haben vorgelegen,
	      wurden gelesen und akzeptiert und 
	      sind jederzeit in Druckform in den
	      Büroräumen in der Max-Planck-Str. 2,
	      06796 Brehna einsehbar.
	    </span>
		
	    <span id="gkAgb1" class="spanNewline noDisplay">
		  Die aktuellen AGB stehen auf
		  www.Brehna.net zum Download zur
		  Verfügung, sowie in Druckform in
		  den Büroräumen in der Max-Planck-
		  Str. 2, 06796 Brehna.
	    </span>
	  
	    <span id="pkAgb2" class="spanNewline noDisplay">
		  <strong>
		    Alle Preise inkl. der aktuell gültigen
		    MwSt.
		  </strong>  
	    </span>
	  
	    <span id="pkAgb3" class="spanNewline noDisplay">
		  <strong>
		    Alle Preise inkl. der aktuell gültigen
		    MwSt. von 19%.
		  </strong>  
	    </span>
		
        <span id="gkAgb2" class="spanNewline noDisplay">
	      <strong>
		    Alle Preise zzgl. MwSt.
	      </strong>
	    </span>
      </div>

      <div class="col">
	    <span class="spanNewline">
	      <strong>Vertragsbedingung</strong>
	    </span>
        <br>
        <span>
		  Der Vertragsbeginn wird rechtswirksam mit Datum des Netzanschlusses,
		  unabhängig vom Datum der getätigten Unterschrift auf dem Vertrag.
	  
		  <span id="pkContractCon1" class="spanNewline">
	        Der Vertrag verlängert sich nach Ablauf der 
	        Mindestvertragsdauer auf unbestimmte Zeit, wenn er 
	        nicht mit einer Frist von vier Wochen zum Ende eines
	        Monats gekündigt wird.
		  </span>
		  
		  <span id="gkContractCon1" class="spanNewline">
		    Der Vertrag verlängert sich automatisch um ein weiteres
		    Jahr, sofern er nicht <b>drei Monate</b> vor Ablauf schriftlich
		    gekündigt wird.
		  </span>
	  
	      Sollte es aus technischen Gründen nicht möglich sein
	      Sie anzuschalten, erhalten Sie eine Mitteilung,
	      sobald die Anschaltung erfolgen kann.
	    </span>
      </div>
	
      <div class="col">
	    <span class="spanNewline">
	      <strong>Widerrufserklärung</strong>
	    </span>
        <br>
        <span>
		  <span id="pkCancel1" class="spanNewline">
	        Sie können Ihre Vertragserklärung innerhalb von <b>zwei</b> 
	        Wochen nach Ihrer Unterzeichnung ohne Angabe von
	        Gründen in Textform (z.B. Brief, Fax) widerrufen.
		  </span>
		  
		  <span id="gkCancel1" class="spanNewline">
		    Sie können Ihre Vertragserklärung innerhalb von <b>zwei</b>
		    Wochen, nach Unterschrift, ohne Angabe von Gründen in
		    Textform (z.B. Brief, Fax) widerrufen.
		  </span>
		
	      Zur Wahrung der Frist genügt der rechtzeitige Eingang
	      des schriftlichen Widerrufs an die Firma Brehna.net,
	      Max-Planck-Str. 2, 06796 Brehna.
	    </span>
      </div>
    </div>
  </div>
	
  <div id="contractConditionFooter" class="borderBox">
	<div class="row puffer">
	  <div class="col">
		<input type="checkbox" id="checkProcessData" name="checkProcessData" value="0">
        <b>Ich stimme der Weiterverarbeitung meiner Daten zu.</b>
		<a href="https://www.brehna.net/datenschutz">[www.brehna.net/datenschutz]</a>
        <br>
		<input type="checkbox" id="checkAGB" name="checkAGB" value="0">
		<b>Ich habe die AGB gelesen und akzeptiere die AGB von Brehna.net.</b>
        <a href="https://brehna.net/agb">[www.brehna.net/agb]</a>
      </div>
	</div>
  </div>
</div>