CREATE TABLE IF NOT EXISTS `tariff_x_tariff_option` (
  `id`               INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tariff_id`        INT(11) UNSIGNED NOT NULL,
  `tariff_option_id` INT(11) UNSIGNED NOT NULL,
  `createDate`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`       CHAR(50)        NOT NULL DEFAULT '',
  `updateDate`       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`       CHAR(50)        NOT NULL DEFAULT '',
  `isDeleted`        TINYINT(1)      NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (tariff_id)        REFERENCES `tariff`(id),
  FOREIGN KEY (tariff_option_id) REFERENCES `tariff_option`(id)
) ENGINE=INNODB;

INSERT INTO `tariff_x_tariff_option` VALUES(null, 1, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 1, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 1, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 1, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 2, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 2, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 2, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 2, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 3, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 3, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 3, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 3, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 4, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 4, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 4, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 4, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 5, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 5, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 5, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 5, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 6, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 6, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 6, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 6, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 7, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 7, 16, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 7, 17, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 7, 18, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 8, 15, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 8, 19, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 8, 20, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 8, 21, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 26, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 23, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 27, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 28, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 29, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 21, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_tariff_option` VALUES(null, 11, 25, NOW(), 'JANINA', NOW(), 'JANINA', 0);