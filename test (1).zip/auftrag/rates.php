<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	require __DIR__ . "/model/asb_availability_queries.php";
    
	$address = array(
	  "street"   => $infos["street"],
	  "hNr"      => $infos["hNr"],
	  "zipcode"  => $infos["zipcode"],
	  "place"    => $infos["place"],
	  "district" => $infos["district"]
	);
	  
	$isNewCon = ($infos["conKind"] == 1)? true : false;
	  
	$asbAvailabilityQueries = new AsbAvailabilityQueries($address, $isNewCon, $infos["selTech"]);
	$tariffs = $asbAvailabilityQueries->getAllTariffByAddress();	  
	$content = '';
	
	$templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company", "mail", "phone", "mobil"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode", "psPlace", "psDistrict")
	);
	  
	$populateValue = array("postalAddress" => $address);
	  
    if (!empty($tariffs) && count($tariffs) > 0) {
	  // items for rate selection
	  require __DIR__ . "/views/rates/tariff.php";
	  $tariffFormHtml = new Tariff($tariffs, $address);
	  $content = array(
		"ident"          => 1,
		"btnStep2"       => "disForward",
		"step2Lable"     => "Tarife",
		"step2"          => $tariffFormHtml->getTemplate(),
		"displayForward" => "none",
		"backBtnStep2"   => "none"
	  );
	} else {
	  if ($infos["selTech"] == 2) {
		// fiberglass application
        require __DIR__ . "/views/glassFibre/glass_fibre.php";
		  
		$templateData["diffAddress"] = 'dAddress';
		$templateData["conAddress"]  = array("coStreet", "coHNr", "coZipcode", "coPlace", "coDistrict");
		
		$glasFibre = new GlassFibre($templateData, $populateValue);
		  
   	    $content = array(
		  "ident"          => 2,
		  "btnStep2FttH"   => "disFttH",
		  "btnStep2Reqs"   => "disRequest",
		  "step2Lable"     => "Ergebnis",
		  "step2"          => $glasFibre->buildDescription(),
		  "displayForward" => "block",
		  "backBtnStep2"   => "block"
		);
	  } else {
		// connection request order
		require __DIR__ . "/views/connectionRequest/connection_request.php";
		  
		$conRequest = new ConnectionRequest($templateData, $populateValue);
		 
        $content = array(
		  "ident"          => 3,
		  "btnStep2"       => "disForward",
		  "step2Lable"     => "Kundendaten",
		  "step2"          => $conRequest->getTemplateStep2(),
		  "displayForward" => "block",
		  "backBtnStep2"   => "block"
		);
	  }
	}
	  
    echo json_encode($content);
  }
?>