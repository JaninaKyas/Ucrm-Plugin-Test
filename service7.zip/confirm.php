<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	
	require_once __DIR__ . "/views/confirm/confirm.php";
	require_once __DIR__ . "/views/confirm/mail_send.php";

	$confirm    = new Confirm($infos);
	$mailSend   = new MailSend($infos);
	  
	$html = "";
	$save = true;

	if ($infos["choosenPath"] == 4 || $infos["choosenSubPath"] == 2) {
	  require_once __DIR__ . "/model/customer_connection_requests_queries.php";
	  $ccrQueries = new CustomerConnectionRequestsQueries();
	  
	  // customer data
	  $salut   = "";
	  $fName   = "";
	  $lName   = "";
	  $company = "";
	  $phone   = "";
	  $mobil   = "";
	  $mail    = "";
	  if (array_key_exists("customer", $infos)) {
		if (array_key_exists("salut", $infos["customer"])) {
		  $salut = $infos["customer"]["salut"];
		}
		
		if (array_key_exists("fName", $infos["customer"])) {
		  $fName = $infos["customer"]["fName"];
		}
		
		if (array_key_exists("lName", $infos["customer"])) {
		  $lName = $infos["customer"]["lName"];
		}
		
		if (array_key_exists("company", $infos["customer"])) {
		  $company = $infos["customer"]["company"];
		}
		
		if (array_key_exists("phone", $infos["customer"])) {
		  $phone = $infos["customer"]["phone"];
		}
		
		if (array_key_exists("mobil", $infos["customer"])) {
		  $mobil = $infos["customer"]["mobil"];
		}
		
		if (array_key_exists("mail", $infos["customer"])) {
		  $mail = $infos["customer"]["mail"];
		}
	  }
	
      // address data	
	  $street   = "";
	  $hNr      = "";
	  $zipcode  = "";
	  $place    = "";
	  $district = "";
	  if (array_key_exists("postalAddress", $infos)) {
		if (array_key_exists("street", $infos["postalAddress"])) {
          $street = $infos["postalAddress"]["street"];
		}
		
		if (array_key_exists("hNr", $infos["postalAddress"])) {
          $hNr = $infos["postalAddress"]["hNr"];
		}
		
		if (array_key_exists("zipcode", $infos["postalAddress"])) {
          $zipcode = $infos["postalAddress"]["zipcode"];
		}
		
		if (array_key_exists("place", $infos["postalAddress"])) {
          $place = $infos["postalAddress"]["place"];
		}
		
		if (array_key_exists("district", $infos["postalAddress"])) {
          $district = $infos["postalAddress"]["district"];
		}
	  }
	  
	  $conKind      =  0;
	  $selTech      =  0;
	  $isWishRecall =  0;
	  $recallTermin = "";
	  if (array_key_exists("conKind", $infos)) {
		$conKind = $infos["conKind"];
	  }

	  if (array_key_exists("selTech", $infos)) {
		$selTech = $infos["selTech"];
	  }
	  
	  if (array_key_exists("recall", $infos)) {
		if (array_key_exists("isWish", $infos)) {
		  $isWishRecall = $infos["recall"]["isWish"];
		}
		
		if (array_key_exists("termin", $infos)) {
		  $recallTermin = $infos["recall"]["termin"];
		}
	  }
	  
	  $rate       = -1;
	  $careTech   = -1;
	  $isPhone    =  0;
	  $isPorting  =  0;
	  $careTermin = "";
	  $message    = "";
	  if (array_key_exists("conRequestRate", $infos)) {
		$rate = $infos["conRequestRate"];
	  }
	  
	  if (array_key_exists("techCare", $infos)) {
		$careTech = $infos["techCare"];
	  }
	  
	  if (array_key_exists("phone", $infos)) {
		$isPhone = $infos["phone"];
	  }

	  if (array_key_exists("porting", $infos)) {
		$isPorting = $infos["porting"];
	  }
	  
	  if (array_key_exists("careTermin1", $infos)) {
		$careTermin = $infos["careTermin1"];
	  }
	  
	  if (array_key_exists("message", $infos)) {
		$message = $infos["message"];
	  }
	  
	  $save = $ccrQueries->saveRequest(
	    $salut, $fName, $lName, $company, $street, $hNr, $zipcode, $place, $district, $phone, $mobil, 
		$mail, $conKind, $selTech, $isWishRecall, $recallTermin, $rate, $careTech, $isPhone, $isPorting, 
		$careTermin, $message
	  );
	  
      if ($save) {
		if ($mailSend->sendMail()) {
		  $html = $confirm->buildConfirmRequest();
		}
	  }	  
	} else if ($infos["choosenPath"] == 1 || $infos["choosenSubPath"] == 1) {
	  require_once __DIR__ . "/model/address_queries.php";
	  require_once __DIR__ . "/model/location_queries.php";
	  require_once __DIR__ . "/model/customer_queries.php";
	  require_once __DIR__ . "/model/house_owner_queries.php";
	  require_once __DIR__ . "/model/debator_queries.php";
	  require_once __DIR__ . "/model/country_queries.php";
	  require_once __DIR__ . "/model/customer_ftth_request_queries.php";

	  $addressQueries             = new AddressQueries();
	  $locationQueries            = new LocationQueries();
      $customerQueries            = new CustomerQueries();
	  $houseOwnerQueries          = new HouseOwnerQueries();
	  $debatorQueries             = new DebatorQueries();
	  $countryQueries             = new CountryQueries();
	  $customerFttHRequestQueries = new CustomerFttHRequestQueries();

	  // save postal address
	  $postalAddressId = -1;
	  $locationId      = -1;
	  $hId             = -1;
	  $hlId            = -1;
	  if (array_key_exists("postalAddress", $infos)) {
	    if ( array_key_exists("street", $infos["postalAddress"])
		  && array_key_exists("hNr", $infos["postalAddress"])
		  && array_key_exists("zipcode", $infos["postalAddress"])
		  && array_key_exists("place", $infos["postalAddress"])
		  && array_key_exists("district", $infos["postalAddress"])) {
		   // get postal address id
		   $hId = $addressQueries->getIdByAddressData(
			 $infos["postalAddress"]["street"],
			 $infos["postalAddress"]["hNr"],
			 $infos["postalAddress"]["zipcode"],
			 $infos["postalAddress"]["place"],
			 $infos["postalAddress"]["district"]
		   );

		   // if no id exists create a new entry and return the newly created id
		   if (empty($hId)) {
			 // get location id 
			 $hlId = $locationQueries->getIdByLocationData(
			   $infos["postalAddress"]["place"],
			   $infos["postalAddress"]["district"]
			 );

			 if (empty($hlId)) {
			   // if no id exists create a new entry and return the newly created id
			   $locationId = $locationQueries->saveLocationData(
				 $infos["postalAddress"]["place"],
			     $infos["postalAddress"]["district"]
			   );
			 } else {
			   $locationId = $hlId[0]["id"];
			 }
			   
			 // if no id exists create a new entry and return the newly created id
			 $postalAddressId = $addressQueries->saveNewAddress(
			   $infos["postalAddress"]["street"],
			   $infos["postalAddress"]["hNr"],
			   $infos["postalAddress"]["zipcode"],
			   $locationId
			 );
		   } else {
			 $postalAddressId = $hId[0]["id"];
		   }
	    }
      }  

	  // save technology address
	  $techAddressId  = $postalAddressId;
	  $techLocationId = $locationId;
	  $htId           = -1;
	  $htlId          = -1;
	  if ( array_key_exists("techAddress", $infos)
		&& array_key_exists("isDiffAddress", $infos["techAddress"])
	    && $infos["techAddress"]["isDiffAddress"]) {
		  if ( array_key_exists("street", $infos["techAddress"])
		    && array_key_exists("hnr", $infos["techAddress"])
		    && array_key_exists("zipcode", $infos["techAddress"])
		    && array_key_exists("place", $infos["techAddress"])
		    && array_key_exists("district", $infos["techAddress"])) {
		    $htId = $addressQueries->getIdByAddressData(
			  $infos["techAddress"]["street"],
			  $infos["techAddress"]["hnr"],
			  $infos["techAddress"]["zipcode"],
			  $infos["techAddress"]["place"],
			  $infos["techAddress"]["district"]
			);
				
			if (empty($htId)) {
			  $htlId = $locationQueries->getIdByLocationData(
				$infos["techAddress"]["place"],
			    $infos["techAddress"]["district"]
			  );

			  if (empty($htlId)) {
			    $techLocationId = $locationQueries->saveLocationData(
				  $infos["techAddress"]["place"],
			      $infos["techAddress"]["district"]
			    );
			  } else {
			   $techLocationId = $htlId[0]["id"];
			  }
				
			  $techAddressId = $addressQueries->saveNewAddress(
			    $infos["techAddress"]["street"],
			    $infos["techAddress"]["hnr"],
			    $infos["techAddress"]["zipcode"],
				$techLocationId
			  );
		    } else {
			  $techAddressId = $htId[0]["id"];
			}
		  }  
	    }

	    // save customer data
		$customerId = -1;
		$hcId       = -1;
		if (array_key_exists("customer", $infos)) {
		  if ( array_key_exists("salut", $infos["customer"])
		    && array_key_exists("fName", $infos["customer"])
		    && array_key_exists("lName", $infos["customer"])
			&& array_key_exists("company", $infos["customer"])
			&& array_key_exists("phone", $infos["customer"])
			&& array_key_exists("mobil", $infos["customer"])
			&& array_key_exists("mail", $infos["customer"])) {
			$hcId = $customerQueries->getIdByCustomerData(
			  $postalAddressId, $techAddressId, '', $infos["customer"]["fName"],
			  $infos["customer"]["lName"], $infos["customer"]["company"], $infos["customer"]["phone"],
			  $infos["customer"]["mobil"], $infos["customer"]["mail"]
		    );
			  
			if (empty($hcId)) {
			  $customerId = $customerQueries->saveCustomerData(
			    $postalAddressId, $techAddressId, '', $infos["customer"]["salut"], '',
				$infos["customer"]["fName"], $infos["customer"]["lName"], $infos["customer"]["company"],
				'1000-01-01', '', '', $infos["customer"]["phone"], $infos["customer"]["mobil"], 
				$infos["customer"]["mail"]
			  );
			} else {
			  $customerId = $hcId[0]["id"];
			}
		  }
		}

		// save sepa data
		$debatorId        = -1;
		$debatorAddressId = -1;
		$debatorLocaId    = -1;
		$debatorCountryId = -1;
		$hdId             = -1;
		$hdaId            = -1;
		$hdlId            = -1;
		if (array_key_exists("sepaData", $infos)) {
		  if ( array_key_exists("name", $infos["sepaData"])
			&& array_key_exists("street", $infos["sepaData"])
			&& array_key_exists("hnr", $infos["sepaData"])
			&& array_key_exists("zipcode", $infos["sepaData"])
			&& array_key_exists("place", $infos["sepaData"])
			&& array_key_exists("district", $infos["sepaData"])
			&& array_key_exists("country", $infos["sepaData"])
			&& array_key_exists("iban", $infos["sepaData"])
			&& array_key_exists("bic", $infos["sepaData"])) {
		    $hdId = $debatorQueries->getIdByDebatorData(
			  $infos["sepaData"]["name"], $infos["sepaData"]["street"], $infos["sepaData"]["hnr"], 
			  $infos["sepaData"]["zipcode"], $infos["sepaData"]["place"], $infos["sepaData"]["district"],
			  $infos["sepaData"]["country"], $infos["sepaData"]["iban"], $infos["sepaData"]["bic"]
			);
			  
			if (empty($hdId)) {
			  // country id
			  $hdcId = $countryQueries->getIdByCountryData($infos["sepaData"]["country"]);
			  $debatorCountryId = $hdcId[0]["id"];
				
			  // address id
			  $hdaId = $addressQueries->getIdByAddressData(
			    $infos["sepaData"]["street"],
			    $infos["sepaData"]["hnr"],
			    $infos["sepaData"]["zipcode"],
			    $infos["sepaData"]["place"],
			    $infos["sepaData"]["district"]
			  );
				
			  if (empty($hdaId)) {
			    $hdlId = $locationQueries->getIdByLocationData(
				  $infos["techAddress"]["place"],
			      $infos["techAddress"]["district"]
			    );
				  
				if (empty($hdlId)) {
				  $debatorLocaId = $locationQueries->saveLocationData(
				    $infos["techAddress"]["place"],
			        $infos["techAddress"]["district"]
			      );
				} else {
				  $debatorLocaId = $hdlId[0]["id"];
				}
				  
				$debatorAddressId = $addressQueries->saveNewAddress(
			      $infos["techAddress"]["street"],
			      $infos["techAddress"]["hnr"],
			      $infos["techAddress"]["zipcode"],
				  $techLocationId
			    );
			  } else {
			    $debatorAddressId = $hdaId[0]["id"];
			  }
				
			  $debatorId = $debatorQueries->saveNewDebator(
			    $debatorAddressId, $debatorCountryId, $infos["sepaData"]["name"],
			    $infos["sepaData"]["iban"], $infos["sepaData"]["bic"]
			  );
			} else {
			  $debatorId = $hdId[0]["id"];
			}
		  }
		}

		// save house owner data
		$houseOwnerId         = -1;
		$houseOwnerAdressId   = -1;
		$houseOwnerFAddressId = -1;
		$houseOwnerLocaId     = -1;
		$houseOwnerFLocaId    = -1;
		$hhoId                = -1;
		$hhoaId               = -1;
		$hhofaId              = -1;
		$hholId               = -1;
		$hhoflId              = -1;
		if (array_key_exists("hoData", $infos)) {
		  if ( array_key_exists("title", $infos["hoData"])
			&& array_key_exists("fName", $infos["hoData"])
			&& array_key_exists("lName", $infos["hoData"])
			&& array_key_exists("company", $infos["hoData"])
			&& array_key_exists("street", $infos["hoData"])
			&& array_key_exists("hnr", $infos["hoData"])
			&& array_key_exists("zipcode", $infos["hoData"])
			&& array_key_exists("place", $infos["hoData"])
			&& array_key_exists("district", $infos["hoData"])
			&& array_key_exists("hrNumber", $infos["hoData"])
			&& array_key_exists("phone", $infos["hoData"])
			&& array_key_exists("mobil", $infos["hoData"])
			&& array_key_exists("mail", $infos["hoData"])
			&& array_key_exists("fFloor", $infos["hoData"])
			&& array_key_exists("fFloorKind", $infos["hoData"])
			&& array_key_exists("fDFloor", $infos["hoData"])
			&& array_key_exists("fStreet", $infos["hoData"])
			&& array_key_exists("fHNr", $infos["hoData"])
			&& array_key_exists("fZipcode", $infos["hoData"])
			&& array_key_exists("fPlace", $infos["hoData"])
			&& array_key_exists("fDistrict", $infos["hoData"])) {
		      $hhoId = $houseOwnerQueries->getIdByHouseOwnerData(
			    $infos["hoData"]["fName"], $infos["hoData"]["lName"], $infos["hoData"]["company"], 
				$infos["hoData"]["street"], $infos["hoData"]["hnr"], $infos["hoData"]["zipcode"], 
				$infos["hoData"]["place"], $infos["hoData"]["district"], $infos["hoData"]["hrNumber"], 
				$infos["hoData"]["phone"], $infos["hoData"]["mobil"], $infos["hoData"]["mail"],
				$infos["hoData"]["fStreet"], $infos["hoData"]["fHNr"], $infos["hoData"]["fZipcode"], 
				$infos["hoData"]["fPlace"], $infos["hoData"]["fDistrict"]
			  );
			  
			  if (empty($hhoId)) {
			    // address
				$hhoaId = $addressQueries->getIdByAddressData(
			      $infos["hoData"]["street"],
			      $infos["hoData"]["hnr"],
			      $infos["hoData"]["zipcode"],
			      $infos["hoData"]["place"],
			      $infos["hoData"]["district"]
			    );
				  
				if (empty($hhoaId)) {
				  $hholId = $locationQueries->getIdByLocationData(
				    $infos["hoData"]["place"],
			        $infos["hoData"]["district"]
			      );
					
				  if (empty($hholId)) {
				    $houseOwnerLocaId = $locationQueries->saveLocationData(
					  $infos["hoData"]["place"],
			          $infos["hoData"]["district"]
					);
				  } else {
				    $houseOwnerLocaId = $hholId[0]["id"];
				  }
					
				  $houseOwnerAdressId = $addressQueries->saveNewAddress(
				    $infos["hoData"]["street"],
			        $infos["hoData"]["hnr"],
			        $infos["hoData"]["zipcode"],
					$houseOwnerLocaId
				  );
				} else {
				  $houseOwnerAdressId = $hhoaId[0]["id"];
				}
				  
				// floor address
				$hhoaId = $addressQueries->getIdByAddressData(
			      $infos["hoData"]["fStreet"],
				  $infos["hoData"]["fHNr"],
				  $infos["hoData"]["fZipcode"],
				  $infos["hoData"]["fPlace"],
				  $infos["hoData"]["fDistrict"]
			    );
				  
				if (empty($hhoaId)) {
				  $hhoflId = $locationQueries->getIdByLocationData(
				    $infos["hoData"]["fPlace"],
				    $infos["hoData"]["fDistrict"]
			      );
					
				  if (empty($hhoflId)) {
				    $houseOwnerFLocaId = $locationQueries->saveLocationData(
					  $infos["hoData"]["fPlace"],
				      $infos["hoData"]["fDistrict"]
					);
				  } else {
				    $houseOwnerFLocaId = $hhoflId[0]["id"];
				  }
					
				  $houseOwnerFAddressId = $addressQueries->saveNewAddress(
				    $infos["hoData"]["fStreet"],
				    $infos["hoData"]["fHNr"],
				    $infos["hoData"]["fZipcode"],
					$houseOwnerFLocaId
				  );
				} else {
				  $houseOwnerFAddressId = $hhoaId[0]["id"];
				}
				  
				$houseOwnerId = $houseOwnerQueries->saveNewHouseOwner(
				  $infos["hoData"]["title"], $infos["hoData"]["fName"], $infos["hoData"]["lName"], 
				  $infos["hoData"]["company"], $houseOwnerAdressId, $houseOwnerFAddressId,
				  $infos["hoData"]["hrNumber"], $infos["hoData"]["fFloor"],
				  $infos["hoData"]["fFloorKind"], $infos["hoData"]["fDFloor"],
				  $infos["hoData"]["mail"], $infos["hoData"]["phone"], $infos["hoData"]["mobil"]
	            );
			  } else {
			    $houseOwnerId = $hhoId[0]["id"];
			  }
		  }
		}
		
		// save customer ftth request data
		if ( array_key_exists("conKind",        $infos)
		  && array_key_exists("selTech",        $infos)
		  && array_key_exists("conPointTyp",    $infos)
		  && array_key_exists("kindConPoint",   $infos["conPointTyp"])
		  && array_key_exists("cntUnits",       $infos["conPointTyp"])
		  && array_key_exists("completionDate", $infos["conPointTyp"])
		  && array_key_exists("introHouse",     $infos)
		  && array_key_exists("ihTyp",          $infos["introHouse"])
		  && array_key_exists("else",           $infos["introHouse"])
		  && array_key_exists("rate",           $infos)
		  && array_key_exists("agb",            $infos)
		  && array_key_exists("safeKeepinData", $infos)) {
		  
		  $mainNum = $infos["sepaData"]["mainNum"];
		  $subNum  = 1;
		  if ($mainNum == 7) {
		    $subNum = $infos["sepaData"]["subNum"];
		  }
			
		  $save = $customerFttHRequestQueries->saveFttHRequestData(
            $customerId, $postalAddressId, $techAddressId, $debatorId, $infos["conKind"], 
			$infos["selTech"], $infos["rate"], $mainNum, $subNum, $infos["conPointTyp"]["kindConPoint"], 
			$infos["conPointTyp"]["cntUnits"], $infos["conPointTyp"]["completionDate"],
            $infos["introHouse"]["ihTyp"], $infos["introHouse"]["else"], $houseOwnerId  
		  );
		}
		
		if ($save) {
		  $html = $confirm->buildConfirmFttH();
		}
	} else if ($infos["choosenPath"] == 2 && $infos["choosenSubPath"] == -1) {
	  require_once __DIR__ . "/model/address_queries.php";
	  require_once __DIR__ . "/model/location_queries.php";
	  require_once __DIR__ . "/model/debator_queries.php";
	  require_once __DIR__ . "/model/country_queries.php";
	  require_once __DIR__ . "/model/customer_queries.php";
		
	  $addressQueries             = new AddressQueries();
	  $locationQueries            = new LocationQueries();
	  $debatorQueries             = new DebatorQueries();
	  $countryQueries             = new CountryQueries();
	  $customerQueries            = new CustomerQueries();
		
	  // save postal address
	  $postalAddressId = -1;
	  $locationId      = -1;
	  $hId             = -1;
	  $hlId            = -1;
	  if (array_key_exists("postalAddress", $infos)) {
	    if ( array_key_exists("street", $infos["postalAddress"])
		  && array_key_exists("hNr", $infos["postalAddress"])
		  && array_key_exists("zipcode", $infos["postalAddress"])
		  && array_key_exists("place", $infos["postalAddress"])
		  && array_key_exists("district", $infos["postalAddress"])) {
		   // get postal address id
		   $hId = $addressQueries->getIdByAddressData(
			 $infos["postalAddress"]["street"],
			 $infos["postalAddress"]["hNr"],
			 $infos["postalAddress"]["zipcode"],
			 $infos["postalAddress"]["place"],
			 $infos["postalAddress"]["district"]
		   );

		   // if no id exists create a new entry and return the newly created id
		   if (empty($hId)) {
			 // get location id 
			 $hlId = $locationQueries->getIdByLocationData(
			   $infos["postalAddress"]["place"],
			   $infos["postalAddress"]["district"]
			 );

			 if (empty($hlId)) {
			   // if no id exists create a new entry and return the newly created id
			   $locationId = $locationQueries->saveLocationData(
				 $infos["postalAddress"]["place"],
			     $infos["postalAddress"]["district"]
			   );
			 } else {
			   $locationId = $hlId[0]["id"];
			 }
			   
			 // if no id exists create a new entry and return the newly created id
			 $postalAddressId = $addressQueries->saveNewAddress(
			   $infos["postalAddress"]["street"],
			   $infos["postalAddress"]["hNr"],
			   $infos["postalAddress"]["zipcode"],
			   $locationId
			 );
		   } else {
			 $postalAddressId = $hId[0]["id"];
		   }
	    }
      }

      // save technology address
	  $techAddressId  = $postalAddressId;
	  $techLocationId = $locationId;
	  $htId           = -1;
	  $htlId          = -1;
	  if ( array_key_exists("techAddress", $infos)
		&& array_key_exists("isDiffAddress", $infos["techAddress"])
	    && $infos["techAddress"]["isDiffAddress"]) {
		  if ( array_key_exists("street", $infos["techAddress"])
		    && array_key_exists("hnr", $infos["techAddress"])
		    && array_key_exists("zipcode", $infos["techAddress"])
		    && array_key_exists("place", $infos["techAddress"])
		    && array_key_exists("district", $infos["techAddress"])) {
		    $htId = $addressQueries->getIdByAddressData(
			  $infos["techAddress"]["street"],
			  $infos["techAddress"]["hnr"],
			  $infos["techAddress"]["zipcode"],
			  $infos["techAddress"]["place"],
			  $infos["techAddress"]["district"]
			);
				
			if (empty($htId)) {
			  $htlId = $locationQueries->getIdByLocationData(
				$infos["techAddress"]["place"],
			    $infos["techAddress"]["district"]
			  );

			  if (empty($htlId)) {
			    $techLocationId = $locationQueries->saveLocationData(
				  $infos["techAddress"]["place"],
			      $infos["techAddress"]["district"]
			    );
			  } else {
			   $techLocationId = $htlId[0]["id"];
			  }
				
			  $techAddressId = $addressQueries->saveNewAddress(
			    $infos["techAddress"]["street"],
			    $infos["techAddress"]["hnr"],
			    $infos["techAddress"]["zipcode"],
				$techLocationId
			  );
		    } else {
			  $techAddressId = $htId[0]["id"];
			}
		  }  
	    }

		// save sepa data
		$debatorId        = -1;
		$debatorAddressId = -1;
		$debatorLocaId    = -1;
		$debatorCountryId = -1;
		$hdId             = -1;
		$hdaId            = -1;
		$hdlId            = -1;
		if (array_key_exists("sepaData", $infos)) {
		  if ( array_key_exists("name", $infos["sepaData"])
			&& array_key_exists("street", $infos["sepaData"])
			&& array_key_exists("hnr", $infos["sepaData"])
			&& array_key_exists("zipcode", $infos["sepaData"])
			&& array_key_exists("place", $infos["sepaData"])
			&& array_key_exists("district", $infos["sepaData"])
			&& array_key_exists("country", $infos["sepaData"])
			&& array_key_exists("iban", $infos["sepaData"])
			&& array_key_exists("bic", $infos["sepaData"])) {
		    $hdId = $debatorQueries->getIdByDebatorData(
			  $infos["sepaData"]["name"], $infos["sepaData"]["street"], $infos["sepaData"]["hnr"], 
			  $infos["sepaData"]["zipcode"], $infos["sepaData"]["place"], $infos["sepaData"]["district"],
			  $infos["sepaData"]["country"], $infos["sepaData"]["iban"], $infos["sepaData"]["bic"]
			);
			  
			if (empty($hdId)) {
			  // country id
			  $hdcId = $countryQueries->getIdByCountryData($infos["sepaData"]["country"]);
			  $debatorCountryId = $hdcId[0]["id"];
				
			  // address id
			  $hdaId = $addressQueries->getIdByAddressData(
			    $infos["sepaData"]["street"],
			    $infos["sepaData"]["hnr"],
			    $infos["sepaData"]["zipcode"],
			    $infos["sepaData"]["place"],
			    $infos["sepaData"]["district"]
			  );
	
			  if (empty($hdaId)) {
			    $hdlId = $locationQueries->getIdByLocationData(
				  $infos["techAddress"]["place"],
			      $infos["techAddress"]["district"]
			    );
				  
				if (empty($hdlId)) {
				  $debatorLocaId = $locationQueries->saveLocationData(
				    $infos["techAddress"]["place"],
			        $infos["techAddress"]["district"]
			      );
				} else {
				  $debatorLocaId = $hdlId[0]["id"];
				}
				  
				$debatorAddressId = $addressQueries->saveNewAddress(
			      $infos["techAddress"]["street"],
			      $infos["techAddress"]["hnr"],
			      $infos["techAddress"]["zipcode"],
				  $techLocationId
			    );
			  } else {
			    $debatorAddressId = $hdaId[0]["id"];
			  }
				
			  $debatorId = $debatorQueries->saveNewDebator(
			    $debatorAddressId, $debatorCountryId, $infos["sepaData"]["name"],
			    $infos["sepaData"]["iban"], $infos["sepaData"]["bic"]
			  );
			} else {
			  $debatorId = $hdId[0]["id"];
			}
		  }
		}
		
	  if ($save) {
	    $html = $confirm->buildConfirmPK();
	  }
	}

	$content = array(
	  "step8content" => $html
	);
	
	echo json_encode($content);
  }
?>