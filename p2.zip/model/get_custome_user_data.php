<?php

declare(strict_types = 1);

class CustomTable {
  private function getQueryWhere(array $searchParams): string {
    $returnValue = 'WHERE';
    
    if (!empty($searchParams['cNr']) && !is_null($searchParams['cNr'])) {
      $returnValue = $returnValue . " ctu.custom_number LIKE '%" . $searchParams['cNr']        . "%' AND"; 
    }
    
    if (!empty($searchParams['fName']) && !is_null($searchParams['fName'])) {
      $returnValue = $returnValue . " ctu.firstname ILIKE '%"     . $searchParams['fName']      . "%' AND"; 
    }
    
    if (!empty($searchParams['lName']) && !is_null($searchParams['lName'])) {
      $returnValue = $returnValue . " ctu.lastname ILIKE '%"      . $searchParams['lName']      . "%' AND"; 
    }
    
    if (!empty($searchParams['company']) && !is_null($searchParams['company'])) {
      $returnValue = $returnValue . " ctu.company ILIKE '%"       . $searchParams['company']    . "%' AND"; 
    }
    
    if (!empty($searchParams['street']) && !is_null($searchParams['street'])) {
      $returnValue = $returnValue . " ctu.street ILIKE '%"        . $searchParams['street']     . "%' AND"; 
    }
    
    if (!empty($searchParams['hNr']) && !is_null($searchParams['hNr'])) {
      $returnValue = $returnValue . " ctu.house_number ILIKE '%"  . $searchParams['hNr']        . "%' AND"; 
    }
    
    if (!empty($searchParams['plz']) && !is_null($searchParams['plz'])) {
      $returnValue = $returnValue . " ctu.postcode LIKE '%"      . $searchParams['plz']        . "%' AND"; 
    }

    if (!empty($searchParams['pId']) && !is_null($searchParams['pId']) && $searchParams['pId'] != "-1") {
      $returnValue = $returnValue . " ctu.place = "              . (int) $searchParams['pId']  . " AND"; 
    }
    
    if (!empty($searchParams['pOtherName']) && !is_null($searchParams['pOtherName'])) {
      $returnValue = $returnValue . " ctu.other_place ILIKE '%"   . $searchParams['pOtherName'] . "%' AND"; 
    }
    
    if (!empty($searchParams['mail']) && !is_null($searchParams['mail'])) {
      $returnValue = $returnValue . " ctu.email ILIKE '%"         . $searchParams['mail']       . "%' AND"; 
    }
    
    if (!empty($searchParams['phone']) && !is_null($searchParams['phone'])) {
      $returnValue = $returnValue . " ctu.phone like '%"         . $searchParams['phone']      . "%' AND"; 
    }
    
    $returnValue = trim(substr($returnValue, 0, -3));
    
    return $returnValue;
  }
  
  function getAllUserByCustomerNumber(PDO $pdo, string $customerNumber, array $searchParams): array {
    $where = $this->getQueryWhere($searchParams);
    
    if (strlen($where) < 6) $where = '';
    
    $query = "SELECT
                ctu.custom_number,
                ctu.firstname,
                ctu.lastname,
                ctu.company,
                ctu.street,
                ctu.house_number,
                ctu.postcode,
                ctu.place,
                CASE
                  WHEN cp.district IS NOT NULL THEN CONCAT (cp.name, ' OT ', cp.district)
                  ELSE cp.name
                END AS place_name,
                ctu.other_place,
                ctu.email,
                ctu.phone
              FROM custom_test_user AS ctu
              JOIN custom_places    AS cp  ON ctu.place = cp.id " .
              $where
              . " ORDER BY ctu.custom_number, ctu.firstname, ctu.lastname";
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
    return ($result !== false) ? $result : [];
  }
}
