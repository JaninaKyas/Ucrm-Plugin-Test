-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 01. Apr 2024 um 20:56
-- Server-Version: 10.4.32-MariaDB
-- PHP-Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `web2027_bnet_db`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `address`
--

CREATE TABLE `address` (
  `id` int(11) UNSIGNED NOT NULL,
  `location_id` int(11) UNSIGNED NOT NULL,
  `street` char(200) NOT NULL DEFAULT '',
  `houseNr` char(5) NOT NULL DEFAULT '',
  `zipcode` char(10) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `asb_availability`
--

CREATE TABLE `asb_availability` (
  `id` int(11) UNSIGNED NOT NULL,
  `address_id` int(11) UNSIGNED NOT NULL,
  `network_node_adress_id` int(11) UNSIGNED NOT NULL,
  `technology_id` int(11) UNSIGNED NOT NULL,
  `down_stream` decimal(10,2) UNSIGNED NOT NULL DEFAULT 0.00,
  `up_stream` decimal(10,2) UNSIGNED NOT NULL DEFAULT 0.00,
  `kvz` char(10) NOT NULL DEFAULT '',
  `onkz` char(10) NOT NULL DEFAULT '',
  `asb` int(11) NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `asb_availability_x_customer`
--

CREATE TABLE `asb_availability_x_customer` (
  `id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) UNSIGNED NOT NULL,
  `asb_availability_id` int(11) UNSIGNED NOT NULL,
  `ext_order_nr` char(11) NOT NULL DEFAULT '',
  `double_wire_nr` char(11) NOT NULL DEFAULT '',
  `switching_nr` char(50) NOT NULL DEFAULT '',
  `line_design_dtag` char(50) NOT NULL DEFAULT '',
  `isConnect` tinyint(1) NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `connection_data_holder`
--

CREATE TABLE `connection_data_holder` (
  `id` int(11) UNSIGNED NOT NULL,
  `address_id` int(11) UNSIGNED NOT NULL,
  `name_company` char(100) NOT NULL DEFAULT '',
  `fName` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contact_person`
--

CREATE TABLE `contact_person` (
  `id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) UNSIGNED NOT NULL,
  `address_id` int(11) UNSIGNED NOT NULL,
  `fName` char(100) NOT NULL DEFAULT '',
  `lName` char(100) NOT NULL DEFAULT '',
  `position` char(100) NOT NULL DEFAULT '',
  `phone` char(20) NOT NULL DEFAULT '',
  `phone2` char(20) NOT NULL DEFAULT '',
  `mobil` char(20) NOT NULL DEFAULT '',
  `eMail` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract`
--

CREATE TABLE `contract` (
  `id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) UNSIGNED NOT NULL,
  `contract_type_id` int(11) UNSIGNED NOT NULL,
  `tariff_id` int(11) UNSIGNED NOT NULL,
  `hardware_id` int(11) UNSIGNED NOT NULL,
  `software_id` int(11) UNSIGNED NOT NULL,
  `service_id` int(11) UNSIGNED NOT NULL,
  `numerically_id` int(11) UNSIGNED NOT NULL,
  `contract_term_id` int(11) UNSIGNED NOT NULL,
  `debator_id` int(11) UNSIGNED NOT NULL,
  `state_id` int(11) UNSIGNED NOT NULL,
  `contractNr` char(50) NOT NULL DEFAULT '',
  `startDate` date NOT NULL DEFAULT '1000-01-01',
  `endDate` date NOT NULL DEFAULT '1000-01-01',
  `desiredDate` date NOT NULL DEFAULT '1000-01-01',
  `onceTotalPrice` decimal(10,2) NOT NULL DEFAULT 0.00,
  `monthlyTotalPrice` decimal(10,2) NOT NULL DEFAULT 0.00,
  `totalPrice` decimal(10,2) NOT NULL DEFAULT 0.00,
  `isConfirmedDataProcess` tinyint(1) NOT NULL DEFAULT 0,
  `isConfirmedAgb` tinyint(1) NOT NULL DEFAULT 0,
  `isConfirmedDataProtection` tinyint(1) NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract_state`
--

CREATE TABLE `contract_state` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `contract_state`
--

INSERT INTO `contract_state` (`id`, `name`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 'neu', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'in Bearbeitung', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'aktiv', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, 'inaktiv', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract_term`
--

CREATE TABLE `contract_term` (
  `id` int(11) UNSIGNED NOT NULL,
  `duration` int(2) UNSIGNED NOT NULL DEFAULT 0,
  `term_option` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `contract_term`
--

INSERT INTO `contract_term` (`id`, `duration`, `term_option`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, 0, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 12, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 24, '(70,00 € Gutschrift Hardware)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 36, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract_type`
--

CREATE TABLE `contract_type` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `contract_type`
--

INSERT INTO `contract_type` (`id`, `name`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 'Vertrag', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'Änderung', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'Vertragsverlängerung', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, '... bitte auswählen ...', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(6, 'Vertrag', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(7, 'Änderung', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(8, 'Vertragsverlängerung', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract_x_provider_change_order`
--

CREATE TABLE `contract_x_provider_change_order` (
  `id` int(11) UNSIGNED NOT NULL,
  `contract_id` int(11) UNSIGNED NOT NULL,
  `change_provider_id` int(11) UNSIGNED NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contract_x_tariff_option`
--

CREATE TABLE `contract_x_tariff_option` (
  `id` int(11) UNSIGNED NOT NULL,
  `contract_id` int(11) UNSIGNED NOT NULL,
  `tariff_option_id` int(11) UNSIGNED NOT NULL,
  `count` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `country`
--

CREATE TABLE `country` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `code` char(5) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `country`
--

INSERT INTO `country` (`id`, `name`, `code`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '', '2024-03-14 21:14:52', 'JANINA', '2024-03-14 21:14:52', 'JANINA', 0),
(2, 'Interne Telefonie', '', '2024-03-14 21:14:52', 'JANINA', '2024-03-14 21:14:52', 'JANINA', 0),
(3, 'Deutschland', 'DE', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(4, 'Afghanistan', 'AFG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(5, 'Ägypten', 'EGY', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(6, 'Albanien', 'ALB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(7, 'Algerien', 'DZA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(8, 'Amerikanisch-Samoa', 'ASM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(9, 'Amerikanische Jungferninseln', 'VIR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(10, 'Andorra', 'AND', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(11, 'Angola', 'AGO', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(12, 'Anguilla', 'AIA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(13, 'Antarktis', 'AQ', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(14, 'Antigua und Barbuda', 'ATG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(15, 'Äquatorialguniea', 'GNQ', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(16, 'Argetinien', 'ARG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(17, 'Armenien', 'ARM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(18, 'Aruba', 'ABW', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(19, 'Ascension', 'AC', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(20, 'Aserbaidschan', 'AZ', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(21, 'Äthopien', 'ETH', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(22, 'Australien', 'AU', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(23, 'Bahamas', 'BHS', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(24, 'Bahrain', 'BHR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(25, 'Bangladesch', 'BGD', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(26, 'Barbados', 'BRB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(27, 'Belgien', 'BEL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(28, 'Belize', 'BLZ', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(29, 'Benin', 'BEN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(30, 'Bermuda', 'BMU', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(31, 'Bhutan', 'BTN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(32, 'Bolivien', 'BOL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(33, 'Bosnien und Herzegowina', 'BIH', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(34, 'Botsuana', 'BWA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(35, 'Brasilien', 'BRA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(36, 'Britische Jungferninseln', 'VGB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(37, 'Brunei', 'BRN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(38, 'Bulgarien', 'BGR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(39, 'Burkina Faso', 'BFA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(40, 'Burundi', 'BDI', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(41, 'Chile', 'CHL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(42, 'China', 'CHN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(43, 'Cook Inseln', 'COK', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(44, 'Costa Rica', 'CRI', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(45, 'Dänemark', 'DNK', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(46, 'Demokratische Republik Kongo', 'COD', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(47, 'Demokratische Volksrepublik Korea', 'PRK', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(48, 'Diego Garcia', 'DG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(49, 'Dominica', 'DMA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(50, 'Dominikanische Republik', 'DOM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(51, 'Dschibuti', 'DJI', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(52, 'Ecuador', 'ECU', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(53, 'El Salvador', 'SLV', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(54, 'Elfenbeinküste', 'CIV', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(55, 'Eritrea', 'ERI', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(56, 'Estland', 'EST', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(57, 'Falkland-Inseln', 'FLK', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(58, 'Färöer', 'FRO', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(59, 'Finnland', 'FIN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(60, 'Frankreich', 'FRA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(61, 'Französich Guyana', 'GF', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(62, 'Französisch Polynesien', 'PYF', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(63, 'Gabun', 'GAB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(64, 'Gambia', 'GMB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(65, 'Georgien', 'GEO', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(66, 'Ghana', 'GHA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(67, 'Gibraltar', 'GIB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(68, 'Grenada', 'GRD', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(69, 'Griechenland', 'GRC', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(70, 'Grönland', 'GRL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(71, 'Großbritanien', 'GBR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(72, 'Nordirland', 'GB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(73, 'Guadeloupe', 'GP', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(74, 'Guam', 'GUM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(75, 'Guatemala', 'GTM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(76, 'Guinea', 'GIN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(77, 'Guniea-Bissau', 'GNB', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(78, 'Guyana', 'GUY', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(79, 'Haiti', 'HTI', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(80, 'Honduras', 'HND', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(81, 'Hongkong', 'HKG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(82, 'Indien', 'IND', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(83, 'Indonesien', 'IDN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(84, 'International', '', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(85, 'Irak', 'IRQ', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(86, 'Irland', 'IRL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(87, 'Islamische Republik Iran', 'IRN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(88, 'Island', 'ISL', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(89, 'Israel', 'ISR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(90, 'Italien', 'ITA', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(91, 'Jamaika', 'JAM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(92, 'Japan', 'JPN', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(93, 'Jordanien', 'JOR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(94, 'Kaimainseln', 'GG', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(95, 'Kambodscha', 'KHM', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(96, 'Kamerun', 'CMR', '2024-03-14 21:14:53', 'JANINA', '2024-03-14 21:14:53', 'JANINA', 0),
(97, 'Kanada', 'CAN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(98, 'Kap Verde', 'CPV', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(99, 'Katar', 'QAT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(100, 'Kenia', 'KEN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(101, 'Kirgisien', 'KGZ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(102, 'Kiribati', 'KIR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(103, 'Kolumbien', 'COL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(104, 'Königreich Saudi-Arabien', 'SAU', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(105, 'Kroatien', 'HRV', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(106, 'Kuba', 'CUB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(107, 'Kuwait', 'KWT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(108, 'Laos', 'LAO', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(109, 'Lesotho', 'LSO', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(110, 'Lettland', 'LVA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(111, 'Libanon', 'LBN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(112, 'Liberia', 'LBR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(113, 'Libyen', 'LBY', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(114, 'Liechtenstein', 'LIE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(115, 'Litauen', 'LTU', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(116, 'Luxemburg', 'LUX', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(117, 'Macao', 'MAC', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(118, 'Madagaskar', 'MDG', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(119, 'Malawi', 'MWI', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(120, 'Malaysia', 'MYS', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(121, 'Malediven', 'MDV', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(122, 'Mali', 'MLI', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(123, 'Malta', 'MLT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(124, 'Marokko', 'MAR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(125, 'Marshallinseln', 'MHL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(126, 'Martinique', 'MTQ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(127, 'Mauretanien', 'MRT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(128, 'Mauritius', 'MUS', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(129, 'Mexiko', 'MEX', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(130, 'Mikronesien', 'FSM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(131, 'Moldawien', 'MDA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(132, 'Monaco', 'MCO', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(133, 'Mongolei', 'MNG', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(134, 'Montenegro', 'MNE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(135, 'Montserrat', 'MSR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(136, 'Mosambik', 'MOZ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(137, 'Myanmar (Burma)', 'MMR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(138, 'Namibia', 'NAM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(139, 'Nauru', 'NRU', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(140, 'Nepal', 'NPL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(141, 'Neu Caledonia', 'NCL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(142, 'Neuseeland', 'NZL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(143, 'Nicaragua', 'NIC', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(144, 'Niederlande', 'NLD', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(145, 'Niederländische Antiellen', 'AN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(146, 'Niger', 'NER', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(147, 'Nigeria', 'NGA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(148, 'Niue', 'NIU', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(149, 'Nördliche Marianen-Inseln', 'MP', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(150, 'Norfolkinseln', 'NFK', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(151, 'Norwegen', 'NOR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(152, 'Oman', 'OMN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(153, 'Ost Timur', 'TLS', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(154, 'Österreich', 'AUT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(155, 'Pakistan', 'PAK', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(156, 'Palästina', 'PSE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(157, 'Palau', 'PLW', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(158, 'Panama', 'PAN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(159, 'Papua-Neiguinea', 'PNG', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(160, 'Paraguay', 'PRY', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(161, 'Peru', 'PER', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(162, 'Philippinen', 'PHL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(163, 'Polen', 'POL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(164, 'Portugal', 'PRT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(165, 'Puerto Rico', 'PRI', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(166, 'Republik Fidschi-Inseln', 'FJ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(167, 'Republik Jemen', 'YEM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(168, 'Republik Kasachstan', 'KAZ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(169, 'Republik Kongo', 'COD', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(170, 'Republik Korea (Südkorea)', 'KOR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(171, 'Republik Mazedonien', 'MKD', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(172, 'Republik Serbien', 'SRB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(173, 'Réunion', 'RE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(174, 'Ruanda', 'RWA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(175, 'Rumänien', 'ROU', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(176, 'Russische Föderation', 'RUS', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(177, 'Saint-Pierre und Miquelon', 'SPM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(178, 'Salomoninseln', 'SLB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(179, 'Sambia', 'ZMB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(180, 'San Marino', 'SMR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(181, 'São Tomé und Príncipe', 'STP', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(182, 'Satellitenverbindung', '', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(183, 'Schweden', 'SWE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(184, 'Schweiz', 'CHE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(185, 'Senegal', 'SEN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(186, 'Seychellen', 'SYC', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(187, 'Sierra Leone', 'SLE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(188, 'Simbabwe', 'ZWE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(189, 'Singapur', 'SGB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(190, 'Sint Maarten', 'SX', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(191, 'Slowakei', 'SVK', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(192, 'Slowenien', 'SVN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(193, 'Somalia', 'SOM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(194, 'Spanien', 'ESP', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(195, 'Sri Lanka', 'LKA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(196, 'St. Helena', 'SH', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(197, 'St. Kitts und Nevis', 'KNA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(198, 'St. Luca', 'LCA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(199, 'St. Vincent und Grenadinen', 'VCT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(200, 'Staat der Vatikanstadt', 'VAT', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(201, 'Südafrika', 'ZAF', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(202, 'Sudan', 'SDN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(203, 'Südsudan', 'SSD', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(204, 'Surinam', 'SUR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(205, 'Swasiland', 'SWZ', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(206, 'Syrien', 'SYR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(207, 'Tadshikistan', 'TJK', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(208, 'Taiwan', 'TWN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(209, 'Tansania', 'TZA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(210, 'Thailand', 'THA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(211, 'Togo', 'TGO', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(212, 'Tokelau', 'TKL', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(213, 'Tonga', 'TON', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(214, 'Trinidad und Tobago', 'TTO', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(215, 'Tschad', 'TCD', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(216, 'Tschechien', 'CZE', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(217, 'Tunesien', 'TUN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(218, 'Turkei', 'TUR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(219, 'Turkmenistan', 'TKM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(220, 'Turks- und Caicosinseln', 'TCA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(221, 'Tuvalu', 'TUV', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(222, 'Uganda', 'UGA', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(223, 'Ukraine', 'UKR', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(224, 'Unabhängiger Staat Samoa', 'WSM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(225, 'Ungarn', 'HUN', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(226, 'Union der Komoren', 'COM', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(227, 'Universal Personal Telecommunications Number (UPTN)', '', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(228, 'Uruguay', 'URY', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(229, 'Uzbekistan', 'UZB', '2024-03-14 21:14:54', 'JANINA', '2024-03-14 21:14:54', 'JANINA', 0),
(230, 'Vanuatu', 'VUT', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(231, 'Venezuela', 'VEN', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(232, 'Vereinigte Arabische Emirate', 'ARE', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(233, 'Vereinigte Staaten von Amerika (USA)', 'USA', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(234, 'Vietnam', 'VNM', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(235, 'Wallis und Futuna Inseln', 'WF', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(236, 'Weißrussland', 'BLR', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(237, 'Zentralafrikanische Republik', 'CAF', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0),
(238, 'Zypern', 'CYP', '2024-03-14 21:14:55', 'JANINA', '2024-03-14 21:14:55', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `customer`
--

CREATE TABLE `customer` (
  `id` int(11) UNSIGNED NOT NULL,
  `postal_adress_id` int(11) UNSIGNED NOT NULL,
  `tech_address_id` int(11) UNSIGNED NOT NULL,
  `legal_form_id` int(11) UNSIGNED NOT NULL,
  `customerNr` char(100) NOT NULL DEFAULT '',
  `fName` char(100) NOT NULL DEFAULT '',
  `lName` char(100) NOT NULL DEFAULT '',
  `company` char(100) NOT NULL DEFAULT '',
  `birthDate` date NOT NULL DEFAULT '1000-01-01',
  `taxNr` char(50) NOT NULL DEFAULT '',
  `appartmentNr` char(50) NOT NULL DEFAULT '',
  `phone` char(20) NOT NULL DEFAULT '',
  `mobil` char(20) NOT NULL DEFAULT '',
  `eMail` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `customer_x_technology`
--

CREATE TABLE `customer_x_technology` (
  `id` int(11) UNSIGNED NOT NULL,
  `customer_id` int(11) UNSIGNED NOT NULL,
  `technology_id` int(11) UNSIGNED NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `debator`
--

CREATE TABLE `debator` (
  `id` int(11) UNSIGNED NOT NULL,
  `address_id` int(11) UNSIGNED NOT NULL,
  `country_id` int(11) UNSIGNED NOT NULL,
  `fName` char(200) NOT NULL DEFAULT '',
  `lName` char(200) NOT NULL DEFAULT '',
  `iban` char(100) NOT NULL DEFAULT '',
  `swift_bc` char(20) NOT NULL DEFAULT '',
  `isPaymentRecurring` tinyint(1) NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `hardware`
--

CREATE TABLE `hardware` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` char(150) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `hardware`
--

INSERT INTO `hardware` (`id`, `name`, `price`, `note`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', 70.00, '(WAN/LAN/WLAN)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 'Brehna.net Standard.Box', 70.00, '(WAN/LAN/WLAN)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'AVM Fritz!Box 7590', 150.00, '(WAN, 4x GLAN, WLAN, VoIP-TK, DECT)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'AVM Fritz!Fon C5/C6', 75.00, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, 'AVM Fritz!Fon C5/C6', 150.00, 'DuoSet', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(6, 'AVM Fritz!Fon C5/C6', 210.00, 'TrioSet', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(7, 'AVM Fritz WLAN Repeater', 90.00, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(8, 'AVM Fritz PowerlineSet', 150.00, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(9, 'Brehna.net Router VoIP', 180.00, '(4x LAN, WLAN, VoIP-TK, ISDN, DECT)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(10, 'AVM Fritz!Box Fon Standard', 100.00, '(4x LAN, WLAN, DECT, Telefonie)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(11, 'Tischtelefon mit grossen Tasten', 75.00, '(Doro/ Gigaset)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(12, 'AVM Fritz Fon C5', 75.00, '(VoIP/ DECT)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(13, 'Amazon Echo Spot', 180.00, 'inkl. Alex Installation und Einweisung', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `legal_form`
--

CREATE TABLE `legal_form` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `shortName` char(10) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `legal_form`
--

INSERT INTO `legal_form` (`id`, `name`, `shortName`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '.... bitte auswählen ...', '', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(2, 'Gesellschaft bürgerlichen Rechts', 'GbR', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(3, 'offene Handelsgesellschaft', 'OHG', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(4, 'Kommanditgesellschaft', 'KG', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(5, 'Gesellschaft mit beschränkter Haftung', 'GmbH', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(6, 'Unternehmergesellschft', 'UG', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(7, 'Aktiengesellschaft', 'AG', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `location`
--

CREATE TABLE `location` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `district` char(150) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Daten für Tabelle `location`
--

INSERT INTO `location` (`id`, `name`, `district`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, '(Anderer)', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'Brehna', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'Kabelsketal', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, 'Landsberg', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(6, 'Landsberg', 'Dammendorf', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(7, 'Landsberg', 'Kneipe', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(8, 'Landsberg', 'Oppin', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(9, 'Landsberg', 'Petersdorf', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(10, 'Landsberg', 'Queis', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(11, 'Petersberg', '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(12, 'Landsberg', 'Brachstedt', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(13, 'Landsberg', 'Hohen', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(14, 'Landsberg', 'Wurp', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(15, 'Sandersdorf-Brehna', 'Glebitzsch', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(16, 'Sandersdorf-Brehna', 'Köckern', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(17, 'Wiedemar', 'Pohritzsch', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(18, 'Zörbig', 'Prussendorf', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(19, 'Zörbig', 'Quetzdölsdorf', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(20, 'Zörbig', 'Rieda', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0),
(21, 'Zörbig', 'Schrenz', '2024-04-01 19:50:37', 'JANINA', '2024-04-01 19:50:37', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `numerically`
--

CREATE TABLE `numerically` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(200) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `numerically`
--

INSERT INTO `numerically` (`id`, `name`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 1),
(2, 'Rechnung monatlich', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 1),
(3, 'Rechnung per Post +1,50 € pro Monat', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'Einzugsermächtigung für Lastschriftverfahren', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, 'Rechnung monatlich im voraus', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 1),
(6, 'einmalig nach Fertigstellung Hausanschluss', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 1),
(7, 'Ratenzahlung nach Vereinbarung', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `phone_numbers`
--

CREATE TABLE `phone_numbers` (
  `id` int(11) UNSIGNED NOT NULL,
  `onkz` char(15) NOT NULL DEFAULT '',
  `phone1` char(25) NOT NULL DEFAULT '',
  `phone2` char(25) NOT NULL DEFAULT '',
  `phone3` char(25) NOT NULL DEFAULT '',
  `phone4` char(25) NOT NULL DEFAULT '',
  `phone5` char(25) NOT NULL DEFAULT '',
  `phone6` char(25) NOT NULL DEFAULT '',
  `phone7` char(25) NOT NULL DEFAULT '',
  `phone8` char(25) NOT NULL DEFAULT '',
  `phone9` char(25) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `provider_change_order`
--

CREATE TABLE `provider_change_order` (
  `id` int(11) UNSIGNED NOT NULL,
  `data_holder_id` int(11) UNSIGNED NOT NULL,
  `phone_nr_id` int(11) UNSIGNED NOT NULL,
  `tele_system_id` int(11) UNSIGNED NOT NULL,
  `currentProvider` char(100) NOT NULL DEFAULT '',
  `executeCancel` tinyint(1) NOT NULL DEFAULT 1,
  `phonePortability` tinyint(1) NOT NULL DEFAULT 1,
  `getAllNr` tinyint(1) NOT NULL DEFAULT 1,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `service`
--

CREATE TABLE `service` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `service`
--

INSERT INTO `service` (`id`, `name`, `price`, `note`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', 0.00, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 'IT-Sicherheitspaket und Updateservice je Endgerät', 9.95, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'Bereitstellungspreis Tarif/Anschluss', 9.95, 'inkl. Techniker für Router/ Telefonie', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(4, 'Bereitstellungspreis Tarif/Anschluss', 75.00, 'inkl. Techniker für Router/ Telefonie', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(5, 'Einrichtung Komfort', 79.00, 'max. 5 Endgeräte, Telefone und IT-Check AVM', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(6, 'Kabel, Anschluss und Installation nach Kundenwunsch', 0.00, '', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(7, 'Einrichtungsentgelt', 100.00, '(inkl. B.net Routerkonfig)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(8, 'Einrichtungspauschale', 100.00, '(TAE/ RJ45 Dose, Kabel & Installation, Einweisung)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `software`
--

CREATE TABLE `software` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` char(100) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `software`
--

INSERT INTO `software` (`id`, `name`, `price`, `note`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', 0.00, '(BSI Zertifiziert bis 25 User, inkl. Service)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(2, 'B.net NextGen UTM-Firewall Appliance', 95.00, '(BSI Zertifiziert bis 25 User, inkl. Service)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0),
(3, 'B.net NextGen UTM-Firewall Appliance', 170.00, '(BSI Zertifiziert bis 50 User, inkl. Service)', '2024-04-01 19:50:36', 'JANINA', '2024-04-01 19:50:36', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tariff`
--

CREATE TABLE `tariff` (
  `id` int(11) UNSIGNED NOT NULL,
  `category_id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` char(100) NOT NULL DEFAULT '',
  `downstream` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `upstream` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `cust_class` smallint(3) UNSIGNED NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tariff`
--

INSERT INTO `tariff` (`id`, `category_id`, `name`, `price`, `note`, `downstream`, `upstream`, `cust_class`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, 1, '... bitte auswählen ...', 0.00, '0', 0, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(2, 1, 'Brehna.net Home Lite', 20.00, '10', 2, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(3, 1, 'Brehna.net Home Standard', 25.00, '25', 5, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(4, 1, 'Brehna.net Home Plus', 35.00, '40', 10, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(5, 1, 'Brehna.net Home Maxx', 45.00, '80', 20, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(6, 1, 'Brehna.net Home 200', 45.00, '200', 100, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(7, 1, 'Brehna.net Home 400', 65.00, '400', 100, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(8, 1, 'Brehna.net Home 1000', 85.00, '1000', 200, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(9, 1, 'Brehna.net Komplett Senior', 19.95, '16', 5, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(10, 1, 'B.net Business Comp. Standard 10', 50.00, '10', 5, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(11, 1, 'B.net Business Comp. Standard MAXX', 60.00, '25', 10, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(12, 1, 'B.net Business Comp. Plus 10', 65.00, '10', 5, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0),
(13, 1, 'B.net Business Comp. Plus MAXX', 75.00, '25', 10, 0, 0, '2024-04-01 19:52:20', 'JANINA', '2024-04-01 19:52:20', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tariff_category`
--

CREATE TABLE `tariff_category` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tariff_category`
--

INSERT INTO `tariff_category` (`id`, `name`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(2, 'Internet', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(3, 'Telefon', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(4, 'TV', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(5, 'Internet & Telefon', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(6, 'Internet & TV', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(7, 'Telefon & TV', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(8, 'Internet & Telefon & TV', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tariff_option`
--

CREATE TABLE `tariff_option` (
  `id` int(11) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT -1,
  `name` char(150) NOT NULL DEFAULT '',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price_sen` decimal(10,2) NOT NULL DEFAULT 0.00,
  `price_gk` decimal(10,2) NOT NULL DEFAULT 0.00,
  `note` char(150) NOT NULL DEFAULT '',
  `downstream` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `upstream` int(5) UNSIGNED NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tariff_option`
--

INSERT INTO `tariff_option` (`id`, `parent_id`, `name`, `price`, `price_sen`, `price_gk`, `note`, `downstream`, `upstream`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(2, 0, '4.95', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(3, 0, '14.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(4, 0, '4.95', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(5, 0, '7.90', 7.90, 9.50, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(6, 0, '19.00', 19.00, 25.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(7, 0, '4.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(8, 0, '4.50', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(9, 0, '0.00', 4.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(10, 0, '0.00', 14.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(11, 0, '20.00', 0.00, 0.00, 0.00, '200', 50, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(12, 0, '40.00', 0.00, 0.00, 0.00, '400', 50, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(13, 0, '80.00', 0.00, 0.00, 0.00, '800', 100, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(14, 0, '12.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(15, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(16, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(17, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(18, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(19, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(20, 1, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(21, 1, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(22, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(23, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(24, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(25, 12, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(26, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(27, 0, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(28, 8, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(29, 2, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(30, 3, '0.00', 0.00, 0.00, 0.00, '0', 0, 0, '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tariff_x_tariff_option`
--

CREATE TABLE `tariff_x_tariff_option` (
  `id` int(11) UNSIGNED NOT NULL,
  `tariff_id` int(11) UNSIGNED NOT NULL,
  `tariff_option_id` int(11) UNSIGNED NOT NULL,
  `count_nr` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tariff_x_technology`
--

CREATE TABLE `tariff_x_technology` (
  `id` int(11) UNSIGNED NOT NULL,
  `tariff_id` int(11) UNSIGNED NOT NULL,
  `technology_id` int(11) UNSIGNED NOT NULL,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `technology`
--

CREATE TABLE `technology` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` char(150) NOT NULL DEFAULT '',
  `shortName` char(10) NOT NULL DEFAULT '',
  `note` char(150) NOT NULL DEFAULT '',
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `technology`
--

INSERT INTO `technology` (`id`, `name`, `shortName`, `note`, `createDate`, `createUser`, `updateDate`, `updateUser`, `isDeleted`) VALUES
(1, '... bitte auswählen ...', '', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(2, 'Glasfaser', 'FttH', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(3, 'Very High Speed Digital Subscriber Line', 'VDSL', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(4, 'Ethernet', 'ETH', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(5, 'Funk', '', '5G LTU', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(6, 'Lichtwellenleiter', 'LWL', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(7, 'Richtfunk Point-to-Point', 'RF PTP', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0),
(8, 'Richtfunk Point-to-Multipoint', 'RF PTMP', '', '2024-04-01 19:52:19', 'JANINA', '2024-04-01 19:52:19', 'JANINA', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `telecommunication_system`
--

CREATE TABLE `telecommunication_system` (
  `id` int(11) UNSIGNED NOT NULL,
  `directDialNr` char(50) NOT NULL DEFAULT '',
  `queryPoint` char(50) NOT NULL DEFAULT '',
  `nrBlockFrom` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `nrBlockTo` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `createDate` datetime NOT NULL DEFAULT current_timestamp(),
  `createUser` char(50) NOT NULL DEFAULT '',
  `updateDate` datetime NOT NULL DEFAULT current_timestamp(),
  `updateUser` char(50) NOT NULL DEFAULT '',
  `isDeleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indizes für die Tabelle `asb_availability`
--
ALTER TABLE `asb_availability`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_id` (`address_id`),
  ADD KEY `network_node_adress_id` (`network_node_adress_id`),
  ADD KEY `technology_id` (`technology_id`);

--
-- Indizes für die Tabelle `asb_availability_x_customer`
--
ALTER TABLE `asb_availability_x_customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indizes für die Tabelle `connection_data_holder`
--
ALTER TABLE `connection_data_holder`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_id` (`address_id`);

--
-- Indizes für die Tabelle `contact_person`
--
ALTER TABLE `contact_person`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `address_id` (`address_id`);

--
-- Indizes für die Tabelle `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `contract_type_id` (`contract_type_id`),
  ADD KEY `tariff_id` (`tariff_id`),
  ADD KEY `hardware_id` (`hardware_id`),
  ADD KEY `software_id` (`software_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `contract_term_id` (`contract_term_id`),
  ADD KEY `debator_id` (`debator_id`),
  ADD KEY `state_id` (`state_id`);

--
-- Indizes für die Tabelle `contract_state`
--
ALTER TABLE `contract_state`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `contract_term`
--
ALTER TABLE `contract_term`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `contract_type`
--
ALTER TABLE `contract_type`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `contract_x_provider_change_order`
--
ALTER TABLE `contract_x_provider_change_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `change_provider_id` (`change_provider_id`);

--
-- Indizes für die Tabelle `contract_x_tariff_option`
--
ALTER TABLE `contract_x_tariff_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contract_id` (`contract_id`),
  ADD KEY `tariff_option_id` (`tariff_option_id`);

--
-- Indizes für die Tabelle `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `postal_adress_id` (`postal_adress_id`),
  ADD KEY `tech_address_id` (`tech_address_id`),
  ADD KEY `legal_form_id` (`legal_form_id`);

--
-- Indizes für die Tabelle `customer_x_technology`
--
ALTER TABLE `customer_x_technology`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `technology_id` (`technology_id`);

--
-- Indizes für die Tabelle `debator`
--
ALTER TABLE `debator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_id` (`address_id`),
  ADD KEY `country_id` (`country_id`);

--
-- Indizes für die Tabelle `hardware`
--
ALTER TABLE `hardware`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `legal_form`
--
ALTER TABLE `legal_form`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `numerically`
--
ALTER TABLE `numerically`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `phone_numbers`
--
ALTER TABLE `phone_numbers`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `provider_change_order`
--
ALTER TABLE `provider_change_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_holder_id` (`data_holder_id`),
  ADD KEY `phone_nr_id` (`phone_nr_id`),
  ADD KEY `tele_system_id` (`tele_system_id`);

--
-- Indizes für die Tabelle `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `software`
--
ALTER TABLE `software`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tariff`
--
ALTER TABLE `tariff`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indizes für die Tabelle `tariff_category`
--
ALTER TABLE `tariff_category`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tariff_option`
--
ALTER TABLE `tariff_option`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tariff_x_tariff_option`
--
ALTER TABLE `tariff_x_tariff_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tariff_id` (`tariff_id`),
  ADD KEY `tariff_option_id` (`tariff_option_id`);

--
-- Indizes für die Tabelle `tariff_x_technology`
--
ALTER TABLE `tariff_x_technology`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tariff_id` (`tariff_id`),
  ADD KEY `technology_id` (`technology_id`);

--
-- Indizes für die Tabelle `technology`
--
ALTER TABLE `technology`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `telecommunication_system`
--
ALTER TABLE `telecommunication_system`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `asb_availability`
--
ALTER TABLE `asb_availability`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `asb_availability_x_customer`
--
ALTER TABLE `asb_availability_x_customer`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `connection_data_holder`
--
ALTER TABLE `connection_data_holder`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `contact_person`
--
ALTER TABLE `contact_person`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `contract_state`
--
ALTER TABLE `contract_state`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `contract_term`
--
ALTER TABLE `contract_term`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT für Tabelle `contract_type`
--
ALTER TABLE `contract_type`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT für Tabelle `contract_x_provider_change_order`
--
ALTER TABLE `contract_x_provider_change_order`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `contract_x_tariff_option`
--
ALTER TABLE `contract_x_tariff_option`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=239;

--
-- AUTO_INCREMENT für Tabelle `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `customer_x_technology`
--
ALTER TABLE `customer_x_technology`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `debator`
--
ALTER TABLE `debator`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `hardware`
--
ALTER TABLE `hardware`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT für Tabelle `legal_form`
--
ALTER TABLE `legal_form`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT für Tabelle `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT für Tabelle `numerically`
--
ALTER TABLE `numerically`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT für Tabelle `phone_numbers`
--
ALTER TABLE `phone_numbers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `provider_change_order`
--
ALTER TABLE `provider_change_order`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT für Tabelle `software`
--
ALTER TABLE `software`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `tariff`
--
ALTER TABLE `tariff`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT für Tabelle `tariff_category`
--
ALTER TABLE `tariff_category`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT für Tabelle `tariff_option`
--
ALTER TABLE `tariff_option`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT für Tabelle `tariff_x_tariff_option`
--
ALTER TABLE `tariff_x_tariff_option`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `tariff_x_technology`
--
ALTER TABLE `tariff_x_technology`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT für Tabelle `technology`
--
ALTER TABLE `technology`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT für Tabelle `telecommunication_system`
--
ALTER TABLE `telecommunication_system`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`id`);

--
-- Constraints der Tabelle `asb_availability`
--
ALTER TABLE `asb_availability`
  ADD CONSTRAINT `asb_availability_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `asb_availability_ibfk_2` FOREIGN KEY (`network_node_adress_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `asb_availability_ibfk_3` FOREIGN KEY (`technology_id`) REFERENCES `technology` (`id`);

--
-- Constraints der Tabelle `asb_availability_x_customer`
--
ALTER TABLE `asb_availability_x_customer`
  ADD CONSTRAINT `asb_availability_x_customer_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`);

--
-- Constraints der Tabelle `connection_data_holder`
--
ALTER TABLE `connection_data_holder`
  ADD CONSTRAINT `connection_data_holder_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);

--
-- Constraints der Tabelle `contact_person`
--
ALTER TABLE `contact_person`
  ADD CONSTRAINT `contact_person_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `contact_person_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);

--
-- Constraints der Tabelle `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `contract_ibfk_2` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_type` (`id`),
  ADD CONSTRAINT `contract_ibfk_3` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  ADD CONSTRAINT `contract_ibfk_4` FOREIGN KEY (`hardware_id`) REFERENCES `hardware` (`id`),
  ADD CONSTRAINT `contract_ibfk_5` FOREIGN KEY (`software_id`) REFERENCES `software` (`id`),
  ADD CONSTRAINT `contract_ibfk_6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`),
  ADD CONSTRAINT `contract_ibfk_7` FOREIGN KEY (`contract_term_id`) REFERENCES `contract_term` (`id`),
  ADD CONSTRAINT `contract_ibfk_8` FOREIGN KEY (`debator_id`) REFERENCES `debator` (`id`),
  ADD CONSTRAINT `contract_ibfk_9` FOREIGN KEY (`state_id`) REFERENCES `contract_state` (`id`);

--
-- Constraints der Tabelle `contract_x_provider_change_order`
--
ALTER TABLE `contract_x_provider_change_order`
  ADD CONSTRAINT `contract_x_provider_change_order_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`),
  ADD CONSTRAINT `contract_x_provider_change_order_ibfk_2` FOREIGN KEY (`change_provider_id`) REFERENCES `provider_change_order` (`id`);

--
-- Constraints der Tabelle `contract_x_tariff_option`
--
ALTER TABLE `contract_x_tariff_option`
  ADD CONSTRAINT `contract_x_tariff_option_ibfk_1` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`),
  ADD CONSTRAINT `contract_x_tariff_option_ibfk_2` FOREIGN KEY (`tariff_option_id`) REFERENCES `tariff_option` (`id`);

--
-- Constraints der Tabelle `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`postal_adress_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `customer_ibfk_2` FOREIGN KEY (`tech_address_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `customer_ibfk_3` FOREIGN KEY (`legal_form_id`) REFERENCES `legal_form` (`id`);

--
-- Constraints der Tabelle `customer_x_technology`
--
ALTER TABLE `customer_x_technology`
  ADD CONSTRAINT `customer_x_technology_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`),
  ADD CONSTRAINT `customer_x_technology_ibfk_2` FOREIGN KEY (`technology_id`) REFERENCES `technology` (`id`);

--
-- Constraints der Tabelle `debator`
--
ALTER TABLE `debator`
  ADD CONSTRAINT `debator_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `debator_ibfk_2` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`);

--
-- Constraints der Tabelle `provider_change_order`
--
ALTER TABLE `provider_change_order`
  ADD CONSTRAINT `provider_change_order_ibfk_1` FOREIGN KEY (`data_holder_id`) REFERENCES `connection_data_holder` (`id`),
  ADD CONSTRAINT `provider_change_order_ibfk_2` FOREIGN KEY (`phone_nr_id`) REFERENCES `phone_numbers` (`id`),
  ADD CONSTRAINT `provider_change_order_ibfk_3` FOREIGN KEY (`tele_system_id`) REFERENCES `telecommunication_system` (`id`);

--
-- Constraints der Tabelle `tariff`
--
ALTER TABLE `tariff`
  ADD CONSTRAINT `tariff_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `tariff_category` (`id`);

--
-- Constraints der Tabelle `tariff_x_tariff_option`
--
ALTER TABLE `tariff_x_tariff_option`
  ADD CONSTRAINT `tariff_x_tariff_option_ibfk_1` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  ADD CONSTRAINT `tariff_x_tariff_option_ibfk_2` FOREIGN KEY (`tariff_option_id`) REFERENCES `tariff_option` (`id`);

--
-- Constraints der Tabelle `tariff_x_technology`
--
ALTER TABLE `tariff_x_technology`
  ADD CONSTRAINT `tariff_x_technology_ibfk_1` FOREIGN KEY (`tariff_id`) REFERENCES `tariff` (`id`),
  ADD CONSTRAINT `tariff_x_technology_ibfk_2` FOREIGN KEY (`technology_id`) REFERENCES `technology` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
