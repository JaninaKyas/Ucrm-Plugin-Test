<?php
  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);
	  
	$address["postalAddress"] = array(
	  "street"   => $infos["street"],
	  "hNr"      => $infos["hNr"],
	  "zipcode"  => $infos["zipcode"],
	  "place"    => $infos["place"],
	  "district" => $infos["district"]
	);
	  
	require __DIR__ . "/views/rates/tariff.php";
	$tariffFormHtml  = new Tariff(array(), $address);

	$content = array(
	  "step3Lable"         => "Kundendaten",
	  "step3"              => $tariffFormHtml->getCustomerTemplate(),
	  "displayTechAddress" => "none"
    );
	  
	echo json_encode($content);
  } 
?>