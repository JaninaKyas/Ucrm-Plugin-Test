<?php

namespace RouterOS\Exceptions;

/**
 * Class QueryException
 *
 * @package RouterOS\Exceptions
 * @since   0.7
 */
class QueryException extends \Exception
{
}
