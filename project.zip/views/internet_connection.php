<div class="borderStyle generally">

<div class="row puffer">
  <div class="col-6">
    <b>Ist der Kunde mit dem Internet verbunden?</b>
  </div>
  <div class="col-2">
    <input type="radio" id="cIConYes" name="cICon" value="cIConYes"> Ja
  </div>
  <div class="col-2">
    <input type="radio" id="cIConNo"  name="cICon" value="cIConNo"> Nein
  </div>
</div>

</div>
