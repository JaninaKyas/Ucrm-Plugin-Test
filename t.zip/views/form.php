<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interferences recording</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <style>      
      .puffer {
        padding: 10px 0 10px 0;
      }
      
      #otherLoca {
        display: none;
      }
      
      body{
        font-family: 'Open Sans', sans-serif;
      }
      #signUpForm {
          max-width: 90%;
          background-color: #ffffff;
          margin: 40px auto;
          padding: 40px;
          box-shadow: 0px 6px 18px rgb(0 0 0 / 9%);
          border-radius: 12px;
      }
      #signUpForm .form-header {
        gap: 5px;
        text-align: center;
        font-size: .9em;
      }
      #signUpForm .form-header .stepIndicator {
        position: relative;
        flex: 1;
        padding-bottom: 30px;
      }
      #signUpForm .form-header .stepIndicator.active {
        font-weight: 600;
      }
      #signUpForm .form-header .stepIndicator.finish {
        font-weight: 600;
        color: #009688;
      }
      #signUpForm .form-header .stepIndicator::before {
        content: "";
        position: absolute;
        left: 50%;
        bottom: 0;
        transform: translateX(-50%);
        z-index: 9;
        width: 20px;
        height: 20px;
        background-color: #d5efed;
        border-radius: 50%;
        border: 3px solid #ecf5f4;
      }
      #signUpForm .form-header .stepIndicator.active::before {
        background-color: #a7ede8;
        border: 3px solid #d5f9f6;
      }
      #signUpForm .form-header .stepIndicator.finish::before {
        background-color: #009688;
        border: 3px solid #b7e1dd;
      }
      #signUpForm .form-header .stepIndicator::after {
        content: "";
        position: absolute;
        left: 50%;
        bottom: 8px;
        width: 100%;
        height: 3px;
        background-color: #f3f3f3;
      }
      #signUpForm .form-header .stepIndicator.active::after {
        background-color: #a7ede8;
      }
      #signUpForm .form-header .stepIndicator.finish::after {
        background-color: #009688;
      }
      #signUpForm .form-header .stepIndicator:last-child:after {
        display: none;
      }
      #signUpForm input {
        padding: 15px 20px;
        width: 100%;
        font-size: 1em;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
      }
      #signUpForm input:focus {
        border: 1px solid #009688;
        outline: 0;
      }
      #signUpForm input.invalid, #signUpForm select.invalid {
        border: 1px solid #ffaba5;
      }
      #signUpForm .step {
        display: none;
      }
      #signUpForm .form-footer{
        overflow:auto;
        gap: 20px;
      }
      #signUpForm .form-footer button{
        background-color: #009688;
        border: 1px solid #009688 !important;
        color: #ffffff;
        border: none;
        padding: 13px 30px;
        font-size: 1em;
        cursor: pointer;
        border-radius: 5px;
        flex: 1;
        margin-top: 5px;
      }
      #signUpForm .form-footer button:hover {
        opacity: 0.8;
      }  
      #signUpForm .form-footer #prevBtn {
        background-color: #fff;
        color: #009688;
      }
      
      #cLocation {
        height: 56px;
      }
      
      #cRowOtherLoca {
        display: none;
      }
    </style>
  </head>
  <body>
    <?php
      if (isset($_POST["search"]) && !empty($_POST['cNr'])) {   
        $customTable = new CustomTable();        
        $userData = $customTable->getAllUserByCustomerNumber($pdo, $_POST['cNr']);
      }

      if (count($userData) > 1) {
        require_once(__DIR__ . '/chooseCustomer.php');
      } else if (count($userData) === 1) {
        require_once(__DIR__ . '/recordingForm.php');
      } else {
        require_once(__DIR__ . '/recordingForm.php');
      }
    ?>
  </body>    
</html>
