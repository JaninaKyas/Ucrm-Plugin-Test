<?php
  declare(strict_types = 1);

  class ConnectionData {
    public $templateData = array();
	public $defaultData  = array();
	  
	public function __construct($newTemplateData, $newDefaultData) {
	  $this->templateData = $newTemplateData;
	  $this->defaultData  = $newDefaultData;
	}
	  
	public function buildConnectionDataTemplate(): string {
	  return '<div class="fontTitle">Anschluss</div>
	    <div class="gfCdBlock">'
	    . $this->buildKindConnectionTemplate()    . '<hr>'
		. $this->buildHouseIntroductionTemplate() . '<hr>'
		. $this->buildChoosenRateTemplate()
		. '</div>';
	}
	  
	private function buildKindConnectionTemplate(): string {
	  $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Typ der Anschlusstelle</label>
		  </div>
        </div>
		  
	    <div class="row puffer left">';
		
	  for ($i = 0; $i < 3; $i++) {
        $returnValue .= '<div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["cptData"][$i]["name"]        . '</span>
		</div>';
	  }
	
	  $returnValue .=  '</div><div class="row puffer left">
	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][3]["id"]   . '">
		  <span>' . $this->defaultData["cptData"][3]["name"]         . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["kindConnection"][1] . '"
				   name="' . $this->templateData["kindConnection"][1] . '"
				   placeholder="Anzahl Wohneinheiten">
		  </span>
		</div>

	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["kindConnection"][0] . '"
				 value="' . $this->defaultData["cptData"][4]["id"]   . '">
		  <span>' . $this->defaultData["cptData"][4]["name"]         . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["kindConnection"][2] . '"
				   name="' . $this->templateData["kindConnection"][2] . '"
				   placeholder="vorraussichtlicher Fertigstellungstermin">
		  </span>
		</div>
      </div>';
		
	  return $returnValue;
	}
	  
	private function buildHouseIntroductionTemplate(): string {
      $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Hauseinführung</label>
		  </div>
        </div>
		
		<div class="row puffer left">';
		
	  for ($i = 0; $i < 2; $i++) {
	    $returnValue .= '<div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["introHouse"][0] . '"
				 value="' . $this->defaultData["hitData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["hitData"][$i]["name"]        . '</span>
		  </div>';
	  }
		
	  $returnValue .=  '</div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <input type="radio"
		         name="'  . $this->templateData["introHouse"][0]   . '"
				 value="' . $this->defaultData["hitData"][2]["id"] . '">
		  <span>' . $this->defaultData["hitData"][2]["name"]       . '</span>
		</div>
	  
	    <div class="col">
          <input type="radio"
		         name="'  . $this->templateData["introHouse"][0]   . '"
				 value="' . $this->defaultData["hitData"][3]["id"] . '">
		  <span>' . $this->defaultData["hitData"][3]["name"]       . '</span>
		  <span class="top1">
		    <input type="text"
			       id="'   . $this->templateData["introHouse"][1] . '"
				   name="' . $this->templateData["introHouse"][1] . '">
		  </span>
		</div>
	  </div>';
		
	  return $returnValue;
	}
	  
	private function buildDesignatedHouseConnectionTemplate(): string {
      $returnValue = '<div class="row puffer">
          <div class="col">
		    <label class="addressLabel">Beauftragter Hausanschluss</label>
		  </div>
        </div>
		
		<div class="row puffer left">
		  <div class="col">';
		
	 for ($i = 0; $i < 4; $i++) {
	   if ($i > 0) {
	     $returnValue .= '<br>';
	   }
		 
	   $returnValue .= '<input type="radio"
		        name="'  . $this->templateData["designConHouse"][0] . '"
			    value="' . $this->defaultData["chtData"][$i]["id"]  . '">
		 <span>' . $this->defaultData["chtData"][$i]["name"]        . '</span>
		 <br>
		 <span class="smFont">(' . $this->defaultData["chtData"][$i]["note"] . ')</span>';
		 
		 if ($i <= 2) {
		   $returnValue .= '<br>';
		 }
	 }
	
	 $returnValue .= '</div><div class="col price">';
		
	 for ($i = 0; $i < 4; $i++) {
	   if ($i > 0) {
	     $returnValue .= '<br>';
	   }
		 
	   $returnValue .= '<span>'
	     . number_format(floatval($this->defaultData["chtData"][$i]["price"]), 2, ',', ' ')
		 . ' €</span><br>';
		 
	   if ($i <= 2) {
		 $returnValue .= '<br>';
	   }
	 }
		
	 $returnValue .= '</div></div>
	 
		<div class="row puffer left">
		  <div class="col">';
	  
	  for ($i = 4; $i < 7; $i++) {
	    if ($i > 4) {
	      $returnValue .= '<br>';
	    }
		  
	    $returnValue .= '<input type="radio"
		         name="'  . $this->templateData["designConHouse"][0] . '"
		 	     value="' . $this->defaultData["chtData"][$i]["id"]  . '">
		  <span>' . $this->defaultData["chtData"][$i]["name"]        . '</span>';
		
		if (!empty($this->defaultData["chtData"][$i]["note"])) {
		  $returnValue .= '<br><span class="smFont">('
		    . $this->defaultData["chtData"][$i]["note"] . ')</span>';
		}
		
		$j = $i - 3;
		$returnValue .= '<br>
		<input type="text"
		       id="' .   $this->templateData["designConHouse"][$j] . '"
			   name="' . $this->templateData["designConHouse"][$j] . '">';
	  }
		
	  $returnValue .= '</div><div class="col price">';
		
	  for ($i = 4; $i < 6; $i++) {
	    if ($i > 4) {
	      $returnValue .= '<br>';
	    }
		  
		if ($i === 5) {
		  $returnValue .= '<br><br>';   
		}
		  
        $returnValue .= '<span>'
	      . number_format(floatval($this->defaultData["chtData"][$i]["price"]), 2, ',', ' ')
		  . ' €</span><br>';
		  
	    if ($i < 6) {
		  $returnValue .= '<br>';
	    }
	  }
		
	  $returnValue .= '</div></div>';
		
	  return $returnValue;
	}
	  
	public function buildSeveralHomeownersConsent($address, $customer): string {
	  return '
	  <div class="row puffer">
	    <div class="col">
		  <label class="addressLabel">Grundstückseigentümererklärung</label>
		</div>
	  </div>
	  
	  <div id="shcBlock" class="borderBoxSub">
	    <div class="row puffer left">
	      <div class="col">
		    Der / des / vertreten durch
		    <br><br>
		    Eigentümer / Eigentümerin Verwaltung
		  </div>
	    </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Titel
		  <input type="text" id="chTitle" name="chTitle">
		</div>

		<div class="col">
		  Vorname*
		  <input type="text" id="chFName" name="chFName" class="requiredGE" value="' . $customer["fName"] . '">
		</div>
		
		<div class="col">
		  Nachname*
		  <input type="text" id="chLName" name="chLName" class="requiredGE" value="' . $customer["lName"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  Firma
		  <input type="text" id="chCompany" name="chCompany" value="' . $customer["company"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  Strasse*
		  <input type="text" id="chStreet" name="chStreet" class="requiredGE" value="' . $address["street"] . '">
		</div>
		
        <div class="col">
		  Hausnummer*
		  <input type="text" id="chHNr" name="chHNr" class="requiredGE" value="' . $address["hNr"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  PLZ*
		  <input type="text" id="chZipcode" name="chZipcode" class="requiredGE" value="' . $address["zipcode"] . '">
		</div>
		
        <div class="col">
		  Ort*
		  <input type="text" id="chPlace" name="chPlace" class="requiredGE" value="' . $address["place"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  Ortsteil
		  <input type="text" id="chDistrict" name="chDistrict" value="' . $address["district"] . '">
		</div>
	  </div>
		
	  <div class="row puffer left">
        <div class="col">
		  HR-Nummer (falls vorhanden)
		  <input type="text" id="chHRNr" name="chHRNr">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  Telefon*
		  <input type="text" id="chPhone" name="chPhone" class="requiredGE" value="' . $customer["phone"] . '">
		</div>
		
        <div class="col">
		  Mobil*
		  <input type="text" id="chMobil" name="chMobil" class="requiredGE" value="' . $customer["mobil"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
        <div class="col">
		  E-Mail*
		  <input type="text" id="chMail" name="chMail" class="requiredGE" value="' . $customer["mail"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer right">
	    <div class="col">Nachfolgend <strong>Eigentümer / Eigentümerin</strong></div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  gegenüber der
		  <br><br>
		  Brehna.net<br>
		  Max-Planck-Straße 2<br>
		  06796 Brehna
		</div>
	  </div>
	  
	  <div class="row puffer right">
	    <div class="col">Nachfolgend <strong>Netzbetreiber</strong> genannt</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Der Eigentümer / die Eigentümerin ist damit einverstanden, dass der Netzbetreiber auf seinem / ihrem Grundstück
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Flur
		  <input type="text" id="chFloor" name="chFloor">
		</div>

		<div class="col">
		  Flurstück
		  <input type="text" id="chFloorKind" name="chFloorKind">
		</div>

		<div class="col">
		  Gemarkung
		  <input type="text" id="chFloorDistrict" name="chFloorDistrict">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Strasse*
		  <input type="text" id="chFloorStreet" name="chFloorStreet" class="requiredGE" value="' . $address["street"] . '">
		</div>

		<div class="col">
		  Hausnummer*
		  <input type="text" id="chFloorHNR" name="chFloorHNR" class="requiredGE" value="' . $address["hNr"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  PLZ*
		  <input type="text" id="chFloorZipcode" name="chFloorZipcode" class="requiredGE" value="' . $address["zipcode"] . '">
		</div>

		<div class="col">
		  Ort*
		  <input type="text" id="chFloorPlace" name="chFloorPlace" class="requiredGE" value="' . $address["place"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Ortsteil
		  <input type="text" id="chFlDistrict" name="chFlDistrict" value="' . $address["district"] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  sowie an und in den darauf befindlichen Gebäuden alle die Vorrichtungen anbringt, die  
		  erforderlich sind, um Zugänge zu seinem öffentlichen Telekommunikationsnetz auf dem 
		  betreffenden oder einem benachbarten Grundstück und in den darauf befindlichen Gebäuden 
		  einzurichten, zu prüfen und instand zu halten. Dieses Recht erstreckt sich auch auf 
		  vorinstallierte Hausverkabelungen. Die Inanspruchnahme de sGrundstücks durch Vorrichtungen darf 
		  nur zu einer notwendigen und zumutbaren Belastung führen.
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col-sm-2">1.</div>

		<div class="col">
          Zudem ist der Eigentümer / die Eigentümerin damit einverstanden, dass die nötigen Arbeiten für
          die Glasfaserverlegung bis zur Wohneinheit erforderlich sind, durchgeführt werden können. Diese
          Arbeiten beziehen sich auf die Sicherstellung des Wohnungsanschlusses durch Nutzung bereits
          bestehender Kabeltrassen, stillgelegter Kaminschächte oder ähnlichen bestehenden baulichen
          Vorrichtungen.
		  <br>
          <i>
		    Falls eine Bestellung der Netzes einen/eine Mieter/Mieterin erfolgt, welcher/welche nicht
            Eigentümer/Eigentümerin des oben aufgeführten Grundstückes ist, willigt der/die
            Eigentümer/Eigentümerin unter den in Punkt 1 aufgeführten Arbeiten ein
		  </i>
		</div>
	  </div>
	  
      <div class="row puffer left">
	    <div class="col-sm-2">2.</div>
		
		<div class="col">
          Mit Unterzeichnung dieser Grundstückseigentümererklärung erwirbt der Eigentümer / die 
          Eigentümerin keinen Anspruch auf Errichtung des Glasfasernetzes. Die Errichtung unterliegt 
		  einer Wirtschaftlichkeitsbetrachtung des Netzbetreibers.
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col-sm-2">3.</div>
		
		<div class="col">
		  Wenn infolge dieser Vorrichtungen das Grundstück und/oder die darauf befindlichen Gebäude 
          beschädigt werden, ist der Netzbetreiber verpflichtet, die beschädigten Teile des Grundstücks 
          und/oder der Gebäude wieder ordnungsgemäß instand zu setzen. Die vom Netzbetreiber 
          errichteten Vorrichtungen müssen verlegt oder – soweit sie nicht das Grundstück selbst 
		  versorgen und eine Verlegung nicht ausreicht – entfernt werden, wenn sie einer veränderten 
		  Nutzung des Grundstücks entgegenstehen und ihr Verbleiben an der bisherigen Stelle nicht mehr 
		  zumutbar ist. Die Kosten für die Verlegung oder Entfernung trägt der Netzbetreiber. Dies gilt 
		  nicht für Vorrichtungen, die ausschließlich das Grundstück versorgen, es sei denn, es sind 
		  gleichzeitig Änderungen am Glasfasernetz erforderlich.
		</div>
	  </div>
	  
      <div class="row puffer left">
	    <div class="col-sm-2">4.</div>
		
		<div class="col">
		  Die Erklärung gilt auf unbestimmte Zeit und kann nur aus wichtigem Grund zurückgezogen 
          werden.
		</div>
	  </div>
	  
      <div class="row puffer left">
	    <div class="col-sm-2">5.</div>
		
		<div class="col">
		  Der Eigentümer / die Eigentümerin erklärt sich insbesondere damit einverstanden, dass ihre 
          Kontaktdaten an die des Netzbetreibers bevollmächtigten Unternehmen und ggf. an weitere 
          Subunternehmer weitergegeben, die mit der Errichtung und/oder dem Betrieb der 
          Baumaßnahme betraut werden, um in Ihrem Interesse einerseits eine reibungslose 
          Bauausführung und andererseits einen störungsfreien Betrieb zu ermöglichen. Die betroffenen 
          Unternehmen werden auf die Einhaltung der geltenden Datenschutzbestimmungen (BDSG) 
          verpflichtet.
		</div>
	  </div>';
	}
	
	private function buildChoosenRateTemplate(): string {
	  $returnValue = '<div class="row puffer left">
	    <div class="col">
		  <strong>Welchen Tarif suchen Sie?</strong>
		</div>
		
		<div class="col">
		  <select id="ftthRateSel" name="ftthRateSel">';
		  
		if (array_key_exists("rates", $this->defaultData)) {
		  for ($i=0;$i < count($this->defaultData["rates"]); $i++) {
		    $returnValue .= '<option value="' . $this->defaultData["rates"][$i]["rateId"] . '">' . $this->defaultData["rates"][$i]["rate"] . '</option>';	
		  }
		}
		
		$returnValue .= '  
		  </select>
		</div>
	  </div>';
	  
	  return $returnValue;
	}
  }
?>