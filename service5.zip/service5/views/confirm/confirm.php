<?php
  declare(strict_types = 1);
  
  class Confirm {
    public $data = array();
	
	public function __construct($newData) {
	  $this->data = $newData;
	}
	
	public function buildConfirmRequest(): string {
	  return '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Bestätigung der Anschluss - Anfrage</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <span>Vielen Dank für Ihre <strong>Anschluss-Anfrage</strong>.</span>
			<br><br>
			Wir haben Ihre Nachricht erhalten und werden uns so schnell wie möglich mit Ihnen in Verbindung
			setzen.
			<br><br>
			In der Zwischenzeit können Sie unsere Website <a></a> besuchen, um mehr über unsere Produkte und
			Dienstleistungen zu erfahren.
			<br><br>
			Sollten Sie Fragen haben, zögern Sie bitte nicht, uns zu kontaktieren.
			<br><br>
			Mit freundlichen Grüßen
			<br><br>
			Project66 IT Service & Design / Brehna.net
			<br>
			Max-Planck-Str. 2
			<br>
			06796 Brehna
		  </div>
		</div>
	  ';
	}
  }
?>