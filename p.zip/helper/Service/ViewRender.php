<?php

declare(strict_types=1);

class ViewRender {
  public function render(string $__view, array $__params): void {
    foreach($__params as $__name => $__value) {
      ${$__name} = $__value;
    }
    
    require $__view;
  }
}
