<?php
    if (isset($_POST["search"]) && !empty($_POST["searchTxt"])) {
      $searchParams = explode(",", $_POST["searchTxt"]);
      
      if (count($searchParams) == 1) {
        $customTable = new CustomTable2();
        $users = $customTable->getAllUserBySearchParam($pdo, $_POST["searchTxt"]);
      } else {
        $customTable = new CustomTable();
        $users = $customTable->getAllUserBySearchParam($pdo, $searchParams);
      }    
      
      if (count($users) == 1) {
        $user = $users[0];
      } 
    }

    if (isset($_POST) && array_key_exists("loadUser", $_POST)) {
      $user = json_decode($_POST["loadUser"], true);
    } 

    if (isset($_POST["search"]) && empty($users)) {
      require(__DIR__ . '/display_empty_message.php');
    }
?>

<?php  
  if (empty($user) && (empty($users) || count($users) > 1)) { 
?>
<div class="row">
  <div class="col-10">
    <input type="text" class="form-control" id="searchTxt" name="searchTxt" 
    placeholder="Kundennr.,Vorname,Nachname,Firma,Strasse,Hsnr.,PLZ,Ort,OT"
    value="<?php if (isset($_POST) && array_key_exists("searchTxt", $_POST)) { echo $_POST["searchTxt"]; } ?>"
    onchange="enDisableSearchButton()" 
    onkeyup="enDisableSearchButton()">                
  </div>
  <div class="col-auto">
    <button class="btn btn-primary btn-md" type="submit" id="search" name="search" value="search" disabled>Suche</button>
  </div>
</div>
<?php } ?>

<?php
    if (count($users) > 1) {
      require(__DIR__ . '/result.php');
    } else if (!empty($user)) {    
      require(__DIR__ . '/recording_process_failure.php');
    }
?>
<script>
  function enDisableSearchButton() {
    var value = document.getElementById("searchTxt").value;
    var isBtnDisabled = true;
    
    if (value.length >= 3) {
      isBtnDisabled = false;
    }
    
    document.getElementById('search').disabled = isBtnDisabled;
  }
</script>
