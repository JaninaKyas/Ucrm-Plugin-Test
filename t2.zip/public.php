<?php

declare(strict_types=1);

use Ubnt\UcrmPluginSdk\Service\UcrmSecurity;

chdir(__DIR__);

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/helper/Service/ViewRender.php';
require __DIR__ . '/helper/Service/Http.php';

$security = UcrmSecurity::create();
$user = $security->getUser();

if (!$user || $user->isClient) {
  $http = new Http();
  $http->forbidden();
}

$result = [
  'test' => 'test1',
];

$renderer = new ViewRender();
$renderer->render(
  __DIR__ . '/views/search.php',
  [
    'result' => $result ?? [],
  ]
);

/*

echo '
<!DOCTYPE html>
<html>
<br>
<br>
<br>
<h4>TEST DATABASE WITH OWN VALUES</h4>
</html>
';

// get data from uisp database without ucrm api -- need for custom values, changes, attributtes, ...
$pdo = require PROJECT_PATH . '/model/connect_db.php';
$query = 'SELECT id, test_name FROM custom_table';
$stmt  = $pdo->prepare($query);
$stmt->execute(); 
$result = $stmt->fetch(PDO::FETCH_ASSOC);
print_r($result);
*/

?>
