<button type="button" class="btn btn-primary col-12" id="loadDataWin" name="loadDataWin" value="loadDataWin">Lade Daten aus WinBox</button>

<br><br>

<div class="row puffer">
  <div class="col">
    <label for="down" class="form-label">Download (Mbps)</label>
    <input type="text" class="form-control" id="down" name="down" placeholder="Download"
    value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
  <div class="col">
    <label for="up" class="form-label">Upload (Mbps)</label>
    <input type="text" class="form-control" id="up" name="up" placeholder="Upload"
    value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="up" class="form-label">Laufzeit Server (Stunden)</label>
    <input type="text" class="form-control" id="duration" name="duration" 
    placeholder="Laufzeit Server" value="">    
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ping (ms)</b>
  </div>
  <div class="col">
    <input type="text" class="form-control" id="pingDown" name="pingDown"
    placeholder="Download" value="">
  </div>
  <div class="col">
    <input type="text" class="form-control" id="pingUp" name="pingUp"
    placeholder="Upload" value="">
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ist CPE vorhanden?</b>
  </div>
  <div class="col">
    <input type="radio" id="cpeYes" name="cpe1" value="cpeYes"> Ja
  </div>
  <div class="col">
    <input type="radio" id="cpeNo"  name="cpe1" value="cpeNo"> Nein
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ist CPE des Routers vorhanden?</b>
  </div>
  <div class="col">
    <input type="radio" id="cpeRYes" name="cpe2" value="cpeRYes"> Ja
  </div>
  <div class="col">
    <input type="radio" id="cpeRNo"  name="cpe2" value="cpeRNo"> Nein
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ist der DSL-Sync vorhanden?</b>
  </div>
  <div class="col">
    <input type="radio" id="dslSyncYes" name="dslSync" value="dslSyncYes"> Ja
  </div>
  <div class="col">
    <input type="radio" id="dslSyncNo"  name="dslSync" value="dslSyncNo"> Nein
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ist der Kunde mit dem Internet verbunden?</b>
  </div>
  <div class="col">
    <input type="radio" id="cIConYes" name="cICon" value="cIConYes"> Ja
  </div>
  <div class="col">
    <input type="radio" id="cIConNo"  name="cICon" value="cIConNo"> Nein
  </div>
</div>
