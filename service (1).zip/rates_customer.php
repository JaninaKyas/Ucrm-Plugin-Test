<?php
  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);
	  
	$address["postalAddress"] = array(
	  "street"   => $infos["street"],
	  "hNr"      => $infos["hNr"],
	  "zipcode"  => $infos["zipcode"],
	  "place"    => $infos["place"],
	  "district" => $infos["district"]
	);
	  
	require __DIR__ . "/views/rates/tariff.php";
	$tariffFormHtml  = new Tariff(array(), $address, $infos["technologyAddress"]);

	$displayTechAddress  = "none";
	$setCheckTechAddress = false;
	if (!empty($infos["technologyAddress"])) {
	  $displayTechAddress  = "block";
	  $setCheckTechAddress = true;
	}
	  
	$content = array(
	  "step3Lable"         => "Kundendaten",
	  "step3"              => $tariffFormHtml->getCustomerTemplate(),
	  "sameTechAddress"    => $isSameTechAddress,
	  "displayTechAddress" => $displayTechAddress,
	  "checkTechAddress"   => $setCheckTechAddress
    );
	  
	echo json_encode($content);
  } 
?>