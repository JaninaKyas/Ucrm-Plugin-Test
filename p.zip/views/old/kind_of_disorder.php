<b>Was von dem Anschluss ist durch die Störung betroffen?</b>
<ul class="list-group">
  <li class="list-group-item">
    <input type="radio" id="complete" name="iKind" value="Komplettausfall" 
    onclick="setDisplayPhoneSubMenu(false, 1)">
    <label for="complete">Komplettausfall</label>
  </li>
  <li class="list-group-item">
    <input type="radio" id="phone1" name="iKind" value="Telefon"
    onclick="setDisplayPhoneSubMenu(true, 2)">
    <label for="phone1">Telefon</label>
    <span id="phoneSub">
      <ul class="list-group">
        <li class="list-group-item">
          <input type="radio" id="phone-total" name="phone1" value="Komplettausfall"
          onclick="setDisplayPhoneSubMenu(true, 3)">
          <label for="phone-total">Komplettausfall</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="phone-Interference" name="phone1" value="Leistungsstörung"
          onclick="setDisplayPhoneSubMenu(true, 4)">
          <label for="phone-Interference">Leistungsstörung</label>
        </li>
      </ul> 
    </span>   
  </li>
  <li class="list-group-item">
    <input type="radio" id="internet" name="iKind" value="Internet" onclick="setDisplayPhoneSubMenu(false, 5)">
    <label for="internet">Internet</label>    
  </li>
  <li class="list-group-item">
    <input type="radio" id="tv" name="iKind" value="TV" onclick="setDisplayPhoneSubMenu(false, 6)">
    <label for="tv">TV</label>
    Bildanzeige
    Bildschirmauflösung    
    Mediathek
    Soundsystem
  </li>
</ul>

<div id="descDiv" class="form-group">
  <label for="description"><b>Fehlerbeschreibung aus Kundensicht</b></label>
  <textarea class="form-control" id="description" name="description" value="" rows="7"></textarea>
</div>

<script>

</script>
