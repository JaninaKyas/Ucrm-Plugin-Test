<?php
  declare(strict_types = 1);

  require __DIR__ . "/forms/porting_phone_number.php";

  class PrivateCustomerOptions {
	public $templateData   = array();
	public $customerData   = array();
	public $optionsValues  = array();
	public $optionTV       = array();
	public $optionFee      = array();
	public $optionsService = array();
	public $optionsHw      = array();
	public $optionAddHw    = array();
	public $addressData    = array();
	public $optionsString  = '';
  
	public function __construct($newTemplateData, $newCustomerData, $newOptionsValues, $newOptionsString, $newTvOption, $newOptionFee, $newOptionService, $newOptionsHw, $newAddHardwareOptions, $newAddress) {
	  $this->templateData   = $newTemplateData;
	  $this->customerData   = $newCustomerData;
	  $this->optionsValues  = $newOptionsValues;
	  $this->optionTV       = $newTvOption;
	  $this->optionFee      = $newOptionFee;
      $this->optionsService = $newOptionService;
	  $this->optionsHw      = $newOptionsHw;
	  $this->optionAddHw    = $newAddHardwareOptions;
	  $this->addressData    = $newAddress;
	  $this->optionsString  = $newOptionsString;
	}
	
	public function buildOptionsPKTemplate(): string {
	  return '<div class="fontTitle">Optionen</div>
	    <div class="rateOptionsBlock">'
        . $this->buildIPAddressChoiceTemplate() . '<hr>'
		. $this->buildPhoneDefaultTemplate()    . '<hr>'
		. $this->buildTVOptionTemplate()
		. $this->buildFeeOptionTemplate()
		. $this->buildServiceTemplate()
		. $this->buildHardwareOptionTemplate()
		. '</div>';
	}
	  
	private function buildIPAddressChoiceTemplate(): string {
	  return '<div class="row puffer">
            <div class="col">
			  <label class="addressLabel">
			    Wählen Sie für Ihre IP-Adresse eine zusätzliche Option aus:
			  </label>
			</div>
          </div>
		  
		  <div class="row left">
		    <div class="col">
              <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][0] . '"
					 name="' . $this->templateData["ipAddress"][0] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[0]['id'] . '">
			  <span>' . $this->optionsValues[0]['name'] . '</span>
			  <br>
			  <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][1] . '"
					 name="' . $this->templateData["ipAddress"][1] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[1]['id'] . '">
			  <span>' . $this->optionsValues[1]['name'] . '</span>
			</div>
			
			<div class="col price">
			  <span>'
		      . number_format(floatval($this->optionsValues[0]['price']), 2, ',', ' ')
		      . ' € pro Monat</span>
			  <br>
              <span>'
		      . number_format(floatval($this->optionsValues[1]['price']), 2, ',', ' ')
		      . ' € pro Monat</span>
			</div>
		  </div>';
	}
	  
	private function buildPhoneDefaultTemplate(): string {		
	  return '<div class="row puffer left">
	    <div class="col">
		  <strong>Telefonie</strong>
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <input type="checkbox"
		         class="form-check-input"
				 id="' . $this->templateData["ipAddress"][2] . '"
				 name="' . $this->templateData["ipAddress"][2] . '"
				 value="' . $this->optionsValues[2]['id'] . '"
				 onclick="displaySubmenus( \'phDefault\', \'phoneSubMenu\')">
		  <span class="addressLabel">' . $this->optionsValues[2]['name'] . '</span>
		  <br>
		  <span class="smFont">(' . $this->optionsValues[2]['note'] . ')</span>
		</div>
		
		<div class="col addressLabel price">
		  <span>'
		  . number_format(floatval($this->optionsValues[2]["price"]), 2, ',', ' ')
		  . ' € pro Monat</span>
		</div>
		
		<div id="phoneSubMenu" class="borderBoxSub">' . $this->buildSubMenuPhoneTemplate() . '</div>
	  </div>';
	}
	  
	private function buildSubMenuPhoneTemplate(): string {
	  return '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel2 smFont">' . $this->optionsValues[3]['name'] . '</label>
			<br>
		    <input type="text"
			       id="' . $this->templateData["ipAddress"][3] . '"
				   name="' . $this->templateData["ipAddress"][3] . '">
		  </div>
		  
		  <div class="col price"> je '
		  . number_format(floatval($this->optionsValues[3]["price"]), 2, ',', ' ')
		  . ' € pro Monat</span>
		  </div>
		</div>
		
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel2 smFont">'
		      . $this->optionsValues[4]['name'] 
		      . ' (' . $this->optionsValues[4]['note']
		      . ')</label>
						<br>
		    <input type="text"
			       id="' . $this->templateData["ipAddress"][4] . '"
				   name="' . $this->templateData["ipAddress"][4] . '">
		  </div>
		  <div class="col price"> je '
		  . number_format(floatval($this->optionsValues[4]["price"]), 2, ',', ' ')
		  . ' € pro Monat</span>
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <input type="checkbox"
		           class="form-check-input"
			  	   id="' . $this->templateData["ipAddress"][5] . '"
				   name="' . $this->templateData["ipAddress"][5] . '"
				   value="' . $this->optionsValues[6]['id'] . '"
				   onClick="displaySubmenus( \'phPorting\', \'portingNr\')">
		    <span class="addressLabel smFont">' . $this->optionsValues[6]['name'] . '</span>
		  </div>
		</div>
		
		<div id="portingNr" class="row">
		  <div class="col">' . $this->buildPortingPhoneNumberTemplate() . '</div>
		</div>
	  ';
	}
	  
	private function buildPortingPhoneNumberTemplate(): string {
	  $portingPhone = new PortingPhoneNumber($this->templateData["phPorting"], $this->customerData, $this->addressData);
      return $portingPhone->buildPortingPhoneNumberTemplate();
	}
	  
    private function buildTVOptionTemplate(): string {
	  $returnValue = '';
		
	  if (!empty($this->optionTV)) {
	    $returnValue = '<div class="row puffer left">
		 <div class="col">
           <input type="checkbox"
		          class="form-check-input"
				  id="'    . $this->templateData["tv"] . '"
				  name="'  . $this->templateData["tv"] . '"
				  value="' . $this->optionTV[0]["id"]     . '">
		   <span class="addressLabel">' . $this->optionTV[0]["title"] . '</span>
		 </div>
		
		 <div class="col addressLabel price">
		   <span>'
		   . number_format(floatval($this->optionTV[0]["price"]), 2, ',', ' ')
		   . ' € pro Monat</span>
		 </div>
	   </div>
	   <hr>';
	  }
		
	  return $returnValue;
	}
	  
	private function buildFeeOptionTemplate(): string {
	  $returnValue = '';

	  if (!empty($this->optionFee)) {
	    $returnValue = '<div class="alert alert-secondary" role="alert">
		  <div class="row puffer left">
		    <div class="col">
		      <input type="checkbox" id="' . $this->templateData["fee"] . '" checked disabled>
			  <strong>' . $this->optionFee["label"] . '</strong>
		    </div>

		    <div class="col price">
              <span>
			    <strong>'
		          . number_format(floatval($this->optionFee["price"]), 2, ',', ' ')
		          . ' € pro Monat
				</strong>
			  </span>
		    </div>
		  </div>
		</div>
		<hr>';
	  }
		
	  return $returnValue;
	}
	  
	private function buildServiceTemplate(): string {
	  $returnValue = '<div class="row puffer left">
	    <div class="col">
		  <strong>Dienstleistungen</strong>
		</div>
	  </div>
	  
	  <div class="alert alert-secondary" role="alert">
	    <div class="row puffer left">
	      <div class="col">
		    <input type="checkbox" id="' . $this->templateData["service"][0] . '" checked disabled>
		    <strong>' . $this->optionsService[0]["name"] . '</strong>
		    <br>
		    <span class="smFont">(' . $this->optionsService[0]["note"] . ')</span>
		  </div>
		
		  <div class="col price">
            <span>
			  <strong>'
		        . number_format(floatval($this->optionsService[0]["price"]), 2, ',', ' ')
		        . ' € einmalig
		      </strong>
		    </span>
		  </div>
	    </div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col itFont">
		  Zusätzlich bieten wir Ihnen folgendes an:
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <input type="checkbox"
		         id="'   . $this->templateData["service"][1] . '"
				 name="' . $this->templateData["service"][1] . '"
				 value="' . $this->optionsService[1]["id"] . '">
		  <span>' . $this->optionsService[1]["name"] . '</span>
		  <br>
		  <span class="smFont">(' . $this->optionsService[1]["note"] . ')</span>
		</div>
		
		<div class="col price">
		  <span>'
		    . number_format(floatval($this->optionsService[1]["price"]), 2, ',', ' ')
		    . ' € einmalig
		  </span>
		</div>
	  </div>
	  <hr>';
		
	  return $returnValue;
	}
	  
	private function buildHardwareOptionTemplate(): string {
	  $returnValue = '<div class="row puffer left">
		    <div class="col">
		    <strong>Hardware</strong>
			<br>';
		
	  for ($i=0; $i < 2; $i++) {
	    $returnValue .= '
		    <br>
            <input type="checkbox"
		           class="form-check-input"
				   id="hw-'    . $this->optionsHw[$i]["id"] . '"
				   name="hw-'  . $this->optionsHw[$i]["id"] . '"
				   value="'    . $this->optionsHw[$i]["id"] . '">
		    <span>' . $this->optionsHw[$i]["name"] . '</span>';
	  }

	  $returnValue .= '</div><div class="col price"><br>';

	  for ($i=0; $i < 2; $i++) {
	    $returnValue .= '<br>' . number_format(floatval($this->optionsHw[$i]["price"]), 2, ',', ' ')
		  . ' € einmalig</span>';
	  }

	  $returnValue .= '</div></div>' . $this->buildAdditionallyHardwareInfoTemplate();

	  return $returnValue;
	}
	  
	private function buildAdditionallyHardwareInfoTemplate(): string {
	  $returnValue = '';
		
	  if ($this->optionAddHw["showInfoAddHwBox"]) {
		$id = $this->templateData["hw"][3];
		  
		if ($this->optionAddHw["label"] == "UFiber Loco GPON") {
		  $id = $this->templateData["hw"][2];
		}
		  
	    $returnValue = '<div class="alert alert-info" role="alert">
		    <div class="row left">
		      <div class="col itFont">
			    <strong>Achtung!</strong> Sie erhalten von uns noch folgende Leihgeräte:
			  </div>
		    </div>
		
		    <div class="row left">
		      <div class="col">
		        <input type="checkbox" id="' . $id . '" checked disabled>
			    <span>' . $this->optionAddHw["label"] . '</span>
		      </div>
		  
		      <div class="col price">
		        <span>'
			      . number_format(floatval($this->optionAddHw["price"]), 2, ',', ' ') . ' € pro Monat
		        </span>
		      </div>
		    </div>
		  </div>';
	  }
		
	  return $returnValue;
	}
  }
?>