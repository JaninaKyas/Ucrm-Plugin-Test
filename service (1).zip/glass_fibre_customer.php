<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	
	$address["postalAddress"] = array(
	  "street"   => $infos["street"],
	  "hNr"      => $infos["hNr"],
	  "zipcode"  => $infos["zipcode"],
	  "place"    => $infos["place"],
	  "district" => $infos["district"]
	);

    $templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company",
		  					   "mail", "phone", "mobil", "birthDay"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode",
							   "psPlace", "psDistrict", "psTae"),
	  "connecAddress" => array("caStreet", "caHNr", "caZipcode", "caPlace",
		 					   "caDistrict", "conTae", "caDiffAddress")
	);
	  
	require __DIR__ . "/views/glassFibre/glass_fibre.php";
	$glassFibre = new GlassFibre($templateData, $address, $infos["technologyAddress"]);
	  
	$content = array(
	  "step3Lable"         => "Kundendaten",
	  "step3"              => $glassFibre->getGlasFibreTemplate(),
	  "displayTechAddress" => "none"
	);

	echo json_encode($content);
  } 
?>