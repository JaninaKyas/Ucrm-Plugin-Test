    <button class="btn czr-btt czr-btta right" ><i class="icn-up-small"></i></button>
<script id="ckyBannerTemplate" type="text/template"><div class="cky-overlay cky-hide"></div><div class="cky-btn-revisit-wrapper cky-revisit-hide" data-cky-tag="revisit-consent" data-tooltip="Cookie-Einstellungen" style="background-color:#b8c402"> <button class="cky-btn-revisit" aria-label="Cookie-Einstellungen"> <img src="https://neu.brehna.net/wp-content/plugins/cookie-law-info/lite/frontend/images/revisit.svg" alt="Revisit consent button"> </button></div><div class="cky-consent-container cky-hide" tabindex="0"> <div class="cky-consent-bar" data-cky-tag="notice" style="background-color:#FFFFFF;border-color:#f4f4f4"> <button class="cky-banner-btn-close" data-cky-tag="close-button" aria-label="Nah dran"> <img src="https://neu.brehna.net/wp-content/plugins/cookie-law-info/lite/frontend/images/close.svg" alt="Close"> </button> <div class="cky-notice"> <p class="cky-title" role="heading" aria-level="1" data-cky-tag="title" style="color:#212121">Wir schätzen Ihre Privatsphäre</p><div class="cky-notice-group"> <div class="cky-notice-des" data-cky-tag="description" style="color:#212121"> <p>Wir verwenden Cookies, um Ihr Surferlebnis zu verbessern, personalisierte Anzeigen oder Inhalte einzusetzen und unseren Datenverkehr zu analysieren. Wenn Sie auf „Alle akzeptieren" klicken, stimmen Sie der Anwendung von Cookies zu.</p> </div><div class="cky-notice-btn-wrapper" data-cky-tag="notice-buttons"> <button class="cky-btn cky-btn-customize" aria-label="Anpassen" data-cky-tag="settings-button" style="color:#b8c402;background-color:transparent;border-color:#b8c402">Anpassen</button> <button class="cky-btn cky-btn-reject" aria-label="Alles ablehnen" data-cky-tag="reject-button" style="color:#ffffff;background-color:#b8c402;border-color:#b8c402">Alles ablehnen</button> <button class="cky-btn cky-btn-accept" aria-label="Alle akzeptieren" data-cky-tag="accept-button" style="color:#b8c402;background-color:#ffffff;border-color:#b8c402">Alle akzeptieren</button>  </div></div></div></div></div><div class="cky-modal" tabindex="0"> <div class="cky-preference-center" data-cky-tag="detail" style="color:#212121;background-color:#FFFFFF;border-color:#f4f4f4"> <div class="cky-preference-header"> <span class="cky-preference-title" role="heading" aria-level="1" data-cky-tag="detail-title" style="color:#212121">Einstellungen für die Zustimmung anpassen</span> <button class="cky-btn-close" aria-label="[cky_preference_close_label]" data-cky-tag="detail-close"> <img src="https://neu.brehna.net/wp-content/plugins/cookie-law-info/lite/frontend/images/close.svg" alt="Close"> </button> </div><div class="cky-preference-body-wrapper"> <div class="cky-preference-content-wrapper" data-cky-tag="detail-description" style="color:#212121"> <p>Wir verwenden Cookies, damit Sie effizient navigieren und bestimmte Funktionen ausführen können. Detaillierte Informationen zu allen Cookies finden Sie unten unter jeder Einwilligungskategorie.</p><p>Die als „notwendig" kategorisierten Cookies werden in Ihrem Browser gespeichert, da sie für die Aktivierung der grundlegenden Funktionalitäten der Website unerlässlich sind.</p><p>Wir verwenden auch Cookies von Drittanbietern, die uns dabei helfen, zu analysieren, wie Sie diese Website nutzen, Ihre Präferenzen zu speichern und die für Sie relevanten Inhalte und Werbeanzeigen bereitzustellen. Diese Cookies werden nur mit Ihrer vorherigen Einwilligung in Ihrem Browser gespeichert.</p><p>Sie können einige oder alle dieser Cookies aktivieren oder deaktivieren, aber die Deaktivierung einiger dieser Cookies kann Ihre Browser-Erfahrung beeinträchtigen.</p> </div><div class="cky-accordion-wrapper" data-cky-tag="detail-categories"> <div class="cky-accordion" id="ckyDetailCategorynecessary"> <div class="cky-accordion-item"> <div class="cky-accordion-chevron"><i class="cky-chevron-right"></i></div> <div class="cky-accordion-header-wrapper"> <div class="cky-accordion-header"><button class="cky-accordion-btn" aria-label="Notwendige" data-cky-tag="detail-category-title" style="color:#212121">Notwendige</button><span class="cky-always-active">Immer aktiv</span> <div class="cky-switch" data-cky-tag="detail-category-toggle"><input type="checkbox" id="ckySwitchnecessary"></div> </div> <div class="cky-accordion-header-des" data-cky-tag="detail-category-description" style="color:#212121"> <p>Notwendige Cookies sind für die Grundfunktionen der Website von entscheidender Bedeutung. Ohne sie kann die Website nicht in der vorgesehenen Weise funktionieren. Diese Cookies speichern keine personenbezogenen Daten.</p></div> </div> </div> <div class="cky-accordion-body"> <div class="cky-audit-table" data-cky-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="cky-empty-cookies-text">Keine Cookies zum Anzeigen.</p></div> </div> </div><div class="cky-accordion" id="ckyDetailCategoryfunctional"> <div class="cky-accordion-item"> <div class="cky-accordion-chevron"><i class="cky-chevron-right"></i></div> <div class="cky-accordion-header-wrapper"> <div class="cky-accordion-header"><button class="cky-accordion-btn" aria-label="Funktionale" data-cky-tag="detail-category-title" style="color:#212121">Funktionale</button><span class="cky-always-active">Immer aktiv</span> <div class="cky-switch" data-cky-tag="detail-category-toggle"><input type="checkbox" id="ckySwitchfunctional"></div> </div> <div class="cky-accordion-header-des" data-cky-tag="detail-category-description" style="color:#212121"> <p>Funktionale Cookies unterstützen bei der Ausführung bestimmter Funktionen, z. B. beim Teilen des Inhalts der Website auf Social Media-Plattformen, beim Sammeln von Feedbacks und anderen Funktionen von Drittanbietern.</p></div> </div> </div> <div class="cky-accordion-body"> <div class="cky-audit-table" data-cky-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="cky-empty-cookies-text">Keine Cookies zum Anzeigen.</p></div> </div> </div><div class="cky-accordion" id="ckyDetailCategoryanalytics"> <div class="cky-accordion-item"> <div class="cky-accordion-chevron"><i class="cky-chevron-right"></i></div> <div class="cky-accordion-header-wrapper"> <div class="cky-accordion-header"><button class="cky-accordion-btn" aria-label="Analyse" data-cky-tag="detail-category-title" style="color:#212121">Analyse</button><span class="cky-always-active">Immer aktiv</span> <div class="cky-switch" data-cky-tag="detail-category-toggle"><input type="checkbox" id="ckySwitchanalytics"></div> </div> <div class="cky-accordion-header-des" data-cky-tag="detail-category-description" style="color:#212121"> <p>Analyse-Cookies werden verwendet um zu verstehen, wie Besucher mit der Website interagieren. Diese Cookies dienen zu Aussagen über die Anzahl der Besucher, Absprungrate, Herkunft der Besucher usw.</p></div> </div> </div> <div class="cky-accordion-body"> <div class="cky-audit-table" data-cky-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="cky-empty-cookies-text">Keine Cookies zum Anzeigen.</p></div> </div> </div><div class="cky-accordion" id="ckyDetailCategoryperformance"> <div class="cky-accordion-item"> <div class="cky-accordion-chevron"><i class="cky-chevron-right"></i></div> <div class="cky-accordion-header-wrapper"> <div class="cky-accordion-header"><button class="cky-accordion-btn" aria-label="Leistungs" data-cky-tag="detail-category-title" style="color:#212121">Leistungs</button><span class="cky-always-active">Immer aktiv</span> <div class="cky-switch" data-cky-tag="detail-category-toggle"><input type="checkbox" id="ckySwitchperformance"></div> </div> <div class="cky-accordion-header-des" data-cky-tag="detail-category-description" style="color:#212121"> <p>Leistungs-Cookies werden verwendet, um die wichtigsten Leistungsindizes der Website zu verstehen und zu analysieren. Dies trägt dazu bei, den Besuchern ein besseres Nutzererlebnis zu bieten.</p></div> </div> </div> <div class="cky-accordion-body"> <div class="cky-audit-table" data-cky-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="cky-empty-cookies-text">Keine Cookies zum Anzeigen.</p></div> </div> </div><div class="cky-accordion" id="ckyDetailCategoryadvertisement"> <div class="cky-accordion-item"> <div class="cky-accordion-chevron"><i class="cky-chevron-right"></i></div> <div class="cky-accordion-header-wrapper"> <div class="cky-accordion-header"><button class="cky-accordion-btn" aria-label="Werbe" data-cky-tag="detail-category-title" style="color:#212121">Werbe</button><span class="cky-always-active">Immer aktiv</span> <div class="cky-switch" data-cky-tag="detail-category-toggle"><input type="checkbox" id="ckySwitchadvertisement"></div> </div> <div class="cky-accordion-header-des" data-cky-tag="detail-category-description" style="color:#212121"> <p>Werbe-Cookies werden verwendet, um Besuchern auf der Grundlage der von ihnen zuvor besuchten Seiten maßgeschneiderte Werbung zu liefern und die Wirksamkeit von Werbekampagne nzu analysieren.</p></div> </div> </div> <div class="cky-accordion-body"> <div class="cky-audit-table" data-cky-tag="audit-table" style="color:#212121;background-color:#f4f4f4;border-color:#ebebeb"><p class="cky-empty-cookies-text">Keine Cookies zum Anzeigen.</p></div> </div> </div> </div></div><div class="cky-footer-wrapper"> <span class="cky-footer-shadow"></span> <div class="cky-prefrence-btn-wrapper" data-cky-tag="detail-buttons"> <button class="cky-btn cky-btn-reject" aria-label="Alles ablehnen" data-cky-tag="detail-reject-button" style="color:#ffffff;background-color:#b8c402;border-color:#b8c402"> Alles ablehnen </button> <button class="cky-btn cky-btn-preferences" aria-label="Speichern Sie meine Einstellungen" data-cky-tag="detail-save-button" style="color:#b8c402;background-color:transparent;border-color:#b8c402"> Speichern Sie meine Einstellungen </button> <button class="cky-btn cky-btn-accept" aria-label="Alle akzeptieren" data-cky-tag="detail-accept-button" style="color:#b8c402;background-color:#ffffff;border-color:#b8c402"> Alle akzeptieren </button> </div><div style="padding: 8px 24px;font-size: 12px;font-weight: 400;line-height: 20px;text-align: right;border-radius: 0 0 6px 6px;direction: ltr;justify-content: flex-end;align-items: center;background-color:#EDEDED;color:#293C5B" data-cky-tag="detail-powered-by"> Powered by <a target="_blank" rel="noopener" href="https://www.cookieyes.com/product/cookie-consent" style="margin-left: 5px;line-height: 0"><img src="https://neu.brehna.net/wp-content/plugins/cookie-law-info/lite/frontend/images/poweredbtcky.svg" alt="Cookieyes logo" style="width: 78px;height: 13px;margin: 0"></a> </div></div></div></div></script><script id="wfc-front-localized">var wfcFrontParams = {"effectsAndIconsSelectorCandidates":[],"wfcOptions":null};</script>          <script id="wfc-front-script">!function(){var e=wfcFrontParams.effectsAndIconsSelectorCandidates;var o,t,c,r,i=(r={},o=navigator.userAgent.toLowerCase(),(c={browser:(t=/(chrome)[ /]([\w.]+)/.exec(o)||/(webkit)[ /]([\w.]+)/.exec(o)||/(opera)(?:.*version|)[ /]([\w.]+)/.exec(o)||/(msie) ([\w.]+)/.exec(o)||o.indexOf("compatible")<0&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(o)||[])[1]||"",version:t[2]||"0"}).browser&&(r[c.browser]=!0,r.version=c.version),r.chrome?r.webkit=!0:r.webkit&&(r.safari=!0),r),s="",a=0;for(var n in i)a>0||(s=n,a++);var f=document.querySelectorAll("body");f&&f[0]&&f[0].classList.add(s||"");try{!function(){for(var o in e){var t=e[o];if(t.static_effect){if("inset"==t.static_effect&&!0===i.mozilla)continue;var c=document.querySelectorAll(t.static_effect_selector);c&&c.forEach(function(e,o){e.classList.add("font-effect-"+t.static_effect)})}}}()}catch(e){window.console&&console.log&&console.log("Font customizer error => could not apply effects",e)}}();</script>
        <script type="text/javascript" src="https://neu.brehna.net/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=5.7.7" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-extra">
/* <![CDATA[ */
var wpcf7 = {"api":{"root":"https:\/\/neu.brehna.net\/wp-json\/","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://neu.brehna.net/wp-content/plugins/contact-form-7/includes/js/index.js?ver=5.7.7" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://neu.brehna.net/wp-includes/js/comment-reply.min.js?ver=6.4.3" id="comment-reply-js" async="async" data-wp-strategy="async"></script>
<script type="text/javascript" src="https://neu.brehna.net/wp-includes/js/jquery/ui/core.min.js?ver=1.13.2" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://neu.brehna.net/wp-content/plugins/page-links-to/dist/new-tab.js?ver=3.3.6" id="page-links-to-js"></script>
<script type="text/javascript" id="wpcf7cf-scripts-js-extra">
/* <![CDATA[ */
var wpcf7cf_global_settings = {"ajaxurl":"https:\/\/neu.brehna.net\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="https://neu.brehna.net/wp-content/plugins/cf7-conditional-fields/js/scripts.js?ver=2.4.7" id="wpcf7cf-scripts-js"></script>
<script type="text/javascript" id="nb_main_front_js_preloading-js-after">
/* <![CDATA[ */
            nb_.listenTo('nb-docready', function() {
                nb_.preloadOrDeferAsset( {
                  id : 'nb-main-js',
                  as : 'script',
                  href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/ccat-nimble-front.min.js?v=3.3.4",
                  scriptEl : document.getElementById('nb-load-main-script')
                });
            });
                            nb_.listenTo('nb-needs-swiper', function() {
                    nb_.preloadOrDeferAsset( {
                      id : "slider-module",
                      as : 'script',
                      href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/partials/slider-module.min.js?v=3.3.4",
                      scriptEl : document.getElementById('nb-load-script-slider-module')
                    });
                });
                                nb_.listenTo('nb-needs-menu-js', function() {
                    nb_.preloadOrDeferAsset( {
                      id : "menu-module",
                      as : 'script',
                      href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/partials/menu-module.min.js?v=3.3.4",
                      scriptEl : document.getElementById('nb-load-script-menu-module')
                    });
                });
                                nb_.listenTo('nb-needs-parallax', function() {
                    nb_.preloadOrDeferAsset( {
                      id : "front-parallax",
                      as : 'script',
                      href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/partials/front-parallax.min.js?v=3.3.4",
                      scriptEl : document.getElementById('nb-load-script-front-parallax')
                    });
                });
                                nb_.listenTo('nb-needs-accordion', function() {
                    nb_.preloadOrDeferAsset( {
                      id : "accordion-module",
                      as : 'script',
                      href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/partials/accordion-module.min.js?v=3.3.4",
                      scriptEl : document.getElementById('nb-load-script-accordion-module')
                    });
                });
                
/* ]]> */
</script>
<script type="text/javascript" id="nb_preload_front_assets-js-after">
/* <![CDATA[ */
            nb_.listenTo('nb-needs-swipebox', function() {
                nb_.preloadOrDeferAsset( {
                    id : 'nb-swipebox',
                    as : 'script',
                    href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/libs/jquery-swipebox.min.js?3.3.4",
                    onEvent : 'nb-docready',
                    // scriptEl : document.currentScript
                });
                nb_.preloadOrDeferAsset( {
                  id : 'nb-swipebox-style',
                  as : 'style',
                  href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/css/libs/swipebox.min.css?3.3.4",
                  onEvent : 'nb-docready',
                  // scriptEl : document.currentScript
                });
            });

            nb_.listenTo('nb-needs-swiper', function() {
                nb_.preloadOrDeferAsset( {
                    id : 'nb-swiper',
                    as : 'script',
                    href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/libs/swiper-bundle.min.js?3.3.4",
                    onEvent : 'nb-docready',
                    // scriptEl : document.currentScript
                });
            });
            nb_.listenTo('nb-needs-videobg-js', function() {
                nb_.preloadOrDeferAsset( {
                    id : 'nb-video-bg-plugin',
                    as : 'script',
                    href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/js/libs/nimble-video-bg.min.js?3.3.4",
                    onEvent : 'nb-docready',
                    // scriptEl : document.currentScript
                });
            });
                                            nb_.listenTo('nb-needs-fa', function() {
                    nb_.preloadOrDeferAsset( {
                      id : 'nb-font-awesome',
                      as : 'style',
                      href : "https://neu.brehna.net/wp-content/plugins/nimble-builder/assets/front/fonts/css/fontawesome-all.min.css?3.3.4",
                      onEvent : 'nb-docready',
                      scriptEl : document.currentScript
                    });
                });
                
/* ]]> */
</script>
<script type="text/javascript" id="nb_emit_nb-needs-swiper-js-after">
/* <![CDATA[ */
(function(){if(window.nb_){nb_.emit("nb-needs-swiper");}})();
/* ]]> */
</script>

<script type="text/javascript" src='//neu.brehna.net/wp-content/uploads/custom-css-js/103.js?v=8014'></script>
<script id="fpu-front-localized">var FPUFront = {"Spanvalue":"4","ThemeName":"customizr-pro","imageCentered":"1","smartLoad":""};</script> 

<script src="/service4/public/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="/service4/public/js/main.js"></script>