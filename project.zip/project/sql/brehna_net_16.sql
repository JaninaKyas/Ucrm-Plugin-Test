CREATE TABLE IF NOT EXISTS `tariff` (
  `id`          INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `category_id` INT(11)       UNSIGNED NOT NULL,
  `name`        CHAR(50)               NOT NULL DEFAULT '',
  `price`       DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `note`        CHAR(100)              NOT NULL DEFAULT '',
  `power_down`  INT(5)        UNSIGNED NOT NULL DEFAULT 0,
  `power_up`    INT(5)        UNSIGNED NOT NULL DEFAULT 0,
  `createDate`  DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)               NOT NULL DEFAULT '',
  `updateDate`  DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)             NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (category_id) REFERENCES `category`(id)
) ENGINE=INNODB;

INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home Lite', 20.00, 10, 2, 'mit NAT-IPv4', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home Standard', 25.00, 25, 5, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home Plus', 35.00, 40, 10, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home Maxx', 45.00, 80, 20, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home 200', 45.00, 200, 100, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home 400', 65.00, 400, 100, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'Brehna.net Home 1000', 85.00, 1000, 200, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 4, 'Brehna.net Komplett Senior', 19.95, 16, 5, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'B.net Business Comp. Standard 10', 50.00, 10, 5, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 1, 'B.net Business Comp. Standard MAXX', 60.00, 25, 10, '> 25 MBit bei Downstream', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 4, 'B.net Business Comp. Plus 10', 65.00, 10, 5, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff` VALUES(null, 4, 'B.net Business Comp. Plus MAXX', 75.00, 25, 10, '', NOW(), 'JANINA', NOW(), 'JANINA', 0);