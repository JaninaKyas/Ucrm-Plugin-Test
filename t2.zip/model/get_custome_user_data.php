<?php

declare(strict_types = 1);

class CustomTable {
  function getUserByCustomerNumber(int $customerNumber): array {
    $pdo = require_once __DIR__ . '/connect_db.php';
    
    $query = 'SELECT id, test_name, customer_number FROM custom_table WHERE customer_number = \'' . $customerNumber . '\'';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return [$result];    
  }
}
