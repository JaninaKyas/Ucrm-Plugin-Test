--
-- Tabellenstruktur für Tabelle `telecommunication_system`
--

CREATE TABLE IF NOT EXISTS `telecommunication_system` (
  `id`           INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `directDialNr` CHAR(50)            NOT NULL DEFAULT '',
  `queryPoint`   CHAR(50)            NOT NULL DEFAULT '',
  `nrBlockFrom`  INT(11)    UNSIGNED NOT NULL DEFAULT 0,
  `nrBlockTo`    INT(11)    UNSIGNED NOT NULL DEFAULT 0,
  `createDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`   CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`   CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`    TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `phone_numbers`
--

CREATE TABLE IF NOT EXISTS `phone_numbers` (
  `id`           INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `onkz`         CHAR(15)            NOT NULL DEFAULT '',
  `phone1`       CHAR(25)            NOT NULL DEFAULT '',
  `phone2`       CHAR(25)            NOT NULL DEFAULT '',
  `phone3`       CHAR(25)            NOT NULL DEFAULT '',
  `phone4`       CHAR(25)            NOT NULL DEFAULT '',
  `phone5`       CHAR(25)            NOT NULL DEFAULT '',
  `phone6`       CHAR(25)            NOT NULL DEFAULT '',
  `phone7`       CHAR(25)            NOT NULL DEFAULT '',
  `phone8`       CHAR(25)            NOT NULL DEFAULT '',
  `phone9`       CHAR(25)            NOT NULL DEFAULT '',
  `createDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`   CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`   CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`    TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `connection_data_holder`
--

CREATE TABLE IF NOT EXISTS `connection_data_holder` (
  `id`           INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `address_id`  INT(11)    UNSIGNED NOT NULL,
  `name_company` CHAR(100)           NOT NULL DEFAULT '',
  `fName`        CHAR(100)           NOT NULL DEFAULT '',
  `createDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`   CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`   DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`   CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`    TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (address_id) REFERENCES address(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `provider_change_order`
--

CREATE TABLE IF NOT EXISTS `provider_change_order` (
  `id`               INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_holder_id`   INT(11)    UNSIGNED NOT NULL,
  `phone_nr_id`      INT(11)    UNSIGNED NOT NULL,
  `tele_system_id`   INT(11)    UNSIGNED NOT NULL,
  `currentProvider`  CHAR(100)           NOT NULL DEFAULT '',
  `executeCancel`    TINYINT(1)          NOT NULL DEFAULT 1,
  `phonePortability` TINYINT(1)          NOT NULL DEFAULT 1,
  `getAllNr`         TINYINT(1)          NOT NULL DEFAULT 1,
  `createDate`       DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`       CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`       DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`       CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`        TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (data_holder_id) REFERENCES connection_data_holder(id),
  FOREIGN KEY (phone_nr_id)    REFERENCES phone_numbers(id),
  FOREIGN KEY (tele_system_id) REFERENCES telecommunication_system(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `contract_x_provider_change_order`
--

CREATE TABLE IF NOT EXISTS `contract_x_provider_change_order` (
  `id`                 INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `contract_id`        INT(11)    UNSIGNED NOT NULL,
  `change_provider_id` INT(11)    UNSIGNED NOT NULL,
  `createDate`         DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`         CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`         DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`         CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`          TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (contract_id)        REFERENCES contract(id),
  FOREIGN KEY (change_provider_id) REFERENCES provider_change_order(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;