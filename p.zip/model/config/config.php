<?php

declare(strict_types = 1);

class ConfigDb {
  protected const DB_HOST     = 'ZFc1dGN5MXdiM04wWjNKbGN3PT0=';
  protected const DB_PORT     = 5432;
  protected const DB_NAME     = 'ZFc1dGN3PT0=';
  protected const DB_USER     = 'ZFdOeWJRPT0=';
  protected const DB_PASSWORD = 'VVZwcE5qUm5SR1JVWVVObE5VeEVlRzAwYzNONVpVVjJXa05ZTVVocGVXVkxSRlYwVW5veFExRlhWWGRXVGxsRw==';
  
  private function _decipherConstants(String $value) : String {
    return base64_decode(base64_decode($value));
  }
  
  public function getDbHost () : String {
    return $this->_decipherConstants(self::DB_HOST);
  }
  
  public function getDbPort () : int {
    return self::DB_PORT;  
  }
  
  public function getDbName () : String {
    return $this->_decipherConstants(self::DB_NAME);  
  }
  
  public function getDbUser () : String {
    return $this->_decipherConstants(self::DB_USER);  
  }
  
  public function getDbPassword () : String {
    return $this->_decipherConstants(self::DB_PASSWORD);  
  } 
}
