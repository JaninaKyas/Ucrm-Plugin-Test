<?php
  declare(strict_types = 1);

  require_once __DIR__ . "/address.php";

  class PortingPhoneNumber {
	public  $templateData   = array();

	private $ekp            = 'Project66 IT-Systemhaus (Brehna.net)';
	private $pkRun          = 'D012';
	private $portTWFirst    = true;
	private $safeHaven      = true;
  
	public function __construct($newTemplateData) {
	  $this->templateData  = $newTemplateData;
	}
	  
	public function buildPortingPhoneNumberTemplate(): string {
	  return '<div id="phPortingBlock" class="borderBoxSub">'
		    . $this->buildTitleTemplate()
		    . $this->buildKUETemplate()
		    . $this->buildDataholderTemplate()
		    . $this->buildPhoneNumbersTemplate()
		    . $this->buildTKSystemTemplate()
		    . '</div>';
	}
	  
	private function buildTitleTemplate(): string {
	  return '<div class="row puffer">
	    <div class="col">
		  <strong>Anbieterwechselauftrag von ' . $this->ekp . '</strong>
		</div>
	  </div>';
	}
	  
	private function buildKUETemplate(): string {
	  return '<div class="row puffer left">
	    <div class="col">
		  <input type="checkbox" id="kueAS" checked disabled>
		  <strong>Kündiung von Anschlüssen beim Endkundenvertragspartner abgebend (EKPabg)</strong>
		  <br>
		  <span class="smFont">
		  (separate Kündigung beim bisherigen Anbieter nicht erforderlich)
		  </span>
		  <br>
		  <span class="smFont paragraph">
		  Hiermit künidge/n ich/wir den zu unten gemachten Angaben gehörenden Anschluss bei
		  zum nächst möglichen Termin.
		  </span>
		</div>
		
		<div class="col-2">
		  <textarea id="'   . $this->templateData["provider"]
		       . '" name="' . $this->templateData["provider"] . '"
			        rows="3" cols="15"></textarea>
		</div>
	  </div>';
	}
	  
	private function buildDataholderTemplate(): string {
	  $dhAddress = new Address($this->templateData["dataholder"]);
		
	  return '<div class="row puffer left">
	    <div class="col">
		  <input type="checkbox" id="dhInfos" checked disabled>
		  <strong>
		    Hiermit beauftrage/n ich/wir die Portierung (Mitnahme) der angegebenen Rufnummern.
		  </strong>
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  Name / Firma*
		  <input type="text"
			     id="'   . $this->templateData["dataholder"][1] . '"
				 name="' . $this->templateData["dataholder"][1] . '">
		</div>
		
		<div class="col">
		  Vorname*
		  <input type="text"
			     id="'   . $this->templateData["dataholder"][0] . '"
				 name="' . $this->templateData["dataholder"][0] . '">
		</div>
	  </div>' . $dhAddress->buildAddressTemplate();
	}
	  
	private function buildPhoneNumbersTemplate(): string {
	  return '<div class="row puffer left">
	    <div class="col">
		  <input type="checkbox" id="pnSpeci" checked disabled>
		  <strong>alle Nr. der Anschlüsse portieren</strong>
		  <br>
		  <span class="smFont">
		    <strong>(Achtung, es muss mindestens eine Rufnummer angegeben werden!)</strong>
		  </span>
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col"><span class="smFont"><strong>Ortsnetzkennzahl</strong></span></div>
		<div class="col"><span class="smFont"><strong>Rufnummer/n</strong></span></div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["onkz"] . '"
				 name="' . $this->templateData["numbers"]["onkz"] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][0] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][0] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][1] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][1] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][2] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][2] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col"></div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][3] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][3] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][4] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][4] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][5] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][5] . '">
		</div>
	  </div>
	  
	  <div class="row puffer left">
	    <div class="col"></div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][6] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][6] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][7] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][7] . '">
		</div>
		
		<div class="col">
		  <input type="text"
			     id="'   . $this->templateData["numbers"]["nrPhones"][8] . '"
				 name="' . $this->templateData["numbers"]["nrPhones"][8] . '">
		</div>
	  </div>';
	}
	  
	private function buildTKSystemTemplate(): string {
	  return '<div class="row puffer left">
	    <div class="col">
		  <strong>Telekommmunikationsanlagen</strong>
		</div>
	  </div>
	  
	  <div class="row left">
	    <div class="col">
		  <label class="addressLabel2 smFont">Durchwahl-RN</label>
		  <br>
		  <input type="text"
			     id="'   . $this->templateData["tkSystem"][0] . '"
				 name="' . $this->templateData["tkSystem"][0] . '">
		</div>
		
		<div class="col">
          <label class="addressLabel2 smFont">Abfragestelle</label>
		  <br>
		  <input type="text"
			     id="'   . $this->templateData["tkSystem"][1] . '"
				 name="' . $this->templateData["tkSystem"][1] . '">
		</div>
		
		<div class="col">
		  <label class="addressLabel2 smFont">Rufnummernblock von</label>
		  <br>
		  <input type="text"
			     id="'   . $this->templateData["tkSystem"][2] . '"
				 name="' . $this->templateData["tkSystem"][2] . '">
		</div>
		<div class="col">
		  <label class="addressLabel2 smFont">bis</label>
		  <br>
		  <input type="text"
			     id="'   . $this->templateData["tkSystem"][3] . '"
				 name="' . $this->templateData["tkSystem"][3] . '">
		</div>
	  </div>';
	}
  }
?>