<?php
  declare(strict_types = 1);

  require __DIR__ . "/address.php";

  class Customer {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
	  
	public function getCustomerTemplate() {		
	  $returnValue = '';
		
	  return $returnValue;
	}
  }
?>