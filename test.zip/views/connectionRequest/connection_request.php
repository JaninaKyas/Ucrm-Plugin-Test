<?php  
  declare(strict_types = 1);

  require __DIR__ . "/forms/customer.php";

  class ConnectionRequest {
	public $templateAttributes = array();
	public $templateValues     = array();
	  
	public function __construct($newTemplateAttributes, $newTemplateValues = array()) {
      $this->templateAttributes = $newTemplateAttributes;
	  $this->templateValues     = $newTemplateValues;
	}
	  
	public function getTemplateStep2(): string {
	  $customer = new Customer($this->templateAttributes, $this->templateValues);
	  $returnValue = $customer->buildCustomerTemplate();
	  return $returnValue;
	}
  }
?>