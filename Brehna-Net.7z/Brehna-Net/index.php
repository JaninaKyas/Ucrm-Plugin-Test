<html lang="de-DE" class="no-js">
  <body class="nb-3-3-4 nimble-has-local-data-skp__post_page_43 nimble-no-group-site-tmpl-skp__all_page page-template-default page page-id-43 wp-custom-logo wp-embed-responsive sek-hide-rc-badge czr-link-hover-underline header-skin-light footer-skin-light czr-no-sidebar tc-center-images czr-full-layout sn-right-mc_slide_top customizr-pro-2-4-7 czr-sticky-footer">
   	<?php require_once __DIR__ . "/layout/main/header.php"; ?>
	<?php require_once __DIR__ . "/layout/main/topMenu.php"; ?>
    <div id="main-wrapper" class="section">
      <div class="container" role="main">
        <?php require_once __DIR__ . "/layout/step_progressbar.php"; ?>
      </div><!-- .container -->
      <div id="czr-push-footer" ></div>
    </div><!-- #main-wrapper -->
    <?php require_once __DIR__ . "/layout/main/footer.php"; ?>
	</body>
</html>

https://codepen.io/lookininward/pen/dKmGrb
https://medium.com/@beyondborders/building-a-responsive-progress-bar-ea5a0ecabe91
https://codepen.io/athimannil/pen/wWPYZQ

https://codepen.io/jidelambo/pen/RaRygY
https://dev.to/jolamemushaj/how-to-create-a-steps-progress-bar-4m2b
https://www.google.de/search?q=css+html+step+progress+bar+responsive+design+example&sca_esv=470f1110063701c7&ei=4KgSZr-mDPu59u8PxeG1sAM&oq=css+html+step+progress+bar+responsive+example&gs_lp=Egxnd3Mtd2l6LXNlcnAiLWNzcyBodG1sIHN0ZXAgcHJvZ3Jlc3MgYmFyIHJlc3BvbnNpdmUgZXhhbXBsZSoCCAAyCBAhGKABGMMESJMvUNUEWLgfcAF4AZABAJgBlwGgAZAKqgEDMi45uAEDyAEA-AEBmAILoALUCcICChAAGEcY1gQYsAPCAgoQIRgKGKABGMMEmAMAiAYBkAYIkgcDMi45oAfjMA&sclient=gws-wiz-serp
