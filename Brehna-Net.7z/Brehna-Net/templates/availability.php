<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dirPath = str_replace('templates', '', __DIR__);
  require $dirPath . "forms/address.php";

  $asbAddress = new Address('asbStreet', 'asbHNr', 'asbPlz', 'asbPlace', 'asbDistrict', 'asbCountry', 'asbAppNr', true);

  if (isset($_POST)) {
    if (isset($_POST["asbStreet"]) && isset($_POST["asbHNr"]) && isset($_POST["asbPlz"]) && isset($_POST["asbPlace"])) {
       var_dump($_POST);
	}
  }
?>
<div class="centerForm">
  <form id="asbCheck" class="borderBox" method="POST">
	<h1>Verfügbarkeit prüfen</h1>
	<?php echo $asbAddress->getTemplate(); ?>
    <button class="button" type="submit" id="asbCheck" name="btnAsbCheck">Prüfen</button>
  </form>
</div>