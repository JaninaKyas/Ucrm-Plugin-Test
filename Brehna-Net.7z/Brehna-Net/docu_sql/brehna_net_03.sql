--
-- Tabellenstruktur für Tabelle `hardware`
--

CREATE TABLE IF NOT EXISTS `hardware` (
  `id` INT(11)            UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` CHAR(150)                 NOT NULL DEFAULT '',
  `price` DECIMAL(10,2)            NOT NULL DEFAULT 0.00,
  `note`  CHAR(150)                NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `hardware`
--

INSERT INTO `hardware` VALUES(null, '... bitte auswählen ...',          70.00, '(WAN/LAN/WLAN)',                         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'Brehna.net Standard.Box',          70.00, '(WAN/LAN/WLAN)',                         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz!Box 7590',              150.00, '(WAN, 4x GLAN, WLAN, VoIP-TK, DECT)',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz!Fon C5/C6',              75.00, '',                                       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz!Fon C5/C6',             150.00, 'DuoSet',                                 NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz!Fon C5/C6',             210.00, 'TrioSet',                                NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz WLAN Repeater',          90.00, '',                                       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz PowerlineSet',          150.00, '',                                       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'Brehna.net Router VoIP',          180.00, '(4x LAN, WLAN, VoIP-TK, ISDN, DECT)',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz!Box Fon Standard',      100.00, '(4x LAN, WLAN, DECT, Telefonie)',        NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'Tischtelefon mit grossen Tasten',  75.00, '(Doro/ Gigaset)',                        NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'AVM Fritz Fon C5',                 75.00, '(VoIP/ DECT)',                           NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `hardware` VALUES(null, 'Amazon Echo Spot',                180.00, 'inkl. Alex Installation und Einweisung', NOW(), 'JANINA', NOW(), 'JANINA', 0);