// https://www.sourcecodester.com/htmlcss/17003/multi-step-form-progress-bar-using-html-css-and-javascript-source-code.html?utm_content=cmp-true
// https://www.codingnepalweb.com/multi-step-progress-bar-html-css-javascript/
// original https://levelup.gitconnected.com/create-a-multi-step-form-using-html-css-and-javascript-30aca5c062fc

// global variables
// array values
let contractData       = {};
let promiseData        = {};
let postalAddress      = {};
let techAddress        = {};
let currentTechAddress = {};
// booleans
var isFormValid        = true;
var isRecallTerminOpen = false;
// decision variables
var choosenPath        =   -1;
var choosenSubPath     =   -1;
var stepDirection      =    0;
// elements
var errorMsg           = document.getElementById("asbErrorMsg");
// constants
const timeout          = 30000;

const navigateToFormStep = (stepNumber) => {
  document.querySelectorAll(".form-step").forEach((formStepElement) => {
    formStepElement.classList.add("d-none");
  });

  document.querySelectorAll(".form-stepper-list").forEach((formStepHeader) => {
    formStepHeader.classList.add("form-stepper-unfinished");
    formStepHeader.classList.remove("form-stepper-active", "form-stepper-completed");
  });

  document.querySelector("#step-" + stepNumber).classList.remove("d-none");

  const formStepCircle = document.querySelector('li[step="' + stepNumber + '"]');

  formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-completed");
  formStepCircle.classList.add("form-stepper-active");

  for (let index = 0; index < stepNumber; index++) {
    const formStepCircle = document.querySelector('li[step="' + index + '"]');
    if (formStepCircle) {
      formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-active");
      formStepCircle.classList.add("form-stepper-completed");
    }
  }
};

document.querySelectorAll(".btn-navigate-form-step").forEach((formNavigationBtn) => {
  formNavigationBtn.addEventListener("click", () => {
    const stepNumber = parseInt(formNavigationBtn.getAttribute("step_number"));
	stepDirection    = parseInt(formNavigationBtn.getAttribute("step_direction"));

	if (stepDirection === 1) {
	  switch(stepNumber) {
	    case 2:
	      isFormValid = validateAvailibityForm();

		  if (isFormValid) {
		    executeAvailabilitySearch();
		  }
		  break;
	    case 3:
		  isFormValid = validateFormsForStep3();

		  if (isFormValid) {
		    loadContentForStep3();
		  }
		  break;
	    case 4:
		  isFormValid = validateFormsForStep4();

		  if (isFormValid) {
			loadContentForStep4();  
		  }
		  break;
	    case 5: break;
	    case 6: break;
	  }
	}

	if (stepDirection === -1) {
	  resetValidateDeclarations();
	}

	if (isFormValid) {
      navigateToFormStep(stepNumber);
	}
  });
});

/* promise fetch data */

async function executeAvailabilitySearch() {	
  var url          = "https://neu.brehna.net/auftrag/rates.php";
  var step2Label   = document.getElementById("step2Lable");
  var step3Label   = document.getElementById("step3Lable");
  var step2Content = document.getElementById("ratesResult");
  var btnMenuStep2 = document.getElementById("step2BtnMenu");
  var btnLabel2    = document.getElementById("btnLable2");
  var altMenuBtn   = document.getElementById("altButtonMenu");
	
  promiseData = {
	"postalAddress": {
	  "street"   : document.getElementById("asbStreet").value,
	  "hNr"      : document.getElementById("asbHNr").value,
      "zipcode"  : document.getElementById("asbPlz").value,
	  "place"    : document.getElementById("asbPlace").value,
      "district" : document.getElementById("asbDistrict").value
	},
	"conKind"  : document.querySelectorAll('input[name=conKind]:checked')[0].value,
	"selTech"  : document.querySelectorAll('input[name=checkConTech]:checked')[0].value
  };
	
  contractData  = promiseData;
  postalAddress = promiseData["postalAddress"];
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
	  // set away according to the result of availability check
	  choosenPath = response["ident"];

	  // set labeling step 2 in multi progressbar
      removeChildren(step2Label);
	  setStepProgressbarLable(step2Label, response["step2Lable"]);
	
	  // set labeling step 3 in multi progressbar
      removeChildren(step3Label);
	  setStepProgressbarLable(step3Label, response["step3Lable"]);
		
	  // display form content for step 2
	  if (step2Content != null) {
        removeChildren(step2Content);
	    setStepProgressbarLable(step2Content, response["step2Content"]);
	  }
		
	  // display buttons

	  // display complete button menu
	  btnMenuStep2.style.display = "block";
	  if (btnMenuStep2 != null && choosenPath === 2 || response["show3Btn"]) {
		btnMenuStep2.style.display = "none";  
	  }

	  if (altMenuBtn != null) {
		removeChildren(altMenuBtn);
	  }
		
	  if (choosenPath == 3 && response["btnMenu"] != "") {
		setStepProgressbarLable(altMenuBtn, response["btnMenu"]);
	  }
		
	  // set labeling second button of step 2
	  if (btnLabel2 != null) {
        removeChildren(btnLabel2);
	    setStepProgressbarLable(btnLabel2, response["step2BtnLable"]);
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsg = document.getElementById("cusError");
  if (errMsg != null) {
	errMsg.style.display = "none";
  }
}

async function loadContentForStep3() {
  var url          = '';
  var step3Content = document.getElementById("step3Result");
	
  switch(choosenPath) {
	case 1:
	  url = 'https://neu.brehna.net/auftrag/glass_fibre_customer.php';
	  break;
	case 2:
	  url = 'https://neu.brehna.net/auftrag/rates_customer.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'https://neu.brehna.net/auftrag/glass_fibre_customer.php';
		  break;
		case 2:
		  url = 'https://neu.brehna.net/auftrag/connection_request_customer.php';  
		  break;
	  }
	  break;
	case 4:
	  url = 'https://neu.brehna.net/auftrag/recall.php';
	  break;
  }
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
	  // display form content for step 3
	  if (step3Content != null) {
        removeChildren(step3Content);
	    setStepProgressbarLable(step3Content, response["step3"]);
	  }
		
	  // hide technology address fields
	  var techAddress = document.getElementById("techAddress");
	  if (techAddress != null) {
		techAddress.style.display = response["caDiffAddress"];
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsgRec = document.getElementById("cusErrorRec");
  if (errMsgRec != null) {
	errMsgRec.style.display = "none";
  }
	
  var cusErr2 = document.getElementById("cusError2");
  var cusErr3 = document.getElementById("cusError3");
	
  if (cusErr2 != null) {
	cusErr2.style.display = "none";  
  }
  
  if (cusErr3 != null) {
	cusErr3.style.display = "none";
  }
	
  var cusErr = document.getElementById("cusError");
  if (cusErr != null) {
	cusErr.style.display = "none";  
  }
	
  var gfErrMsg = document.getElementById("gfErrMsg");
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none";  
  }
	
  // display recall sub menu
  var terminRecallMain = document.getElementById("terminRecallMain");
  if (terminRecallMain != null) {
	terminRecallMain.style.display = "none";
  }
}

async function loadContentForStep4() {
  console.log("Hallo");
}

/* validate functions */

function validateAvailibityForm() {	
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");

  for (i = 0; i < requiredInputs.length; i++) { 
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  for (j = 0; j < requiredRadio.length; j++) {
	if (requiredRadio[j].checked) {
	  returnValue = true;
	  break;
	} else {
	  requiredRadio[j].className += " invalid";
	  returnValue = false; 
	}
  }

  if (!returnValue) {
	errorMsg.classList.remove("d-none");
	errorMsg.style.display = "block";
  }

  return returnValue;
}

function validateFormsForStep3() {
  var returnValue      = true;
  var requiredInputs   = document.getElementsByClassName("form-control requiredF");
  var requiredInputsAA = document.getElementsByClassName("form-control requiredAA");
  var errMsg           = document.getElementById("cusError");
	
  for (i = 0; i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }
	
  for (i = 0; i < requiredInputsAA.length; i++) {
    if (requiredInputsAA[i].value == null
	 || requiredInputsAA[i].value == ""
	 || requiredInputsAA[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputsAA[i].className += " invalid";
	}
  }
	
  if (errMsg != null && !returnValue) {
	errMsg.style.display = "block";
  }
	
  return returnValue;
}

function validateFormsForStep4() {
  var returnValue      = true;
  var requiredInputs   = document.getElementsByClassName("form-control requiredF");
  var requiredInputsR  = document.getElementsByClassName("form-control requiredRC");
  var chkCaDiffAddress = document.getElementById("caDiffAddress");
  var alTitle          = document.getElementById("recALTitel");
  var recallTermin     = document.getElementById("terminRecall");
  var birthDay         = document.getElementById("birthDay");
	
  for (i = 0; i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }
	
  for (i = 0; i < requiredInputsR.length; i++) {
    if (requiredInputsR[i].value == null
	 || requiredInputsR[i].value == ""
	 || requiredInputsR[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputsR[i].className += " invalid";
	}
  }
	
  if (chkCaDiffAddress != null && chkCaDiffAddress.checked) {
	var requiredInputsFT  = document.getElementsByClassName("form-control requiredFT");
    var requiredInputsRC1 = document.getElementsByClassName("form-control requiredRC1");
	  
    for (i = 0; i < requiredInputsFT.length; i++) {
      if (requiredInputsFT[i].value == null
	   || requiredInputsFT[i].value == ""
	   || requiredInputsFT[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    requiredInputsFT[i].className += " invalid";
	  }
    }
	  
    for (i = 0; i < requiredInputsRC1.length; i++) {
      if (requiredInputsRC1[i].value == null
	   || requiredInputsRC1[i].value == ""
	   || requiredInputsRC1[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    requiredInputsRC1[i].className += " invalid";
	  }
    }
  }
	
  if (alTitle != null) {
	if (!document.getElementById("reAnswerYes").checked && 
		!document.getElementById("reAnswerNo").checked) {
	  returnValue = false;
	  alTitle.style.color = "ffaba5";
	}
  }

  if (isRecallTerminOpen && (recallTermin.value == ""
						 ||  recallTermin.value.length == 0
						 ||  recallTermin.value == null))
  {
    returnValue = false;
	document.getElementById("terminRecall").className += " invalid";
  }
	
  var gfErrMsg = document.getElementById("gfErrMsg");
  if (gfErrMsg != null && !returnValue) {
	gfErrMsg.style.display = "block";
  }
	
  var cusErrorRec = document.getElementById("cusErrorRec");
  if (cusErrorRec != null && !returnValue) {
	cusErrorRec.style.display = "block";
  }
	
  var cusError2 = document.getElementById("cusError2");
  var cusError3 = document.getElementById("cusError3");

  console.log(returnValue);	

  cusError2.style.display = "none";
  if (cusError2 != null && !returnValue) {
	cusError2.style.display = "block";
  }
  
  isInValidBirth = false;
  if (birthDay.value == "" || birthDay.value == null || birthDay.value.length == 0) {
	birthDay.className += " invalid";
	isInValidBirth = true;
  }	

  if (!returnValue && cusError3 != null && isInValidBirth && cusError2.style.display == "none") {
	cusError3.style.display = "block";
  }

  return returnValue;
}

/* helper functions */ 

function removeChildren(parent) {
  while(parent.hasChildNodes()) {
	parent.removeChild(parent.lastChild);
  }
}

function setStepProgressbarLable(parent, child) {
  parent.insertAdjacentHTML('afterbegin', child);
}

function resetValidateDeclarations() {
  var requiredInputs   = document.getElementsByClassName("form-control required");
  var requiredInputsAA = document.getElementsByClassName("form-control requiredAA");
  var requiredInputsF  = document.getElementsByClassName("form-control requiredF");
  var requiredRadio    = document.getElementsByClassName("required2");
  var chkALTitle       = document.getElementById("recALTitel");
  var recallTermin     = document.getElementById("terminRecall");
  var cusError  = document.getElementById("cusError");
  var cusError3 = document.getElementById("cusError3");
  var cusErrRec = document.getElementById("cusErrorRec");
  var gfErrMsg  = document.getElementById("gfErrMsg");
	
  for (i = 0; i < requiredInputs.length; i++) {
	requiredInputs[i].classList.remove("invalid");
  }
		  
  for (i = 0; i < requiredInputsAA.length; i++) {
    requiredInputsAA[i].classList.remove("invalid");
  }

  for (i = 0; i < requiredInputsF.length; i++) {
    requiredInputsF[i].classList.remove("invalid");
  }
	
  for (j = 0; j < requiredRadio.length; j++) {
	requiredRadio[j].parentNode.children[1].style.color = "#444";
  }
	
  if (chkALTitle != null) {
	chkALTitle.style.color = "black";  
  }

  if (recallTermin != null) {
	recallTermin.classList.remove("invalid");
  }
	
  if (errorMsg != null) {
    errorMsg.style.display = "none";
  }
	
  if (cusError != null) {
	cusError.style.display = "none";
  }
  
  if (cusError3 != null) {
	cusError3.style.display = "none";
  }
	
  if (cusErrRec != null) {
	cusErrRec.style.display = "none"; 
  }
	
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none"; 
  }
}

function backwardToStep1(isToReset = true) {
  if (isToReset) {
	resetValidateDeclarations();
  }

  navigateToFormStep(1);
}

function setchoosenRate(rate) {
  contractData["rateId"] = rate;
  loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentFttHStep3() {
  choosenSubPath = 1;
  await loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentConRequestStep3() {
  choosenSubPath = 2;
  await loadContentForStep3();
  navigateToFormStep(3);
}

/* other functions */

function displayTechAddress() {
  var isCheckedDiffAddress = document.getElementById("caDiffAddress").checked;
  document.getElementById("techAddress").style.display = "none";
  if (isCheckedDiffAddress) {
	document.getElementById("techAddress").style.display = "block";
  }
}

function displayRecallTerminMain(state) {
  isRecallTerminOpen = false;

  document.getElementById("terminRecallMain").style.display = "none";
  if (state == 1) {
	document.getElementById("terminRecallMain").style.display = "block";
	isRecallTerminOpen = true;
  }
}

/*let contractData         = {};

let data                 = {};
let displayAddress       = {};
let defaultAddress       = {};
let technologyAddress    = {};
let technologyOldAddress = {};

var isFormConRequest     = false;
var isValidConRequest    = true;
var isDisplayDiffAddress = false;
var isSameTechAddress    = false;
var isWishRecall         = false;
var isOpenRecallTermin   = false;

var choosenRateId        =  0;
var choosenPath          = -1;

function validateConRequest() {
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control requiredAA");
	
  for (i = 0;i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }
	
  if (!returnValue) {
	document.getElementById("cusError").style.display = "block";  
  }

  return returnValue;
}

function validateCustomerData() {	
  var returnValue   = true;
  var isOver18Years = true;
	
  var requiredInputs  = document.getElementsByClassName("form-control requiredRC");
  var requiredInputs1 = document.getElementsByClassName("form-control requiredRC1");
  var bDayField       = document.getElementById("birthDay");

  for (i = 0;i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  if (isDisplayDiffAddress && document.getElementById("caDiffAddress").checked) {
    for (i = 0;i < requiredInputs1.length; i++) {
      if (requiredInputs1[i].value == null
	   || requiredInputs1[i].value == ""
	   || requiredInputs1[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    requiredInputs1[i].className += " invalid";
	  }
    } 
  }
	
  var cusError2 = document.getElementById("cusError2");
  var cusError3 = document.getElementById("cusError3");
  
  if (cusError2 != null && !returnValue) {
	cusError2.style.display = "block";
  } else if (bDayField != null && returnValue) {
	var ageYears = getAge(bDayField.value);
	  
	if (ageYears < 18) {
	  cusError2.style.display = "none";
	  cusError3.style.display = "block";

	  isOver18Years = false;
	  returnValue   = isOver18Years;
	}
  }
	
  return returnValue;
}

function validateConRequestRecallData() {
  var returnValue  = true;
  var recallTermin = document.getElementById("terminRecall");
  var alTitle      = document.getElementById("recALTitel");
	
  if (!isWishRecall && alTitle != null) {
	returnValue = false;
	alTitle.style.color = "#ffaba5";
  }

  if (isOpenRecallTermin && (recallTermin.value        == null
					     ||  recallTermin.value.length ==    0
						 || recallTermin.value         ==   "")) {
	returnValue = false;
	document.getElementById("terminRecall").className += " invalid";
  }
	
  if (!returnValue) {
	document.getElementById("cusErrorRec").style.display = "block";
  }
	
  return returnValue;
}

async function executeAvailabilitySearch(type = 1) {	
  var url           = "https://neu.brehna.net/auftrag/rates.php";
  var checkedBoxes  = document.querySelectorAll('input[name=checkConTech]:checked');
  var conKind       = document.querySelectorAll('input[name=conKind]:checked');
  var step2Lable    = document.getElementById("step2Lable");
  var step3Lable    = document.getElementById("step3Lable");
  var mspChilds     = document.getElementById("multi-step-form-container").getElementsByTagName("li");
  var activeStepNr  = 0;
	
  for (k = 0; k < mspChilds.length; k++) {
    if (mspChilds[k].classList.contains("form-stepper-active")) {
	  activeStepNr = parseInt(mspChilds[k].getAttribute("step"));
	  break;
	}
  }
	
  if (type == 1) {	  
	defaultAddress = {
	  "street"   : document.getElementById("asbStreet").value,
	  "hNr"      : document.getElementById("asbHNr").value,
      "zipcode"  : document.getElementById("asbPlz").value,
	  "place"    : document.getElementById("asbPlace").value,
      "district" : document.getElementById("asbDistrict").value
    }
  } else {	  
	technologyAddress = {
	  "street"   : document.getElementById("caStreet").value,
	  "hNr"      : document.getElementById("caHNr").value,
      "zipcode"  : document.getElementById("caZipcode").value,
	  "place"    : document.getElementById("caPlace").value,
      "district" : document.getElementById("caDistrict").value
    }
  }
  
  data = {
    "defaultAddress"    : defaultAddress,
	"technologyAddress" : technologyAddress,
	"conKind"           : conKind[0].value,
	"selTech"           : checkedBoxes[0].value,
	"oldTechAddress"    : technologyOldAddress
  }
	
  displayAddress                      = data["defaultAddress"];
  displayAddress["technologyAddress"] = technologyAddress;
	
  // set data to save in database
  contractData["postalAddress"] = {
	"street"   : document.getElementById("asbStreet").value,
	"hNr"      : document.getElementById("asbHNr").value,
    "zipcode"  : document.getElementById("asbPlz").value,
	"place"    : document.getElementById("asbPlace").value,
    "district" : document.getElementById("asbDistrict").value
  };
  contractData["technoAddress"] = technologyAddress;
  contractData["contractCateg"] = data["conKind"];
  contractData["selectedTechn"] = data["selTech"];
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	  // display button "Weiter"
	  document.getElementById("disForward").style.display   = response["displayForward"];
	  // display button "Zurück" (bottom button)
	  document.getElementById("backBtnStep2").style.display = response["backBtnStep2"]
	  
	  choosenPath = response["ident"];
	  isSameTechAddress = JSON.stringify(response["techAddress"]) == 
		                  JSON.stringify(response["oldTechAddress"]);
	  
	  switch(response["ident"]) {
	    case 1:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
	      displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";
		  document.getElementById("btnLable5").style.display = "none";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;
          technologyOldAddress = technologyAddress;

		  break;
	    case 2:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "block";
		  document.getElementById("btnLable3").style.display = "none";
		  document.getElementById("btnLable4").style.display = "block";
		  document.getElementById("btnLable5").style.display = "none";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;
		  technologyOldAddress = technologyAddress;
			  
		  break;
	    case 3:  
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);
		
	      document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";
		  document.getElementById("btnLable5").style.display = "none";
			
		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Rückruf");
			  
		  isFormConRequest = true;
		  document.getElementById("cusError").style.display = "none";
			  
		  break;
		case 4:			  
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);			  		  

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "none";
          document.getElementById("btnLable4").style.display = "none";
		  document.getElementById("btnLable5").style.display = "block";			  

		  isFormConRequest = false;
		  technologyOldAddress = technologyAddress;

		  break;
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadStep3Content(elementId) {	
  var stepLabel  = document.getElementById("step2Lable").innerText;
  var step3      = document.getElementById("step3Result");
  var url        = '';
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(displayAddress)
  }
	
  if (stepLabel == 'Tarife') {
    // path to "Auftragsbestellung"
    url = "https://neu.brehna.net/auftrag/rates_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'disForward' || choosenPath == 4) {
    // path to "Glasfaserhausanschluss"
    url = "https://neu.brehna.net/auftrag/glass_fibre_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'conAS') {
    // path to "Anschlussanfrage"
	url = "https://neu.brehna.net/auftrag/connection_request_customer.php";
  } else {
	// path to "Anschlussanfrage" -- recall
    url      = "https://neu.brehna.net/auftrag/recall.php";
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	if (response) {		
      // remove all children from parent
	  removeChildren(step3);
	  // display form
	  setStepProgressbarLable(step3, response["step3"]);

	  // display 
	  if ("displayTechAddress" in response) {
	    document.getElementById("techAddress").style.display = response["displayTechAddress"];
	  }
		
	  if ("checkTechAddress" in response) {
		document.getElementById("caDiffAddress").checked = response["checkTechAddress"];
	  }
		
	  // display page without error message when loading it for the first time
	  var cusError = document.getElementById("cusError");
	  if (cusError != null) {
		cusError.style.display = "none";
	  }
		
	  var cusError2 = document.getElementById("cusError2");
	  var cusError3 = document.getElementById("cusError3");
	  var cusErrRec = document.getElementById("cusErrorRec");
	  if (cusError2 != null) {
		cusError2.style.display = "none";
	  }

	  if (cusError3 != null) {
		cusError3.style.display = "none";  
	  }
		
	  if (cusErrRec != null) {
		cusErrRec.style.display = "none";  
	  }
		
	  var recallBlock = document.getElementById("terminRecallMain");
	  if (recallBlock != null) {
	    recallBlock.style.display = "none";
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function executeContractPK() {
  var resultStep2 = document.getElementById("ratesResult"); 
  var stepLabel   = document.getElementById("step4Lable");
  var step4       = document.getElementById("step4Result");
  var url         = 'https://neu.brehna.net/auftrag/rates_options.php';
  var district    = '';
  let displayAddress2 = displayAddress;
  delete displayAddress2["technologyAddress"];

  // set data for save in database
  contractData["salutation"]     = document.getElementById("salutation").value;
  contractData["firstName"]      = document.getElementById("fName").value;
  contractData["lastName"]       = document.getElementById("lName").value;
  contractData["birthDate"]      = document.getElementById("birthDay").value;
  contractData["techLocaTAE"]    = document.getElementById("psTae").value;
  contractData["defaultLocaTAE"] = document.getElementById("conTae").value;
  contractData["phone"] = document.getElementById("phone").value;
  contractData["mobil"] = document.getElementById("mobil").value;
  contractData["eMail"] = document.getElementById("mail").value;
	
 /* if (  isDisplayDiffAddress
	|| ( !isSameTechAddress
	&& technologyAddress    != null
	&& technologyOldAddress != null
	&& technologyAddress.length    > 0
	&& technologyOldAddress.length > 0)) {

  }

  if (  isDisplayDiffAddress && technologyAddress != null
    && (JSON.stringify(defaultAddress) == JSON.stringify(technologyAddress))) {
	  
  }
	
  console.log(displayAddress);
  console.log(technologyAddress);
  console.log(technologyOldAddress);
  console.log(isDisplayDiffAddress && technologyAddress != null && (JSON.stringify(displayAddress) == JSON.stringify(technologyAddress)));

  // remove old content
  removeChildren(resultStep2);
	  
  // performed new search and replaced old content from step 2
  await executeAvailabilitySearch(2);
	  
  // go back to step 2
  navigateToFormStep(2);
	
  /*
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }

  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
    if (response) {
	  // remove all childrens from step 4
	  removeChildren(step4);
		
	  // append content to step 4
	  setStepProgressbarLable(step4, response["step4content"]);
		
	  // hide sub menus
	  document.getElementById("phoneSubMenu").style.display = "none";
	  document.getElementById("portingNr"   ).style.display = "none";
		
	  // show main buttons of step 4
	  document.getElmentById("step4ButtonMain").style.display = "block";
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function executeGlassFibreCustomerData() {
  var stepLabel   = document.getElementById("step4Lable");
  var step4       = document.getElementById("step4Result");
  var url         = 'https://neu.brehna.net/auftrag/glass_fibre_connection_data.php';
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	if (response) {
	  // change lable from multi step progressbar step 4
	  removeChildren(stepLabel);
	  setStepProgressbarLable(stepLabel, response["step4label"]);
		
	  // change content from multi step progressbar step 4
	  removeChildren(step4);
	  setStepProgressbarLable(step4, response["step4content"]);
		
	  // show main buttons of step 4
	  document.getElmentById("step4ButtonMain").style.display = "block";
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function executeConRequestRateData() {
  var stepLabel   = document.getElementById("step4Lable");
  var step4       = document.getElementById("step4Result");
  var url         = 'https://neu.brehna.net/auftrag/connection_request_rate.php';
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	if (response) {
	  // change lable from multi step progressbar step 4
	  removeChildren(stepLabel);
	  setStepProgressbarLable(stepLabel, response["step4label"]);
		
	  // change content from multi step progressbar step 4
	  removeChildren(step4);
	  setStepProgressbarLable(step4, response["step4content"]);
		
	  // hide main buttons of step 4
	  document.getElmentById("step4ButtonMain").style.display = "none";
	}
  } catch {
    console.error('Promise rejected');
  }
}

function displayStep2Content(content) {	
  var step = document.getElementById("ratesResult");

  // remove children from parent element
  removeChildren(step);

  // inserts elements inside the element, before its first child
  setStepProgressbarLable(step, content);
}

function forwardStep3(lable = "disForward", rateId = -1) {
  var isValid = validateConRequest();
  var errMsg  = document.getElementById("cusError2");
  var errMsg1 = document.getElementById("cusError3");
	
  if (errMsg != null) {
	errMsg.style.display = "none";
  }
	
  if (errMsg1 != null) {
	errMsg1.style.display = "none";
  }
	
  if (choosenPath == 2 || choosenPath == 4 || isValid) {
	data["rateId"] = rateId;
	contractData["choosenRateId"] = data["rateId"];
	navigateToFormStep(3);
    loadStep3Content(lable);
  }
	
  if (choosenPath == 2 || choosenPath == 4) {
	return true; 
  }

  isValidConRequest = isValid;
	
  return isValidConRequest;
}

function chooseIPAddressOption() {
  // get checkbox elements
  var ipDynamic = document.getElementById("ipDynamic");
  var ipFix     = document.getElementById("ipFix");
	
  // enable checkboxes
  ipDynamic.disabled = false;
  ipFix.disabled     = false;
	
  // disable a checkbox if another is already set
  if (ipDynamic.checked) {
	ipFix.disabled = ipDynamic.checked; 
  } else if (ipFix.checked) {
    ipDynamic.disabled = ipFix.checked;
  }
}

function displaySubmenus(parentId, childId) {
  // get elements
  var chkParent = document.getElementById(parentId);
  var menuChild = document.getElementById(childId);

  // hide child element
  menuChild.style.display = "none";

  // show child if conditions are true
  if (menuChild != null && chkParent.checked) {
    menuChild.style.display = "block";
  }
}

// helper js functions

// calculates age from customer
function getAge(dateString) {
  var today     = new Date();
  var birthDate = new Date(dateString);
	
  var age = today.getFullYear() - birthDate.getFullYear();
  var m   = today.getMonth()    - birthDate.getMonth();
  
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
	
  return age;
} */