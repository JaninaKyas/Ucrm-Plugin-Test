<?php
  if (isset($_POST)){
    $data = file_get_contents("php://input");
    $infos = json_decode($data, true);
	
	// variables for div blocks
	$topDiv            = '';
	$ownAddressDiv     = '';
	$cusAddressDiv     = '';
	$subjectDiv        = '';
	$salutationDiv     = '';
	$introTxtDiv       = '';	
	$pdCustomerDataDiv = '';
	$pdConAddressDiv   = '';
	$pdTariffDiv       = '';
	$pdTariffOptDiv    = '';
	$pdNumberPortDiv   = '';
	$pdHardwareDiv     = '';
	$pdServiceDiv      = '';
	$pdSoftwareDiv     = '';
	$pdContractTermDiv = '';
	$pdSepaDiv         = '';
	$allowedConfirmDiv = '';
	$finshTxtDiv       = '';
	$footerDiv         = '';
	  
	// variables for helper
	$topTitle          = '';
	$address           = '';
	$salutation        = '';
	$orderDate         = date("d.m.Y");
	$adressData        = '';
	$birthDateData     = '';
	$appartmentData    = '';
	$legalFormData     = '';
	$taxIdData         = '';
	$phoneData         = '';
	$mobilData         = '';
	$eMailData         = '';
	$conAddressData    = '';
	$categoryData      = '';
	$tariffeDtailsData = '';
	$tariffPriceData   = '';
	$addTariffOptData  = '';
	$contentData       = '';
	$dataHolderData    = '';
	$debatorData       = '';
	
	// top div
	$topTitle = '<b>Auftrag';
	if ($infos["formType"] == 1) {
	  $topTitle .= ' Privatkunden';
	} else if ($infos["formType"] == 2) {
	  $topTitle .= ' Seniorentarif';
	} else if ($infos["formType"] == 3) {
	  $topTitle .= ' Business Complete';
	}
	$topTitle .= '</b>';
	
	/* if ($infos["contractType"] > 0) {
	  if ($infos["contractType"] == 1) {
	    $topTitle .= '
		  <span class="spanNewline">
		    <b>als Vertrag</b>
		  </span>
		';
	  } else if ($infos["contractType"] == 2) {
	    $topTitle .= '
		  <span class="spanNewline">
		    <b>als Änderung</b>
		  </span>
		';
	  } else if ($infos["contractType"] == 3) {
	    $topTitle .= '
		  <span class="spanNewline">
		    <b>als Vertragsverlängerung</b>
		  </span>
		';
	  }
	} */
	  
	$topDiv = '
	  <div class="row puffer2">
	    <div class="col topTitle">' . $topTitle . '</div>

		<div class="col directionLogo">
	      <img src="https://brehna.net/wp-content/uploads/2023/08/bnet-website-logo.png" class="logo" 
		       alt="logo">
		</div>
	  </div>
	  <hr class="noMargin">
	';
	  
	// own company address div
	$ownAddressDiv = '
	  <div class="row puffer">
	    <div class="col">
		  <span class="spanNewline">Project66 IT Service & Design / Brehna.net</span>
		  <span class="spanNewline">Max-Planck-Str. 2</span>
		  <span class="spanNewline">06796 Brehna</span>
	    </div>
	  </div>
	';
	 
	// customer address div
	if (!empty($infos["company"]) && $infos["company"] != "" && $infos["formType"] == 3) {
	  $address = '
	    <span class="spanNewline">' . $infos["company"]                         . '</span>
	    <span class="spanNewline">' . $infos["fName"]   . ' ' . $infos["lName"] . '</span>
		<span class="spanNewline">' . $infos["street"]  . ' ' . $infos["hNr"]   . '</span>
		<span class="spanNewline">' . $infos["plz"]     . ' ' . $infos["place"] . '</span>';
	} else {
	  $address = '
	    <span class="spanNewline">' . $infos["fName"]  . ' ' . $infos["lName"] . '</span>
		<span class="spanNewline">' . $infos["street"] . ' ' . $infos["hNr"]   . '</span>
		<span class="spanNewline">' . $infos["plz"]    . ' ' . $infos["place"] . '</span>';
	}
	
	if (!empty($infos["district"]) && $infos["district"] != "") {
	  $address .= '<span class="spanNewline">Ortsteil: ' . $infos["district"] . '</span>';
	}
	 
	$cusAddressDiv = '
	  <div class="row puffer marginTopBottom">
	    <div class="col">'
		  . $address .
	   '</div>
	  </div>
	';
	
	// subject div
	$subjectDiv = '
	  <div class="row puffer">
	    <div class="col">
	      <b>Ihre Auftragsbestellung vom ' . $orderDate . '</b>
		</div>
	  </div>
	';
	
	// $salutation div
    if ($infos["salutation"] == 1) {
	  $salutation = 'Sehr geehrter Herr ' . $infos["fName"]  . ' ' . $infos["lName"] . ',';
	} else {
	  $salutation = 'Sehr geehrte Frau '  . $infos["fName"]  . ' ' . $infos["lName"] . ',';
	}
	 
	$salutationDiv = '
	  <div class="row puffer">
	    <div class="col">' . $salutation . '</div>
	  </div>
	';
	
	// intro text div
	$introTxtDiv = '
	  <div class="row puffer">
	    <div class="col">
		  vielen Dank für Ihre Bestellung vom ' . $orderDate . '. Wir freuen uns über Ihren Auftrag. 
		  Die Details entnehmen Sie bitte der folgenden Übersicht:
		</div>
	  </div>
	  <hr class="noMargin">
	';

	// personal customer data div
	$adressData = '
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>Anschrift</b></div>
		<div class="col">' . $address . '</div>
	  </div>
	';
	
	if ($infos["formType"] == 1 || $infos["formType"] == 2) {
	  $birthDate = date_create($infos["birthDay"]);
	  $birthDateData = '
	    <div class="row puffer">
	      <div class="col marginGapLeft"><b>Geburtsdatum</b></div>
	      <div class="col">' . date_format($birthDate,"d.m.Y") . '</div>
	    </div>
	  ';
	
	  if (!empty($infos["whg"]) && $infos["whg"] != "") {
	    $appartmentData = '
		  <div class="row puffer">
	        <div class="col marginGapLeft"><b>Wohnungsnummer</b></div>
		    <div class="col">' . $infos["whg"] . '</div>
	      </div>
		';
	  }
	} else {
	  $legalFormData = '
	    <div class="row puffer">
	      <div class="col marginGapLeft"><b>Rechtsform</b></div>
		  <div class="col">' . $infos["legalFormTxt"] . '</div>
	    </div>
	  ';
		
	  if (!empty($infos["taxId"]) && $infos["taxId"] != "") {
	    $taxIdData = '
		  <div class="row puffer">
	        <div class="col marginGapLeft"><b>Umsatzsteuer-ID</b></div>
		    <div class="col">' . $infos["taxId"] . '</div>
	      </div>
		';
	  }
	}
	
	$phoneData = '
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>Telefon</b></div>
	    <div class="col">' . $infos["conPhone"] . '</div>
	  </div>
	';
	  
	if (!empty($infos["conMobil"]) && $infos["conMobil"] != "") {
	  $mobilData = '
        <div class="row puffer">
	      <div class="col marginGapLeft"><b>Mobil</b></div>
		  <div class="col">' . $infos["conMobil"] . '</div>
	    </div>
	  ';
	}
	  
	$eMailData = '
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>E-Mail</b></div>
		<div class="col">' . $infos["conMail"] . '</div>
	  </div>
	';

	// connection address div
	if ($infos["isConAddress"]) {
	  $conAddressData = '
		<span class="spanNewline">' . $infos["streetAS"] . ' ' . $infos["hNrAS"]   . '</span>
		<span class="spanNewline">' . $infos["plzAS"]    . ' ' . $infos["placeAS"] . '</span>
	  ';
		
	  if (!empty($infos["districtAS"]) && $infos["districtAS"] != "") {
	    $conAddressData .= '<span class="spanNewline">Ortsteil: ' . $infos["districtAS"] . '</span>';
	  }
		
	  $pdConAddressDiv = '
	    <div class="row puffer">
	      <div class="col marginGapLeft"><b>Anschlussadresse</b></div>
		  <div class="col">' . $conAddressData . '  </div>
		</div>
	  ';
	}
	  
	$pdCustomerDataDiv = '
	  <div class="personalData marginTop">
	    <div class="row puffer titelBackgroundColor center">
		  <div class="col"><b>Persönliche Daten</b></div>
		</div>
	' .
	    $adressData      .
		$birthDateData   .
		$appartmentData  .
		$legalFormData   .
		$taxIdData       .
		$phoneData       .
		$mobilData       .
		$eMailData       .
		$pdConAddressDiv . '</div>
      <hr class="noMargin">
	';
	 
	// tariff div
	require __DIR__ . "/model/tariff_queries.php";
	  
	$tariffQueries = new TariffQueries();
    $tariffData    = $tariffQueries->getAllTariffDataById($infos["tariff"]);
	  
	$img = '
	  <img id="internetImg" 
		   src="https://neu.brehna.net/auftragsautomatisierung/public/img/internet.png" 
		   alt="internet">
	';
	  
	if (strpos($tariffData["category"], 'Telefon') != false) {
	  $img .= '
	    <img id="phoneImg" 
			   src="https://neu.brehna.net/auftragsautomatisierung/public/img/phone.png" 
			   alt="phone">
	  ';
	}
	  
	$categoryData = '
	  <span>' . $img . '</span>
	  <br>
	  <span class="pufferLeft"><b>' . $tariffData["category"] . '</b></span>
	';
	
	$tariffTech = '';
	if (!empty($tariffData["techName"]) 
	    && $tariffData["techName"] != '' 
	    && $tariffData["techName"] != null)
	{
      $tariffTech = $tariffData["techName"] . "<br><br>";
	}
	
	$options = '';
	if (!empty($tariffData["tOptions"])
		&& $tariffData["tOptions"] != ''
		&& $tariffData["tOptions"] != null)
	{
      $options = '<ul>';
	
	  $arrOption = explode(",", $tariffData["tOptions"]);
	  for ($i = 0; $i < count($arrOption); $i++) {
	    $options .= '
		  <li>
		    <img id="check"
			 src="https://neu.brehna.net/auftragsautomatisierung/public/img/check-mark-1.png" 
			 alt="check">' . $arrOption[$i] . '
		  </li>
		';
	  }
		
	  $options .= '</ul>';
	}
	  
	$tariffeDtailsData = '
	  <b>' . $tariffData["name"] . '</b>
	  <br><br>' . $tariffTech .
	  '<ul>
	     <li><b>' . $tariffData["downstream"] . '</b> MBit/s max. Download</li>
		 <li><b>' . $tariffData["upStream"]   . '</b> MBit/s max. Upload</li>
	   </ul><br>' . $options;
	
	if (gettype($tariffData["price"]) == "string") {
	  $tariffPriceData = number_format($tariffData["price"], 2, ',', ' ');
	}
	  
	$pdTariffDiv = '
	  <div class="personalData marginTop">
	    <div class="row puffer titelBackgroundColor center">
		  <div class="col"><b>Ausgewählter Tarif</b></div>
		</div>
	    
		<div class="row puffer">
		  <div class="col vlr2">' . $categoryData . '</div>
		  
		  <div class="col vlr2 smFont2">' . $tariffeDtailsData . '</div>
		  <div id="tPri" class="col marginRight"><b>' . $tariffPriceData . ' € pro Monat</b></div>
		</div>
	  </div>
	  <hr class="noMargin">
	';
	
	// additional tariff options div
	if (!empty($infos["optionsGen"]) && $infos["optionsGen"] != "") {
	  require __DIR__ . "/model/tariff_option_queries.php";
		
	  $tariffOptionQueries = new TariffOptionsQueries();
	
	  $optionsData = explode(",", $infos["optionsGen"]);
		
	  for ($od = 0; $od < count($optionsData); $od++) {
	    if ($optionsData[$od] != "") {
		  $data = $tariffOptionQueries->getAllTariffOptionDataById($optionsData[$od]);
		  
		  $firstCol = '<div class="col marginGapLeft"><b>' . $data["name"] . '</b>';
			
		  if (!empty($data["note"]) && $data["note"] != "") {
		    $firstCol .= '<br><span class="smFont2">' . $data["note"] . '</span>';
		  }
		
		  $firstCol .= '</div>';
			
		  $secondCol = '';
		  if ($data["power_down"] > 0 && $data["power_up"] > 0) {
		    $secondCol = '
			  <div class="col smFont2">
			    <ul>
				  <li><b>' . $data["power_down"] . '</b> MBit/s Download</li>
				  <li><b>' . $data["power_up"]   . '</b> MBit/s Download</li>
				</ul>
			  </div>
			';
		  }

		  $contentData .= '
			<div class="row puffer">'
			  . $firstCol
			  . $secondCol
			  . '<div id="tPri" class="col marginRight"><b>' . number_format($data["price"], 2, ',', ' ') . ' € pro Monat</b></div>
			</div>
		  ';
		}
	  }
		
	  $pdTariffOptDiv = '
	    <div class="personalData marginTop">
		  <div class="row puffer titelBackgroundColor center">
		    <div class="col"><b>Tarifoption</b></div>
		  </div>' . $contentData . '
	    </div>
	    <hr class="noMargin">
	  '; 
	}
	
	// phone number portability div
	if ($infos["isRNPortWish"]) {
	  $holderName = $infos["holderName"];
	  if (!empty($infos["holderFName"]) && $infos["holderFName"] != "") {
	    $holderName = $infos["holderFName"] . ' ' . $infos["holderName"];
	  }
		
	  $dataHolderData = '
        <span class="spanNewline">' . $holderName                                          . '</span>
		<span class="spanNewline">' . $infos["holderStreet"] . ' ' . $infos["holderHNr"]   . '</span>
		<span class="spanNewline">' . $infos["holderPLZ"]    . ' ' . $infos["holderPlace"] . '</span>
	  ';
		
	  // phone numbers
	  $phoneNr = '';
	  if (!empty($infos["phone11"]) && $infos["phone11"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' . $infos["phone11"] . '</span>';
	  }
		
	  if (!empty($infos["phone14"]) && $infos["phone14"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone14"] . '</span>';
	  }
		
	  if (!empty($infos["phone17"]) && $infos["phone17"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone17"] . '</span>';
	  }
		
	  if (!empty($infos["phone22"]) && $infos["phone22"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone22"] . '</span>';
	  }
		
	  if (!empty($infos["phone25"]) && $infos["phone25"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone25"] . '</span>';
	  }
		
	  if (!empty($infos["phone28"]) && $infos["phone28"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone28"] . '</span>';
	  }
		
	  if (!empty($infos["phone33"]) && $infos["phone33"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone33"] . '</span>';
	  }
		
	  if (!empty($infos["phone36"]) && $infos["phone36"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone36"] . '</span>';
	  }
		
	  if (!empty($infos["phone39"]) && $infos["phone39"] != "") {
	    $phoneNr .= '<span class="spanNewline">(' . $infos["phoneOnkz1"] . ') ' .  $infos["phone39"] . '</span>';
	  }
		
	  // telecommunications systems
	  $tkSystems = '';
	  if (!empty($infos["tkOnkz"]) && $infos["tkOnkz"] != "") {
	    $tkSystems = '
		  <div class="row puffer subTitelColor center">
			<div class="col"><b>Telekommunikationsanlagen</b></div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col marginGapLeft"><b>Durchwahlrufnummer</b></div>
			<div class="col">' . $infos["tkOnkz"] . '</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col marginGapLeft"><b>Abfragestelle</b></div>
			<div class="col">' . $infos["tkQueryPoint"] . '</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col marginGapLeft"><b>Rufnummernblock</b></div>
			<div class="col">
			  von<br>bis
			</div>
			<div class="col">' . $infos["tkPhoneBlockFrom"] . '<br>' . $infos["tkPhoneBlockTo"] . '</div>
		  </div>
		';
	  }
		
	  $pdNumberPortDiv = '
	    <div class="personalData marginTop">
		  <div class="row puffer titelBackgroundColor center">
		    <div class="col"><b>Rufnummernmitnahme</b></div>
		  </div>
		  
	      <div class="row puffer">
		    <div class="col marginGapLeft"><b>Gegenwärtiger Anbieter</b></div>
		    <div class="col">' . $infos["phoneProvider"] . '</div>
	      </div>
		  
		  <div class="row puffer">
		    <div class="col marginGapLeft"><b>Anschlussinhaber</b></div>
			<div class="col">' . $dataHolderData . '</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col marginGapLeft"><b>Rufnummern</b></div>
			<div class="col">' . $phoneNr . '</div>
		  </div>' . $tkSystems . '
	    </div>
		<hr class="noMargin">
	  ';
	}
	  
	// hardware options div
	if (!empty($infos["optionsHW"]) && $infos["optionsHW"] != "") {
	  require __DIR__ . "/model/hardware_queries.php";
	
	  $hardwareQueries = new HardwareQueries();
		
	  $hardwareData = explode(",", $infos["optionsHW"]);
	  
	  $contentData = '';
	  for ($hd = 0; $hd < count($hardwareData); $hd++) {
	    if ($hardwareData[$hd] != "") {
		  $data = $hardwareQueries->getAllHardwareDataById($hardwareData[$hd]);
		
		  $contentData .= '
		    <div class="row puffer">
			  <div class="col marginGapLeft"><b>'
			    . $data["name"]
			    . '</b><br>'
			    . '<span class="smFont2">' . $data["note"] . '</span>
			  </div>
			  
			  <div id="tPri" class="col marginRight"><b>' . number_format($data["price"], 2, ',', ' ') . ' € pro Monat</b></div>
			</div>
		  ';
		}
	  }
		
	  $pdHardwareDiv = '
	    <div class="personalData marginTop">
		  <div class="row puffer titelBackgroundColor center">
		    <div class="col"><b>Hardware</b></div>
		  </div>' . $contentData . '
		</div>
		<hr class="noMargin">
	  ';
	}
	 
	// service options div
	if (!empty($infos["optionsSV"]) && $infos["optionsSV"] != "") {
	  require __DIR__ . "/model/service_queries.php";
	
	  $servcieQueries = new ServiceQueries();
		
	  $serviceData = explode(",", $infos["optionsSV"]);
		
	  $contentData = '';
      for ($svd = 0; $svd < count($serviceData); $svd++) {
	    if ($serviceData[$svd] != "") {
		  $data = $servcieQueries->getAllServiceDataById($serviceData[$svd]);
		
		  $contentData .= '
		    <div class="row puffer">
			  <div class="col marginGapLeft"><b>'
			    . $data["name"]
			    . '</b><br>'
			    . '<span class="smFont2">' . $data["note"] . '</span>
			  </div>
			  
			  <div id="tPri" class="col marginRight"><b>' . number_format($data["price"], 2, ',', ' ') . ' € pro Monat</b></div>
			</div>
		  ';
		}
	  }
		
	  $pdServiceDiv = '
	    <div class="personalData marginTop">
		  <div class="row puffer titelBackgroundColor center">
		    <div class="col"><b>Dienstleistungen</b></div>
		  </div>' . $contentData . '
		</div>
		<hr class="noMargin">
	  ';
	}
	  
	// software options div
	if (!empty($infos["optionsSW"]) && $infos["optionsSW"] != "") {
	  require __DIR__ . "/model/software_queries.php";
		
	  $softwareQueries = new SoftwareQueries();
		
	  $softwareData = explode(",", $infos["optionsSW"]);
		
	  $contentData = '';
      for ($sd = 0; $sd < count($softwareData); $sd++) {
	    if ($softwareData[$sd] != "") {
		  $data = $softwareQueries->getAllSoftwareDataById($softwareData[$sd]);
		
		  $contentData .= '
		    <div class="row puffer">
			  <div class="col marginGapLeft"><b>'
			    . $data["name"]
			    . '</b><br>'
			    . '<span class="smFont2">' . $data["note"] . '</span>
			  </div>
			  
			  <div id="tPri" class="col marginRight"><b>' . number_format($data["price"], 2, ',', ' ') . ' € pro Monat</b></div>
			</div>
		  ';
		}
	  }
		
	  $pdSoftwareDiv = '
	    <div class="personalData marginTop">
		  <div class="row puffer titelBackgroundColor center">
		    <div class="col"><b>Software</b></div>
		  </div>' . $contentData . '
		</div>
		<hr class="noMargin">
	  ';
	}
	 
	// contract term div
	require __DIR__ . "/model/contract_term_queries.php";
	  
	$contractTermQueries = new ContractTermQueries();
	  
	$data = $contractTermQueries->getAllContractTermsDataById($infos["contractTerm"]);
	  
	$pdContractTermDiv ='
	  <div class="personalData marginTop">
	    <div class="row puffer titelBackgroundColor center">
		  <div class="col"><b>Vertragslaufzeit</b></div>
		</div>
		
		<div class="row puffer">
		  <div id="terms" class="col">min. ' . $data["duration"] . ' Monate ' . $data["term_option"] . '</div>
		</div>
	  </div>
	  <hr class="noMargin">
	';
	 
	// bank account div
	$debatorDataAddress = '
	  <span class="spanNewline">' . $infos["debStreet"] . ' ' .  $infos["debHNr"]   . '</span>
	  <span class="spanNewline">' . $infos["debPLZ"]    . ' ' .  $infos["debPlace"] . '</span>
	';
	
	if (!empty($infos["debDistrict"]) && $infos["debDistrict"] != "") {
	  $debatorDataAddress .= '
	    <span class="spanNewline">Ortsteil: ' . $infos["debDistrict"] . '</span>';
	}
	  
	$debatorDataAddress .= '
	  <span class="spanNewline">' . $infos["debCountry"] . '</span>
	';
	  
	$debatorData = '
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>Kontoinhaber</b></div>
		<div class="col">' . $infos["debName"] . '</div>
	  </div>
	  
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>Rechnungsadresse</b></div>
		<div class="col">' . $debatorDataAddress . '</div>
	  </div>
	  
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>IBAN</b></div>
		<div class="col">' . $infos["debIBAN"] . '</div>
	  </div>
	  
	  <div class="row puffer">
	    <div class="col marginGapLeft"><b>SWIFT BIC</b></div>
		<div class="col">' . $infos["debBIC"] . '</div>
	  </div>
	';
	  
	if ($infos["num1"] == 2) {
	  $debatorData .= '
	    <div class="row puffer">
	      <div class="col marginGapLeft"><b>Versand</b></div>
		  <div class="col">' . $infos["num1Txt"] . '</div>
	    </div>
	  ';
	}
	  
	$pdSepaDiv = '
	  <div class="personalData marginTop">
	    <div class="row puffer titelBackgroundColor center">
		  <div class="col"><b>Bankdaten</b></div>
		</div>' . $debatorData . '
	  </div>
	  <hr class="noMargin">
	';
	  
	// allowed confirm div
	$allowedConfirmDiv = '
	  <div class="personalData marginTop">
	    <div class="row puffer titelBackgroundColor center">
		  <div class="col"><b>Zustimmung Datenschutz und AGB</b></div>
		</div>
		
		<div class="row puffer">
		  <div class="col center">Zustimmung zur Weiterverarbeitung Ihrer Daten liegt vor.</div>
		</div>
		
		<div class="row puffer">
		  <div class="col center">Zustimmung zu den AGB liegt vor.</div>
		</div>
	  </div>
	  <hr class="noMargin">
	';
	
	// finsh text div
	$finshTxtDiv = '
	  <div class="row puffer">
	    <div class="col">
		  Sie haben noch Fragen? Sie erreichen uns von Montag bis Freitag von 8.00 Uhr bis 17.00 Uhr 
		  unter (034954) 524 66 oder per E-Mail <a href="mailto:info@brehna.net">info@brehna.net</a>.
		  <br><br>
		  Wir freuen uns auf die Zusammenarbeit!
		  <br><br>
		  Mit freundlichen Grüßen
		  <br><br>
		  Niels Rosenhahn
		  <br>
		</div>
	  </div>
	  <hr class="noMargin">
	';
	  
	// footer div
	$footerDiv = '
	  <div class="row puffer">
	    <div class="col">
	      <img src="https://brehna.net/wp-content/uploads/2023/08/bnet-website-logo.png" class="logo2" 
		       alt="logo brehna.net">
		</div>
	  
	    <div class="col smFont2 vlr">
		  <span class="spanNewline">Inhaber: Niels Rosenhahn</span>
		  <span class="spanNewline">Max-Planck-Straße 2</span>
		  <span class="spanNewline">06796 Sandersdorf-brehna</span>
		  <span class="spanNewline">Ortsteil: Brehna</span>
		</div>
		
		<div class="col smFont2 vlr">
		  <span class="spanNewline">Telefon: (034954) 524-66</span>
		  <span class="spanNewline">Fax: (034954) 524-67</span>
		  <span class="spanNewline">Web: www.brehna.net</span>
		  <span class="spanNewline">E-Mail: info@brehna.net</span>
		</div>
		
		<div class="col smFont2">
		  <span class="spanNewline">Technischer Notdienst:</span>
		  <span class="spanNewline">(034954) 524-68</span>
		  <span class="spanNewline">Umsatzsteuer-ID:</span>
		  <span class="spanNewline">DE234728145</span>
		</div>
	  </div>
	';
	  
	// main html
	$html = '
	  <div id="summaryContent">'
	  . $topDiv
	  . $ownAddressDiv
	  . $cusAddressDiv
	  . $subjectDiv
	  . $salutationDiv
	  . $introTxtDiv
	  . $pdCustomerDataDiv
	  . $pdTariffDiv
	  . $pdTariffOptDiv
	  . $pdNumberPortDiv
	  . $pdHardwareDiv
	  . $pdServiceDiv
	  . $pdSoftwareDiv
	  . $pdContractTermDiv
	  . $pdSepaDiv
	  . $allowedConfirmDiv
	  . $finshTxtDiv
	  . $footerDiv
	  . '</div>
    ';
	  
	echo json_encode($html);
  }
?>