<?php
  require_once __DIR__ . "/plugins/PDF/dompdf/autoload.inc.php";

  use Dompdf\Dompdf;

  $dompdf = new Dompdf();

  $html = '<h1 style="color: blue;">Hello this from DOM PDF to conver html to PDF</h1>';

  $dompdf->loadHtml($html);
  $dompdf->setPaper('A4', 'portrait');
  $dompdf->render();
  //$dompdf->stream("test.pdf", array('Attachment' => 0));
  $pdf = $dompdf->output();
  file_put_contents("newTest.pdf", $pdf);
?>