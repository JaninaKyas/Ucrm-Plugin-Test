<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class CustomerQueries {
    public function getIdByCustomerData(
	  $postAddressId, $techAddressId, $customerNr, $fName, $lName, $company, $phone, $mobil, $mail
	): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT id FROM customer WHERE isDeleted = 0';
			
		  if ($postAddressId > 0) {
			$query .= ' AND postal_adress_id = ' . $postAddressId;
		  }

		  if ($techAddressId > 0) {
			$query .= ' AND tech_address_id = ' . $techAddressId;
		  }
		  
		  if ($customerNr != '') {
			$query .= ' AND customerNr = ' . $customerNr;
		  }
			
          if ($fName != '') {
			$query .= ' AND fName = ' . $fName; 
		  }

          if ($lName != '') {
			$query .= ' AND lName = ' . $lName; 
		  }

          if ($company != '') {
			$query .= ' AND company = ' . $company; 
		  }

          if ($phone != '') {
			$query .= ' AND phone = ' . $phone;
		  }
		  
          if ($mobil != '') {
			$query .= ' AND mobil = ' . $mobil; 
		  }

          if ($mail != '') {
			$query .= ' AND eMail = ' . $mail; 
		  }
			
		  $result = $connection->query($query);
			
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
    public function saveCustomerData(
	  $postAddressId, $techAddressId, $legalFormId = 1, $customerNr = '',     $salut = '',
	     $title = '',         $fName,           $lName,    $company = '', $birthDate = '',
		 $taxNr = '',    $appNr = '',           $phone,           $mobil, $mail
	): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'INSERT INTO customer 
		            VALUES(null, NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>