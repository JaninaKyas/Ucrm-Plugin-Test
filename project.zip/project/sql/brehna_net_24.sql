INSERT INTO `pricelist_phone_pk` VALUES(null, 1, 2, 'kostenlos', 0.000, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 3, 'Allgemein',                                              0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Auskunft, BT GmbH & co. oHG',                            2.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Behördeneinheitliche Rufnummer',                         0.085, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Freephone',                                              0.000, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Harmonisierte Dienste von sozialem Wert (HDSW)',         0.000, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Internationale Virtuelle Private Netze (0181)',          0.169, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Mobilfunk',                                              0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Nationale Teilnehmerrufnummer',                          0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Notruf',                                                 0.000, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Nutzergruppen',                                          0.169, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Pager',                                                  1.690, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Persönliche Rufnummer',                                  0.250, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1801)',                                 0.095, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1802)',                                 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1803)',                                 0.110, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1804)',                                 0.200, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1805)',                                 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Service-Dienste (1806)',                                 0.200, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Televoting-/ Massenverkehrs-Dienste 0137-[1,5]',         1.090, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Televoting-/ Massenverkehrs-Dienste 0137-[2,3,4], 0138', 1.090, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Televoting-/ Massenverkehrs-Dienste 0137-[8,9]',         1.090, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Televoting-/ Massenverkehrs-Dienste 01376',              1.090, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 2, 1, 'Televoting-/ Massenverkehrs-Dienste 01377',              1.090, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 3, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 3, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 4, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 5, 3, 'Allgemein',    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 5, 1, 'Mobilfunk',    0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 5, 1, 'Premium Rate', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 6, 3, 'Allgemein',                     0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 6, 1, 'Mobilfunk',                     0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 6, 1, 'Nationale Teilnehmerrufnummer', 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 7, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 8, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 9, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 9, 1, 'Mobilfunk', 0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 10, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 10, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 11, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 11, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 12, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 13, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 14, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 14, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 15, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 15, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 16, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 16, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 17, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 17, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 18, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 19, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 19, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 20, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 20, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 21, 3, 'Allgemein',                     0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 21, 1, 'Mobilfunk',                     0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 21, 1, 'Nationale Teilnehmerrufnummer', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 21, 1, 'Pager',                         0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 22, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 23, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 23, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 23, 1, 'Premium Rate', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 24, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 25, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 25, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 26, 3, 'Allgemein',    0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 26, 1, 'Mobilfunk',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES(null, 26, 1, 'Premium Rate', 0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 27, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES(null, 28, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 29, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 30, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 31, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 31, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 32, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 32, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 33, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 33, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 34, 3, 'Allgemein',              0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 34, 1, 'Mobilfunk',              0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 34, 1, 'Mobilfunk, Spezial',     0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 34, 1, 'Rio de Janeiro (Stadt)', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 34, 1, 'São Paulo (Stadt)',      0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 35, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 35, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 36, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 37, 3, 'Allgemein',          0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 37, 1, 'Mobilfunk',          0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 37, 1, 'Mobilfunk, Spezial', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 37, 1, 'Premium Rate',       0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 38, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 38, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 39, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 39, 1, 'Mobilfunk', 0.790, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 40, 3, 'Allgemein',       0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 40, 1, 'Ländlicher Raum', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 40, 1, 'Mobilfunk',       0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 40, 1, 'Premium Rate',    1.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 41, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 41, 1, 'Mobilfunk', 0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 42, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 43, 3, 'Allgemein',          0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 43, 1, 'Mobilfunk',          0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 43, 1, 'Mobilfunk, Spezial', 0.790, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 44, 3, 'Allgemein',          0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 44, 1, 'Freephone',          0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 44, 1, 'Mobilfunk, Spezial', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 45, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 45, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 45, 1, 'Premium Rate', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 46, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 47, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 48, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 48, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 49, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 49, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 49, 1, 'Pager',     0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 50, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 51, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 51, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 52, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 53, 3, 'Allgemein',          0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 53, 1, 'Mobilfunk',          0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 53, 1, 'Mobilfunk, Spezial', 1.270, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 54, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 55, 3, 'Allgemein',             0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 55, 1, 'Mobilfunk',             0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 55, 1, 'Mobilfunk, Spezial',    0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 55, 1, 'Persönliche Rufnummer', 0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 55, 1, 'Premium Rate',          0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 56, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 57, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 57, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 58, 3, 'Allgemein',           0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 58, 1, 'Mobilfunk',           0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 58, 1, 'Nationale Rufnummer', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 58, 1, 'Premium Rate',        0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 3, 'Allgemein',                     0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Freephone',                     0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Ländlicher Raum',               0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Mobilfunk',                     0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Mobilfunk, Spezial',            0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Nationale Teilnehmerrufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 59, 1, 'Premium Rate',                  0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 60, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 60, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 61, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 62, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 62, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 63, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 64, 3, 'Allgemein',       0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 64, 1, 'Ländlicher Raum', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 64, 1, 'Mobilfunk',       0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 64, 1, 'Premium Rate',    1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 65, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 65, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 66, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 66, 1, 'Mobilfunk', 0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 67, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 67, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 68, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 68, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 69, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 69, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 3, 'Allgemein',             0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 1, 'Mobilfunk',             0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 1, 'Mobilfunk, Spezial',    0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 1, 'Pager',                 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 1, 'Persönliche Rufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 70, 1, 'Premium Rate',          0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 3, 'Allgemein',             0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 1, 'Mobilfunk',             0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 1, 'Mobilfunk, Spezial',    0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 1, 'Pager',                 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 1, 'Persönliche Rufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 71, 1, 'Premium Rate',          0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 72, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 72, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 73, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 74, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 75, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 75, 1, 'Mobilfunk',    0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 75, 1, 'Premium Rate', 1.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 76, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 76, 1, 'Mobilfunk',    0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 76, 1, 'Premium Rate', 1.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 77, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 77, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 78, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 79, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 79, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 80, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 80, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 81, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 82, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'AeroMobile',                            8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Deutsche Telekon AG (DTAG)',            8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Ellipso',                               8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Freephone',                             0.000, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Global Networks Switzerland AG',        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Intermatica',                           8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Jersey Telecom',                        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'M2N',                                   8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Maritime Communications Partner (MCP)', 8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'ONAIR GSM',                             8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Oration Technologies, Inc.',            8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Seanet Maritime Communications',        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Vodaphone Malta',                       8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 83, 1, 'Voxbox SA',                             8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 84, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 84, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 85, 3, 'Allgemein',                     0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 85, 1, 'Mobilfunk',                     0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 85, 1, 'Nationale Teilnehmerrufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 85, 1, 'Persönliche Rufnummer',         0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 86, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 86, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 86, 1, 'Pager',     0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 87, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 87, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 88, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 88, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 88, 1, 'Palästina', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 89, 3, 'Allgemein',          0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 89, 1, 'Mobilfunk',          0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 89, 1, 'Mobilfunk, Spezial', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 90, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 90, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 91, 3, 'Allgemein',                     0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 91, 1, 'Mobilfunk',                     0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 91, 1, 'Nationale Teilnehmerrufnummer', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 92, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 92, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 93, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 93, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 94, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 95, 3, 'Allgemein',          0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 95, 1, 'Mobilfunk',          0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 95, 1, 'Mobilfunk, Spezial', 1.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 96, 3, 'Allgemein',       0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 96, 1, 'Ländlicher Raum', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 97, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 97, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 98, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 98, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 99, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 99, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 100, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 101, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 102, 3, 'Allgemein',       0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 102, 1, 'Ländlicher Raum', 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 102, 1, 'Mobilfunk',       0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 103, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 103, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 104, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 104, 1, 'Mobilfunk', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 105, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 106, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 106, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 107, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 108, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 108, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 109, 3, 'Allgemein',          0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 109, 1, 'Mobilfunk',          0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 109, 1, 'Mobilfunk, Spezial', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 110, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 110, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 111, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 112, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 112, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 113, 3, 'Allgemein',    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 113, 1, 'Mobilfunk',    1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 113, 1, 'Premium Rate', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 114, 3, 'Allgemein',             0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 114, 1, 'Freephone',             0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 114, 1, 'Mobilfunk',             0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 114, 1, 'Persönliche Rufnummer', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 114, 1, 'Premium Rate',          0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 115, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 115, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 116, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 116, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 117, 3, 'Allgemein',          0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 117, 1, 'Mobilfunk',          0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 117, 1, 'Mobilfunk, Spezial', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 118, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 118, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 119, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 119, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 120, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 120, 1, 'Mobilfunk',    0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 120, 1, 'Premium Rate', 1.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 121, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 121, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 122, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 122, 1, 'Mobilfunk', 0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 123, 3, 'Allgemein',       0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 123, 1, 'Ländlicher Raum', 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 123, 1, 'Mobilfunk',       0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 123, 1, 'OLO',             0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 124, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 125, 3, 'Allgemein', 0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 125, 1, 'Mobilfunk', 0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 126, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 126, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 127, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 128, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 128, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 129, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 130, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 130, 1, 'Mobilfunk', 0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 131, 3, 'Allgemein',    0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 131, 1, 'Mobilfunk',    0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 131, 1, 'Premium Rate', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 132, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 132, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 133, 3, 'Allgemein',                     0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 133, 1, 'Mobilfunk',                     0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 133, 1, 'Nationale Teilnehmerrufnummer', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 133, 1, 'Premium Rate',                  1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 134, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 135, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 135, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 136, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 137, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 137, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 138, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 139, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 140, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 141, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 141, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 142, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 142, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 143, 3, 'Allgemein',    0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 143, 1, 'Mobilfunk',    0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 143, 1, 'Pager',        2.900, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 143, 1, 'Premium Rate', 2.900, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 144, 3, 'Allgemein', 2.900, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 145, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 146, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 147, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 148, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 149, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 150, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 150, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 151, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 151, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 152, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 153, 3, 'Allgemein',                     0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 153, 1, 'Mobilfunk',                     0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 153, 1, 'Nationale Teilnehmerrufnummer', 0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 153, 1, 'Nutzergruppen',                 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 153, 1, 'Premium Rate',                  0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 154, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 155, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 155, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 156, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 157, 3, 'Allgemein',    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 157, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 157, 1, 'Premium Rate', 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 158, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 159, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 159, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 160, 3, 'Allgemein',       0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 160, 1, 'Ländlicher Raum', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 160, 1, 'Mobilfunk',       0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 161, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 161, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 162, 3, 'Allgemein',    0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 162, 1, 'Mobilfunk',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 162, 1, 'Premium Rate', 0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 163, 3, 'Allgemein',    0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 163, 1, 'Mobilfunk',    0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 163, 1, 'Premium Rate', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 164, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 165, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 165, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 166, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 167, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 167, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 168, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 168, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 169, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 169, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 170, 3, 'Allgemein',    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 170, 1, 'Mobilfunk',    0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 170, 1, 'Premium Rate', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 171, 3, 'Allgemein',       0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 171, 1, 'Ländlicher Raum', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 171, 1, 'Mobilfunk',       0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 172, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 173, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 174, 3, 'Allgemein',    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 174, 1, 'Mobilfunk',    0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 174, 1, 'Premium Rate', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 175, 3, 'Allgemein',       0.050, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 175, 1, 'Ländlicher Raum', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 175, 1, 'Premium Rate',    0.280, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 176, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 176, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 177, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 178, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 178, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 179, 3, 'Allgemein',                     0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 179, 1, 'Mobilfunk',                     0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 179, 1, 'Nationale Teilnehmerrufnummer', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 179, 1, 'Premium Rate',                  1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 180, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 180, 1, 'Mobilfunk', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Ellipso',           8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Emsat',             8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Globalstar',        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat Aero',     8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat B',        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat B HSD',    8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat BGAN',     8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat BGAN HSD', 8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat M',        8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat M4 HSD',   8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Immarsat mini-M',   8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Iridium',           8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 181, 1, 'Thuraya',           8.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 182, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 182, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 183, 3, 'Allgemein',          0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 183, 1, 'Mobilfunk',          0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 183, 1, 'Mobilfunk, Spezial', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 183, 1, 'Nutzergruppen',      0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 183, 1, 'Pager',              0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 184, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 184, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 185, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 185, 1, 'Premium Rate', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 186, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 187, 3, 'Allgemein',                     0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 187, 1, 'Mobilfunk',                     0.790, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 187, 1, 'Nationale Teilnehmerrufnummer', 0.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 188, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 188, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 189, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 190, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 190, 1, 'Mobilfunk', 0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 191, 3, 'Allgemein',                     0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 191, 1, 'Mobilfunk',                     0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 191, 1, 'Mobilfunk, Spezial',            0.480, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 191, 1, 'Nationale Teilnehmerrufnummer', 1.100, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 192, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 193, 3, 'Allgemein',                     0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 193, 1, 'Mobilfunk',                     0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 193, 1, 'Nationale Teilnehmerrufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 193, 1, 'Persönliche Rufnummer',         0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 193, 1, 'Premium Rate',                  0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 194, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 194, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 195, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 196, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 196, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 197, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 197, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 198, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 198, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 199, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 200, 3, 'Allgemein',                    0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 200, 1, 'Mobilfunk',                    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 200, 1, 'National Teilnehmerrufnummer', 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 200, 1, 'Premium Rate',                 0.830, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 201, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 202, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 203, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 203, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 204, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 204, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 205, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 205, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 206, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 206, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 207, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 207, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 208, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 208, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 209, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 210, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 211, 3, 'Allgemein', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 212, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 213, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 213, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 214, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 214, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 215, 3, 'Allgemein',          0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 215, 1, 'Freephone',          0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 215, 1, 'Mobilfunk',          0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 215, 1, 'Mobilfunk, Spezial', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 215, 1, 'Premium Rate',       0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 216, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 216, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 3, 'Allgemein',                     0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 1, 'Mobilfunk',                     0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 1, 'Mobilfunk, Spezial',            0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 1, 'Nationale Teilnehmerrufnummer', 0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 1, 'Nordzypern',                    0.500, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 217, 1, 'Nordzypern, Mobilfunk',         0.220, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 218, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 219, 3, 'Allgemein',    0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 219, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 220, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 221, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 221, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 221, 1, 'Premium Rate', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 222, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 222, 1, 'Mobilfunk', 0.310, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 223, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 223, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 224, 3, 'Allgemein', 0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 224, 1, 'Mobilfunk', 0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 225, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 225, 1, 'Mobilfunk',    1.270, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 225, 1, 'Premium Rate', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 226, 1, 'VISIONng', 4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 227, 3, 'Allgemein', 0.140, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 227, 1, 'Mobilfunk', 0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 228, 3, 'Allgemein', 0.120, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 229, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 230, 3, 'Allgemein', 0.021, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 230, 1, 'Mobilfunk', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 231, 3, 'Allgemein', 0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 232, 3, 'Allgemein',    0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 232, 1, 'Alaska',       0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 232, 1, 'Freephone',    0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 232, 1, 'Hawaii',       0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 232, 1, 'Premium Rate', 2.900, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 233, 3, 'Allgemein', 0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 233, 1, 'Mobilfunk', 0.800, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 234, 3, 'Allgemein',    4.000, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 235, 3, 'Allgemein',    0.450, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 235, 1, 'Mobilfunk',    0.580, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 235, 1, 'Premium Rate', 1.350, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 236, 3, 'Allgemein',    0.820, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 236, 1, 'Premium Rate', 1.600, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);

INSERT INTO `pricelist_phone_pk` VALUES (null, 237, 3, 'Allgemein',             0.016, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 237, 1, 'Mobilfunk',             0.210, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `pricelist_phone_pk` VALUES (null, 237, 1, 'Persönliche Rufnummer', 0.530, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);