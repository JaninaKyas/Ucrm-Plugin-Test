<?php
  declare(strict_types = 1);

  class ErrorMessage {
    public $message = '';
	public $dClass  = false;
	public $msgId   = 'asbErrorMsg';
	
	public function __construct($newMsg, $displayClass = false, $newId = 'asbErrorMsg') {
	  $this->message = $newMsg;
	  $this->dClass  = $displayClass;
	  $this->msgId   = $newId;
	}
	  
	public function buildErrorDiv() {
	  return '<div id="asbErrorMsg" class="d-none">
          <div class="row">
	        <div class="col">
	          <div class="alert alert-danger" role="alert">
		        <img id="errorImg"
			         src="https://neu.brehna.net/auftrag/public/images/error-5.png" alt="errorMsg">
		        <span>' . $this->message . '</span>
	          </div>
	        </div>
          </div>
        </div>';
	}
	  
	public function buildErrorDiv2() {
	  return '<div id="' . $this->msgId . '" class="blockDiv">
          <div class="row">
	        <div class="col">
	          <div class="alert alert-danger" role="alert">
		        <img id="errorImg"
			         src="https://neu.brehna.net/auftrag/public/images/error-5.png" alt="errorMsg">
		        <span>' . $this->message . '</span>
	          </div>
	        </div>
          </div>
        </div>';
	}
  }
?>