<?php

namespace RouterOS\Exceptions;

/**
 * Class ConfigException
 *
 * @package RouterOS\Exceptions
 * @since   0.4
 */
class ConfigException extends \Exception
{
}
