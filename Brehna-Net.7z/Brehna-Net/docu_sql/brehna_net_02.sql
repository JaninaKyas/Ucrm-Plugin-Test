--
-- Tabellenstruktur für Tabelle `contract_state`
--

CREATE TABLE IF NOT EXISTS `contract_state` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(100)           NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `contract_state`
--

INSERT INTO `contract_state` VALUES(null, '... bitte auswählen ...', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_state` VALUES(null, 'neu',                     NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_state` VALUES(null, 'in Bearbeitung',          NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_state` VALUES(null, 'aktiv',                   NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_state` VALUES(null, 'inaktiv',                 NOW(), 'JANINA', NOW(), 'JANINA', 0);