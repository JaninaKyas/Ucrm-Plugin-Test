<div>
  <div class="form-header d-flex mb-4">
    <span class="stepIndicator">Kundendaten</span>
    <span class="stepIndicator">CPE</span>
    <span class="stepIndicator">DSL</span>
    <span class="stepIndicator">Internet</span>
    <span class="stepIndicator">Messdaten</span>
    <span class="stepIndicator">Störung</span>
    <span class="stepIndicator">Router</span>
    <span class="stepIndicator">Ursache/ Lösung</span>    
  </div>

  <div class="step"><?php require(__DIR__ . '/customer.php');            ?></div>
  <div class="step"><?php require(__DIR__ . '/cpe.php');                 ?></div>
  <div class="step"><?php require(__DIR__ . '/dsl_snyc.php');            ?></div>
  <div class="step"><?php require(__DIR__ . '/internet_connection.php'); ?></div>
  <div class="step"><?php require(__DIR__ . '/measurement_data.php');    ?></div>
  <div class="step"><?php require(__DIR__ . '/interference.php');        ?></div>
  <div class="step"><?php require(__DIR__ . '/router.php');              ?></div>
  
  <div class="step">     
     <?php require(__DIR__ . '/recover.php'); ?>
     
     <span id="typeCo" class="displayBlock">Test Komplett    </span>
     <span id="typeIn" class="displayBlock">Test Internet    </span>
     <span id="typePh" class="displayBlock">Test Telefon     </span>
     <span id="typeTQ" class="displayBlock">Test TV Queis    </span>
     <span id="typeTL" class="displayBlock">Test TV Landsberg</span>
     <span id="typeTB" class="displayBlock">Test TV beliebig </span>
  </div>

  <div class="form-footer d-flex">
    <button type="button" id="searchB" style="background-color: #FD7660;" onclick="returnToSearchForm()">Suche</button>
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>
</div>
