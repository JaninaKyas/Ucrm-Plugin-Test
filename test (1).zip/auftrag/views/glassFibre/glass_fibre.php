<?php
  declare(strict_types = 1);

  require __DIR__ . "/forms/customer.php";

  class GlassFibre {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
 
	public function buildDescription() {
	  $returnValue = '
	    <div>
		  <div class="row">
		    <div class="col">
			  <div class="alert alert-danger" role="alert">
			    <img id="errorImg"
				     src="https://neu.brehna.net/auftrag/public/images/error-5.png" alt="errorMsg">
			    Die von Ihnen angegebene Adresse konnte nicht gefunden werden.
			  </div>
			  <br>
			  <div class="alert alert-primary" role="alert">
				<span class="dirLeft">
				<b>ACHTUNG!</b><br> Sie haben nun aber die Alternative über uns einen 
				Glasfaserhausanschluss FttH via Mikrorohrsystems zu beantragen oder senden Sie uns eine 
				Anschluss-Anfrage.  
				</span>
			  </div>
			</div>
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
	  
    public function getGlasFibreTemplate(): string {
	  $customer = new Customer($this->templateData, $this->values);		
	  return $customer->buildCustomerTemplate();
	}
  }
?>