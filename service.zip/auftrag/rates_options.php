<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	$content = array();
	  
	require __DIR__ . "/model/tariff_options.php";
	require __DIR__ . "/views/rates/forms/options/private_customer_options.php";
	
	$rateOptionsQueries = new TariffOptionsQueries();
	$optionReRate = $rateOptionsQueries->getAllOptionsRegardlessOfRateForPK();
	$optionDeRate = $rateOptionsQueries->getAllOptionsDependingOnRatesForPK();
	  
	$templateData = array(
	  "ipAddress" => array("ipDynamic", "ipFix", "phDefault", "phSip", "phAllnet", "phPorting"),
	  "phPorting" => array(
		"provider"   => "curProvider",
		"dataholder" => array("dhFName", "dhLName", "dhStreet", "dhHNr", "dhZipcode", "dhPlace"),
		"numbers"    => array(
		   "onkz"     => "nrOnkz",
		   "nrPhones" => array(
			  "phone1", "phone2", "phone3", "phone4", "phone5", "phone6", "phone7", "phone7", "phone8", 
			  "phone9"
		   )
	    ),
		"tkSystem" => array("directDial", "queryPoint", "nbFrom", "nbTo")
	  )
	);
	  
	$rateOptionsTemplate = new PrivateCustomerOptions($templateData, $optionReRate, $optionDeRate);
	$content["step4content"] = $rateOptionsTemplate->buildOptionsPKTemplate();
	  
	echo json_encode($content);
  }
?>