---
name: Bug report
about: Create a report to help us improve
title: ''
labels: bug
assignees: EvilFreelancer

---

**Version of RouterOS**
Please describe on which version of RouterOS your issue is occurring.

**To Reproduce**
Sample of code to reproduce the behavior.

**Expected behavior**
A clear and concise description of what you expected to happen.
