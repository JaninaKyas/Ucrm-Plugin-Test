<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class TariffOptionsQueries {
    public function getAllOptionsRegardlessOfRateForPK(): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT
			  id,
			  name,
			  price,
			  note
			FROM tariff_option
			WHERE isDeleted         =  0
			  AND customer_class_id =  2
			  OR  id                = 15";

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
    public function getAllOptionsDependingOnRatesForPK(): string {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT GROUP_CONCAT(DISTINCT(top.name) SEPARATOR \", \") AS options
		    FROM      tariff_option          AS top
			LEFT JOIN tariff_x_tariff_option AS txtop ON txtop.tariff_option_id = top.id
			WHERE top.isDeleted         = 0
			  AND txtop.isDeleted       = 0
			  AND top.customer_class_id = 2";

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue[0]["options"];
	}
  }
?>