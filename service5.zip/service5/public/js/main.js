// global variables
// array values
let contractData       = {};
let promiseData        = {};
let postalAddress      = {};
let techAddress        = {
  "isDiffAddress": "",
  "street"       : "",
  "hnr"          : "",
  "zipcode"      : "",
  "place"        : "",
  "district"     : ""
};
let currentTechAddress = {
  "isDiffAddress": "",
  "street"       : "",
  "hnr"          : "",
  "zipcode"      : "",
  "place"        : "",
  "district"     : ""
};
// booleans
var isFormValid        = true;
var isWishRecall       = false;
var isRecallTerminOpen = false;
var isDiffAddress      = false;
// decision variables
var choosenPath        =   -1;
var choosenSubPath     =   -1;
var stepDirection      =    0;
// elements
var errorMsg           = document.getElementById("asbErrorMsg");

const navigateToFormStep = (stepNumber) => {
  document.querySelectorAll(".form-step").forEach((formStepElement) => {
    formStepElement.classList.add("d-none");
  });

  document.querySelectorAll(".form-stepper-list").forEach((formStepHeader) => {
    formStepHeader.classList.add("form-stepper-unfinished");
    formStepHeader.classList.remove("form-stepper-active", "form-stepper-completed");
  });

  document.querySelector("#step-" + stepNumber).classList.remove("d-none");

  const formStepCircle = document.querySelector('li[step="' + stepNumber + '"]');
  
  if (formStepCircle != null)  {
  formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-completed");
  formStepCircle.classList.add("form-stepper-active");

  for (let index = 0; index < stepNumber; index++) {
    const formStepCircle = document.querySelector('li[step="' + index + '"]');
    if (formStepCircle) {
      formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-active");
      formStepCircle.classList.add("form-stepper-completed");
    }
  }  
  }
};

document.querySelectorAll(".btn-navigate-form-step").forEach((formNavigationBtn) => {
  formNavigationBtn.addEventListener("click", () => {
    const stepNumber = parseInt(formNavigationBtn.getAttribute("step_number"));
	stepDirection    = parseInt(formNavigationBtn.getAttribute("step_direction"));

	if (stepDirection === 1) {
	  switch(stepNumber) {
	    case 2:
	      isFormValid = validateAvailibityForm();

		  if (isFormValid) {
		    executeAvailabilitySearch();
		  }
		  break;
	    case 3:
		  isFormValid = validateFormsForStep3();

		  if (isFormValid) {
			setContractCustomerData();
		    loadContentForStep3();
		  }
		  break;
	    case 4:
		  isFormValid = validateFormsForStep4();

		  if (isFormValid) {
	        setContractCustomerData();
			
			if (isDiffAddress && !isAddressIdentic(techAddress, currentTechAddress)) {
              goBackToStep2();
			  isFormValid = false;
			} else {
			  loadContentForStep4();	
			}  
		  }
		  break;
	    case 5:
		  isFormValid = validateFormsForStep5();

		  if (isFormValid) {
			setContractCustomerData();
			loadContentForStep5();
		  }

		  break;
	    case 6:
		  isFormValid = validateFormsForStep6();

		  if (isFormValid) {
			setContractCustomerData();
			loadContentForStep6();
		  }
			  
		  break;
		case 7:
		  isFormValid = validateFormsForStep7();

		  if (isFormValid) {
			setContractCustomerData();
			loadContentForStep7();
		  }
  
		  break;
	    case 8:
		  isFormValid = validateFormsForStep8();
		  
		  if (isFormValid) {
			setContractCustomerData();
			console.log(contractData);
			loadContentForStep8();
		  }
		  
		  break;
	  }
	}

	if (stepDirection === -1) {
	  resetValidateDeclarations();
	}

	if (isFormValid) {
      navigateToFormStep(stepNumber);
	}
  });
});

/* promise fetch data */

async function executeAvailabilitySearch() {	
  var url          = "http://localhost/service5/rates.php";
  
  var step2Label   = document.getElementById("step2Lable");
  var step3Label   = document.getElementById("step3Lable");
  var step4Lable   = document.getElementById("step4Lable");
  var step5Lable   = document.getElementById("step5Lable");
  var step6Lable   = document.getElementById("step6Lable");
  var step7Lable   = document.getElementById("step7Lable");
  var step8Lable   = document.getElementById("step8Lable");
  var step2Content = document.getElementById("ratesResult");
  var btnMenuStep2 = document.getElementById("step2BtnMenu");
  var btnLabel2    = document.getElementById("btnLable2");
  var altMenuBtn   = document.getElementById("altButtonMenu");
	
  promiseData = {
	"postalAddress": {
	  "street"   : document.getElementById("asbStreet").value,
	  "hNr"      : document.getElementById("asbHNr").value,
      "zipcode"  : document.getElementById("asbPlz").value,
	  "place"    : document.getElementById("asbPlace").value,
      "district" : document.getElementById("asbDistrict").value
	},
	"conKind"  : document.querySelectorAll('input[name=conKind]:checked')[0].value,
	"selTech"  : document.querySelectorAll('input[name=checkConTech]:checked')[0].value
  };

  contractData = promiseData;
  promiseData["techAddress"] = currentTechAddress;
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
    if (response) {
	  isWishRecall = false;

	  // set away according to the result of availability check
	  choosenPath = response["ident"];

	  // set labeling step 2 in multi progressbar
      removeChildren(step2Label);
	  setStepProgressbarLable(step2Label, response["step2Lable"]);
	
	  // set labeling step 3 in multi progressbar
      removeChildren(step3Label);
	  setStepProgressbarLable(step3Label, response["step3Lable"]);
		
	  // set labeling step 4 in multi progressbar
      removeChildren(step4Lable);
	  setStepProgressbarLable(step4Lable, response["step4Lable"]);
		
	  // set labeling step 5 in multi progressbar
      removeChildren(step5Lable);
	  setStepProgressbarLable(step5Lable, response["step5Lable"]);
		
	  // set labeling step 6 in multi progressbar
      removeChildren(step6Lable);
	  setStepProgressbarLable(step6Lable, response["step6Lable"]);
		
	  // set labeling step 7 in multi progressbar
      removeChildren(step7Lable);
	  setStepProgressbarLable(step7Lable, response["step7Lable"]);
		
	  // set labeling step 8 in multi progressbar
      removeChildren(step8Lable);
	  setStepProgressbarLable(step8Lable, response["step8Lable"]);
		
	  // display form content for step 2
	  if (step2Content != null) {
        removeChildren(step2Content);
	    setStepProgressbarLable(step2Content, response["step2Content"]);
	  }
		
	  // display buttons

	  // display complete button menu
	  btnMenuStep2.style.display = "block";
	  if (btnMenuStep2 != null && choosenPath === 2 || response["show3Btn"]) {
		btnMenuStep2.style.display = "none";  
	  }

	  if (altMenuBtn != null) {
		removeChildren(altMenuBtn);
	  }
		
	  if (choosenPath == 3 && response["btnMenu"] != "") {
		setStepProgressbarLable(altMenuBtn, response["btnMenu"]);
	  }
		
	  // set labeling second button of step 2
	  if (btnLabel2 != null) {
        removeChildren(btnLabel2);
	    setStepProgressbarLable(btnLabel2, response["step2BtnLable"]);
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsg = document.getElementById("cusError");
  if (errMsg != null) {
	errMsg.style.display = "none";
  }
}

async function loadContentForStep3() {
  var url          = '';
  var step3Content = document.getElementById("step3Result");
	
  var step3Label   = document.getElementById("step3Lable");
  var step4Lable   = document.getElementById("step4Lable");
  var step5Lable   = document.getElementById("step5Lable");
  var step6Lable   = document.getElementById("step6Lable");
  var step7Lable   = document.getElementById("step7Lable");
  var step8Lable   = document.getElementById("step8Lable");
	
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/service5/glass_fibre_customer.php';
	  break;
	case 2:
	  url = 'http://localhost/service5/rates_customer.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/service5/glass_fibre_customer.php';
		  break;
		case 2:
		  url = 'http://localhost/service5/connection_request_customer.php';  
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/service5/recall.php';
	  break;
  }
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
  	  // set lable for sub path 2
	  if (choosenSubPath === 2) {
	    // set labeling step 3 in multi progressbar
        removeChildren(step3Label);
	    setStepProgressbarLable(step3Label, "Kundendaten");
		  
	    // set labeling step 4 in multi progressbar
        removeChildren(step4Lable);
	    setStepProgressbarLable(step4Lable, "Rückruf");
		  
	    // set labeling step 5 in multi progressbar
        removeChildren(step5Lable);
	    setStepProgressbarLable(step5Lable, "Tarif");
		  
	    // set labeling step 6 in multi progressbar
        removeChildren(step6Lable);
	    setStepProgressbarLable(step6Lable, "Optionen");
		
	    // set labeling step 7 in multi progressbar
        removeChildren(step7Lable);
	    setStepProgressbarLable(step7Lable, "Nachricht");
	  }
		
	  // display form content for step 3
	  if (step3Content != null) {
        removeChildren(step3Content);
	    setStepProgressbarLable(step3Content, response["step3"]);
	  }
		
	  // hide technology address fields
	  var techAddress = document.getElementById("techAddress");
	  if (techAddress != null) {
		techAddress.style.display = response["caDiffAddress"];
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsgRec = document.getElementById("cusErrorRec");
  if (errMsgRec != null) {
	errMsgRec.style.display = "none";
  }
	
  var cusErr2 = document.getElementById("cusError2");
  var cusErr3 = document.getElementById("cusError3");
	
  if (cusErr2 != null) {
	cusErr2.style.display = "none";  
  }
  
  if (cusErr3 != null) {
	cusErr3.style.display = "none";
  }
	
  var cusErr = document.getElementById("cusError");
  if (cusErr != null) {
	cusErr.style.display = "none";  
  }
	
  var gfErrMsg = document.getElementById("gfErrMsg");
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none";  
  }
	
  // display recall sub menu
  var terminRecallMain = document.getElementById("terminRecallMain");
  if (terminRecallMain != null) {
	terminRecallMain.style.display = "none";
  }
}

async function loadContentForStep4() {
  var url          = '';
  var step4Result  = document.getElementById("step4Result");
  
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/service5/glass_fibre_connection_data.php';
	  break;
	case 2:
	  url = 'http://localhost/service5/rates_options.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/service5/glass_fibre_connection_data.php';
		  break;
		case 2:
		  url = 'http://localhost/service5/recall.php';  
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/service5/connection_request_rate.php';
	  break;
  }
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
      if (step4Result != null) {
        removeChildren(step4Result);
	    setStepProgressbarLable(step4Result, response["step4content"]);
	  }
		
	  // hide sub menus
	  var phoneSubMenu = document.getElementById("phoneSubMenu");
	  var portingNr    = document.getElementById("portingNr"   );
		
	  if (phoneSubMenu != null) {
		phoneSubMenu.style.display = "none";
	  }
	  
	  if (portingNr != null) {
		portingNr.style.display = "none"; 
	  }
		
	  var cusErrorRec = document.getElementById("cusErrorRec");
	  if (cusErrorRec != null) {
		cusErrorRec.style.display = "none";
	  }
		
	  var terminRecallMain = document.getElementById("terminRecallMain");
	  if (terminRecallMain != null && choosenSubPath == 2) {
		terminRecallMain.style.display = "none";
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadContentForStep5() {
  var url          = '';
  var subPath      = -1;
  var step5Result  = document.getElementById("step5Result");

  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/service5/glas_fibre_property.php';
	  break;
	case 2:
	  url = 'http://localhost/service5/rates_konto_contract.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/service5/glas_fibre_property.php';
		  break;
		case 2:
		  url = 'http://localhost/service5/connection_request_rate.php';
		  subPath = 2;
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/service5/connection_request_primary_care.php';
	  break;
  }

  promiseData["customer"] = contractData["customer"];
  promiseData["subPath"]  = subPath;
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {	
	  // display content step 5
      if (step5Result != null) {
        removeChildren(step5Result);
	    setStepProgressbarLable(step5Result, response["step5content"]);
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadContentForStep6() {
  var url          = '';
  var subPath      = -1;
  var step6Result  = document.getElementById("step6Result");
	
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/service5/glass_fibre_konto.php';
	  break;
	case 2:
	  url = 'http://localhost/service5/rate_agb.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/service5/glass_fibre_konto.php';
		  break;
		case 2:
		  url = 'http://localhost/service5/connection_request_options.php';
		  subPath = 2;
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/service5/connection_request_options.php';
	  break;
  }

  promiseData = contractData;
  promiseData["subPath"] = subPath;
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
      if (step6Result != null) {
        removeChildren(step6Result);
	    setStepProgressbarLable(step6Result, response["step6content"]);
	  }
		
	  // hide numerically sub menu
	  var numDurationBox = document.getElementById("numDurationBox");
	  if (numDurationBox != null) {
		numDurationBox.style.display = "none";  
	  }
		
	  var pkErrAgb = document.getElementById("pkErrAgb");
	  if (pkErrAgb != null) {
		pkErrAgb.style.display = 'none';
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadContentForStep7() {
  var url          = '';
  var step7Result  = document.getElementById("step7Result");
  
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/service5/glass_fibre_agb.php';
	  break;
	case 2:
	  url = 'http://localhost/service5/';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/service5/glass_fibre_agb.php';
		  break;
		case 2:
		  url = 'http://localhost/service5/connection_request_message.php';  
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/service5/connection_request_message.php';
	  break;
  }

  promiseData = contractData;
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
      if (step7Result != null) {
        removeChildren(step7Result);
	    setStepProgressbarLable(step7Result, response["step7content"]);
	  }
	  
	  var ftthErrAgb = document.getElementById("ftthErrAgb");
	  if (ftthErrAgb != null) {
		ftthErrAgb.style.display = "none";
	  }
	  
	  var errMsgAGB = document.getElementById("errMsgAGB");
	  if (errMsgAGB != null) {
		errMsgAGB.style.display = "none";
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadContentForStep8() {
  var url          = 'http://localhost/service5/confirm.php';
  var step8Result  = document.getElementById("step8Result");

  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
      if (step8Result != null) {
        removeChildren(step8Result);
	    setStepProgressbarLable(step8Result, response["step8content"]);
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

/* validate functions */

function validateAvailibityForm() {	
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");

  for (i = 0; i < requiredInputs.length; i++) { 
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  for (j = 0; j < requiredRadio.length; j++) {
	if (requiredRadio[j].checked) {
	  returnValue = true;
	  break;
	} else {
	  requiredRadio[j].className += " invalid";
	  returnValue = false; 
	}
  }

  if (!returnValue) {
	errorMsg.classList.remove("d-none");
	errorMsg.style.display = "block";
  }

  return returnValue;
}

function validateFormsForStep3() {
  var returnValue      = true;

  var inputRequiredF = document.getElementsByClassName("form-control requiredF");
  var caDiffAddress  = document.getElementById("caDiffAddress");
  var inputRequiredFt = document.getElementsByClassName("form-control requiredFT");
  var gfErrMsg = document.getElementById("gfErrMsg");

  var inputRequiredAA = document.getElementsByClassName("form-control requiredAA");
  var cusError        = document.getElementById("cusError");

  for (i = 0;i < inputRequiredF.length; i++) {
    if (inputRequiredF[i].value == null
	 || inputRequiredF[i].value == ""
	 || inputRequiredF[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredF[i].className += " invalid";
	}
  }

  if (caDiffAddress != null && caDiffAddress.checked) {
    for (i = 0;i < inputRequiredFt.length; i++) {
      if (inputRequiredFt[i].value == null
	   || inputRequiredFt[i].value == ""
	   || inputRequiredFt[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    inputRequiredFt[i].className += " invalid";
	  }
    }
  }

  for (i = 0;i < inputRequiredAA.length; i++) {
    if (inputRequiredAA[i].value == null
	 || inputRequiredAA[i].value == ""
	 || inputRequiredAA[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredAA[i].className += " invalid";
	}
  }

  if (gfErrMsg != null && !returnValue) {
	gfErrMsg.style.display = "block";
  }
  
  if (cusError != null && !returnValue) {
	cusError.style.display = "block";  
  }

  return returnValue;
}

function validateFormsForStep4() {
  var returnValue      = true;

  var inputRequiredF = document.getElementsByClassName("form-control requiredF");
  var caDiffAddress  = document.getElementById("caDiffAddress");
  var inputRequiredFt = document.getElementsByClassName("form-control requiredFT");
  var gfErrMsg = document.getElementById("gfErrMsg");

  var inputRequiredRC = document.getElementsByClassName("form-control requiredRC");
  var birthDay = document.getElementById("birthDay");
  var cusError2 = document.getElementById("cusError2");
  var cusError3 = document.getElementById("cusError3");

  var inputRequiredAA = document.getElementsByClassName("form-control requiredAA");
  var cusError = document.getElementById("cusError");

  for (i = 0;i < inputRequiredF.length; i++) {
    if (inputRequiredF[i].value == null
	 || inputRequiredF[i].value == ""
	 || inputRequiredF[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredF[i].className += " invalid";
	}
  }

  if (caDiffAddress != null && caDiffAddress.checked) {
    for (i = 0;i < inputRequiredFt.length; i++) {
      if (inputRequiredFt[i].value == null
	   || inputRequiredFt[i].value == ""
	   || inputRequiredFt[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    inputRequiredFt[i].className += " invalid";
	  }
    }
  }

  for (i = 0;i < inputRequiredRC.length; i++) {
    if (inputRequiredRC[i].value == null
	 || inputRequiredRC[i].value == ""
	 || inputRequiredRC[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredRC[i].className += " invalid";
	}
  }

  if (gfErrMsg != null && !returnValue) {
	gfErrMsg.style.display = "block";
  }

  if (!isWishRecall) {
	var recALTitel  = document.getElementById("recALTitel");
	var cusErrorRec = document.getElementById("cusErrorRec");
	
	if (recALTitel != null) {
	  returnValue = false;
	  recALTitel.style.color = "#ffaba5";
	}
  }
	
  if (cusErrorRec != null && !returnValue) {
	cusErrorRec.style.display = "block";
  }

  if (cusError2 != null && !returnValue) {
    cusError2.style.display = "block";
  }

  if (birthDay != null && getAge(birthDay.value) < 18) {
	returnValue = false;  
  }

  if (!returnValue && cusError3 != null && cusError2.style.display == 'none') {
	cusError2.style.display = "none";
    cusError3.style.display = "block";
  }

  for (i = 0;i < inputRequiredAA.length; i++) {
    if (inputRequiredAA[i].value == null
	 || inputRequiredAA[i].value == ""
	 || inputRequiredAA[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredAA[i].className += " invalid";
	}
  }

  if (cusError != null && !returnValue) {
	cusError.style.display = "block";  
  }

  return returnValue;
}

function validateFormsForStep5() {
  var returnValue = true;
	
  if (!isWishRecall) {
	var recALTitel  = document.getElementById("recALTitel");
	var cusErrorRec = document.getElementById("cusErrorRec");
	
	if (recALTitel != null) {
	  returnValue = false;
	  recALTitel.style.color = "#ffaba5";
	}
  }
	
  var cusErrorRec = document.getElementById("cusErrorRec");
  if (cusErrorRec != null && !returnValue) {
	cusErrorRec.style.display = "block"; 
  }
	
  return returnValue;
}

function validateFormsForStep6() {
  var returnValue = true;
	
  var inputRequiredGE = document.getElementsByClassName("requiredGE");
  var inputRequiredPK = document.getElementsByClassName("form-control requiredSepaPK");
	
  for (i = 0;i < inputRequiredGE.length; i++) {
    if (inputRequiredGE[i].value == null
	 || inputRequiredGE[i].value == ""
	 || inputRequiredGE[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredGE[i].className += " invalid";
	}
  }
	
  for (i = 0;i < inputRequiredPK.length; i++) {
    if (inputRequiredPK[i].value == null
	 || inputRequiredPK[i].value == ""
	 || inputRequiredPK[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredPK[i].className += " invalid";
	}
  }
	
  return returnValue;
}

function validateFormsForStep7() {
  var returnValue = true;
	
  var inputRequiredFttH = document.getElementsByClassName("form-control requiredSepaFtth");
  var pkErrAgb          = document.getElementById("pkErrAgb");
	
  for (i = 0;i < inputRequiredFttH.length; i++) {
    if (inputRequiredFttH[i].value == null
	 || inputRequiredFttH[i].value == ""
	 || inputRequiredFttH[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredFttH[i].className += " invalid";
	}
  }
	
  var checkProcessData = document.getElementById("checkProcessData");
  var checkAGB         = document.getElementById("checkAGB");
  if (checkProcessData != null && checkAGB != null && !checkProcessData.checked && !checkAGB.checked) {
	pkErrAgb.style.display = 'block';
	returnValue = false;
  }
	
  return returnValue;
}

function validateFormsForStep8() {
  var returnValue = true;
  var checkProcessData = document.getElementById("checkProcessData");
  var checkAGB         = document.getElementById("checkAGB");
  var ftthErrAgb       = document.getElementById("ftthErrAgb");
  var errMsgAGB        = document.getElementById("errMsgAGB");
  
  if (checkProcessData != null && checkAGB != null && !checkProcessData.checked && !checkAGB.checked) {
	returnValue = false;
    if (ftthErrAgb != null) {
	  ftthErrAgb.style.display = "block";
	}	
  }
  
  if (checkProcessData != null && !checkProcessData.checked) {
	returnValue = false;
    if (errMsgAGB != null) {
	  errMsgAGB.style.display = "block";
	}	
  }
	
  return returnValue;
}

/* helper functions */ 

function removeChildren(parent) {
  while(parent.hasChildNodes()) {
	parent.removeChild(parent.lastChild);
  }
}

function setStepProgressbarLable(parent, child) {
  parent.insertAdjacentHTML('afterbegin', child);
}

function resetValidateDeclarations() {
  var requiredInputs    = document.getElementsByClassName("form-control required");
  var requiredInputsAA  = document.getElementsByClassName("form-control requiredAA");
  var requiredInputsF   = document.getElementsByClassName("form-control requiredF");
  var requiredInputsFt  = document.getElementsByClassName("form-control requiredFT");
  var inputRequiredGE   = document.getElementsByClassName("requiredGE");
  var inputRequiredFttH = document.getElementsByClassName("form-control requiredSepaFtth");
  var requiredRadio     = document.getElementsByClassName("required2");
  var inputRequiredPK   = document.getElementsByClassName("form-control requiredSepaPK");
  var chkALTitle        = document.getElementById("recALTitel");
  var checkProcessData  = document.getElementById("checkProcessData");
  var checkAGB          = document.getElementById("checkAGB");
  var recallTermin      = document.getElementById("terminRecall");
  var cusError          = document.getElementById("cusError");
  var cusError3         = document.getElementById("cusError3");
  var cusErrRec         = document.getElementById("cusErrorRec");
  var gfErrMsg          = document.getElementById("gfErrMsg");
  var ftthErrAgb        = document.getElementById("ftthErrAgb");
  var pkErrAgb          = document.getElementById("pkErrAgb");
  var errMsgAGB         = document.getElementById("errMsgAGB");
	
  for (i = 0; i < requiredInputs.length; i++) {
	requiredInputs[i].classList.remove("invalid");
  }
		  
  for (i = 0; i < requiredInputsAA.length; i++) {
    requiredInputsAA[i].classList.remove("invalid");
  }

  for (i = 0; i < requiredInputsF.length; i++) {
    requiredInputsF[i].classList.remove("invalid");
  }

  for (i = 0; i < requiredInputsFt.length; i++) {
    requiredInputsFt[i].classList.remove("invalid");
  }
	
  for (j = 0; j < requiredRadio.length; j++) {
	requiredRadio[j].parentNode.children[1].style.color = "#444";
  }
	
  for (j = 0;j < inputRequiredGE.length; j++) {
    inputRequiredGE[j].classList.remove("invalid");
  }
	
  for (j = 0;j < inputRequiredFttH.length; j++) {
    inputRequiredFttH[j].classList.remove("invalid");
  }
	
  for (i = 0;i < inputRequiredPK.length; i++) {
    inputRequiredPK[i].classList.remove("invalid");
  }
	
  if (chkALTitle != null) {
	chkALTitle.style.color = "black";  
  }

  if (checkProcessData != null && checkAGB != null) {
	  
  }
	
  if (recallTermin != null) {
	recallTermin.classList.remove("invalid");
  }
	
  if (errorMsg != null) {
    errorMsg.style.display = "none";
  }
	
  if (cusError != null) {
	cusError.style.display = "none";
  }
  
  if (cusError3 != null) {
	cusError3.style.display = "none";
  }
	
  if (cusErrRec != null) {
	cusErrRec.style.display = "none"; 
  }
	
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none"; 
  }
  
  if (ftthErrAgb != null) {
	ftthErrAgb.style.display = "none";   
  }
	
  if (pkErrAgb != null) {
	pkErrAgb.style.display = "none";  
  }
  
  if (errMsgAGB != null) {
	errMsgAGB.style.display = "none";  
  }
}

function backwardToStep1(isToReset = true) {
  if (isToReset) {
	resetValidateDeclarations();
  }

  navigateToFormStep(1);
}

function goBackToStep2(isToReset = true) {
  if (isToReset) {
	resetValidateDeclarations();
  }

  executeAvailabilitySearch();
  navigateToFormStep(2);
}

function setchoosenRate(rate) {
  contractData["rateId"] = rate;
  loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentFttHStep3() {
  var step4Lable = document.getElementById("step4Lable");
	
  removeChildren(step4Lable);
  setStepProgressbarLable(step4Lable, "Anschluss");
	
  choosenSubPath = 1;
  await loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentConRequestStep3() {
  var step4Lable = document.getElementById("step4Lable");
	
  removeChildren(step4Lable);
  setStepProgressbarLable(step4Lable, "Rückruf");
	
  choosenSubPath = 2;
  await loadContentForStep3();
  navigateToFormStep(3);
}

// calculates age from customer
function getAge(dateString) {
  var today     = new Date();
  var birthDate = new Date(dateString);
	
  var age = today.getFullYear() - birthDate.getFullYear();
  var m   = today.getMonth()    - birthDate.getMonth();
  
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
	
  return age;
}

/* set contract data */

function setContractCustomerData() {
contractData["choosenPath"]    = choosenPath;
contractData["choosenSubPath"] = choosenSubPath;
	
  switch(choosenPath) {
    case 1:
	  techAddress = currentTechAddress;
	
	  contractData["customer"] = {
		"salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"company"  : (document.getElementById("companyFttH") != null)? document.getElementById("companyFttH").value : '',
		"phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  };
	  
	  contractData["techAddress"] = {
        "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		"street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		"hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		"zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		"place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		"district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : ''
	  };
	  
	  currentTechAddress = contractData["techAddress"];
	  isDiffAddress = contractData["techAddress"]["isDiffAddress"];
	  
	  // Connection point typ
	  contractData["conPointTyp"] = {
	    "kindConPoint": (document.querySelector('input[name="typeCon"]:checked') != null)? document.querySelector('input[name="typeCon"]:checked').value : -1,
		"cntUnits": (document.getElementById("inMfhWe") != null)? document.getElementById("inMfhWe").value:  0,
		"completionDate": (document.getElementById("inFinishTermin") != null)? document.getElementById("inFinishTermin").value: ''
	  };

	  // house introduction
	  contractData["introHouse"] = {
	    "ihTyp": (document.querySelector('input[name="introHouse"]:checked') != null)? document.querySelector('input[name="introHouse"]:checked').value: -1,
	    "else": (document.getElementById("addElse") != null)? document.getElementById("addElse").value : ''
	  };
	  
      // rate
      contractData["rate"] = (document.getElementById("ftthRateSel") != null)? document.getElementById("ftthRateSel").value : -1
	  
	  // house owners
	  contractData["hoData"] = {
	    "title": (document.getElementById("chTitle") != null)? document.getElementById("chTitle").value : '',
	    "fName": (document.getElementById("chFName") != null)? document.getElementById("chFName").value : '',
		"lName": (document.getElementById("chLName") != null)? document.getElementById("chLName").value : '',
		"company": (document.getElementById("chCompany") != null)?document.getElementById("chCompany").value : '',
		"street": (document.getElementById("chStreet") != null)?document.getElementById("chStreet").value : '',
		"hnr": (document.getElementById("chStreet") != null)? document.getElementById("chHNr").value : '',
		"zipcode": (document.getElementById("chZipcode") != null)?document.getElementById("chZipcode").value : '',
		"place": (document.getElementById("chPlace") != null)? document.getElementById("chPlace").value : '',
		"district": (document.getElementById("chDistrict") != null)?document.getElementById("chDistrict").value : '',
		"hrNumber": (document.getElementById("chHRNr") != null)? document.getElementById("chHRNr").value : '',
		"phone": (document.getElementById("chPhone") != null)? document.getElementById("chPhone").value : '',
		"mobil": (document.getElementById("chMobil") != null)? document.getElementById("chMobil").value : '',
		"mail": (document.getElementById("chMobil") != null)? document.getElementById("chMail").value : '',
		"fFloor": (document.getElementById("chMobil") != null)? document.getElementById("chFloor").value : '',
		"fFloorKind": (document.getElementById("chFloorKind") != null)? document.getElementById("chFloorKind").value : '',
		"fDFloor": (document.getElementById("chFloorDistrict") != null)? document.getElementById("chFloorDistrict").value : '',
		"fStreet": (document.getElementById("chFloorStreet") != null)? document.getElementById("chFloorStreet").value : '',
		"fHNr": (document.getElementById("chFloorHNR") != null)? document.getElementById("chFloorHNR").value : '',
		"fZipcode": (document.getElementById("chFloorZipcode") != null)? document.getElementById("chFloorZipcode").value : '',
		"fPlace": (document.getElementById("chFloorPlace") != null)? document.getElementById("chFloorPlace").value : '',
		"fDistrict": (document.getElementById("chFloorPlace") != null)? document.getElementById("chFlDistrict").value : ''
	  };
		
	  // konto data
	  contractData["sepaData"] = {
		"mainNum" : (document.querySelector('input[name="sepaFCon"]:checked') != null)? document.querySelector('input[name="sepaFCon"]:checked').value : -1,
		"subNum"  : (document.querySelector('input[name="sepaFCon1"]:checked') != null)? document.querySelector('input[name="sepaFCon1"]:checked').value : -1,
		"name"    : (document.getElementById("debatorName") != null)? document.getElementById("debatorName").value : '',
		"street"  : (document.getElementById("debatorStreet") != null)? document.getElementById("debatorStreet").value : '',
		"hnr"     : (document.getElementById("debatorHNr") != null)? document.getElementById("debatorHNr").value : '',
		"zipcode" : (document.getElementById("debatorPlz") != null)? document.getElementById("debatorPlz").value : '',
		"place"   : (document.getElementById("debatorPlace") != null)? document.getElementById("debatorPlace").value : '',
		"district": (document.getElementById("debatorDistrict") != null)? document.getElementById("debatorDistrict").value : '',
		"country" : (document.getElementById("debatorCountry") != null)? document.getElementById("debatorCountry").value : '',
		"iban"    : (document.getElementById("debatorIban") != null)? document.getElementById("debatorIban").value : '',
		"bic"     : (document.getElementById("debatorBic") != null)? document.getElementById("debatorBic").value : ''
	  };
	  
	  // agb and data safe
	  contractData["agb"] = 1;
	  contractData["safeKeepinData"] = 1;
	  
	  break;
	case 2:
	  techAddress = currentTechAddress;
	  
	  contractData["customer"] = {
		"salut"    : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"    : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"    : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"birthDay" : (document.getElementById("birthDay")   != null)? document.getElementById("birthDay").value   : '',
		"psTae"    : (document.getElementById("psTae")      != null)? document.getElementById("psTae").value      : '',
		"phone"    : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"    : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"     : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  };
	  
	  contractData["techAddress"] = {
        "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		"street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		"hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		"zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		"place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		"district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : '',
		"conTae":        (document.getElementById("conTae")        != null)? document.getElementById("conTae").value          : ''
	  };
	  
	  // options data
	  var ipValue = -1;
      if (document.getElementById("ipDynamic") != null && document.getElementById("ipDynamic").checked) {
		ipValue = document.getElementById("ipDynamic").value;
	  }
	  
	  if (document.getElementById("ipFix") != null && document.getElementById("ipFix").checked) {
		ipValue = document.getElementById("ipFix").value;  
	  }

      var phoneDefault = -1;
	  var cntAddSIP    =  0;
	  var cntAllnet    =  0;
		  
	  if (document.getElementById("phDefault") != null && document.getElementById("phDefault").checked) {
		phoneDefault = document.getElementById("phDefault").value;
		  
		if (document.getElementById("phSip").value != null && document.getElementById("phSip").value != "" && document.getElementById("phSip").value.length > 0) {
		  cntAddSIP = document.getElementById("phSip").value;
		}
		
		if (document.getElementById("phAllnet").value != null && document.getElementById("phAllnet").value != "" && document.getElementById("phAllnet").value.length > 0) {
  cntAllnet = document.getElementById("phAllnet").value;			
		}
	  }

      let portingPhoneData = {};
	  if (document.getElementById("phPorting") != null && document.getElementById("phPorting").checked) {
  portingPhoneData = {
    "porting"    : 15,
	"curProvider": document.getElementById("curProvider").value,
	"dataHolder" : {
	  "fName"  : document.getElementById("dhFName").value,
	  "lName"  : document.getElementById("dhLName").value,
	  "street" : document.getElementById("dhStreet").value,
	  "hnr"    : document.getElementById("dhHNr").value,
	  "zipcode": document.getElementById("dhZipcode").value,
	  "place"  : document.getElementById("dhPlace").value
	},
    "phoneNr": {
      "onkz"  : document.getElementById("nrOnkz").value,
	  "phone1": document.getElementById("phone1").value,
	  "phone2": document.getElementById("phone2").value,
	  "phone3": document.getElementById("phone3").value,
	  "phone4": document.getElementById("phone4").value,
	  "phone5": document.getElementById("phone5").value,
	  "phone6": document.getElementById("phone6").value,
	  "phone7": document.getElementById("phone7").value,
	  "phone8": document.getElementById("phone8").value,
	  "phone9": document.getElementById("phone9").value
    },
	"tkSystems": {
	  "directNr"   : document.getElementById("directDial").value,
	  "queryPoint" : document.getElementById("queryPoint").value,
	  "rnBlockFrom": document.getElementById("nbFrom").value,
	  "rnBlockTo"  : document.getElementById("nbTo").value
	}
  };  
	  }		  

      var serComfort = -1;
      if (document.getElementById("serComfort") != null && document.getElementById("serComfort").checked) {
		serComfort = document.getElementById("serComfort").value;
	  }

      let hardware = {};
	  if (document.getElementById("hw-2") != null && document.getElementById("hw-2").checked) {
		hardware["hw-2"] = document.getElementById("hw-2").value;
	  }
	  
	  if (document.getElementById("hw-3") != null && document.getElementById("hw-3").checked) {
		hardware["hw-3"] = document.getElementById("hw-3").value;  
	  }

      var tv = -1;
      if (document.getElementById("isChooseTv") != null && document.getElementById("isChooseTv").checked) {
		tv = document.getElementById("isChooseTv").value; 
	  }

      contractData["options"] = {
	    "ipAddress"       : ipValue,
		"phoneDefault"    : phoneDefault,
		"cntAddSIP"       : cntAddSIP,
		"cntAllnet"       : cntAllnet,
		"portingPhoneData": portingPhoneData,
		"lineFee"         : 7,
		"deployPrice"     : 4,
		"serviceComfort"  : serComfort,
		"hardware"        : hardware,
		"tvOption"        : tv
	  };

	  currentTechAddress = contractData["techAddress"];
	  isDiffAddress = contractData["techAddress"]["isDiffAddress"];
	
      // konto
	  contractData["wishTermin"] = (document.getElementById("contractBegin") != null)? document.getElementById("contractBegin").value : '';
	  contractData["duration"] = (document.querySelector('input[name="durMonth"]:checked') != null)? document.querySelector('input[name="durMonth"]:checked').value : -1;
	  contractData["invoicePost"] = (document.getElementById("numAddPost") != null && document.getElementById("numAddPost").checked)? document.getElementById("numAddPost").value : -1;
		  
      // konto sepa
	  contractData["sepaData"] = {
		"name"    : (document.getElementById("debatorName") != null)? document.getElementById("debatorName").value : '',
		"street"  : (document.getElementById("debatorStreet") != null)? document.getElementById("debatorStreet").value : '',
		"hnr"     : (document.getElementById("debatorHNr") != null)? document.getElementById("debatorHNr").value : '',
		"zipcode" : (document.getElementById("debatorPlz") != null)? document.getElementById("debatorPlz").value : '',
		"place"   : (document.getElementById("debatorPlace") != null)? document.getElementById("debatorPlace").value : '',
		"district": (document.getElementById("debatorDistrict") != null)? document.getElementById("debatorDistrict").value : '',
		"country" : (document.getElementById("debatorCountry") != null)? document.getElementById("debatorCountry").value : '',
		"iban"    : (document.getElementById("debatorIban") != null)? document.getElementById("debatorIban").value : '',
		"bic"     : (document.getElementById("debatorBic") != null)? document.getElementById("debatorBic").value : ''
	  };
		  
	  // agb
	  contractData["agb"] = 1;
	  contractData["safeKeepinData"] = 1;

	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
	  techAddress = currentTechAddress;
	
	  contractData["customer"] = {
		"salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"company"  : (document.getElementById("companyFttH") != null)? document.getElementById("companyFttH").value : '',
		"phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  };
	  
	  contractData["techAddress"] = {
        "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		"street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		"hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		"zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		"place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		"district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : ''
	  };
	  
	  currentTechAddress = contractData["techAddress"];
	  isDiffAddress = contractData["techAddress"]["isDiffAddress"];
	  
	  // Connection point typ
	  contractData["conPointTyp"] = {
	    "kindConPoint": (document.querySelector('input[name="typeCon"]:checked') != null)? document.querySelector('input[name="typeCon"]:checked').value : -1,
		"cntUnits": (document.getElementById("inMfhWe") != null)? document.getElementById("inMfhWe").value:  0,
		"completionDate": (document.getElementById("inFinishTermin") != null)? document.getElementById("inFinishTermin").value: ''
	  };

	  // house introduction
	  contractData["introHouse"] = {
	    "ihTyp": (document.querySelector('input[name="introHouse"]:checked') != null)? document.querySelector('input[name="introHouse"]:checked').value: -1,
	    "else": (document.getElementById("addElse") != null)? document.getElementById("addElse").value : ''
	  };
	  
      // rate
      contractData["rate"] = (document.getElementById("ftthRateSel") != null)? document.getElementById("ftthRateSel").value : -1;
	  
	  // house owners
	  contractData["hoData"] = {
	    "title": (document.getElementById("chTitle") != null)? document.getElementById("chTitle").value : '',
	    "fName": (document.getElementById("chFName") != null)? document.getElementById("chFName").value : '',
		"lName": (document.getElementById("chLName") != null)? document.getElementById("chLName").value : '',
		"company": (document.getElementById("chCompany") != null)?document.getElementById("chCompany").value : '',
		"street": (document.getElementById("chStreet") != null)?document.getElementById("chStreet").value : '',
		"hnr": (document.getElementById("chStreet") != null)? document.getElementById("chHNr").value : '',
		"zipcode": (document.getElementById("chZipcode") != null)?document.getElementById("chZipcode").value : '',
		"place": (document.getElementById("chPlace") != null)? document.getElementById("chPlace").value : '',
		"district": (document.getElementById("chDistrict") != null)?document.getElementById("chDistrict").value : '',
		"hrNumber": (document.getElementById("chHRNr") != null)? document.getElementById("chHRNr").value : '',
		"phone": (document.getElementById("chPhone") != null)? document.getElementById("chPhone").value : '',
		"mobil": (document.getElementById("chMobil") != null)? document.getElementById("chMobil").value : '',
		"mail": (document.getElementById("chMobil") != null)? document.getElementById("chMail").value : '',
		"fFloor": (document.getElementById("chMobil") != null)? document.getElementById("chFloor").value : '',
		"fFloorKind": (document.getElementById("chFloorKind") != null)? document.getElementById("chFloorKind").value : '',
		"fDFloor": (document.getElementById("chFloorDistrict") != null)? document.getElementById("chFloorDistrict").value : '',
		"fStreet": (document.getElementById("chFloorStreet") != null)? document.getElementById("chFloorStreet").value : '',
		"fHNr": (document.getElementById("chFloorHNR") != null)? document.getElementById("chFloorHNR").value : '',
		"fZipcode": (document.getElementById("chFloorZipcode") != null)? document.getElementById("chFloorZipcode").value : '',
		"fPlace": (document.getElementById("chFloorPlace") != null)? document.getElementById("chFloorPlace").value : '',
		"fDistrict": (document.getElementById("chFloorPlace") != null)? document.getElementById("chFlDistrict").value : ''
	  };
		
	  // konto data
	  contractData["sepaData"] = {
		"mainNum" : (document.querySelector('input[name="sepaFCon"]:checked') != null)? document.querySelector('input[name="sepaFCon"]:checked').value : -1,
		"subNum"  : (document.querySelector('input[name="sepaFCon1"]:checked') != null)? document.querySelector('input[name="sepaFCon1"]:checked').value : -1,
		"name"    : (document.getElementById("debatorName") != null)? document.getElementById("debatorName").value : '',
		"street"  : (document.getElementById("debatorStreet") != null)? document.getElementById("debatorStreet").value : '',
		"hnr"     : (document.getElementById("debatorHNr") != null)? document.getElementById("debatorHNr").value : '',
		"zipcode" : (document.getElementById("debatorPlz") != null)? document.getElementById("debatorPlz").value : '',
		"place"   : (document.getElementById("debatorPlace") != null)? document.getElementById("debatorPlace").value : '',
		"district": (document.getElementById("debatorDistrict") != null)? document.getElementById("debatorDistrict").value : '',
		"country" : (document.getElementById("debatorCountry") != null)? document.getElementById("debatorCountry").value : '',
		"iban"    : (document.getElementById("debatorIban") != null)? document.getElementById("debatorIban").value : '',
		"bic"     : (document.getElementById("debatorBic") != null)? document.getElementById("debatorBic").value : ''
	  };
	  
	  // agb and data safe
	  contractData["agb"] = 1;
	  contractData["safeKeepinData"] = 1;
		
		  break;
		case 2:
	      contractData["customer"] = {
		    "salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		    "fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		    "lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		    "company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		    "phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		    "mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		    "mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	      };

          // recall
		  var reAnswerYes = document.getElementById("reAnswerYes");
		  var reCallWish  = 0;
		  if (reAnswerYes != null) {
			 reCallWish = 1;
		  }

          var terminRecall = document.getElementById("terminRecall");
		  var termin       = "";
		  if (terminRecall != null) {
			termin = terminRecall.value;
		  }

          contractData["recall"] = {
			"isWish": reCallWish,
			"termin": termin
		  };

          // rate
          contractData["rate"] = (document.getElementById("ftthRateSel") != null)? document.getElementById("ftthRateSel").value : -1;
		  
		  // primary technology care
		  contractData["techCare"] = (document.querySelector('input[name="techKindCare"]:checked') != null)? document.querySelector('input[name="techKindCare"]:checked').value : -1;
		  
		  // options
          contractData["porting"]    = (document.getElementById("conRequestPort")    != null && document.getElementById("conRequestPort").checked )? 1 : 0;
          contractData["phone"]      = (document.getElementById("conRequestPhone")   != null && document.getElementById("conRequestPhone").checked)? 1 : 0;
          contractData["careTermin"] = (document.getElementById("primaryCareTermin") != null)?  document.getElementById("primaryCareTermin") : "";		  
		  
		  // request message text
		  contractData["message"]  = (document.getElementById("txtConRequestMsg") != null)? document.getElementById("txtConRequestMsg").value : "";
		  contractData["safeData"] = 1;
		  
		  break;
	  }
	
	  break;
	case 4:
	  contractData["customer"] = {
		"salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		"phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  };

      // recall
	  var reAnswerYes = document.getElementById("reAnswerYes");
	  var reCallWish  = 0;
	  if (reAnswerYes != null && reAnswerYes.checked) {
		reCallWish = 1;
	  }

      var terminRecall = document.getElementById("terminRecall");
	  var termin       = "";
	  if (terminRecall != null) {
	    termin = terminRecall.value;
	  }

      contractData["recall"] = {
	    "isWish": reCallWish,
		"termin": termin
	  };

      // rate
      contractData["rate"] = (document.getElementById("ftthRateSel") != null)? document.getElementById("ftthRateSel").value : -1;
		  
	  // primary technology care
	  contractData["techCare"] = (document.querySelector('input[name="techKindCare"]:checked') != null)? document.querySelector('input[name="techKindCare"]:checked').value : -1;
		  
	  // options
      contractData["porting"]    = (document.getElementById("conRequestPort")    != null && document.getElementById("conRequestPort").checked )? 1 : 0;
      contractData["phone"]      = (document.getElementById("conRequestPhone")   != null && document.getElementById("conRequestPhone").checked)? 1 : 0;
      contractData["careTermin1"] = (document.getElementById("primaryCareTermin") != null)?  document.getElementById("primaryCareTermin").value : "";		  
		  
	  // request message text
	  contractData["message"]  = (document.getElementById("txtConRequestMsg") != null)? document.getElementById("txtConRequestMsg").value : "";
	  contractData["safeData"] = 1;
	  
	  // rate
	  contractData["conRequestRate"] = (document.getElementById("conRequestRate") != null)? document.getElementById("conRequestRate").value : -1;
		  
	  break;
  }
}

function isAddressIdentic(tAddress, ctAddress) {
  var returnValue = true;
  
  if ( (tAddress["street"]   !== ctAddress["street"])
	|| (tAddress["hnr"]      !== ctAddress["hnr"])
    || (tAddress["zipcode"]  !== ctAddress["zipcode"])
	|| (tAddress["place"]    !== ctAddress["place"])
	|| (tAddress["district"] !== ctAddress["district"])) {
    returnValue = false;
  }
  
  return returnValue;
}

/* other functions */

function displayTechAddress() {
  var isCheckedDiffAddress = document.getElementById("caDiffAddress").checked;
  document.getElementById("techAddress").style.display = "none";
  if (isCheckedDiffAddress) {
	document.getElementById("techAddress").style.display = "block";
  }
}

function displayRecallTerminMain(state) {
  isRecallTerminOpen = false;
  isWishRecall       = true;

  document.getElementById("terminRecallMain").style.display = "none";
  if (state == 1) {
	document.getElementById("terminRecallMain").style.display = "block";
	isRecallTerminOpen = true;
  }
}

function displaySubmenus(parentId, childId) {
  // get elements
  var chkParent = document.getElementById(parentId);
  var menuChild = document.getElementById(childId);

  // hide child element
  menuChild.style.display = "none";

  // show child if conditions are true
  if (menuChild != null && chkParent.checked) {
    menuChild.style.display = "block";
  }
}

function chooseIPAddressOption() {
  // get checkbox elements
  var ipDynamic = document.getElementById("ipDynamic");
  var ipFix     = document.getElementById("ipFix");
	
  // enable checkboxes
  ipDynamic.disabled = false;
  ipFix.disabled     = false;
	
  // disable a checkbox if another is already set
  if (ipDynamic.checked) {
	ipFix.disabled = ipDynamic.checked; 
  } else if (ipFix.checked) {
    ipDynamic.disabled = ipFix.checked;
  }
}

function displayNumMenu() {
  var numDurationBox = document.getElementById("numDurationBox");
	
  numDurationBox.style.display = "none";
  if (document.getElementById("sepaFCon2").checked) {
	numDurationBox.style.display = "block";  
  }
}