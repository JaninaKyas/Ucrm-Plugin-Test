<?php

declare(strict_types = 1);

class CustomTable {
  function getUserByCustomerNumber(PDO $pdo, string $customerNumber): array {
    $query = 'SELECT custom_number, firstname, lastname, company, street, house_number, postcode, place, email, phone FROM 
    custom_test_user WHERE custom_number = \'' . $customerNumber . '\'';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return ($result !== false) ? $result : [];
  }
  
  function getAllUserByCustomerNumber(PDO $pdo, string $customerNumber): array {
    $query = 'SELECT custom_number, firstname, lastname, company, street, house_number, postcode, place, email, phone FROM 
    custom_test_user WHERE custom_number like \'%' . $customerNumber . '%\' ORDER BY firstname, lastname';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
    return ($result !== false) ? $result : [];
  }
}
