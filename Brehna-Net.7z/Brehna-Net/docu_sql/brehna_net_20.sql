--
-- Tabellenstruktur für Tabelle `contact_person`
--

CREATE TABLE IF NOT EXISTS `contact_person` (
  `id`          INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id` INT(11)    UNSIGNED NOT NULL,
  `address_id`  INT(11)    UNSIGNED NOT NULL,
  `fName`       CHAR(100)           NOT NULL DEFAULT '',
  `lName`       CHAR(100)           NOT NULL DEFAULT '',
  `position`    CHAR(100)           NOT NULL DEFAULT '',
  `phone`       CHAR(20)            NOT NULL DEFAULT '',
  `phone2`      CHAR(20)            NOT NULL DEFAULT '',
  `mobil`       CHAR(20)            NOT NULL DEFAULT '',
  `eMail`       CHAR(100)           NOT NULL DEFAULT '',
  `createDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY(customer_id) REFERENCES `customer`(id),
  FOREIGN KEY(address_id)  REFERENCES `address`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `customer_x_technology`
--

CREATE TABLE IF NOT EXISTS `customer_x_technology` (
  `id`            INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`   INT(11)    UNSIGNED NOT NULL,
  `technology_id` INT(11)    UNSIGNED NOT NULL, 
  `createDate`    DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`    CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`    DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`    CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`     TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (customer_id)   REFERENCES `customer`(id),
  FOREIGN KEY (technology_id) REFERENCES `technology`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;