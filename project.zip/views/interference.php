<b>Was von dem Anschluss ist durch die Störung betroffen?*</b>
<ul class="list-group">
  <li class="list-group-item">
    <input type="radio" class="interference required" id="ikdTotal" name="iKind" value="Komplettausfall" 
    onclick="showHideSubmenu(0, 1)">
    <label for="ikdTotal">Komplettausfall</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="interference required" id="ikdPhone" name="iKind" value="Telefon" onclick="showHideSubmenu(0, 2)">
    <label for="ikdPhone">Telefon</label>  
  </li>
  <li class="list-group-item">
    <input type="radio" class="interference required" id="ikInternet" name="iKind" value="Internet" onclick="showHideSubmenu(0, 3)">
    <label for="ikInternet">Internet</label>   
  </li>
  <li class="list-group-item">
    <input type="radio" class="interference required" id="ikTv" name="iKind" value="TV" onclick="showHideSubmenu(1, 4)">
    <label for="ikTv">TV</label>
    <span id="tvSub">
      <ul class="list-group">
        <li class="list-group-item">
          <input type="radio" class="interference required" id="tv-satQueis" name="ikTv" value="SAT Queis" onclick="setTypeMalfunction(5)">
          <label for="tv-media">SAT Queis</label> 
        </li>
        <li class="list-group-item">
          <input type="radio" class="interference required" id="tv-satLandsberg" name="ikTv" value="SAT Landsberg" onclick="setTypeMalfunction(6)">
          <label for="tv-screen">SAT Landsberg</label> 
        </li>
        <li class="list-group-item">
          <input type="radio" class="interference required" id="tv-elseTVProduct" name="ikTv" value="Beliebiges TV Produkt" onclick="setTypeMalfunction(7)">
          <label for="tv-sound">Beliebiges TV Produkt</label> 
        </li>
      </ul>
    </span>    
  </li>
</ul>

<div id="descDiv" class="form-group gapTitelQuestion">
  <label for="description"><b>Fehlerbeschreibung aus Kundensicht</b></label>
  <textarea class="form-control" id="description" name="description" value="" rows="7"></textarea>
</div>
