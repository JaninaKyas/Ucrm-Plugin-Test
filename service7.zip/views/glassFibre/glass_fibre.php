<?php
  declare(strict_types = 1);

  $dir = str_replace("/glassFibre", "", __DIR__);

  require __DIR__ . "/forms/customer.php";
  require __DIR__ . "/forms/connection_data.php";
  require $dir    . "/errorMsg/error_message.php";

  class GlassFibre {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();
	public $addressName  = '';

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
		
	  if (!empty($newTechAddress)) {
	    //$this->addressName = $newTechAddress;
	  } else if (!empty($newValues)) {
	    $this->addressName = $newValues["postalAddress"]["street"]  . ' '
			               . $newValues["postalAddress"]["hNr"]     . ', '
			               . $newValues["postalAddress"]["zipcode"] . ' '
			               . $newValues["postalAddress"]["place"];
		  
		if (!empty($newValues["postalAddress"]["district"])) {
		  $this->addressName .= ' OT ' . $newValues["postalAddress"]["district"];
		}
	  }
	}
 
	public function buildDescription() {
      $errorMsg = new ErrorMessage('Die von Ihnen angegebene Adresse konnte nicht gefunden werden.');
		
	  $returnValue = '
	    <div>
		  <div class="row">
		    <div class="col">' . $errorMsg->buildErrorDiv2() . '<br>
			  <div class="alert alert-primary" role="alert">
				<span class="dirLeft">
				<b>ACHTUNG!</b><br> Sie haben nun aber die Alternative über uns einen 
				Glasfaserhausanschluss FttH via Mikrorohrsystems zu beantragen oder senden Sie uns eine 
				Anschluss-Anfrage.  
				</span>
			  </div>
			</div>
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
	  
	public function buildExpansionAreaTemplate(): string {
      $returnValue = '
	    <div id="gfInfoBlock">
		  <div class="row">
		    <div class="col">
			  <div class="alert alert-success" role="alert">
			    <strong>Achtung!</strong><br>
				<span>
				  Ihre Adresse <strong><u>' . $this->addressName . '</u></strong> befindet sich in 
				  unserem Ausbaugebiet. Dadurch können Sie über einen klick auf den Button 
				  "Glasfaserhausanschluss" einen kostenlosen Glasfaserhausanschluss bei uns beantragen.
				</span>
			  </div>
			</div>
		  </div>
		</div>
	  ';
	  
	  return $returnValue;
	}
	  
    public function getGlasFibreTemplate(): string {
	  $customer = new Customer($this->templateData, $this->values);		
	  return $customer->buildCustomerTemplate();
	}
	  
    public function getGlasFibreConnectionTemplate($defaultData): string {		
	  $templateData = array(
	    "kindConnection" => array("typeCon", "inMfhWe", "inFinishTermin"),
		"introHouse"     => array("introHouse", "addElse"),
		"designConHouse" => array("designConHouse", "cntInMeter", "cntInHour", "cntAdd")
	  );
	  $connectionData = new ConnectionData($templateData, $defaultData);
	  return $connectionData->buildConnectionDataTemplate();
	}
	  
	public function buildButtonMenuTemplate(): string {
	  return '
          <div class="row mt-3">
	        <div class="col">
		      <button id="backBtnStep3"
					  class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="1"
					  step_direction="-1"
					  onClick="backwardToStep1(false)">
			    <span id="btnLable11">Zurück</span>
		      </button>
		    </div>
		    <div class="col">
			  <button class="button btn-navigate-form-step addressButton"
				      type="button"
					  step_number="3"
					  step_direction="1"
					  id="btnFttH1"
					  onClick="loadContentFttHStep3()">
			    <span>Glasfaserhausanschluss</span>
			  </button>
		    </div>
            <div class="col">
              <button id="disForward"
				      class="button btn-navigate-form-step addressButton"
				      type="button"
				      step_number="3"
					  step_direction="1"
					  onClick="loadContentConRequestStep3()">
		          <span id="btnLable21">Anschluss - Anfrage</span>
		      </button>
		    </div>
          </div>
	  ';
	}
  }
?>