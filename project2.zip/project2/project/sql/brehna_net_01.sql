/**
 * project: Auftragsautomatisierung
 * author : Janina Kyas
 * version: 0.1
 * company: Brehna66
 **/
CREATE DATABASE IF NOT EXISTS `web2027_bnet_db`
CHARACTER SET   utf8
COLLATE         utf8_general_ci