--
-- Tabellenstruktur für Tabelle `contract_type`
--

CREATE TABLE IF NOT EXISTS `contract_type` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(150)           NOT NULL DEFAULT '', 
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `contract_type`
--

INSERT INTO `contract_type` VALUES(null, '... bitte auswählen ...', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_type` VALUES(null, 'Vertrag',                 NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_type` VALUES(null, 'Änderung',                NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_type` VALUES(null, 'Vertragsverlängerung',    NOW(), 'JANINA', NOW(), 'JANINA', 0);