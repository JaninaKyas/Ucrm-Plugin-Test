CREATE TABLE IF NOT EXISTS `legal_form` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(100)           NOT NULL DEFAULT '',
  `shortName`  CHAR(5)             NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0, 
  PRIMARY KEY (id)
) ENGINE=INNODB;

INSERT INTO `legal_form` VALUES(null, 'Gesellschaft bürgerlichen Rechts',       'GbR', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `legal_form` VALUES(null, 'offene Handelsgesellschaft',             'OHG', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `legal_form` VALUES(null, 'Kommanditgesellschaft',                   'KG', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `legal_form` VALUES(null, 'Gesellschaft mit beschränkter Haftung', 'GmbH', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `legal_form` VALUES(null, 'Unternehmergesellschft',                  'UG', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `legal_form` VALUES(null, 'Aktiengesellschaft',                      'AG', NOW(), 'JANINA', NOW(), 'JANINA', 0);