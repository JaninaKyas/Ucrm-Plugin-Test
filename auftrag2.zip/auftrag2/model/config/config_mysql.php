<?php

declare(strict_types = 1);

class ConfigDb {
  protected const DB_HOST     = 'Ykc5allXeG9iM04w';
  protected const DB_PORT     = 3306;
  protected const DB_NAME     = 'YzJWeWRtbGpaUT09'; //'ZDJWaU1qQXlOMTlpYm1WMFgyUmk=';
  protected const DB_USER     = 'Y205dmRBPT0='; //'WW01bGRHUmlkWE5sY2c9PQ==';
  protected const DB_PASSWORD = 'Y0dGemMzZHZjbVE9'; //'ZHpGSGNHTTBQelk9';
  
  private function _decipherConstants(String $value) : String {
    return base64_decode(base64_decode($value));
  }
  
  public function getDbHost () : String {
    return 'localhost';
	//return $this->_decipherConstants(self::DB_HOST);
  }
  
  public function getDbPort () : int {
    return self::DB_PORT;  
  }
  
  public function getDbName () : String {
    return 'service'; //$this->_decipherConstants(self::DB_NAME);  
  }
  
  public function getDbUser () : String {
    return 'root'; //$this->_decipherConstants(self::DB_USER);  
  }
  
  public function getDbPassword () : String {
    return ''; //$this->_decipherConstants(self::DB_PASSWORD);  
  } 
}

?>