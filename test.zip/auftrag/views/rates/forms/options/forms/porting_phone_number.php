<?php
  declare(strict_types = 1);

  class PortingPhoneNumber {
	public  $templateData   = array();

	private $ekp            = 'Project66 IT-Systemhaus (Brehna.net)';
	private $pkRun          = 'D012';
	private $portTWFirst    = true;
	private $safeHaven      = true;
  
	public function __construct($newTemplateData) {
	  $this->templateData  = $newTemplateData;
	}
	  
	public function buildPortingPhoneNumberTemplate(): string {
	  return '';
	}
	  
	private function buildTitleTemplate(): string {
	  return '';
	}
	  
	private function buildKUETemplate(): string {
	  return '';
	}
	  
	private function buildDataholderTemplate(): string {
	  return '';
	}
	  
	private function buildPhoneNumbersTemplate(): string {
	  return '';
	}
	  
	private function buildTKSystemTemplate(): string {
	  return '';
	}
  }
?>