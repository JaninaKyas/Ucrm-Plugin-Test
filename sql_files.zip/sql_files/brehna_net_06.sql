CREATE TABLE IF NOT EXISTS `numerically` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(200)           NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=INNODB;

INSERT INTO `numerically` VALUES(null, 'Rechnung monatlich',                           NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `numerically` VALUES(null, 'Rechnung per Post +1,50 € pro Monat',          NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `numerically` VALUES(null, 'Einzugsermächtigung für Lastschriftverfahren', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `numerically` VALUES(null, 'Rechnung monatlich im voraus',                 NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `numerically` VALUES(null, 'einmalig nach Fertigstellung Hausanschluss',   NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `numerically` VALUES(null, 'Ratenzahlung nach Vereinbarung',               NOW(), 'JANINA', NOW(), 'JANINA', 0);