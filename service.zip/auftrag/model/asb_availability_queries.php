<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class AsbAvailabilityQueries {
    public $address     = array();
	public $isNewCon    = false;
	public $choosenTech = -1;
	  
    public function __construct($newAddress, $isNewCon1 = true, $newChoosenTech = -1) {
	  $this->address     = $newAddress;
	  $this->isNewCon    = $isNewCon1;
	  $this->choosenTech = $newChoosenTech;
	}
	  
	public function getAllTariffByAddress(): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

	  $returnValue = array();
	  $config = new ConfigDb();

      try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);

		if ($connection != false) {
		  $connection->set_charset("utf8");
			
		  $query = '
            SELECT
              t.id                                           AS rateId,
              t.name                                         AS rate,
              t.price                                        AS monthPrice,
              t.note                                         AS note,
              t.downstream                                   AS dStream,
              t.upstream                                     AS uStream,
			  tc.id                                          AS catId,
              tc.name                                        AS catName,
			  GROUP_CONCAT(DISTINCT(tech.id) SEPARATOR ",")  AS technologyIds,
              GROUP_CONCAT(DISTINCT(tao.name) SEPARATOR ",") AS options
            FROM      asb_availability       AS asb
            LEFT JOIN address                AS ad   ON ad.id             = asb.address_id
            LEFT JOIN technology             AS tech ON tech.id           = asb.technology_id
            LEFT JOIN tariff_x_technology    AS txt  ON txt.technology_id = asb.technology_id
            LEFT JOIN tariff                 AS t    ON txt.tariff_id     = t.id
            LEFT JOIN tariff_category        AS tc   ON t.category_id     = tc.id
            LEFT JOIN tariff_x_tariff_option AS txto ON t.id              = txto.tariff_id
            LEFT JOIN tariff_option          AS tao  ON tao.id            = txto.tariff_option_id
            LEFT JOIN location               AS l    ON l.id              = ad.location_id
		  ';
		  $query .= $this->getWhereConditions();
		  $query .= ' GROUP BY rateId, rate, monthPrice, note, dStream, uStream, catId, catName';
			
		  $result = $connection->query($query);
		  
		  if ($result != false) {
			$connection->set_charset("utf8");
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }

	  return $returnValue;
	}
	  
	protected function getWhereConditions(): string {
	  $returnValue = '
        WHERE
          t.isDeleted = 0
        AND
          asb.isDeleted = 0
		AND
		  tech.isDeleted = 0
	  ';

	  if (array_key_exists('street', $this->address) && !empty($this->address["street"])) {
	    $returnValue .= ' AND ad.street LIKE "' . $this->address["street"] . '"';
	  }
		
	  if (array_key_exists('hNr', $this->address) && !empty($this->address["hNr"])) {
	    $returnValue .= ' AND ad.houseNr LIKE "' . $this->address["hNr"] . '"';
	  }
		
	  if (array_key_exists('zipcode', $this->address) && !empty($this->address["zipcode"])) {
	    $returnValue .= ' AND ad.zipcode LIKE "' . $this->address["zipcode"] . '"';
	  }
		
	  if (array_key_exists('place', $this->address) && !empty($this->address["place"])) {
	    $returnValue .= ' AND l.name LIKE "' . $this->address["place"] . '"';
	  }
		
	  if (array_key_exists('district', $this->address) && !empty($this->address["district"])) {
	    $returnValue .= ' AND l.district LIKE "' . $this->address["district"] . '"';
	  }
		
	  return $returnValue;
	}
  }
?>