<?php
  declare(strict_types = 1);
  
  class Confirm {
    public $data = array();
	
	public function __construct($newData) {
	  $this->data = $newData;
	}
	
	public function buildConfirmRequest(): string {
	  return '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Eingangsbestätigung Ihrer Anschluss - Anfrage</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <span>Vielen Dank für Ihre <strong>Anschluss-Anfrage</strong>.</span>
			<br><br>
			Wir haben Ihre Nachricht erhalten und werden uns so schnell wie möglich mit Ihnen in 
			Verbindung setzen.
			<br><br>
			In der Zwischenzeit können Sie unsere Website <a></a> besuchen, um mehr über unsere Produkte 
			und Dienstleistungen zu erfahren.
			<br><br>
			Sollten Sie Fragen haben, zögern Sie bitte nicht, uns zu kontaktieren.
			<br><br>
			Mit freundlichen Grüßen
			<br><br>
			Project66 IT Service & Design / Brehna.net
			<br>
			Max-Planck-Str. 2
			<br>
			06796 Brehna
		  </div>
		</div>
	  ';
	}
	  
    public function buildConfirmPK(): string {
      return '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Vielen Dank für Ihren Auftrag!</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Vielen Dank für Ihre Bestellung auf unserer Website.
			<br><br>
			Wir haben Ihren Auftrag erhalten und werden uns so schnell wie möglich mit Ihnen in 
			Verbindung setzen.
			<br><br>
			Zur Kontrolle haben wir Ihre Angaben zusammengefasst und senden Ihnen diese per Mail zu.
			<br><br>
			Bei Fragen, Unklarheiten oder Problemen zu Ihrem Auftrag rufen Sie uns bitte unter der 
			Telefonnummer (034954) 524 66 oder senden Sie eine E-Mail an info@brehna.net.
            <br><br>
			Mit freundlichen Grüßen
			<br><br>
			Project66 IT Service & Design / Brehna.net
			<br>
			Max-Planck-Str. 2
			<br>
			06796 Brehna
		  </div>
		</div>';
    }
	  
    public function buildConfirmFttH(): string {
      return '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Vielen Dank für Ihren Auftrag zum Glasfaserhauseanschluss!</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    Vielen Dank für Ihre Bestellung auf unserer Website.
			<br><br>
			Wir haben Ihren Auftrag erhalten und werden uns so schnell wie möglich mit Ihnen in 
			Verbindung setzen.
			<br><br>
			Zur Kontrolle haben wir Ihre Angaben zusammengefasst und senden Ihnen diese per Mail zu.
			<br><br>
			Bei Fragen, Unklarheiten oder Problemen zu Ihrem Auftrag rufen Sie uns bitte unter der 
			Telefonnummer (034954) 524 66 oder senden Sie eine E-Mail an info@brehna.net.
            <br><br>
			Mit freundlichen Grüßen
			<br><br>
			Project66 IT Service & Design / Brehna.net
			<br>
			Max-Planck-Str. 2
			<br>
			06796 Brehna
		  </div>
		</div>';
    }
  }
?>