<?php  
  declare(strict_types = 1);

  class ConnectionRequestCare {
	public $techKinds = array();

	public function __construct($newTechKinds) {
	  $this->techKinds = $newTechKinds;
		
	  if (empty($this->techKinds)) {
		$this->techKinds = array(
		  array("id" => "", "name" => "", "shortName" => "", "note" => ""),
		  array("id" => "", "name" => "", "shortName" => "", "note" => ""),
		  array("id" => "", "name" => "", "shortName" => "", "note" => ""),
		  array("id" => "", "name" => "", "shortName" => "", "note" => ""),
		  array("id" => "", "name" => "", "shortName" => "", "note" => ""),
		);  
	  }
	}
	  
	public function getPrimaryCareTemplate(): string {
	  return '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Über welche Technologie ist ihre Adresse versorgt?</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="radio"
			       id   ="notSure"
				   name ="techKindCare"
				   value="-1"
				   checked>
			 <span>nicht sicher</span>
		  </div>
		  
		  <div class="col">
		    <input type="radio"
			       id   ="careFttH"
				   name ="techKindCare"
				   value="' . $this->techKinds[0]["id"] . '">
			 <span>' . $this->techKinds[0]["name"] . ' (' . $this->techKinds[0]["shortName"] . ')</span>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="radio"
			       id   ="careVDSL"
				   name ="techKindCare"
				   value="' . $this->techKinds[1]["id"] . '">
			<span>' . $this->techKinds[1]["shortName"] . ' (' . $this->techKinds[1]["note"] . ')</span>
		  </div>
		  
		  <div class="col">
		    <input type="radio"
			       id   ="careLTE"
				   name ="techKindCare"
				   value="' . $this->techKinds[2]["id"] . '">
			<span>' . $this->techKinds[2]["name"] . ' (' . $this->techKinds[2]["shortName"] . ')</span>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input type="radio"
			       id   =""
				   name ="techKindCare"
				   value="' . $this->techKinds[3]["id"] . '">
			<span>' . $this->techKinds[3]["name"] . ' (' . $this->techKinds[3]["note"] . ')</span>
		  </div>
		  
		  <div class="col">
		    <input type="radio"
			       id   =""
				   name ="techKindCare"
				   value="' . $this->techKinds[4]["id"] . '">
			<span>' . $this->techKinds[4]["name"] . '</span>
		  </div>
		</div>
	  ';
	}
	  
	public function buildConnectionRequestOptionsTemplate($isToUsePrimaryCare = false): string {
	  $returnValue = ''; 
		
	  if ($isToUsePrimaryCare) {
	    $returnValue .= $this->getPrimaryCareTemplate() . '<hr>';
	  }
		
	  $returnValue .= '
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Ich bin interessiert an den Optionen</strong>
		  </div>
		</div>
		
		<div class="row puffer left">
		  <div class="col">
		    <input id="conRequestPort" name="conRequestPort" type="checkbox" value="15">
			<span>Rufnummernmitnahme</span>
		  </div>
		  
		  <div class="col">
		    <input id="conRequestPhone" name="conRequestPhone" type="checkbox" value="4">
			<span>Telefonie</span>
		  </div>
	    </div>
		<hr>
		<div class="row puffer left">
		  <div class="col">
		    <strong>gewünschter Versorgungsbeginn</strong>
			<input type="date"
			       class="form-control"
				   id="primaryCareTermin"
				   name="primaryCareTermin">
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
	  
	public function buildMessageBoxWithAGBTemplate(): string {
	  return '
	    <div id="errMsgAGB">
          <div class="row">
	        <div class="col">
	          <div class="alert alert-danger" role="alert">
		        <img id="errorImg"
			         src="https://neu.brehna.net/auftrag/public/images/error-5.png" alt="errorMsg">
		        <span>
				  Eine weitere Bearbeitung Ihrer Anfrage ist nur mit Ihrer Zustimmung des Datenschutzes und der Weiterverarbeitung Ihrer Daten möglich.
				  Bitte stimmen Sie den Datenschutz-Bestimmungen und der Weiterverarbeitung Ihrer Daten zu.
				</span>
	          </div>
	        </div>
          </div>
        </div>
	  
	    <div class="row puffer left">
		  <div class="col">
		    <strong>Schreiben Sie uns eine zusätzliche Nachricht oder Nachfrage</strong>
			<textarea id="txtConRequestMsg" name="txtConRequestMsg" rows="15" cols="25"></textarea>
		  </div>
		</div>
		
        <div class="row puffer left">
		  <div class="col">
		    <input type="checkbox" id="checkProcessData" name="checkProcessData" class="reqSafeData"> 
			<strong>
			  Ich habe die <a href="https://brehna.net/datenschutz/">Datenschutz-Bestimmungen</a> gelesen 
			  und stimme der Weiterverarbeitung meiner Daten für diese Kontaktaufnahme zu.
			</strong>
		  </div>
		</div>
	  ';
	}
  }
?>