<div id="contractConfirmation">
  <div class="row">
	<div class="col">
	  <strong>Herzlichen Dank für Ihren Auftrag</strong>
	</div>
  </div>
	
  <div class="row">
	<div class="col">
	  Sehr geehrte Damen und Herren,
		
	  wir bedanken uns für Ihren Auftrag.
		
	  Sie haben noch Fragen? Sie erreichen uns unter <a href="https://brehna.net/kontakt/tel:+493495452466">(034954) 52466</a> oder per E-Mail <a href="mailto:info@brehna.net">info@brehna.net</a>.
		
	  Wir freuen uns auf die Zusammenarbeit!
		
	  Mit freundlichen Grüßen
	</div>
  </div>
</div>