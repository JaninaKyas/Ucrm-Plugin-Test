<style>
  .tablePuffer {
    margin: 0 50px 0 50px;
  }
  
  .link-button {
    background: none;
    border: none;
    color: #1a0dab;
    text-decoration: underline;
    cursor: pointer;
  }
</style>
<form id="chooseUser" method="post">
<div class="tablePuffer">
  <h1 class="text-center fs-4" style="margin-top: 15px;">Suchergebnisse</h1>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>Kundennummer</th>
        <th>Kundenname</th>
        <th>Strasse</th>
        <th>Hausnummer</th>
        <th>PLZ</th>
        <th>Ort</th>
      </tr>
    </thead>
    <tbody>
      <?php
        foreach ($users as $data) {
          $uData = json_encode($data);
      ?>
      <tr>
        <td><?php echo $data["custom_number"]; ?></td>
        <td>
          <?php               
            if (!is_null($data["company"])) {
              echo  "<button class=\"link-button\" type=\"submit\" name=\"loadUser\" value='". 
              $uData . "'>" . $data["company"] . "</button>";
            } else {
              echo "<button class=\"link-button\" type=\"submit\" name=\"loadUser\" value='". 
              $uData . "'>" . $data["lastname"] . ", " . $data["firstname"] . "</button>";
            }
          ?>
        </td>
        <td><?php echo $data["street"]; ?></td>
        <td><?php echo $data["house_number"]; ?></td>
        <td><?php echo $data["postcode"]; ?></td>
        <td><?php echo $data["place"]; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</form>
