<?php
  var_dump($_POST);  

  if (isset($_POST)) {
	$html = $infos["content"];

	// load plugin
    require_once __DIR__ . "/plugins/PDF/dompdf/autoload.inc.php";
    
	// use namespace
	use Dompdf\Dompdf;
	  
	// create new instance of plugin
    $dompdf = new Dompdf();
	    
	if (!empty($html) && $html != "") {
      //$dompdf->loadHtml($html);
      //$dompdf->setPaper('A4', 'portrait');
      //$dompdf->render();
		
	  //$pdf = $dompdf->output();
      //file_put_contents("newTest.pdf", $pdf);
	}
  }
?>