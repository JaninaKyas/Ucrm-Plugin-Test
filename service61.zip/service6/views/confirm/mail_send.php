<?php
  // https://stackoverflow.com/questions/7814910/how-to-send-an-html-email-using-smtp-in-php

  declare(strict_types = 1);
  
  $main = str_replace("views\\confirm", "", __DIR__);
  
  require_once $main . "/model/technology_queries.php";
  require_once $main . "/model/tariff_queries.php";
  require_once $main . "/model/contract_category_queries.php";
  
  class MailSend {
	public $data = array();
	  
	private $empfaenger = 'janinakyas@web.de';
	private $absender   = 'janinakyas@web.de';
	private $subject    = '';
    private $message    = '';
	private $headers    = array("MIME-Version: 1.0", "Content-type: text/html; charset=iso-8859-1", "From: <janinakyas@web.de>");

    public function __construct($newData) {
	  $this->data = $newData;	
	}
	
	public function sendMail(): bool {
      $returnValue = true;
		
	  if (!empty($this->data)) {
		if (array_key_exists("choosenPath", $this->data) && array_key_exists("choosenSubPath", $this->data)) {
		  if ($this->data["choosenPath"] == 4 || $this->data["choosenSubPath"] == 2) {
			$this->subject = 'Anschlussanfrage vom ' . date("Y.m.d");
		    $this->message = $this->buildConnectionMsgText();
		  }
		} 
	  }
	  
	  // mail($this->empfaenger, $this->subject, $this->message, implode("\r\n", $this->headers));
	  return $returnValue;
	}
	
	private function buildConnectionMsgText(): string {
	  $rateQueries     = new TariffQueries();
      $techKindQueries = new TechnologyQueries();
      $conTypeQueries  = new ContractCategoryQueries();
		
	  $returnValue = '
	    <html>
		  <body>
			Hallo,
			<br>
			<br>
			Es ist eine neue Anschluss-Anfrage mit den folgenden Details eingegangen:
			<br>
			<br>
			<table>';

      if ( array_key_exists("customer", $this->data)
		&& array_key_exists("salut"   , $this->data["customer"])
		&& array_key_exists("fName"   , $this->data["customer"])
		&& array_key_exists("lName"   , $this->data["customer"])
		&& array_key_exists("company" , $this->data["customer"])
		&& array_key_exists("postalAddress" , $this->data)
		&& array_key_exists("street"   , $this->data["postalAddress"])
		&& array_key_exists("hNr"      , $this->data["postalAddress"])
		&& array_key_exists("zipcode"  , $this->data["postalAddress"])
		&& array_key_exists("place"    , $this->data["postalAddress"])
		&& array_key_exists("district" , $this->data["postalAddress"])
		&& array_key_exists("phone"    , $this->data["customer"])
		&& array_key_exists("mobil"    , $this->data["customer"])
		&& array_key_exists("mail"     , $this->data["customer"])) {
			  
		  $returnValue .= '
			<tr>
			  <td>Anschrift</td>
			  <td>';
			  
			if ($this->data["customer"]["company"] != "") {
			  $returnValue .= $this->data["customer"]["company"] . "<br>";
			}
			  
			$returnValue .= $this->data["customer"]["salut"]                                 . "<br>" 
			              . $this->data["customer"]["fName"]        . " " . $this->data["customer"]["lName"]  . "<br>"
						  . $this->data["postalAddress"]["street"]  . " " . $this->data["postalAddress"]["hNr"]    . "<br>"
						  . $this->data["postalAddress"]["zipcode"] . " " . $this->data["postalAddress"]["place"];
							  
			if ($this->data["postalAddress"]["district"] != "") {
			  $returnValue .= "<br>Ortsteil: " . $this->data["postalAddress"]["district"]; 
			}
			  
			$returnValue .= '
			    </td>
			  </tr>
			  <tr>
				<td>Kontakt</td>
				<td>
				  Telefon: ' . $this->data["customer"]["phone"] . '<br>
			      Mobil  : ' . $this->data["customer"]["mobil"] . '<br>
				  E-Mail : ' . $this->data["customer"]["mail"]  . '</td>
			  </tr>';				
		  }
			
		  if ( array_key_exists("recall", $this->data)
			&& array_key_exists("isWish", $this->data["recall"])
		    && array_key_exists("termin", $this->data["recall"])) {
			$strRecall = "nein";
			if ($this->data["recall"]["isWish"] == 1) {
			  $strRecall = "ja";
				
			  if ($this->data["recall"]["termin"] != "") {
			    $date       = date_create($this->data["recall"]["termin"]);
			    $strRecall .= ' zum ' . date_format($date, "d.m.Y");
			  }
		    }
				  
			$returnValue .= '<tr>
			  <td>Rückruf ist gewünscht</td>
			  <td>' . $strRecall . '</td>
			</tr>';
		  }

          $contractType[0]["name"] = "keine Angabe";
          if (array_key_exists("conKind", $this->data) && $this->data["conKind"] > 0) {
			$contractType = $conTypeQueries->getContractCategoriesById($this->data["conKind"]);
		  }

          $selectedTech[0]["name"] = "keine Angabe";
          if (array_key_exists("selTech", $this->data) && $this->data["selTech"] > 0) {
			$selectedTech = $techKindQueries->getTechKindById($this->data["selTech"]);
		  }

          $conRequestRate[0]["name"] = "keine Angabe";
          if (array_key_exists("conRequestRate", $this->data) && $this->data["conRequestRate"] > 0) {
			$conRequestRate = $rateQueries->getRateById($this->data["conRequestRate"]);
		  }
			
		  $conRequestRate[0]["name"] = "nicht sicher";
		  if (array_key_exists("techCare", $this->data) && $this->data["techCare"] > 0) {
			$techCare = $techKindQueries->getTechKindById($this->data["techCare"]);
		  }

          $returnValue .= '
			<tr>
			  <td>Bei dem Anschluss handelt es sich um</td>
			  <td>' . $contractType[0]["name"] . '</td>
			<tr>
			  
			<tr>
			  <td>gewünschte Technology</td>
			  <td>' . $selectedTech[0]["name"] . '</td>
			<tr>
			  
			<tr>
			  <td>gewünschter Tarif</td>
			  <td>' . $conRequestRate[0]["name"] . '</td>
			<tr>
			  
			<tr>
			  <td>Kunde ist über folgende Technology versorgt</td>
			  <td>' . $techCare[0]["name"] . '</td>
			<tr>';

          $options      = "keine Angabe";
		  $optionsPort  = "";
		  $optionsPhone = "";
          if (array_key_exists("porting", $this->data) && $this->data["porting"] == 1) {
			$optionsPort = "Rufnummernmitnahme";
			$options     = $optionsPort;
		  }
			
		  if (array_key_exists("phone", $this->data) && $this->data["phone"] == 1) {
			$optionsPhone = "Telfonie";
			$options      = $optionsPhone;
		  }
			
		  if ($optionsPort != "" && $optionsPhone != "") {
			$options = $optionsPort . '<br>' . $optionsPhone;	
		  }
			
		  $returnValue .= '
			<tr>
			  <td>Otionen</td>
		      <td>' . $options . '</td>
			</tr>';
			
		  $careTermin = "kein Angabe";
		  if (array_key_exists("careTermin", $this->data) && $this->data["careTermin1"] != "") {
			$date        = date_create($this->data["careTermin1"]);
			$careTermin .= ' zum ' . date_format($date, "d.m.Y");
		  }
			
		  $returnValue .= '
			<tr>
			  <td>gewünschter Versorgungstermin</td>
			  <td>zum ' . $careTermin . '</td>
			</tr>';		
			
		  if (array_key_exists("message", $this->data)) {
			$returnValue .= '
			  <tr>
				<td>Anfrage vom Kunden: ' . $this->data["message"] . '</td>
			  </tr>'; 
		  }

          $returnValue .= '
			</table>
			<br>
			<br>
			Bitte die Anfrage bearbeiten und dem Kunden bescheid geben.
		    <br>
			<br>
			Vielen Dank.
			<br>
			<br>
			Mit freundlichen Grüßen
		  </body>
		</html>';
			
	  return $returnValue;
	}
  }
?>