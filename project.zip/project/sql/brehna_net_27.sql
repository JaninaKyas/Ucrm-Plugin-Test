ALTER TABLE `tariff` ADD `customer_class` SMALLINT(3) UNSIGNED NOT NULL DEFAULT '0' AFTER `power_up`;

UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 1;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 2;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 3;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 4;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 5;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 6;
UPDATE `tariff` SET `customer_class` = '1' WHERE `tariff`.`id` = 7;
UPDATE `tariff` SET `customer_class` = '2' WHERE `tariff`.`id` = 8;
UPDATE `tariff` SET `customer_class` = '3' WHERE `tariff`.`id` = 9;
UPDATE `tariff` SET `customer_class` = '3' WHERE `tariff`.`id` = 10;
UPDATE `tariff` SET `customer_class` = '3' WHERE `tariff`.`id` = 11;
UPDATE `tariff` SET `customer_class` = '3' WHERE `tariff`.`id` = 12;