<?php
  $dir = str_replace("layout", "", __DIR__);
?>
<form id="contractAuto" method="post">
  <div class="form-header d-flex mb-4">
    <span class="stepIndicator">Verfügbarkeit</span>
	<span class="stepIndicator" id="asbResult"></span>
  </div>

  <div class="borderBox">  
    <div class="step"><?php require_once $dir . "/templates/availability.php"; ?></div>
    <div class="step"></div>
  </div>
  
  <div>
    <button type="button" id="prevBtn" class="button">Zurück</button>
    <button type="button" id="nextBtn" class="button">Weiter</button>
  </div>
</form>
