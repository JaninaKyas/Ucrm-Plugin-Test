<?php

namespace RouterOS\Exceptions;

/**
 * Class ClientException
 *
 * @package RouterOS\Exceptions
 * @since   0.4
 */
class ClientException extends \Exception
{
}
