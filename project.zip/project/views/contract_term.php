<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views", "", __DIR__);

  require $dir . "/model/contract_term_queries.php";

  $contractTermQueries = new ContractTermQueries();
  $terms = $contractTermQueries->getAllContractTerms();
?>

<div id="errorNotChooseContractTerm">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Bitte wählen Sie eine Mindestvertragslaufzeit aus.
    </div>
  </div>
</div>

<div id="contractTerms" class="borderbox">
  <div id="termHead" class="borderbox">
	<div class="row puffer">
	  <div class="col">
		<strong>Mindestvertragslaufzeit</strong>
	  </div>
	</div>

	<div id="pkTerm" class="noDisplay">
      <div class="row puffer">
		<div class="col">
          <input type="radio" id="term1" name="contractTerm"
		  value="<?php echo $terms[1]["id"]; ?>"> <?php echo $terms[1]["duration"] . " Monate"; ?>
		</div>
		<div class="col">
          <input type="radio" id="term2" name="contractTerm" value="<?php echo $terms[2]["id"]; ?>"> <?php echo $terms[2]["duration"] . " Monate " . $terms[2]["term_option"]; ?>
		</div>
	  </div>
	</div>
	
	<div id="pkSenTerm" class="noDisplay">
      <div class="row puffer">
		<div class="col">
          <input type="radio" id="term3" name="contractTerm"
		  value="<?php echo $terms[2]["id"]; ?>"> <?php echo $terms[2]["duration"] . " Monate"; ?>
		</div>
	  </div>
	</div>
	  
	<div id="gkTerm" class="noDisplay">
      <div class="row puffer">
		<div class="col">
          <input type="radio" id="term4" name="contractTerm"
		  value="<?php echo $terms[2]["id"]; ?>"> <?php echo $terms[2]["duration"] . " Monate"; ?>
		</div>
		<div class="col">
          <input type="radio" id="term5" name="contractTerm"
		  value="<?php echo $terms[3]["id"]; ?>"> <?php echo $terms[3]["duration"] . " Monate"; ?>
		</div>
	  </div>
	</div>
  </div>
</div>