<div class="borderStyle generally">

<div class="row puffer">
  <div class="col">
    <b>Ist CPE vorhanden?</b>
  </div>
  <div class="col">
    <input type="radio" id="cpeYes" name="cpe1" value="cpeYes" onclick="displayMeasurementData(1)"> Ja
  </div>
  <div class="col">
    <input type="radio" id="cpeNo"  name="cpe1" value="cpeNo" onclick="displayMeasurementData(0)"> Nein
  </div>
</div>

<div id="test" class="displayBlock">
<div class="row puffer">
  <div class="col">
    <label for="upTime" class="form-label">UP-Time</label>
    <input type="text" class="form-control" id="upTime" name="upTime" placeholder="UP-Time" value="">
  </div>
  
  <div class="col">
    <label for="conTime" class="form-label">Connection-Time</label>
    <input type="text" class="form-control" id="conTime" name="conTime" placeholder="Connection-Time" value="">
  </div>
</div>
</div>

</div>

<script>
  function displayMeasurementData(counter) {  
    if (counter == 1) {
      document.getElementById("test").style.display = "block";
    } else {
      document.getElementById("test").style.display = "none";
    }
  }
</script>
