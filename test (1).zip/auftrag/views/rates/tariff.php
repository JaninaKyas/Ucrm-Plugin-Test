<?php
  declare(strict_types = 1);

  require_once __DIR__ . "/forms/rate_card.php";
  require_once __DIR__ . "/forms/customer.php";

  class Tariff extends RateCard {
    public $rates   = array();
	public $address = array();
	  
	public function __construct($newRates, $newAddress = array()) {
	  $this->rates   = $newRates;
	  $this->address = $newAddress;
	}
	  
	public function getTemplate(): string {
	  $returnValue = '
	    <div>
		  <div class="fontTitle">Tarifauswahl</div>
	  ';
	
	  for ($i = 0; $i < count($this->rates); $i++) {
	    $rateCard = new RateCard($this->rates[$i]);
		$returnValue .= $rateCard->getRateCard();
	  }
		
	  $returnValue .= '</div>';
		
	  return $returnValue;
	}
	  
	public function getCustomerTemplate(): string {		
	  $templateData = array(
	    "personalData"  => array("salutation", "fName", "lName", "company",
								 "mail", "phone", "mobil", "birthDay"),
	    "postalAddress" => array("psStreet", "psHNr", "psZipcode",
								 "psPlace", "psDistrict", "psTae"),
	    "connecAddress" => array("caStreet", "caHNr", "caZipcode", "caPlace",
								 "caDistrict", "conTae", "caDiffAddress")
	  );

	  $customer = new Customer($templateData, $this->address);
	  return $customer->buildCustomerTemplate();
	}
  }
?>