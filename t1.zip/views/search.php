<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interferences recording</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
  </head>
  <body>
    <div id="title" style="margin-left: 50px;">
      <h3>Störungsaufnahme</h3>
    </div>
    
    <form id="customSearch" method="post">
      <div class="row" style="background-color: #B8C402; margin-left: 50px; margin-right: 50px;">
        <div id="customerNumber" class="form-group col-md-12"  style="margin-top: 10px;">
          <label for="cusNrLabel">Kundennummer</label>
          <input type="text" id="cusNrInput" class="form-control" placeholder="Kundennummer"><br/> 
          <button class="btn btn-primary btn-md" type="submit" name="search" value="search">Suche</button>   
        </div>
      </div>
    </form>
    
      <div class="row" style="background-color: #B8C402; margin-left: 50px; margin-right: 50px;">
        <div id="firstName" class="form-group col-xs-6">
          <label for="firstNameLabel">Vorname</label>
          <input type="text" id="firstInput" class="form-control" placeholder="Vorname">    
        </div>
        <div id="lastName" class="form-group col-xs-6">
          <label for="lastNameLabel">Nachname</label>
          <input type="text" id="lastNameInput" class="form-control" placeholder="Nachname">    
        </div>      
      </div>

      <div class="row" style="background-color: #B8C402; margin-left: 50px; margin-right: 50px;">          
        <div id="company" class="form-group col-md-12">
          <label for="companyLabel">Firma (Optional)</label>
          <input type="text" id="companyInput" class="form-control" placeholder="Firma"> 
        </div>      
      </div>
            
    <?php
      var_dump($_POST);
     
      if (isset($_POST["search"])) {       
        $path = substr(__DIR__, 0, -6);
        require_once($path . '/model/get_custome_user_data.php');
        $customTable = new CustomTable();
        $test = $customTable->getUserByCustomerNumber('2');
        var_dump($test);
      }
     
      // if ($result) {
      //  require_once(__DIR__ . '/result.php');
      // }
    ?>
    
  </body>
</html>
