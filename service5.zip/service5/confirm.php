<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	
	require_once __DIR__ . "/views/confirm/confirm.php";
	require_once __DIR__ . "/views/confirm/mail_send.php";
	
	$confirm    = new Confirm($infos);
	$mailSend   = new MailSend($infos);
	
	$html = "";
	if ($infos["choosenPath"] == 4 || $infos["choosenSubPath"] == 2) {
	  require_once __DIR__ . "/model/confirm/customer_connection_requests_queries.php";
	  $ccrQueries = new CustomerConnectionRequestsQueries();
	  
	  // customer data
	  $salut   = "";
	  $fName   = "";
	  $lName   = "";
	  $company = "";
	  $phone   = "";
	  $mobil   = "";
	  $mail    = "";
	  if (array_key_exists("customer", $infos)) {
		if (array_key_exists("salut", $infos["customer"])) {
		  $salut = $infos["customer"]["salut"];
		}
		
		if (array_key_exists("fName", $infos["customer"])) {
		  $fName = $infos["customer"]["fName"];
		}
		
		if (array_key_exists("lName", $infos["customer"])) {
		  $lName = $infos["customer"]["lName"];
		}
		
		if (array_key_exists("company", $infos["customer"])) {
		  $company = $infos["customer"]["company"];
		}
		
		if (array_key_exists("phone", $infos["customer"])) {
		  $phone = $infos["customer"]["phone"];
		}
		
		if (array_key_exists("mobil", $infos["customer"])) {
		  $mobil = $infos["customer"]["mobil"];
		}
		
		if (array_key_exists("mail", $infos["customer"])) {
		  $mail = $infos["customer"]["mail"];
		}
	  }
	
      // address data	
	  $street   = "";
	  $hNr      = "";
	  $zipcode  = "";
	  $place    = "";
	  $district = "";
	  if (array_key_exists("postalAddress", $infos)) {
		if (array_key_exists("street", $infos["postalAddress"])) {
          $street = $infos["postalAddress"]["street"];
		}
		
		if (array_key_exists("hNr", $infos["postalAddress"])) {
          $hNr = $infos["postalAddress"]["hNr"];
		}
		
		if (array_key_exists("zipcode", $infos["postalAddress"])) {
          $zipcode = $infos["postalAddress"]["zipcode"];
		}
		
		if (array_key_exists("place", $infos["postalAddress"])) {
          $place = $infos["postalAddress"]["place"];
		}
		
		if (array_key_exists("district", $infos["postalAddress"])) {
          $district = $infos["postalAddress"]["district"];
		}
	  }
	  
	  $conKind      =  0;
	  $selTech      =  0;
	  $isWishRecall =  0;
	  $recallTermin = "";
	  if (array_key_exists("conKind", $infos)) {
		$conKind = $infos["conKind"];
	  }

	  if (array_key_exists("selTech", $infos)) {
		$selTech = $infos["selTech"];
	  }
	  
	  if (array_key_exists("recall", $infos)) {
		if (array_key_exists("isWish", $infos)) {
		  $isWishRecall = $infos["recall"]["isWish"];
		}
		
		if (array_key_exists("termin", $infos)) {
		  $recallTermin = $infos["recall"]["termin"];
		}
	  }
	  
	  $rate       = -1;
	  $careTech   = -1;
	  $isPhone    =  0;
	  $isPorting  =  0;
	  $careTermin = "";
	  $message    = "";
	  if (array_key_exists("conRequestRate", $infos)) {
		$rate = $infos["conRequestRate"];
	  }
	  
	  if (array_key_exists("techCare", $infos)) {
		$careTech = $infos["techCare"];
	  }
	  
	  if (array_key_exists("phone", $infos)) {
		$isPhone = $infos["phone"];
	  }

	  if (array_key_exists("porting", $infos)) {
		$isPorting = $infos["porting"];
	  }
	  
	  if (array_key_exists("careTermin1", $infos)) {
		$careTermin = $infos["careTermin1"];
	  }
	  
	  if (array_key_exists("message", $infos)) {
		$message = $infos["message"];
	  }
	  
	  $save = $ccrQueries->saveRequest(
	    $salut, $fName, $lName, $company, $street, $hNr, $zipcode, $place, $district, $phone, $mobil, $mail, $conKind,
		selTech, $isWishRecall, $recallTermin, $rate, $careTech, $isPhone, $isPorting, $careTermin, $message 
	  );
	  
      if ($save) {
		if ($mailSend->sendMail()) {
		  $html = $confirm->buildConfirmRequest();
		}
	  }	  
	}
	
	$content = array(
	  "step8content" => $html
	);
	
	echo json_encode($content);
  }
?>