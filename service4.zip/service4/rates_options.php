<?php
  if (isset($_POST)) {
    $data       = file_get_contents("php://input");
    $infos      = json_decode($data, true);

	$content    = array();
	$address    = array();
	$feeLabel   = array();
	$addHwInfos = array();
	  
	require_once __DIR__ . "/model/tariff_options.php";
	require_once __DIR__ . "/model/hardware_queries.php";
	require_once __DIR__ . "/model/service_queries.php";
	require_once __DIR__ . "/views/rates/forms/options/private_customer_options.php";

    $address = $infos["postalAddress"];
	if ($infos["techAddress"]["street"] != "") {
	  $address = $infos["techAddress"];
	}

	if ($infos["selTech"] == 3 || ($infos["rateId"] >= 2 && $infos["rateId"] <= 5)) {
	  $feeLabel["label"] = "Leitungsgebühr";
	  $feeLabel["price"] = 4.00;
	} /* else {
	  $feeLabel["label"] = "Technologiegebühr";
	  $feeLabel["price"] = 4.00;
	}*/

	$rateOptionsQueries = new TariffOptionsQueries();
	$optionReRate = $rateOptionsQueries->getAllOptionsRegardlessOfRateForPK();
	$optionDeRate = $rateOptionsQueries->getAllOptionsDependingOnRatesForPK();
	$optionTV     = $rateOptionsQueries->getTVOptionByAvailibity($address);

	$hardwareQueries = new HardwareQueries();
	$hardwareOptions = $hardwareQueries->getAllHardware(2);
	  
	$addHwInfos["showInfoAddHwBox"] = false;
	$addHwInfos["price"]            = "0.00";
	if ($infos["selTech"] > -1) {
	  if ($infos["selTech"] == 2) {
	    $addHwInfos["showInfoAddHwBox"] = true;
		$addHwInfos["label"] = "UFiber Loco GPON";
	  } else if ($infos["selTech"] == 5) {
	    $addHwInfos["showInfoAddHwBox"] = true;
		$addHwInfos["label"] = "Funkempfänger";
	  } 
	}
	  
    $serviceQueries = new ServiceQueries();
	$serviceOptions = $serviceQueries->getAllService(2);
	  
	$templateData = array(
	  "ipAddress" => array("ipDynamic", "ipFix", "phDefault", "phSip", "phAllnet", "phPorting"),
	  "phPorting" => array(
		"provider"   => "curProvider",
		"dataholder" => array("dhFName", "dhLName", "dhStreet", "dhHNr", "dhZipcode", "dhPlace"),
		"numbers"    => array(
		   "onkz"     => "nrOnkz",
		   "nrPhones" => array(
			  "phone1", "phone2", "phone3", "phone4", "phone5", "phone6", "phone7", "phone7", "phone8", 
			  "phone9"
		   )
	    ),
		"tkSystem" => array("directDial", "queryPoint", "nbFrom", "nbTo")
	  ),
	  "tv"      => "isChooseTv",
	  "fee"     => "chkFee",
	  "service" => array("serDefault", "serComfort"),
	  "hw"      => array("hwDefault", "hw7590", "hwFttH", "hwFunk")
	);
	  
	$rateOptionsTemplate = new PrivateCustomerOptions(
	   $templateData, $infos["customer"], $optionReRate, $optionDeRate, $optionTV, $feeLabel, $serviceOptions,
	   $hardwareOptions, $addHwInfos);
	$content["step4content"] = $rateOptionsTemplate->buildOptionsPKTemplate();
	  
	echo json_encode($content);
  }
?>