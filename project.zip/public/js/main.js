var currentTab  =  0;
var typeMalfunction = -1;
var typeRouter = -1;
  
showTab(currentTab);

function showTab(n) {
  var x = document.getElementsByClassName("step");
  x[n].style.display = "block";

  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
    
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }

  fixStepIndicator(n)
}
    
function nextPrev(n) {
  var x = document.getElementsByClassName("step");

  if (n == 1 && !validateForm()) return false;

  x[currentTab].style.display = "none";

  currentTab = currentTab + n;

  if (currentTab == 7 && n == 1) {
    // displayQuestionContent();
  } else {
    // hideAllQuestionContent();
  }

  if (currentTab >= x.length) {
    typeMalfunction = -1;
    typeRouter = -1;
    document.getElementById("recordingForm").submit();
    return false;
  }

  showTab(currentTab);
}
    
function validateForm() {
  var x, y, i, valid = true;
  x = document.getElementsByClassName("step");
  y = x[currentTab].getElementsByClassName("form-control required");

  for (i = 0; i < y.length; i++) {    
    if (y[i].id == "cOtherLoca1" && document.getElementById("cRowOtherLoca").style.display == "block" && 
        y[i].value == "") {
      valid = setValidateState(y[i]);  
    } else if (y[i].id == "oModell" && document.getElementById("other").checked && y[i].value == "") {
      valid = setValidateState(y[i]);
    } else if (y[i].id != "cOtherLoca1" && y[i] != "oModell" && y[i].value == "") {
      valid = setValidateState(y[i]);
    }
  }  
  
  if (document.getElementById("cLocation").value == "-1") {
    valid = setValidateState(document.getElementById("cLocation"));
  }

  if (currentTab == 5) {
    valid = validateRadioButton("interference required");
  }

  if (currentTab == 6) {
    valid = validateRadioButton("router required");
  }

  if (valid) {
    document.getElementsByClassName("stepIndicator")[currentTab].className += " finish";
  }
    
  return valid;
}
    
function validateRadioButton(className) {
  var returnValue = false;
  var radioButtons = document.getElementsByClassName(className);

  for (i = 0; i < radioButtons.length; i++) {    
    if (radioButtons[i].checked) {
      if (currentTab == 6 && i == (radioButtons.length - 1)) {
        var modell = document.getElementById("rModell")
  
        if (modell.value != "") {
          returnValue = true;
        }
      } else {
        returnValue = true;
        break;
      }
    }
  }

  return returnValue;
}
    
function fixStepIndicator(n) {
  var i, x = document.getElementsByClassName("stepIndicator");
   
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }

  x[n].className += " active";
}
  
function setValidateState(element) {
  element.className += " invalid";
  return false;
}
  
function returnToSearchForm() {
  location.href = 'public.php';
}
  
function showHideSubmenu(kind, type) {
  setTypeMalfunction(type);
  
  switch (kind) {
    case 1  :
      document.getElementById("tvSub").style.display   = "block";
      break;
    default :
      document.getElementById("tvSub").style.display   = "none";
  }
}
  
function setTypeMalfunction(type) {
  typeMalfunction = type;
}
  
function displayQuestionContent() {
  hideAllQuestionContent();
  
  if (typeMalfunction == 2) {
    document.getElementById("typePh").style.display = "block";
  } else if (typeMalfunction == 3) {
    document.getElementById("typeIn").style.display = "block";
  } else if (typeMalfunction == 5) {
    document.getElementById("typeTQ").style.display = "block";
  } else if (typeMalfunction == 6) {
    document.getElementById("typeTL").style.display = "block";
  } else if (typeMalfunction == 7 || typeMalfunction == 4) {
    document.getElementById("typeTB").style.display = "block";
  } else {
    document.getElementById("typeCo").style.display = "block";
  }
}
  
function hideAllQuestionContent() {
  document.getElementById("typeCo").style.display = "none";
  document.getElementById("typeIn").style.display = "none";
  document.getElementById("typePh").style.display = "none";
  document.getElementById("typeTQ").style.display = "none";
  document.getElementById("typeTL").style.display = "none";
  document.getElementById("typeTB").style.display = "none";
}

function showFritzBoxLedState(type) {
  setTypeRouter(type);
  hideAllLedState();
  document.getElementById("otherRouter").style.display = "none";
    
  document.getElementById("router-questionLabel").style.display = "block";
  document.getElementById("fritzLedState").style.display = "block";
}
  
function showLancomLedState() {
  hideAllLedState();
  document.getElementById("otherRouter").style.display = "none";
    
  document.getElementById("router-questionLabel").style.display = "block";
  document.getElementById("lancomLedState").style.display = "block";
}
  
function hideAllLedState() {
  document.getElementById("router-questionLabel").style.display = "none";
  document.getElementById("fritzLedState").style.display = "none";
  document.getElementById("lancomLedState").style.display = "none";
  document.getElementById("otherRouter").style.display = "block";
}

function setTypeRouter(type) {
  typeRouter = type;
}
