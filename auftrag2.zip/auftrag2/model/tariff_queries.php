<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class TariffQueries {
    public function getAllRates(): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT
			  t.id          AS rateId,
			  t.name        AS rate,
              t.price       AS monthPrice,
			  t.note        AS note,
			  t.downstream  AS dStream,
			  t.upstream    AS uStream,
			  t.category_id AS catId,
			  tc.name       AS catName,
              GROUP_CONCAT(DISTINCT(tao.name) SEPARATOR ",") AS options
			FROM      tariff                 AS t
			LEFT JOIN tariff_category        AS tc   ON t.category_id         = tc.id
            LEFT JOIN tariff_x_tariff_option AS txto ON txto.tariff_id        = t.id
            LEFT JOIN tariff_option          AS tao  ON txto.tariff_option_id = tao.id
			WHERE
			  t.isDeleted    = 0
			AND
			  tc.isDeleted   = 0
            AND
              txto.isDeleted = 0
            AND
              tao.isDeleted  = 0
			AND
			  t.id >= 2
            GROUP BY rateId, rate, monthPrice, note, dStream, uStream, catId, catName';

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>