// global variables
// array values
let contractData       = {};
let promiseData        = {};
let postalAddress      = {};
let techAddress        = {
  "isDiffAddress": "",
  "street"       : "",
  "hnr"          : "",
  "zipcode"      : "",
  "place"        : "",
  "district"     : ""
};
let currentTechAddress = {
  "isDiffAddress": "",
  "street"       : "",
  "hnr"          : "",
  "zipcode"      : "",
  "place"        : "",
  "district"     : ""
};
// booleans
var isFormValid        = true;
var isWishRecall       = false;
var isRecallTerminOpen = false;
var isDiffAddress      = false;
// decision variables
var choosenPath        =   -1;
var choosenSubPath     =   -1;
var stepDirection      =    0;
// elements
var errorMsg           = document.getElementById("asbErrorMsg");

const navigateToFormStep = (stepNumber) => {
  document.querySelectorAll(".form-step").forEach((formStepElement) => {
    formStepElement.classList.add("d-none");
  });

  document.querySelectorAll(".form-stepper-list").forEach((formStepHeader) => {
    formStepHeader.classList.add("form-stepper-unfinished");
    formStepHeader.classList.remove("form-stepper-active", "form-stepper-completed");
  });

  document.querySelector("#step-" + stepNumber).classList.remove("d-none");

  const formStepCircle = document.querySelector('li[step="' + stepNumber + '"]');

  formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-completed");
  formStepCircle.classList.add("form-stepper-active");

  for (let index = 0; index < stepNumber; index++) {
    const formStepCircle = document.querySelector('li[step="' + index + '"]');
    if (formStepCircle) {
      formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-active");
      formStepCircle.classList.add("form-stepper-completed");
    }
  }
};

document.querySelectorAll(".btn-navigate-form-step").forEach((formNavigationBtn) => {
  formNavigationBtn.addEventListener("click", () => {
    const stepNumber = parseInt(formNavigationBtn.getAttribute("step_number"));
	stepDirection    = parseInt(formNavigationBtn.getAttribute("step_direction"));

	if (stepDirection === 1) {
	  switch(stepNumber) {
	    case 2:
	      isFormValid = validateAvailibityForm();

		  if (isFormValid) {
		    executeAvailabilitySearch();
		  }
		  break;
	    case 3:
		  isFormValid = validateFormsForStep3();

		  if (isFormValid) {
			setContractCustomerData();
		    loadContentForStep3();
		  }
		  break;
	    case 4:
		  isFormValid = validateFormsForStep4();

		  if (isFormValid) {
	        setContractCustomerData();
			
			if (isDiffAddress && !isAddressIdentic(techAddress, currentTechAddress)) {
              goBackToStep2();
			  isFormValid = false;
			} else {
			  loadContentForStep4();	
			}  
		  }
		  break;
	    case 5: break;
	    case 6: break;
	  }
	}

	if (stepDirection === -1) {
	  resetValidateDeclarations();
	}

	if (isFormValid) {
      navigateToFormStep(stepNumber);
	}
  });
});

/* promise fetch data */

async function executeAvailabilitySearch() {	
  var url          = "http://localhost/auftrag2/rates.php"; //"https://neu.brehna.net/auftrag/rates.php";
  var step2Label   = document.getElementById("step2Lable");
  var step3Label   = document.getElementById("step3Lable");
  var step2Content = document.getElementById("ratesResult");
  var btnMenuStep2 = document.getElementById("step2BtnMenu");
  var btnLabel2    = document.getElementById("btnLable2");
  var altMenuBtn   = document.getElementById("altButtonMenu");
	
  promiseData = {
	"postalAddress": {
	  "street"   : document.getElementById("asbStreet").value,
	  "hNr"      : document.getElementById("asbHNr").value,
      "zipcode"  : document.getElementById("asbPlz").value,
	  "place"    : document.getElementById("asbPlace").value,
      "district" : document.getElementById("asbDistrict").value
	},
	"conKind"  : document.querySelectorAll('input[name=conKind]:checked')[0].value,
	"selTech"  : document.querySelectorAll('input[name=checkConTech]:checked')[0].value
  };

  contractData = promiseData;
  promiseData["techAddress"] = currentTechAddress;
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
	  isWishRecall = false;

	  // set away according to the result of availability check
	  choosenPath = response["ident"];

	  // set labeling step 2 in multi progressbar
      removeChildren(step2Label);
	  setStepProgressbarLable(step2Label, response["step2Lable"]);
	
	  // set labeling step 3 in multi progressbar
      removeChildren(step3Label);
	  setStepProgressbarLable(step3Label, response["step3Lable"]);
		
	  // display form content for step 2
	  if (step2Content != null) {
        removeChildren(step2Content);
	    setStepProgressbarLable(step2Content, response["step2Content"]);
	  }
		
	  // display buttons

	  // display complete button menu
	  btnMenuStep2.style.display = "block";
	  if (btnMenuStep2 != null && choosenPath === 2 || response["show3Btn"]) {
		btnMenuStep2.style.display = "none";  
	  }

	  if (altMenuBtn != null) {
		removeChildren(altMenuBtn);
	  }
		
	  if (choosenPath == 3 && response["btnMenu"] != "") {
		setStepProgressbarLable(altMenuBtn, response["btnMenu"]);
	  }
		
	  // set labeling second button of step 2
	  if (btnLabel2 != null) {
        removeChildren(btnLabel2);
	    setStepProgressbarLable(btnLabel2, response["step2BtnLable"]);
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsg = document.getElementById("cusError");
  if (errMsg != null) {
	errMsg.style.display = "none";
  }
}

async function loadContentForStep3() {
  var url          = '';
  var step3Content = document.getElementById("step3Result");
	
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/auftrag2/glass_fibre_customer.php';
	  break;
	case 2:
	  url = 'http://localhost/auftrag2/rates_customer.php';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/auftrag2/glass_fibre_customer.php';
		  break;
		case 2:
		  url = 'http://localhost/auftrag2/connection_request_customer.php';  
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/auftrag2/recall.php';
	  break;
  }
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {
	  // display form content for step 3
	  if (step3Content != null) {
        removeChildren(step3Content);
	    setStepProgressbarLable(step3Content, response["step3"]);
	  }
		
	  // hide technology address fields
	  var techAddress = document.getElementById("techAddress");
	  if (techAddress != null) {
		techAddress.style.display = response["caDiffAddress"];
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
	
  // display error messages
  var errMsgRec = document.getElementById("cusErrorRec");
  if (errMsgRec != null) {
	errMsgRec.style.display = "none";
  }
	
  var cusErr2 = document.getElementById("cusError2");
  var cusErr3 = document.getElementById("cusError3");
	
  if (cusErr2 != null) {
	cusErr2.style.display = "none";  
  }
  
  if (cusErr3 != null) {
	cusErr3.style.display = "none";
  }
	
  var cusErr = document.getElementById("cusError");
  if (cusErr != null) {
	cusErr.style.display = "none";  
  }
	
  var gfErrMsg = document.getElementById("gfErrMsg");
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none";  
  }
	
  // display recall sub menu
  var terminRecallMain = document.getElementById("terminRecallMain");
  if (terminRecallMain != null) {
	terminRecallMain.style.display = "none";
  }
}

async function loadContentForStep4() {
  var url          = '';
  var subLable     = '';
  var step3Content = document.getElementById("step4Result");
  
  switch(choosenPath) {
	case 1:
	  url = 'http://localhost/auftrag2/';
	  break;
	case 2:
	  url = 'http://localhost/auftrag2/';
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
		  url = 'http://localhost/auftrag2/';
		  break;
		case 2:
		  subLable = 'Rückruf';
		  url = 'http://localhost/auftrag2/';  
		  break;
	  }
	  break;
	case 4:
	  url = 'http://localhost/auftrag2/';
	  break;
  }

  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(promiseData)
  }
  
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });

    if (response) {

	}
  } catch {
    console.error('Promise rejected');
  }
}

/* validate functions */

function validateAvailibityForm() {	
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");

  for (i = 0; i < requiredInputs.length; i++) { 
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  for (j = 0; j < requiredRadio.length; j++) {
	if (requiredRadio[j].checked) {
	  returnValue = true;
	  break;
	} else {
	  requiredRadio[j].className += " invalid";
	  returnValue = false; 
	}
  }

  if (!returnValue) {
	errorMsg.classList.remove("d-none");
	errorMsg.style.display = "block";
  }

  return returnValue;
}

function validateFormsForStep3() {
  var returnValue      = true;

  var inputRequiredF = document.getElementsByClassName("form-control requiredF");
  var caDiffAddress  = document.getElementById("caDiffAddress");
  var inputRequiredFt = document.getElementsByClassName("form-control requiredFT");
  var gfErrMsg = document.getElementById("gfErrMsg");

  var inputRequiredAA = document.getElementsByClassName("form-control requiredAA");
  var cusError        = document.getElementById("cusError");

  for (i = 0;i < inputRequiredF.length; i++) {
    if (inputRequiredF[i].value == null
	 || inputRequiredF[i].value == ""
	 || inputRequiredF[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredF[i].className += " invalid";
	}
  }

  if (caDiffAddress != null && caDiffAddress.checked) {
    for (i = 0;i < inputRequiredFt.length; i++) {
      if (inputRequiredFt[i].value == null
	   || inputRequiredFt[i].value == ""
	   || inputRequiredFt[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    inputRequiredFt[i].className += " invalid";
	  }
    }
  }

  for (i = 0;i < inputRequiredAA.length; i++) {
    if (inputRequiredAA[i].value == null
	 || inputRequiredAA[i].value == ""
	 || inputRequiredAA[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredAA[i].className += " invalid";
	}
  }

  if (gfErrMsg != null && !returnValue) {
	gfErrMsg.style.display = "block";
  }
  
  if (cusError != null && !returnValue) {
	cusError.style.display = "block";  
  }

  return returnValue;
}

function validateFormsForStep4() {
  var returnValue      = true;

  var inputRequiredF = document.getElementsByClassName("form-control requiredF");
  var caDiffAddress  = document.getElementById("caDiffAddress");
  var inputRequiredFt = document.getElementsByClassName("form-control requiredFT");
  var gfErrMsg = document.getElementById("gfErrMsg");

  var inputRequiredRC = document.getElementsByClassName("form-control requiredRC");
  var birthDay = document.getElementById("birthDay");
  var cusError2 = document.getElementById("cusError2");
  var cusError3 = document.getElementById("cusError3");

  var inputRequiredAA = document.getElementsByClassName("form-control requiredAA");
  var cusError = document.getElementById("cusError");

  for (i = 0;i < inputRequiredF.length; i++) {
    if (inputRequiredF[i].value == null
	 || inputRequiredF[i].value == ""
	 || inputRequiredF[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredF[i].className += " invalid";
	}
  }

  if (caDiffAddress != null && caDiffAddress.checked) {
    for (i = 0;i < inputRequiredFt.length; i++) {
      if (inputRequiredFt[i].value == null
	   || inputRequiredFt[i].value == ""
	   || inputRequiredFt[i].value.length == 0) {
	    if (returnValue) {
		  returnValue = false; 
	    }

	    inputRequiredFt[i].className += " invalid";
	  }
    }
  }

  for (i = 0;i < inputRequiredRC.length; i++) {
    if (inputRequiredRC[i].value == null
	 || inputRequiredRC[i].value == ""
	 || inputRequiredRC[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredRC[i].className += " invalid";
	}
  }

  if (gfErrMsg != null && !returnValue) {
	gfErrMsg.style.display = "block";
  }

  if (!isWishRecall) {
	var recALTitel  = document.getElementById("recALTitel");
	var cusErrorRec = document.getElementById("cusErrorRec");
	
	if (recALTitel != null) {
	  returnValue = false;
	  recALTitel.style.color = "#ffaba5";
	}
  }
	
  if (cusErrorRec != null && !returnValue) {
	cusErrorRec.style.display = "block";
  }

  if (cusError2 != null && !returnValue) {
    cusError2.style.display = "block";
  }

  if (birthDay != null && getAge(birthDay.value) < 18) {
	returnValue = false;  
  }

  if (!returnValue && cusError3 != null) {
	cusError2.style.display = "none";
    cusError3.style.display = "block";
  }

  for (i = 0;i < inputRequiredAA.length; i++) {
    if (inputRequiredAA[i].value == null
	 || inputRequiredAA[i].value == ""
	 || inputRequiredAA[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  inputRequiredAA[i].className += " invalid";
	}
  }

  if (cusError != null && !returnValue) {
	cusError.style.display = "block";  
  }

  return returnValue;
}

/* helper functions */ 

function removeChildren(parent) {
  while(parent.hasChildNodes()) {
	parent.removeChild(parent.lastChild);
  }
}

function setStepProgressbarLable(parent, child) {
  parent.insertAdjacentHTML('afterbegin', child);
}

function resetValidateDeclarations() {
  var requiredInputs   = document.getElementsByClassName("form-control required");
  var requiredInputsAA = document.getElementsByClassName("form-control requiredAA");
  var requiredInputsF  = document.getElementsByClassName("form-control requiredF");
  var requiredInputsFt = document.getElementsByClassName("form-control requiredFT");
  var requiredRadio    = document.getElementsByClassName("required2");
  var chkALTitle       = document.getElementById("recALTitel");
  var recallTermin     = document.getElementById("terminRecall");
  var cusError  = document.getElementById("cusError");
  var cusError3 = document.getElementById("cusError3");
  var cusErrRec = document.getElementById("cusErrorRec");
  var gfErrMsg  = document.getElementById("gfErrMsg");
	
  for (i = 0; i < requiredInputs.length; i++) {
	requiredInputs[i].classList.remove("invalid");
  }
		  
  for (i = 0; i < requiredInputsAA.length; i++) {
    requiredInputsAA[i].classList.remove("invalid");
  }

  for (i = 0; i < requiredInputsF.length; i++) {
    requiredInputsF[i].classList.remove("invalid");
  }

  for (i = 0; i < requiredInputsFt.length; i++) {
    requiredInputsFt[i].classList.remove("invalid");
  }
	
  for (j = 0; j < requiredRadio.length; j++) {
	requiredRadio[j].parentNode.children[1].style.color = "#444";
  }
	
  if (chkALTitle != null) {
	chkALTitle.style.color = "black";  
  }

  if (recallTermin != null) {
	recallTermin.classList.remove("invalid");
  }
	
  if (errorMsg != null) {
    errorMsg.style.display = "none";
  }
	
  if (cusError != null) {
	cusError.style.display = "none";
  }
  
  if (cusError3 != null) {
	cusError3.style.display = "none";
  }
	
  if (cusErrRec != null) {
	cusErrRec.style.display = "none"; 
  }
	
  if (gfErrMsg != null) {
	gfErrMsg.style.display = "none"; 
  }
}

function backwardToStep1(isToReset = true) {
  if (isToReset) {
	resetValidateDeclarations();
  }

  navigateToFormStep(1);
}

function goBackToStep2(isToReset = true) {
  if (isToReset) {
	resetValidateDeclarations();
  }

  executeAvailabilitySearch();
  navigateToFormStep(2);
}

function setchoosenRate(rate) {
  contractData["rateId"] = rate;
  loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentFttHStep3() {
  choosenSubPath = 1;
  await loadContentForStep3();
  navigateToFormStep(3);
}

async function loadContentConRequestStep3() {
  choosenSubPath = 2;
  await loadContentForStep3();
  navigateToFormStep(3);
}

// calculates age from customer
function getAge(dateString) {
  var today     = new Date();
  var birthDate = new Date(dateString);
	
  var age = today.getFullYear() - birthDate.getFullYear();
  var m   = today.getMonth()    - birthDate.getMonth();
  
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
	
  return age;
}

/* set contract data */

function setContractCustomerData() {
  switch(choosenPath) {
    case 1:
	  techAddress = currentTechAddress;
	
	  contractData["customer"] = {
		"salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		"phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  }
	  
	  contractData["techAddress"] = {
        "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		"street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		"hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		"zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		"place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		"district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : ''
	  }
	  
	  currentTechAddress = contractData["techAddress"];
	  isDiffAddress = contractData["techAddress"]["isDiffAddress"];
	  
	  break;
	case 2:
	  techAddress = currentTechAddress;
	  
	  contractData["customer"] = {
		"salut"    : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"    : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"    : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"birthDay" : (document.getElementById("birthDay")   != null)? document.getElementById("birthDay").value   : '',
		"psTae"    : (document.getElementById("psTae")      != null)? document.getElementById("psTae").value      : '',
		"phone"    : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"    : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"     : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  }
	  
	  contractData["techAddress"] = {
        "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		"street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		"hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		"zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		"place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		"district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : '',
		"conTae":        (document.getElementById("conTae")        != null)? document.getElementById("conTae").value          : ''
	  }
	  
	  currentTechAddress = contractData["techAddress"];
	  isDiffAddress = contractData["techAddress"]["isDiffAddress"];
	
	  break;
	case 3:
	  switch(choosenSubPath) {
		case 1:
	      techAddress = currentTechAddress;
	
	      contractData["customer"] = {
		    "salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		    "fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		    "lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		    "company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		    "phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		    "mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		    "mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	      }
	  
	      contractData["techAddress"] = {
            "isDiffAddress": (document.getElementById("caDiffAddress") != null)? document.getElementById("caDiffAddress").checked : false,
		    "street"       : (document.getElementById("caStreet")      != null)? document.getElementById("caStreet").value        : '',
		    "hnr"          : (document.getElementById("caHNr")         != null)? document.getElementById("caHNr").value           : '',
		    "zipcode"      : (document.getElementById("caZipcode")     != null)? document.getElementById("caZipcode").value       : '',
		    "place"        : (document.getElementById("caPlace")       != null)? document.getElementById("caPlace").value         : '',
		    "district"     : (document.getElementById("caDistrict")    != null)? document.getElementById("caDistrict").value      : ''
	      }
	  
	      currentTechAddress = contractData["techAddress"];
	      isDiffAddress = contractData["techAddress"]["isDiffAddress"];
		
		  break;
		case 2:
	      contractData["customer"] = {
		    "salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		    "fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		    "lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		    "company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		    "phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		    "mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		    "mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	      }

		  break;
	  }
	
	  break;
	case 4:
	  contractData["customer"] = {
		"salut"   : (document.getElementById("salutation") != null)? document.getElementById("salutation").value : -1,
		"fName"   : (document.getElementById("fName")      != null)? document.getElementById("fName").value      : '',
		"lName"   : (document.getElementById("lName")      != null)? document.getElementById("lName").value      : '',
		"company" : (document.getElementById("company")    != null)? document.getElementById("company").value    : '',
		"phone"   : (document.getElementById("phone")      != null)? document.getElementById("phone").value      : '',
		"mobil"   : (document.getElementById("mobil")      != null)? document.getElementById("mobil").value      : '',
		"mail"    : (document.getElementById("mail")       != null)? document.getElementById("mail").value       : ''
	  }

	  break;
  }
}

function isAddressIdentic(tAddress, ctAddress) {
  var returnValue = true;
  
  if ( (tAddress["street"]   !== ctAddress["street"])
	|| (tAddress["hnr"]      !== ctAddress["hnr"])
    || (tAddress["zipcode"]  !== ctAddress["zipcode"])
	|| (tAddress["place"]    !== ctAddress["place"])
	|| (tAddress["district"] !== ctAddress["district"])) {
    returnValue = false;
  }
  
  return returnValue;
}

/* other functions */

function displayTechAddress() {
  var isCheckedDiffAddress = document.getElementById("caDiffAddress").checked;
  document.getElementById("techAddress").style.display = "none";
  if (isCheckedDiffAddress) {
	document.getElementById("techAddress").style.display = "block";
  }
}

function displayRecallTerminMain(state) {
  isRecallTerminOpen = false;
  isWishRecall       = true;

  document.getElementById("terminRecallMain").style.display = "none";
  if (state == 1) {
	document.getElementById("terminRecallMain").style.display = "block";
	isRecallTerminOpen = true;
  }
}
