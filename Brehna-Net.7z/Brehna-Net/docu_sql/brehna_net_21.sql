--
-- Tabellenstruktur für Tabelle `contract`
--

CREATE TABLE IF NOT EXISTS `contract` (
  `id`                        INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`               INT(11)       UNSIGNED NOT NULL,
  `contract_type_id`          INT(11)       UNSIGNED NOT NULL, 
  `tariff_id`                 INT(11)       UNSIGNED NOT NULL,
  `hardware_id`               INT(11)       UNSIGNED NOT NULL,
  `software_id`               INT(11)       UNSIGNED NOT NULL,    
  `service_id`                INT(11)       UNSIGNED NOT NULL,    
  `numerically_id`            INT(11)       UNSIGNED NOT NULL,    
  `contract_term_id`          INT(11)       UNSIGNED NOT NULL,    
  `debator_id`                INT(11)       UNSIGNED NOT NULL,
  `state_id`                  INT(11)       UNSIGNED NOT NULL,      
  `contractNr`                CHAR(50)               NOT NULL DEFAULT '',      
  `startDate`                 DATE                   NOT NULL DEFAULT '1000-01-01',
  `endDate`                   DATE                   NOT NULL DEFAULT '1000-01-01',
  `desiredDate`               DATE                   NOT NULL DEFAULT '1000-01-01',  
  `onceTotalPrice`            DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `monthlyTotalPrice`         DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `totalPrice`                DECIMAL(10,2)          NOT NULL DEFAULT 0.00,  
  `isConfirmedDataProcess`    TINYINT(1)             NOT NULL DEFAULT 0,
  `isConfirmedAgb`            TINYINT(1)             NOT NULL DEFAULT 0,
  `isConfirmedDataProtection` TINYINT(1)             NOT NULL DEFAULT 0,
  `createDate`                DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`                CHAR(50)               NOT NULL DEFAULT '',
  `updateDate`                DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`                CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`                 TINYINT(1)             NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (customer_id)      REFERENCES customer(id),
  FOREIGN KEY (contract_type_id) REFERENCES contract_type(id),
  FOREIGN KEY (tariff_id)        REFERENCES tariff(id),
  FOREIGN KEY (hardware_id)      REFERENCES hardware(id),
  FOREIGN KEY (software_id)      REFERENCES software(id),
  FOREIGN KEY (service_id)       REFERENCES service(id),
  FOREIGN KEY (contract_term_id) REFERENCES contract_term(id),
  FOREIGN KEY (debator_id)       REFERENCES debator(id),
  FOREIGN KEY (state_id)         REFERENCES contract_state(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tabellenstruktur für Tabelle `contract_x_tariff_option`
--

CREATE TABLE IF NOT EXISTS `contract_x_tariff_option` (
  `id`               INT(11)   UNSIGNED NOT NULL AUTO_INCREMENT,
  `contract_id`      INT(11)   UNSIGNED NOT NULL,
  `tariff_option_id` INT(11)   UNSIGNED NOT NULL,
  `count` INT(11) UNSIGNED NOT NULL DEFAULT 0,
  `createDate`       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`       CHAR(50)           NOT NULL DEFAULT '',
  `updateDate`       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`       CHAR(50)           NOT NULL DEFAULT '',
  `isDeleted`        TINYINT(1)         NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (contract_id)      REFERENCES contract(id),
  FOREIGN KEY (tariff_option_id) REFERENCES tariff_option(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;