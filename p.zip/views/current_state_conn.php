<button type="button" class="btn btn-primary col-12" id="loadDataWin" name="loadDataWin" value="loadDataWin">Lade Daten aus WinBox</button>

<br><br>

<div class="row puffer">
  <div class="col">
    <label for="down" class="form-label">Download (Mbps)</label>
    <input type="text" class="form-control" id="down" name="down" placeholder="Download"
    value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
  <div class="col">
    <label for="up" class="form-label">Upload (Mbps)</label>
    <input type="text" class="form-control" id="up" name="up" placeholder="Upload"
    value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="up" class="form-label">Laufzeit Server (Stunden)</label>
    <input type="text" class="form-control" id="duration" name="duration" placeholder="Laufzeit Server" 
    value="">    
  </div>
</div>
