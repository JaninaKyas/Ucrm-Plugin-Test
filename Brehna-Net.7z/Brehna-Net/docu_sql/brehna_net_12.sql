--
-- Tabellenstruktur für Tabelle `technology`
--

CREATE TABLE IF NOT EXISTS `technology` (
  `id`          INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        CHAR(150)           NOT NULL DEFAULT '',
  `shortName`   CHAR(10)            NOT NULL DEFAULT '',
  `note`        CHAR(150)           NOT NULL DEFAULT '',
  `createDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `technology`
--

INSERT INTO `technology` VALUES(null, '... bitte auswählen ...',                        '', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Glasfaser',                                  'FttH', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Very High Speed Digital Subscriber Line',    'VDSL', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Ethernet',                                    'ETH', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Funk',                                           '', '5G LTU', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Lichtwellenleiter',                           'LWL', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Richtfunk Point-to-Point',                 'RF PTP', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `technology` VALUES(null, 'Richtfunk Point-to-Multipoint',           'RF PTMP', '',       NOW(), 'JANINA', NOW(), 'JANINA', 0);