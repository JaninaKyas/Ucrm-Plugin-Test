<?php
  declare(strict_types = 1);

  class PrivateCustomerOptions {
	public $templateData  = array();
	public $optionsValues = array();
	public $optionsString = '';
  
	public function __construct($newTemplateData, $newOptionsValues, $newOptionsString) {
	  $this->templateData  = $newTemplateData;
	  $this->optionsValues = $newOptionsValues;
	  $this->optionsString = $newOptionsString;
	}
	
	public function buildOptionsPKTemplate(): string {
	  return '<div class="fontTitle">Optionen</div>
	    <div class="rateOptionsBlock">'
        . $this->buildIPAddressChoiceTemplate() . '<hr>'
		. $this->buildPhoneDefaultTemplate()    . '<hr>' .
		'</div>
	  ';
	}
	  
	private function buildIPAddressChoiceTemplate(): string {
	  return '<div class="row puffer">
            <div class="col">
			  <label class="addressLabel">
			    Wählen Sie für Ihre IP-Adresse eine zusätzliche Option aus:
			  </label>
			</div>
          </div>
		  
		  <div class="row left">
		    <div class="col">
              <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][0] . '"
					 name="' . $this->templateData["ipAddress"][0] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[0]['id'] . '">
			  <span>' . $this->optionsValues[0]['name'] . '</span>
			  <br>
			  <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][1] . '"
					 name="' . $this->templateData["ipAddress"][1] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[1]['id'] . '">
			  <span>' . $this->optionsValues[1]['name'] . '</span>
			</div>
			
			<div class="col price">
			  <span>'
		      . number_format(floatval($this->optionsValues[0]['price']), 2, ',', ' ')
		      . ' pro Monat</span>
			  <br>
              <span>'
		      . number_format(floatval($this->optionsValues[1]['price']), 2, ',', ' ')
		      . ' pro Monat</span>
			</div>
		  </div>';
	}
	  
	private function buildPhoneDefaultTemplate(): string {
	  /*
	    <div class="row puffer">
		
		</div>
	  */
		
	  return '<div class="row puffer left">
	    <div class="col">
		  <input type="checkbox"
		         class="form-check-input"
				 id="' . $this->templateData["ipAddress"][2] . '"
				 name="' . $this->templateData["ipAddress"][2] . '"
				 value="' . $this->optionsValues[2]['id'] . '">
		  <span class="addressLabel">' . $this->optionsValues[2]['name'] . '</span>
		</div>
		
		<div class="col addressLabel price">
		  <span>'
		  . number_format(floatval($this->optionsValues[2]["price"]), 2, ',', ' ')
		  . ' pro Monat</span>
		</div>
	  </div>';
	}
	  
	private function buildPortingPhoneNumberTemplate(): string {
	  return '';
	}
  }
?>