<b>Was für ein Router wird verwendet?*</b>
<ul class="list-group">
  <li class="list-group-item">
    <input type="radio" class="router required" id="r1" name="router" value="FRITZ!Box 7590" onclick="showFritzBoxLedState()">
    <label for="r1">FRITZ!Box 7590</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r2" name="router" value="FRITZ!Box 7530" onclick="showFritzBoxLedState()">
    <label for="r2">FRITZ!Box 7530</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r3" name="router" value="FRITZ!Box 7510" onclick="showFritzBoxLedState()">
    <label for="r3">FRITZ!Box 7510</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r4" name="router" value="FRITZ!Box 7490" onclick="showFritzBoxLedState()">
    <label for="r4">FRITZ!Box 7490</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r5" name="router" value="FRITZ!Box 7430" onclick="showFritzBoxLedState()">
    <label for="r5">FRITZ!Box 7430</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r6" name="router" value="FRITZ!Box 4040" onclick="showFritzBoxLedState()">
    <label for="r6">FRITZ!Box 4040</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r7" name="router" value="FRITZ!Box 4020" onclick="showFritzBoxLedState()">
    <label for="r7">FRITZ!Box 4020</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="r8" name="router" value="LANCOM" onclick="showLancomLedState()">
    <label for="r8">LANCOM</label>
  </li>
  <li class="list-group-item">
    <input type="radio" class="router required" id="other" name="router" value="sonstiges" onclick="hideAllLedState()">
    <label for="other">Anderes Modell</label>
    <br>
    <div id="otherRouter" class="row puffer">
      <div class="col">
        <label for="rModell" class="form-label">Um welches Modell handelt es sich?*</label>
        <input type="text" class="form-control required" id="rModell" name="rModell" placeholder="Modell">
        <br>
        <label for="oLed" class="form-label">Welche LED sind auf dem Router vorhanden? Wie leuchten die LED?</label>
        <textarea class="form-control" id="oLed" rows="6"></textarea>
      </div>
    </div>
  </li>
</ul>

<div id="router-questionLabel">
  <b>Wie leuchten die LED auf dem Router?</b>
</div>

<div id="fritzLedState" class="borderStyle">
  <div class="row puffer">
    <div class="col">
      <label for="powerFB" class="form-label">Power</label>
      <select id="powerFB" name="powerFB" class="form-select">
        <option value="Power aus" selected>aus</option>
        <option value="Power blinkt">blinkt</option>
        <option value="Power leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="internetFB" class="form-label">Internet</label>
      <select id="internetFB" name="internetFB" class="form-select">
        <option value="Internet aus" selected>aus</option>
        <option value="Internet blinkt">blinkt</option>
        <option value="Internet leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
  </div>
  
  <div class="row puffer">
    <div class="col">
      <label for="festnetzFB" class="form-label">Festnetz</label>
      <select id="festnetzFB" name="festnetzFB" class="form-select">
        <option value="Festnetz aus" selected>aus</option>
        <option value="Festnetz blinkt">blinkt</option>
        <option value="Festnetz leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="fonFB" class="form-label">Fon</label>
      <select id="fonFB" name="fonFB" class="form-select">
        <option value="Fon aus" selected>aus</option>
        <option value="Fon blinkt">blinkt</option>
        <option value="Fon leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
  </div>
  
  <div class="row puffer">
    <div class="col">
      <label for="dslFB" class="form-label">DSL</label>
      <select id="dslFB" name="dslFB" class="form-select">
        <option value="DSL aus" selected>aus</option>
        <option value="DSL blinkt">blinkt</option>
        <option value="DSL leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="wlanFB" class="form-label">WLAN</label>
      <select id="wlanFB" name="wlanFB" class="form-select">
        <option value="WLAN aus" selected>aus</option>
        <option value="WLAN blinkt">blinkt</option>
        <option value="WLAN leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
  </div>
  
  <div class="row puffer">
    <div class="col">
      <label for="wpsFB" class="form-label">Connect/ WPS</label>
      <select id="wpsFB" name="wpsFB" class="form-select">
        <option value="Connect/ WPS aus" selected>aus</option>
        <option value="Connect/ WPS blinkt">blinkt</option>
        <option value="Connect/ WPS blinkt schnell">blinkt schnell</option>
      </select>
    </div>
    
    <div class="col">
      <label for="lanFB" class="form-label">LAN</label>
      <select id="lanFB" name="lanFB" class="form-select">
        <option value="LAN aus" selected>aus</option>
        <option value="LAN leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
  </div>
  
  <div class="row puffer">
    <div class="col">
      <label for="dectFB" class="form-label">DECT</label>
      <select id="dectFB" name="dectFB" class="form-select">
        <option value="DECT aus" selected>aus</option>
        <option value="DECT blinkt">blinkt</option>
        <option value="DECT leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="infoFB" class="form-label">Info</label>
      <select id="infoFB" name="infoFB" class="form-select">
        <option value="Info aus" selected>aus</option>
        <option value="Info blinkt">blinkt</option>
        <option value="Info blinkt rot">blinkt rot</option>
        <option value="Info leuchtet/ an">leuchtet/ an</option>
      </select>
    </div>
  </div>
</div>

<div id="lancomLedState" class="borderStyle">
  <div class="row puffer">
    <div class="col">
      <label for="powerLC" class="form-label">Power</label>
      <select id="powerLC" name="powerLC" class="form-select">
        <option value="Power aus" selected>aus</option>
        <option value="Power rot blinkend">rot blinkend</option>
        <option value="Power grün/ rot blinkend">grün/ rot blinkend</option>
        <option value="Power 1x blau invers blinkend">1x blau invers blinkend</option>
        <option value="Power 2x blau invers blinkend">2x blau invers blinkend</option>
        <option value="Power 3x blau invers blinkend">3x blau invers blinkend</option>
        <option value="Power 1x grün invers blinkend">1x grün invers blinkend</option>
        <option value="Power 2x grün invers blinkend">2x grün invers blinkend</option>
        <option value="Power 3x grün invers blinkend">3x grün invers blinkend</option>
        <option value="Power blau dauerhaft an">blau dauerhaft an</option>
        <option value="Power grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="onlineLC" class="form-label">Online</label>
      <select id="onlineLC" name="onlineLC" class="form-select">
        <option value="Online aus" selected>aus</option>
        <option value="Online blau blinkend">blau blinkend</option>
        <option value="Online grün blinkend">grün blinkend</option>
        <option value="Online rot dauerhaft an">rot dauerhaft an</option>
        <option value="Online blau dauerhaft an">blau dauerhaft an</option>
        <option value="Online grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <label for="dslLC" class="form-label">DSL</label>
      <select id="dslLC" name="dslLC" class="form-select">
        <option value="DSL aus" selected>aus</option>
        <option value="DSL rot flackernd">rot flackernd</option>
        <option value="DSL blau flackernd">blau flackernd</option>
        <option value="DSL grün flackernd">grün flackernd</option>
        <option value="DSL rot/ orange blinkend">rot/ orange blinkend</option>
        <option value="DSL orange blinkend">orange blinkend</option>
        <option value="DSL grün blinkend">grün blinkend</option>
        <option value="DSL blau blinkend/ schnell blinkend">blau blinkend/ schnell blinkend</option>
        <option value="DSL blau blitzend">blau blitzend</option>
        <option value="DSL orange dauerhaft an">orange dauerhaft an</option>
        <option value="DSL blau dauerhaft an">blau dauerhaft an</option>
        <option value="DSL grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="isdnLC" class="form-label">ISDN</label>
      <select id="isdnLC" name="isdnLC" class="form-select">
        <option value="ISDN aus" selected>aus</option>
        <option value="ISDN rot flackernd">rot flackernd</option>
        <option value="ISDN grün flackernd">grün flackernd</option>
        <option value="ISDN rot/ orange blinkend">rot/ orange blinkend</option>
        <option value="ISDN orange blinkend">orange blinkend</option>
        <option value="ISDN blau blinkend">blau blinkend</option>        
        <option value="ISDN grün blinkend">grün blinkend</option>
        <option value="ISDN orange/ grün synchron blinkend">orange/ grün synchron blinkend</option>
        <option value="ISDN blau blitzend">blau blitzend</option>
        <option value="ISDN orange dauerhaft an">orange dauerhaft an</option>
        <option value="ISDN blau dauerhaft an">blau dauerhaft an</option>
        <option value="ISDN grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>
  
  <div class="row puffer">
    <div class="col">
      <label for="ethLC" class="form-label">ETH</label>
      <select id="ethLC" name="ethLC" class="form-select">
        <option value="ETH grün, orange aus" selected>grün, orange aus</option>
        <option value="ETH blau flackernd">blau flackernd</option>
        <option value="ETH grün flackernd">grün flackernd</option>
        <option value="ETH orange dauerhaft an">orange dauerhaft an</option>
        <option value="ETH blau dauerhaft an">blau dauerhaft an</option>
        <option value="ETH grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="wlanLC" class="form-label">WLAN</label>
      <select id="wlanLC" name="wlanLC" class="form-select">
        <option value="WLAN aus" selected>aus</option>
        <option value="WLAN rot blinkend">rot blinkend</option>
        <option value="WLAN blau blinkend">blau blinkend</option>
        <option value="WLAN grün blinkend">grün blinkend</option>
        <option value="WLAN grün blitzend">grün blitzend</option>
        <option value="WLAN blau dauerhaft an">blau dauerhaft an</option>
        <option value="WLAN grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <label for="vpnLC" class="form-label">VPN</label>
      <select id="vpnLC" name="vpnLC" class="form-select">
        <option value="VPN aus" selected>aus</option>
        <option value="VPN blau flackernd">blau flackernd</option>
        <option value="VPN grün blitzend">grün blitzend</option>
        <option value="VPN blau dauerhaft an">blau dauerhaft an</option>
        <option value="VPN grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="voipLC" class="form-label">VoIP</label>
      <select id="voipLC" name="voipLC" class="form-select">
        <option value="VoIP aus" selected>aus</option>
        <option value="VoIP blau blinkend">blau blinkend</option>
        <option value="VoIP rot oder grün invers blitzend">rot oder grün invers blitzend</option>
        <option value="VoIP rot dauerhaft an">rot dauerhaft an</option>
        <option value="VoIP blau dauerhaft an">blau dauerhaft an</option>
        <option value="VoIP grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <label for="g4LC" class="form-label">4G</label>
      <select id="g4LC" name="g4LC" class="form-select">
        <option value="4G aus" selected>aus</option>
        <option value="4G blau flackernd">blau flackernd</option>
        <option value="4G grün flackernd">grün flackernd</option>
        <option value="4G rot/ orange blinkend">rot/ orange blinkend</option>
        <option value="4G orange blinkend">orange blinkend</option>
        <option value="4G blau blinkend">blau blinkend</option>
        <option value="4G rot/ grün blinkend">rot/ grün blinkend</option>
        <option value="4G blau blitzend">blau blitzend</option>
        <option value="4G blau schnell blitzend">blau schnell blitzend</option>
        <option value="4G rot dauerhaft an">rot dauerhaft an</option>
        <option value="4G orange dauerhaft an">orange dauerhaft an</option>
        <option value="4G blau dauerhaft an">blau dauerhaft an</option>
        <option value="4G grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="g5LC" class="form-label">5G</label>
      <select id="g5LC" name="g5LC" class="form-select">
        <option value="5G aus" selected>aus</option>
        <option value="5G grün flackernd">grün flackernd</option>
        <option value="5G rot/ orange blinkend">rot/ orange blinkend</option>
        <option value="5G orange blinkend">orange blinkend</option>
        <option value="5G rot/ grün blinkend">rot/ grün blinkend</option>
        <option value="5G rot dauerhaft an">rot dauerhaft an</option>
        <option value="5G orange dauerhaft an">orange dauerhaft an</option>
        <option value="5G grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <label for="wanLC" class="form-label">WAN</label>
      <select id="wanLC" name="wanLC" class="form-select">
        <option value="WAN grün, orange aus" selected>grün, orange aus</option>
        <option value="WAN blau flackernd">blau flackernd</option>
        <option value="WAN orange dauerhaft an">orange dauerhaft an</option>
        <option value="WAN blau dauerhaft an">blau dauerhaft an</option>
        <option value="WAN grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="analogLC" class="form-label">Analog</label>
      <select id="analogLC" name="analogLC" class="form-select">
        <option value="Analog aus" selected>aus</option>
        <option value="Analog ">grün flackernd</option>
        <option value="Analog blau blinkend">blau blinkend</option>
        <option value="Analog grün blickend">grün blickend</option>
        <option value="Analog blau dauerhaft an">blau dauerhaft an</option>
        <option value="Analog grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
  </div>

  <div class="row puffer">
    <div class="col">
      <label for="gVdslLC" class="form-label">G.FAST/ VDSL</label>
      <select id="gVdslLC" name="gVdslLC" class="form-select">
        <option value="G.FAST/ VDSL aus" selected>aus</option>
        <option value="G.FAST/ VDSL orange/ grün flackernd">orange/ grün flackernd</option>
        <option value="G.FAST/ VDSL grün flackernd">grün flackernd</option>
        <option value="G.FAST/ VDSL orange blinkend">orange blinkend</option>
        <option value="G.FAST/ VDSL grün blinkend">grün blinkend</option>
        <option value="G.FAST/ VDSL orange/ grün synchron blinkend">orange/ grün synchron blinkend</option>
        <option value="G.FAST/ VDSL orange dauerhaft an">orange dauerhaft an</option>
        <option value="G.FAST/ VDSL grün dauerhaft an">grün dauerhaft an</option>
      </select>
    </div>
    
    <div class="col">
      <label for="sfpLC" class="form-label">SFP</label>
      <select id="sfpLC" name="sfpLC" class="form-select">
        <option value="SFP aus" selected>aus</option>
        <option value="SFP ">blau flackernd</option>
        <option value="SFP ">blau dauerhaft an</option>
      </select>
    </div>
  </div>
</div>

<script>
function showFritzBoxLedState() {
  hideAllLedState();
  document.getElementById("otherRouter").style.display = "none";
    
  document.getElementById("router-questionLabel").style.display = "block";
  document.getElementById("fritzLedState").style.display = "block";
}
  
function showLancomLedState() {
  hideAllLedState();
  document.getElementById("otherRouter").style.display = "none";
    
  document.getElementById("router-questionLabel").style.display = "block";
  document.getElementById("lancomLedState").style.display = "block";
}
  
function hideAllLedState() {
  document.getElementById("router-questionLabel").style.display = "none";
  document.getElementById("fritzLedState").style.display = "none";
  document.getElementById("lancomLedState").style.display = "none";
  document.getElementById("otherRouter").style.display = "block";
}
</script>
