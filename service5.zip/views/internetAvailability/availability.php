<?php
  declare(strict_types = 1);

  $dir = str_replace("/internetAvailability", "", __DIR__);

  require __DIR__ . "/forms/address.php";
  require $dir    . "/errorMsg/error_message.php";

  $asbAddress = new Address('asbStreet', 'asbHNr', 'asbPlz', 'asbPlace', 'asbDistrict', '', '', true);
  $errorMsg   = new ErrorMessage('Bitte füllen Sie alle Pflichtfelder aus.', true);
?>
<div class="centerForm">
  <?php echo $errorMsg->buildErrorDiv(); ?>

  <div class="fontTitle">PRÜFEN SIE DIE VERFÜGBARKEIT</div>
  <form id="asbCheck" method="POST">
	<?php echo $asbAddress->getTemplate(); ?>
  </form>
</div>