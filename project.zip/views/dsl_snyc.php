<div class="borderStyle generally">

<div class="row puffer">
  <div class="col">
    <b>Ist der DSL-Sync vorhanden?</b>
  </div>
  <div class="col">
    <input type="radio" id="dslSyncYes" name="dslSync" value="dslSyncYes"> Ja
  </div>
  <div class="col">
    <input type="radio" id="dslSyncNo"  name="dslSync" value="dslSyncNo"> Nein
  </div>
</div>

</div>
