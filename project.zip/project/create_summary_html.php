<?php
  if(isset($_POST)){
    $data = file_get_contents("php://input");
    $infos = json_decode($data, true);
	  
	$html = '
	  <div id="summaryContent">
	    
		<div class="row puffer">
	      <img src="https://brehna.net/wp-content/uploads/2023/08/bnet-website-logo.png" class="logo" 
		       alt="logo">		
	    </div>
	
        <hr class="noMargin">
	  
	    <div class="row puffer">
	      <div class="col">
		    <span class="spanNewline">Project66 IT Service & Design / Brehna.net</span>
		    <span class="spanNewline">Max-Planck-Str. 2</span>
		    <span class="spanNewline">06796 Brehna</span>
	      </div>
	    </div>

        <div class="row puffer">
	      <div class="col">
		    <span class="spanNewline">' . $infos["fName"]  . ' ' . $infos["lName"] . '</span>
		    <span class="spanNewline">' . $infos["street"] . ' ' . $infos["hNr"]   . '</span>
		    <span class="spanNewline">' . $infos["plz"]    . ' ' . $infos["place"];
		
    if (!empty($infos["district"])) {
	  $html .= ' OT ' + $infos["district"] + '</span>';
	} else {
	  $html .= '</span>
	      </div>
		</div>';
	}

	$html .= '
	  <div class="row puffer">
	    <div class="marginGapLeft">
	      <b>Ihre Auftragsbestellung vom ' . date("d.m.Y") . '</b>
		</div>
	  </div>
	';
	  
	$html .= '</div>';
	  
	echo json_encode($html);
  }
?>