<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views", "", __DIR__);

  require $dir . "/model/hardware_queries.php";
  require $dir . "/model/software_queries.php";
  require $dir . "/model/service_queries.php";
  require $dir . "/model/tariff_option_queries.php";

  $hardwareQueries = new HardwareQueries();
  $softwareQueries = new SoftwareQueries();
  $serviceQueries  = new ServiceQueries();
  $tariffOptionsQueries  = new TariffOptionsQueries();

  $hardwares = $hardwareQueries->getAllHardware();
  $softwares = $softwareQueries->getAllSoftware();
  $services  = $serviceQueries->getAllService();
  $options   = $tariffOptionsQueries->getAllTariffOptions();
?>
<div id="contractOptions" class="borderbox">
  <div id="contractOptionTO" class="borderbox">
	<div id="toTitle" class="row puffer">
	  <div class="col">
        <strong>Tarifoptionen</strong>
	  </div>
	</div>
	  
	<div id="pkTo" class="noDisplay">
	  <div class="row puffer">
		<div class="col-8">
          <span class="spanNewline">
			<input type="checkbox" id="to1" name="option" value="<?php echo $options[0]["id"]; ?>"> <?php echo $options[0]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to2" name="option" value="<?php echo $options[1]["id"]; ?>"> <?php echo $options[1]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to3" name="option" value="<?php echo $options[2]["id"]; ?>"> <?php echo $options[2]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to4" name="option" value="<?php echo $options[3]["id"]; ?>"> <?php echo $options[3]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to5" name="option" value="<?php echo $options[4]["id"]; ?>"> <?php echo $options[4]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to6" name="option" value="<?php echo $options[5]["id"]; ?>"> <?php echo $options[5]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to7" name="option" value="<?php echo $options[7]["id"]; ?>"> <?php echo $options[7]["name"] . " <span class=\"smFont\">" . $options[7]["note"] . "</span>"; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to8" name="optionPhone" value="<?php echo $options[6]["id"]; ?>" 
		    onclick="displayFormPhoneNumberPortability(this)"> <?php echo $options[6]["name"]; ?>
		  </span>
		</div>
		  
		<div id="pkToPrices" class="col">
          <span class="spanNewline"><?php echo number_format($options[0]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[1]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
	      <span class="spanNewline"><?php echo number_format($options[2]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[3]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[4]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[5]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[7]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		</div>
	  </div>
	</div>
	  
	<div id="pkSenTo" class="noDisplay">
	  <div class="row puffer">
		<div class="col">
          <span class="spanNewline">
			<input type="checkbox" id="to9" name="option" value="<?php echo $options[4]["id"]; ?>"> <?php echo str_replace(" je Sprachkanal", "", $options[4]["name"]); ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to10" name="option" value="<?php echo $options[3]["id"]; ?>"> <?php echo $options[3]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to11" name="option" value="<?php echo $options[8]["id"]; ?>"> <?php echo $options[8]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to12" name="option" value="<?php echo $options[9]["id"]; ?>"> <?php echo $options[9]["name"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="to13" name="optionPhone" value="<?php echo $options[6]["id"]; ?>" 
				   onclick="displayFormPhoneNumberPortability(this)"> <?php echo str_replace( " bei Telefonie", "", $options[6]["name"]); ?>
		  </span>
		</div>

		<div id="pkSenToPrices" class="col">
          <span class="spanNewline"><?php echo number_format($options[4]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[3]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[8]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($options[9]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		</div>
	  </div>
	</div>

	<div id="gkTo" class="noDisplay">
	  <div class="row puffer">
		<div class="col-6">
          <span class="spanNewline">
			<input type="checkbox" id="to14" name="option" value="<?php echo $options[10]["id"]; ?>"> <?php echo $options[10]["name"] . " <span class=\"smFont\">" . $options[10]["note"] . "</span>"; ?>
		  </span>

          <span class="spanNewline">
			<input type="checkbox" id="to15" name="option" value="<?php echo $options[11]["id"]; ?>"> <?php echo $options[11]["name"] . " <span class=\"smFont\">" . $options[11]["note"] . "</span>"; ?>
		  </span>

          <span class="spanNewline">
			<input type="checkbox" id="to16" name="option" value="<?php echo $options[12]["id"]; ?>"> <?php echo $options[12]["name"] . " <span class=\"smFont\">" . $options[12]["note"] . "</span>"; ?>
		  </span>

          <span class="spanNewline">
			<input type="checkbox" id="to17" name="option" value="<?php echo $options[13]["id"]; ?>"> <?php echo $options[13]["name"]; ?>
		  </span>
		</div>

		<div class="col">
		  <span class="spanNewline">
			<?php echo $options[10]["power_down"] . " MBit / " . $options[10]["power_up"] . " MBit/s"; ?>
		  </span>

		  <span class="spanNewline">
			<?php echo $options[11]["power_down"] . " MBit / " . $options[11]["power_up"] . " MBit/s"; ?>
		  </span>

		  <span class="spanNewline">
			<?php echo $options[12]["power_down"] . " MBit / " . $options[12]["power_up"] . " MBit/s"; ?>
		  </span>
		</div>
		  
		<div id="gkToPrices" class="col">
		  <span class="spanNewline"><?php echo number_format($options[10]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		  <span class="spanNewline"><?php echo number_format($options[11]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		  <span class="spanNewline"><?php echo number_format($options[12]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		  <span class="spanNewline"><?php echo number_format($options[13]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		</div>
	  </div>
		
	  <div class="row puffer">
		<div class="col-7">
		  <?php echo $options[4]["name"]; ?>
		  <input type="text" name="gkTOCnt1" id="gkTOCnt1" placeholder="Anzahl">
		</div>
		
		<div id="gkToPrices2" class="col">
          <?php echo "je " . number_format($options[4]["price_gk"], 2, ',', ' ') . " € pro Monat"; ?>
		</div>
	  </div>

	  <div class="row puffer">
	    <div class="col-7">
			<?php echo $options[3]["name"]; ?>
			<input type="text" name="gkTOCnt2" id="gkTOCnt2" placeholder="Anzahl">
        </div>
		
		<div id="gkToPrices3" class="col">
          <?php echo "je " . number_format($options[3]["price_gk"], 2, ',', ' ') . " € pro Monat"; ?>
		</div>
	  </div>
		
	  <div class="row puffer">
	    <div class="col">
		  <input type="checkbox" id="to20" name="optionPhone" value="<?php echo $options[6]["id"]; ?>" 
		  onclick="displayFormPhoneNumberPortability(this)"> <?php echo str_replace( " bei Telefonie", "", $options[6]["name"]); ?>  
		</div>
	  </div>
	</div>
  </div>
  
  <div  id="contractOptionPhone" class="borderbox noDisplay">
	<?php require "phone_number_portability.php"; ?>  
  </div>
	
  <div id="contractOptionHw" class="borderbox">
	<div id="hwTitle" class="row puffer">
	  <div class="col">
        <strong>Hardware</strong>
	  </div>
	</div>
	  
	<div id="pkHw" class="noDisplay">
	  <div class="row puffer">
		<div class="col">
		  <span class="spanNewline">
		    <input type="checkbox" id="hw1" name="optionHW" value="<?php echo $hardwares[0]["id"]; ?>"> <?php echo $hardwares[0]["name"] . " " . $hardwares[0]["note"]; ?>
		  </span>
			
		  <span class="spanNewline">
		    <input type="checkbox" id="hw2" name="optionHW" value="<?php echo $hardwares[1]["id"]; ?>"> <?php echo $hardwares[1]["name"] . " " . $hardwares[1]["note"]; ?>
		  </span>
			
		  <span class="spanNewline">
		    <input type="checkbox" id="hw3" name="optionHW" value="<?php echo $hardwares[2]["id"]; ?>"> <?php echo $hardwares[2]["name"]; ?>
		  </span>

		  <span class="spanNewline">
		    <input type="checkbox" id="hw4" name="optionHW" value="<?php echo $hardwares[3]["id"]; ?>"> <?php echo $hardwares[3]["name"] . " " . $hardwares[3]["note"]; ?>
		  </span>
			
		  <span class="spanNewline">
		    <input type="checkbox" id="hw5" name="optionHW" value="<?php echo $hardwares[4]["id"]; ?>"> <?php echo $hardwares[4]["name"] . " " . $hardwares[4]["note"]; ?>
		  </span>
			
		  <span class="spanNewline">
		    <input type="checkbox" id="hw6" name="optionHW" value="<?php echo $hardwares[5]["id"]; ?>"> <?php echo $hardwares[5]["name"]; ?>
		  </span>
			  
		  <span class="spanNewline">
		    <input type="checkbox" id="hw7" name="optionHW" value="<?php echo $hardwares[6]["id"]; ?>"> <?php echo $hardwares[6]["name"]; ?>
		  </span>
		</div>
		  
		<div id="pkHwPrices" class="col">			
		  <span class="spanNewline"><?php echo number_format($hardwares[0]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[1]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[2]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[3]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[4]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[5]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		  <span class="spanNewline"><?php echo number_format($hardwares[6]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>
	</div>

	<div id="pkSenHw" class="noDisplay">
	  <div class="row puffer">
		<div class="col-8">
		  <span class="spanNewline">
			<input type="checkbox" id="hw8" name="optionHW" value="<?php echo $hardwares[8]["id"]; ?>"> <?php echo $hardwares[8]["name"] . " " . $hardwares[8]["note"]; ?>
		  </span>
		  
		  <span class="spanNewline">
			<input type="checkbox" id="hw9" name="optionHW" value="<?php echo $hardwares[9]["id"]; ?>"> <?php echo $hardwares[9]["name"] . " " . $hardwares[9]["note"]; ?>
		  </span>
		  
		  <span class="spanNewline">
			<input type="checkbox" id="hw10" name="optionHW" value="<?php echo $hardwares[10]["id"]; ?>"> <?php echo $hardwares[10]["name"] . " " . $hardwares[10]["note"]; ?>
		  </span>
		  
		  <span class="spanNewline">
			<input type="checkbox" id="hw11" name="optionHW" value="<?php echo $hardwares[11]["id"]; ?>"> <?php echo $hardwares[11]["name"] . " " . $hardwares[11]["note"]; ?>
		  </span>
		</div>
		  
		<div id="pkSenHwPrices" class="col">
	  <span class="spanNewline"><?php echo number_format($hardwares[8]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
	  <span class="spanNewline"><?php echo number_format($hardwares[9]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
	  <span class="spanNewline"><?php echo number_format($hardwares[10]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
	  <span class="spanNewline"><?php echo number_format($hardwares[11]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>
	</div>

	<div id="gkHw" class="noDisplay">
      <div class="row puffer">
		<div class="col-8">
		  <span class="spanNewline">
			<input type="checkbox" id="hw12" name="optionHW" value="<?php echo $hardwares[7]["id"]; ?>"> <?php echo $hardwares[7]["name"] . " " . $hardwares[7]["note"]; ?>
		  </span>
		</div>
		  
		<div id="gkHwPrices" class="col">
		  <span class="spanNewline"><?php echo number_format($hardwares[7]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>
	</div>
  </div>
	
  <div id="contractOptionSv" class="borderbox">
	<div id="svTitle" class="row puffer">
	  <div class="col">
        <strong>Dienstleistung</strong>
	  </div>
	</div>
	  
	<div id="pkSv" class="noDisplay">
	  <div class="row puffer">
		<div class="col-8">
		  <span class="spanNewline">
			<input type="checkbox" id="sv1" name="optionSV" value="<?php echo $services[0]["id"]; ?>"> <?php echo $services[0]["name"]; ?>
		  </span>
			
		  <span class="spanNewline">
			<input type="checkbox" id="sv2" name="optionSV" value="<?php echo $services[2]["id"]; ?>"> <?php echo "<b>" . $services[2]["name"] . "</b> <span class=\"smFont\">" . $services[2]["note"] . "</span>"; ?>
		  </span>
			
		  <span class="spanNewline">
			<input type="checkbox" id="sv3" name="optionSV" value="<?php echo $services[3]["id"]; ?>"> <?php echo $services[3]["name"] . " für " . $services[3]["note"]; ?>
		  </span>
		</div>
		  
		<div id="pkSvPrices" class="col">
		  <span class="spanNewline"><?php echo number_format($services[0]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
          <span class="spanNewline"><?php echo number_format($services[2]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
          <span class="spanNewline"><?php echo number_format($services[3]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>
	</div>
	  
	<div id="pkSenSv" class="noDisplay">
	  <div class="row puffer">
		<div class="col-8">
          <span class="spanNewline">
			<input type="checkbox" id="sv4" name="optionSV" value="<?php echo $services[6]["id"]; ?>"> <?php echo $services[6]["name"] . " " . $services[6]["note"]; ?>
		  </span>
		</div>
		  
		<div id="pkSenSvPrices" class="col">
          <span class="spanNewline"><?php echo number_format($services[6]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>
	</div>
	  
	<div id="gkSv" class="noDisplay">
	  <div class="row puffer">
		<div class="col-8">
          <span class="spanNewline">
			<input type="checkbox" id="sv5" name="optionSV" value="<?php echo $services[5]["id"]; ?>"> <?php echo $services[5]["name"] . " " . $services[5]["note"]; ?>
		  </span>
			
          <span class="spanNewline">
			<input type="checkbox" id="sv6" name="optionSV" value="<?php echo $services[4]["id"]; ?>"> <?php echo $services[4]["name"] . " " . $services[4]["note"]; ?>
		  </span>
		</div>
		  
		<div id="gkSvPrices" class="col">
          <span class="spanNewline"><?php echo number_format($services[5]["price"], 2, ',', ' ') . " € einmalig"; ?></span>
		</div>
	  </div>  
	</div>
  </div>
	
  <div id="contractOptionSw" class="borderbox noDisplay">
    <div id="swTitle" class="row puffer">
	  <div class="col">
        <strong>Software</strong>
	  </div>
	</div>
	  
	<div class="row puffer">
	  <div class="col-8">
        <span class="spanNewline">
		  <input type="checkbox" id="sw1" name="optionSW" value="<?php echo $softwares[0]["id"]; ?>"> <?php echo $softwares[0]["name"] . " " . $softwares[0]["note"]; ?>
		</span>

        <span class="spanNewline">
		  <input type="checkbox" id="sw2" name="optionSW" value="<?php echo $softwares[1]["id"]; ?>"> <?php echo $softwares[1]["name"] . " " . $softwares[1]["note"]; ?>
		</span>
	  </div>
		
	  <div id="gkSwPrices" class="col">
        <span class="spanNewline"><?php echo number_format($softwares[0]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
		  
        <span class="spanNewline"><?php echo number_format($softwares[1]["price"], 2, ',', ' ') . " € pro Monat"; ?></span>
	  </div>
	</div>
  </div>
</div>