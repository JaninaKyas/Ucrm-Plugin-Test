<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);

	require_once __DIR__ . "/model/numerically_queries.php";
	require_once __DIR__ . "/views/glassFibre/glass_fibre_sepa.php";
	  
	$numericallyQueries = new NumericallyQueries();
	$defaultValues      = $numericallyQueries->getAllNumericallyFttH();
	  
	$sepaTemplate = new GlassFibreSepa($defaultValues);

	$customer = $infos["customer"];
	$address  = $infos["postalAddress"];

	$content = array(
	  "step6content" => $sepaTemplate->buildGlassFibreKontoTemplate($customer, $address)
	);

	echo json_encode($content);
  } 
?>