<?php
  declare(strict_types = 1);

  $dir = str_replace("/glassFibre", "", __DIR__);

  require __DIR__ . "/forms/customer.php";
  require __DIR__ . "/forms/connection_data.php";
  require $dir    . "/errorMsg/error_message.php";

  class GlassFibre {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
	}
 
	public function buildDescription() {
      $errorMsg = new ErrorMessage('Die von Ihnen angegebene Adresse konnte nicht gefunden werden.');
		
	  $returnValue = '
	    <div>
		  <div class="row">
		    <div class="col">' . $errorMsg->buildErrorDiv2() . '<br>
			  <div class="alert alert-primary" role="alert">
				<span class="dirLeft">
				<b>ACHTUNG!</b><br> Sie haben nun aber die Alternative über uns einen 
				Glasfaserhausanschluss FttH via Mikrorohrsystems zu beantragen oder senden Sie uns eine 
				Anschluss-Anfrage.  
				</span>
			  </div>
			</div>
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
	  
	public function buildExpansionAreaTemplate(): string {
	  return '';
	}
	  
    public function getGlasFibreTemplate(): string {
	  $customer = new Customer($this->templateData, $this->values);		
	  return $customer->buildCustomerTemplate();
	}
	  
    public function getGlasFibreConnectionTemplate($defaultData): string {		
	  $templateData = array(
	    "kindConnection" => array("typeCon", "inMfhWe", "inFinishTermin"),
		"introHouse"     => array("introHouse", "addElse"),
		"designConHouse" => array("designConHouse", "cntInMeter", "cntInHour", "cntAdd")
	  );
	  $connectionData = new ConnectionData($templateData, $defaultData);
	  return $connectionData->buildConnectionDataTemplate();
	}
  }
?>