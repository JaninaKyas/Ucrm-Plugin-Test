<div class="row puffer">
  <div class="col">
    <label for="cNr" class="form-label">Kundennummer</label>
    <input type="text" class="form-control" id="cNr" name="cNr" placeholder="Kundennummer" 
    value="<?php if (!empty($user) && !empty($user["custom_number"])) { echo trim($user["custom_number"]); } ?>" 
    onkeypress="return /[0-9]/.test(event.key)"> 
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="cFirstname" class="form-label">Vorname*</label>
    <input type="text" class="form-control required" id="cFirstname" name="cFirstname" placeholder="Vorname" 
       value="<?php if (!empty($user) && !empty($user["firstname"])) { echo trim($user["firstname"]); } ?>">               
  </div>
  <div class="col">
        <label for="cLastname" class="form-label">Nachname*</label>
        <input type="text" class="form-control required" id="cLastname" name="cLastname" placeholder="Nachname" 
       value="<?php if (!empty($user) && !empty($user["lastname"])) { echo trim($user["lastname"]); } ?>">               
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="cCompany" class="form-label">Firma (falls Meldung als Businesskunde)</label>
    <input type="text" class="form-control" id="cCompany" name="cCompany" placeholder="Firma"
    value="<?php if (!empty($user) && !empty($user["company"])) { echo trim($user["company"]); } ?>">            
  </div>
</div>
            
<div class="row puffer">
  <div class="col">
    <label for="cStreet" class="form-label">Strasse*</label>
    <input type="text" class="form-control required" id="cStreet" name="cStreet" placeholder="Strasse"
    value="<?php if (!empty($user) && !empty($user["street"])) { echo trim($user["street"]); } ?>">   
  </div>
  <div class="col">
    <label for="cHNr" class="form-label">Hausnummer*</label>
    <input type="text" class="form-control required" id="cHNr" name="cHNr" placeholder="Hausnummer"
    value="<?php if (!empty($user) && !empty($user["house_number"])) { echo trim($user["house_number"]); } ?>" 
    onkeypress="return /[0-9a-zA-Z]/.test(event.key)">
  </div>
</div>
            
<div class="row puffer">
  <div class="col">
    <label for="cPLZ" class="form-label">Postleitzahl*</label>
    <input type="text" class="form-control required" id="cPLZ" name="cPLZ" placeholder="Postleitzahl"
    value="<?php if (!empty($user) && !empty($user["postcode"])) { echo trim($user["postcode"]); } ?>" 
    onkeypress="return /[0-9]/.test(event.key)"> 
  </div>
  <div class="col">
    <label for="cLocation" class="form-label">Ort*</label>
    <select id="cLocation" name="cLocation" class="form-select" onchange="setVisibilityRow(this)">
      <option value="-1">... bitte auswählen ...</option>
      <?php                  
        foreach ($places as $place) {
          $placeName = $place["name"];
          
          if (!is_null($place["district"])) {
            $placeName = $placeName . " OT " . $place["district"]; 
          }
                      
          if (!empty($user) && $user["place"] == $place["id"]) {
            echo "<option value='" . trim($user["place"]) . "' selected>" . trim($placeName) . "</option>";
          } else {
            echo "<option value='" . trim($place["id"]) . "'>" . trim($placeName) . "</option>";
          }
        }
      ?>               
    </select>
  </div>
</div>

<?php if ($user["place"] == 20) { ?>
<div id="cRowOtherLoca" class="row puffer">
  <div class="col">
    <label for="cOtherLoca1" class="form-label">Anderer Ort*</label>
    <input type="text" class="form-control required" id="cOtherLoca1" name="cOtherLoca1" placeholder="Anderer Ort" 
    value="<?php if (!empty($user) && !empty($user["other_place"])) { echo trim($user["other_place"]); } ?>">
  </div>
</div>
<?php } else { ?>   
<div id="cRowOtherLoca" class="row visibleRow"> 
  <div class="col">
    <label for="cOtherLoca1" class="form-label">Anderer Ort*</label>
    <input type="text" class="form-control required" id="cOtherLoca1" name="cOtherLoca1" placeholder="Anderer Ort" 
    value="<?php if (!empty($user) && !empty($user["other_place"])) { echo trim($user["other_place"]); } ?>">
  </div>
</div>      
<?php } ?>
    
<div class="row puffer">
  <div class="col">
    <label for="cMail" class="form-label">E-Mail*</label>
    <input type="text" class="form-control required" id="cMail" name="cMail" placeholder="E-Mail"
    value="<?php if (!empty($user) && !empty($user["email"])) { echo trim($user["email"]); } ?>">
  </div>
  <div class="col">
    <label for="cPhone" class="form-label">Telefon/Mobil*</label>
    <input type="text" class="form-control required" id="cPhone" name="cPhone" placeholder="Telefon/Mobil"
    value="<?php if (!empty($user) && !empty($user["phone"])) { echo trim($user["phone"]); } ?>" 
    onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="cTechnik" class="form-label required">Über welche Technologie wird der Kunde versorgt?*</label>
    <input type="text" class="form-control required" id="cTechnik" name="cTechnik"
    placeholder="Glasfaser, VDSL, Funk" value="<?php if (!empty($user) && !empty($user["technology"])) { echo trim($user["technology"]); } ?>">
  </div>
</div>

<script>
  function setVisibilityRow(select) {
    var selectValue = select.value;
    var row = document.getElementById("cRowOtherLoca");
        
    if (selectValue === "20") {
      row.style.display = "block";
    } else {
      row.style.display = "none";
    }
  }
</script>
