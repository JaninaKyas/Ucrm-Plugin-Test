<div id="router-1">
  <b>Was für ein Router wird verwendet?</b>
  <ul class="list-group">
    <li class="list-group-item">
      <input type="radio" id="fritzbox2" name="rKind" value="Fritz!Box 7590 AX" onclick="showFritzBoxLedState()">
      <label for="fritzbox2">Fritz!Box 7590 AX</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox3" name="rKind" value="Fritz!Box 7590" onclick="showFritzBoxLedState()">
      <label for="fritzbox3">Fritz!Box 7590</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox5" name="rKind" value="Fritz!Box 7530 AX" onclick="showFritzBoxLedState()">
      <label for="fritzbox5">Fritz!Box 7530 AX</label>
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox6" name="rKind" value="Fritz!Box 7530" onclick="showFritzBoxLedState()">
      <label for="fritzbox6">Fritz!Box 7530</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox7" name="rKind" value="Fritz!Box 7490" onclick="showFritzBoxLedState()">
      <label for="fritzbox7">Fritz!Box 7490</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox8" name="rKind" value="Fritz!Box 7430" onclick="showFritzBoxLedState()">
      <label for="fritzbox8">Fritz!Box 7430</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox9" name="rKind" value="Fritz!Box 4040" onclick="showFritzBoxLedState()">
      <label for="fritzbox9">Fritz!Box 4040</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox10" name="rKind" value="Fritz!Box 4020" onclick="showFritzBoxLedState()">
      <label for="fritzbox10">Fritz!Box 4020</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom" name="rKind" value="LANCOM 1926VAG-5G" 
      onclick="showLancom1926LedState(true, false)">
      <label for="lancom">LANCOM 1926VAG-5G</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom1" name="rKind" value="LANCOM 1926VAG-4G"
      onclick="showLancom1926LedState(false, true)">
      <label for="lancom1">LANCOM 1926VAG-4G</label>    
    </li>  
    <li class="list-group-item">
      <input type="radio" id="lancom2" name="rKind" value="LANCOM 1926VAG"
      onclick="showLancom1926LedState(false, false)">
      <label for="lancom2">LANCOM 1926VAG</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom3" name="rKind" value="LANCOM 1803VA-4G/1803VA"
      onclick="showLancom18LedState(false, true, true)">
      <label for="lancom3">LANCOM 1803VA-4G/1803VA</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom4" name="rKind" value="LANCOM 1800VAW-4G/1800VAW"
      onclick="showLancom18LedState(true, false, false)">
      <label for="lancom4">LANCOM 1800VAW-4G/1800VAW</label>    
    </li>   
    <li class="list-group-item">
      <input type="radio" id="lancom5" name="rKind" value="LANCOM 1800VA-4G/1800VA"
      onclick="showLancom18LedState(false, false, false)">
      <label for="lancom5">LANCOM 1800VA-4G/1800VA</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom6" name="rKind" value="LANCOM 1793VAW"
      onclick="showLancom1793LedState()">
      <label for="lancom6">LANCOM 1793VAW</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom7" name="rKind" value="LANCOM 1790VA-4G+"
      onclick="showLancom17LedState(false, true)">
      <label for="lancom7">LANCOM 1790VA-4G+</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom8" name="rKind" value="LANCOM 1790VAW"
      onclick="showLancom17LedState(true, false)">
      <label for="lancom8">LANCOM 1790VAW</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom8" name="rKind" value="LANCOM 1790VA"
      onclick="showLancom17LedState(false, false)">
      <label for="lancom8">LANCOM 1790VA</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="cOwnRouter" name="rKind" value="Eigenhardware" onclick="hideAllLedDisplays()">
      <label for="cOwnRouter">Anderes Modell</label>
      <br>
      <div class="row puffer">
        <div class="col">
          <label for="rModell" class="form-label">Um welches Modell handelt es sich?</label>
          <input type="text" class="form-control" id="rModell" name="rModell" placeholder="Modell" value="">
        </div>
      </div>
    </li>            
  </ul>
</div>

<div id="router-questionLabel">
  <b>Wie leuchten die Lampen auf dem Router?</b>
</div>

<div id="fritzBoxLedState" class="borderStyle">
  <div id="router-2 puffer">
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Power/ DSL</h4>
        <input type="radio" id="powerShine" name="power" value="Power/ DSL leuchtet">
        <label for="powerShine">leuchtet</label>
        <br>
        <input type="radio" id="powerFlash" name="power" value="Power/ DSL blinkt">
        <label for="powerFlash">blinkt</label>      
      </div>
      <div class="col">
        <h4>Info</h4>
        <input type="radio" id="infoShine" name="info" value="Info leuchtet grün">
        <label for="infoShine">leuchtet grün</label>
        <br>
        <input type="radio" id="infoFlash" name="info" value="Info blinkt grün">
        <label for="infoFlash">blinkt grün</label>   
        <br>
        <input type="radio" id="infoRed" name="info" value="Info leuchtet rot">
        <label for="infoRed">leuchtet rot</label>
        <br>
        <input type="radio" id="infoRed1" name="info" value="Info blinkt rot">
        <label for="infoRed1">blinkt rot</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>WLAN</h4>
        <input type="radio" id="wlanShine" name="wlan" value="WLAN leuchtet">
        <label for="wlanShine">leuchtet</label>
        <br>
        <input type="radio" id="wlanFlash" name="wlan" value="WLAN blinkt">
        <label for="wlanFlash">blinkt</label>  
      </div>
      <div class="col">
        <h4>FON/ DECT</h4>
        <input type="radio" id="fonShine" name="fon" value="FON/ DECT leuchtet">
        <label for="fonShine">leuchtet</label>
        <br>
        <input type="radio" id="fonFlash" name="fon" value="FON/ DECT blinkt">
        <label for="fonFlash">blinkt</label>
      </div>
    </div>
  </div>
</div>

<div id="lancomLedState-1" class="borderStyle">
  <div id="router-4 puffer">
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Power</h4>
        <input type="radio" id="lancom19-out" name="lPower" value="Power aus">
        <label for="lancom19-out">aus</label>
        <br>
        <input type="radio" id="lancom19-green" name="lPower" value="Power grün dauerhaft an">
        <label for="lancom19-green">grün dauerhaft an</label>
        <br>
        <input type="radio" id="lancom19-green1" name="lPower" value="Power grün/ rot blinkend">
        <label for="lancom19-green1">grün/ rot blinkend</label>
        <br>
        <input type="radio" id="lancom19-red" name="lPower" value="Power rot blinkend">
        <label for="lancom19-red">rot blinkend</label>
        <br>
        <input type="radio" id="lancom19-iGreen" name="lPower" value="Power 1x grün invers blinkend">
        <label for="lancom19-iGreen">1x grün invers blinkend</label>
        <br>
        <input type="radio" id="lancom19-iGreen1" name="lPower" value="Power 2x grün invers blinkend">
        <label for="lancom19-iGreen1">2x grün invers blinkend</label>
        <br>
        <input type="radio" id="lancom19-iGreen2" name="lPower" value="Power 3x grün invers blinkend">
        <label for="lancom19-iGreen2">3x grün invers blinkend</label>
      </div>
      <div class="col">
        <h4>VPN</h4>
        <input type="radio" id="l1926-vpnOut" name="lVpn" value="VPN aus">
        <label for="l1926-vpnOut">aus</label>
        <br>
        <input type="radio" id="l1926-vpnGreen" name="lVpn" value="VPN grün dauerhaft an">
        <label for="l1926-vpnGreen">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-vpnGreen1" name="lVpn" value="VPN grün blitzend">
        <label for="l1926-vpnGreen1">grün blitzend</label>
      </div>
    </div> 
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>VoIP</h4>
        <input type="radio" id="l1926-voipOut" name="lVoIp" value="VoIP aus">
        <label for="l1926-voipOut">aus</label>
        <br>
        <input type="radio" id="l1926-voipGreen" name="lVoIp" value="VoIP grün dauerhaft an">
        <label for="l1926-voipGreen">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-voipRed" name="lVoIp" value="VoIP rot dauerhaft an">
        <label for="l1926-voipRed">rot dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-voipRed1" name="lVoIp" value="VoIP rot oder grün invers blitzend">
        <label for="l1926-voipRed1">rot oder grün invers blitzend</label>
      </div>
      <div class="col">
        <h4>G.FAST/ VDSL</h4>
        <input type="radio" id="l1926-vdslOut" name="lVdsl" value="G.FAST/ VDSL aus">
        <label for="l1926-vdslOut">aus</label>
        <br>
        <input type="radio" id="l1926-vdslGreen" name="lVdsl" value="G.FAST/ VDSL grün blinkend">
        <label for="l1926-vdslGreen">grün blinkend</label>
        <br>
        <input type="radio" id="l1926-vdslOk" name="lVdsl" value="G.FAST/ VDSL grün dauerhaft an">
        <label for="l1926-vdslOk">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-vdslGreenFlash" name="lVdsl" value="G.FAST/ VDSL grün flackernd">
        <label for="l1926-vdslGreenFlash">grün flackernd</label>
        <br>
        <input type="radio" id="l1926-vdslGreenFlash1" name="lVdsl" value="G.FAST/ VDSL orange/ grün flackernd">
        <label for="l1926-vdslGreenFlash1">orange/ grün flackernd</label>
        <br>
        <input type="radio" id="l1926-vdslGreenFlash2" name="lVdsl" value="G.FAST/ VDSL orange/ grün synchron blinkend">
        <label for="l1926-vdslGreenFlash2">orange/ grün synchron blinkend</label>
        <br>
        <input type="radio" id="l1926-vdslGreenFlash3" name="lVdsl" value="G.FAST/ VDSL orange blinkend">
        <label for="l1926-vdslGreenFlash3">orange blinkend</label>
        <br>                       
        <input type="radio" id="l1926-vdslGreenFlash4" name="lVdsl" value="G.FAST/ VDSL orange dauerhaft an">
        <label for="l1926-vdslGreenFlash4">orange dauerhaft an</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>WAN</h4>
        <input type="radio" id="l1926-wanGreen" name="lWan" value="WAN grün, orange aus">
        <label for="l1926-wanGreen">grün, orange aus</label>
        <br>
        <input type="radio" id="l1926-wanGreen1" name="lWan" value="WAN grün dauerhaft an">
        <label for="l1926-wanGreen1">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-wanOrange" name="lWan" value="WAN orange aus">
        <label for="l1926-wanOrange">orange aus</label>
        <br>
        <input type="radio" id="l1926-wanOrange1" name="lWan" value="WAN orange dauerhaft an">
        <label for="l1926-wanOrange1">orange dauerhaft an</label>
      </div>
      <div class="col">
        <h4>ETH</h4>
        <input type="radio" id="l1926-ethGreen" name="lEth" value="ETH grün, orange aus">
        <label for="l1926-ethGreen">grün, orange aus</label>
        <br>
        <input type="radio" id="l1926-ethGreen1" name="lEth" value="ETH grün dauerhaft an">
        <label for="l1926-ethGreen1">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-ethOrange" name="lEth" value="ETH orange aus">
        <label for="l1926-ethOrange">orange aus</label>
        <br>
        <input type="radio" id="l1926-ethOrange1" name="lEth" value="ETH orange dauerhaft an">
        <label for="l1926-ethOrange1">orange dauerhaft an</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>ISDN</h4>
        <input type="radio" id="l1926-isdnOut" name="lIsdn" value="ISDN aus">
        <label for="l1926-isdnOut">aus</label>
        <br>
        <input type="radio" id="l1926-isdnGreen" name="lIsdn" value="ISDN grün dauerhaft an">
        <label for="l1926-isdnGreen">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1926-isdnGreen1" name="lIsdn" value="ISDN grün blinkend">
        <label for="l1926-isdnGreen1">grün blinkend</label>
        <br>
        <input type="radio" id="l1926-isdnOrange" name="lIsdn" value="ISDN orange blinkend">
        <label for="l1926-isdnOrange">orange blinkend</label>
        <br>
        <input type="radio" id="l1926-isdnOrange1" name="lIsdn" value="ISDN orange/ grün synchron blinkend">
        <label for="l1926-isdnOrange1">orange/ grün synchron blinkend</label>
        <br>
        <input type="radio" id="l1926-isdnOrange2" name="lIsdn" value="ISDN orange dauerhaft an">
        <label for="l1926-isdnOrange2">orange dauerhaft an</label>
      </div>
      <div class="col">
        <span id="l1926-5g">
          <h4>5G</h4>
          <input type="radio" id="l1926-5gOut" name="l5G" value="5G aus">
          <label for="l1926-5gOut">aus</label>
          <br>
          <input type="radio" id="l1926-5gGreen" name="l5G" value="5G grün dauerhaft an">
          <label for="l1926-5gGreen">grün dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-5gGreen1" name="l5G" value="5G grün flackernd">
          <label for="l1926-5gGreen1">grün flackernd</label>
          <br>
          <input type="radio" id="l1926-5gOrange" name="l5G" value="5G orange blinkend">
          <label for="l1926-5gOrange">orange blinkend</label>
          <br>
          <input type="radio" id="l1926-5gOrange1" name="l5G" value="5G orange dauerhaft an">
          <label for="l1926-5gOrange1">orange dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-5gRed" name="l5G" value="5G rot dauerhaft an">
          <label for="l1926-5gRed">rot dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-5gRed1" name="l5G" value="5G rot/ grün blinkend">
          <label for="l1926-5gRed1">rot/ grün blinkend</label>
          <br>
          <input type="radio" id="l1926-5gRed2" name="l5G" value="5G rot/ orange blinkend">
          <label for="l1926-5gRed2">rot/ orange blinkend</label>
        </span>
        <span id="l1926-4g">
          <h4>4G</h4>
          <input type="radio" id="l1926-4gOut" name="l4G" value="4G aus">
          <label for="l1926-4gOut">aus</label>
          <br>
          <input type="radio" id="l1926-4gGreen" name="l4G" value="4G grün dauerhaft an">
          <label for="l1926-4gGreen">grün dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-4gGreen1" name="l4G" value="4G grün flackernd">
          <label for="l1926-4gGreen1">grün flackernd</label>
          <br>
          <input type="radio" id="l1926-4gOrange" name="l4G" value="4G orange blinkend">
          <label for="l1926-4gOrange">orange blinkend</label>
          <br>
          <input type="radio" id="l1926-4gOrange1" name="l4G" value="4G orange dauerhaft an">
          <label for="l1926-4gOrange1">orange dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-4gRed" name="l4G" value="4G rot dauerhaft an">
          <label for="l1926-4gRed">rot dauerhaft an</label>
          <br>
          <input type="radio" id="l1926-4gRed1" name="l4G" value="4G rot/ grün blinkend">
          <label for="l1926-4gRed1">rot/ grün blinkend</label>
          <br>
          <input type="radio" id="l1926-4gRed2" name="l4G" value="4G rot/ orange blinkend">
          <label for="l1926-4gRed2">rot/ orange blinkend</label>        
        </span>
      </div>
    </div>
  </div>
</div>

<div id="lancomLedState-2" class="borderStyle">
  <div id="router-3 puffer">
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Power</h4>
        <input type="radio" id="l1800-out" name="l18P" value="Power aus">
        <label for="l1800-out">aus</label>
        <br>
        <input type="radio" id="l1800-blue" name="l18P" value="Power blau dauerhaft an">
        <label for="l1800-blue">Power blau dauerhaft an</label>
        <br>
        <input type="radio" id="l1800-blue1" name="l18P" value="Power 1x blau invers blinkend">
        <label for="l1800-blue1">1x blau invers blinkend</label>
        <br>
        <input type="radio" id="l1800-blue2" name="l18P" value="Power 2x blau invers blinkend">
        <label for="l1800-blue2">2x blau invers blinkend</label>
        <br>
        <input type="radio" id="l1800-blue3" name="l18P" value="Power 3x blau invers blinkend">
        <label for="l1800-blue3">3x blau invers blinkend</label>
      </div>
      <div class="col">
        <h4>Online</h4>
        <input type="radio" id="l1800-online" name="l18O" value="Online aus">
        <label for="l1800-online">aus</label>
        <br>
        <input type="radio" id="l1800-onlineBlue" name="l18O" value="Online blau blinkend">
        <label for="l1800-onlineBlue">blau blinkend</label>
        <br>
        <input type="radio" id="l1800-onlineBlue1" name="l18O" value="Online blau dauerhaft an">
        <label for="l1800-onlineBlue1">blau dauerhaft an</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>WAN</h4>
        <input type="radio" id="l1800-wan" name="l18W" value="WAN aus">
        <label for="l1800-wan">aus</label>
        <br>
        <input type="radio" id="l1800-wan1" name="l18W" value="WAN blau flackernd">
        <label for="l1800-wan1">blau flackernd</label>
        <br>
        <input type="radio" id="l1800-wan2" name="l18W" value="WAN blau dauerhaft an">
        <label for="l1800-wan2">blau dauerhaft an</label>
      </div>
      <div class="col">
        <h4>SFP</h4>
        <input type="radio" id="l1800-sfp" name="l18S" value="SFP aus">
        <label for="l1800-sfp">aus</label>
        <br>
        <input type="radio" id="l1800-sfp1" name="l18S" value="SFP blau flackernd">
        <label for="l1800-sfp1">blau flackernd</label>
        <br>
        <input type="radio" id="l1800-sfp2" name="l18S" value="SFP blau dauerhaft an">
        <label for="l1800-sfp2">blau dauerhaft an</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>DSL</h4>
        <input type="radio" id="l1800-dsl" name="l18D" value="DSL aus">
        <label for="l1800-dsl">aus</label>
        <br>
        <input type="radio" id="l1800-dsl1" name="l18D" value="DSL blau blinkend/ schnell blinkend">
        <label for="l1800-dsl1">blau blinkend/ schnell blinkend</label>
        <br>
        <input type="radio" id="l1800-dsl2" name="l18D" value="DSL blau dauerhaft an">
        <label for="l1800-dsl2">blau dauerhaft an</label>
        <br>
        <input type="radio" id="l1800-dsl3" name="l18D" value="DSL blau flackernd">
        <label for="l1800-dsl3">blau flackernd</label>  
        <br>
        <input type="radio" id="l1800-dsl4" name="l18D" value="DSL blau blitzend">
        <label for="l1800-dsl4">blau blitzend</label>       
      </div>
      <div class="col">
        <h4>ETH</h4>
        <input type="radio" id="l1800-eth" name="l18E" value="ETH aus">
        <label for="l1800-eth">aus</label>
        <br>
        <input type="radio" id="l1800-eth1" name="l18E" value="ETH blau dauerhaft an">
        <label for="l1800-eth1">blau dauerhaft an</label>
        <br>
        <input type="radio" id="l1800-eth2" name="l18E" value="ETH blau flackernd">
        <label for="l1800-eth2">blau flackernd</label> 
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>VPN</h4>
        <input type="radio" id="l1800-vpn" name="l18V" value="VPN aus">
        <label for="l1800-vpn">aus</label>
        <br>
        <input type="radio" id="l1800-vpn1" name="l18V" value="VPN blau dauerhaft an">
        <label for="l1800-vpn1">blau dauerhaft an</label>
        <br>
        <input type="radio" id="l1800-vpn2" name="l18V" value="VPN blau flackernd">
        <label for="l1800-vpn2">blau flackernd</label>         
      </div>
      <div class="col">
        <h4>4G</h4>
        <input type="radio" id="l1800-4g" name="l18G" value="4G aus">
        <label for="l1800-4g">aus</label>
        <br>
        <input type="radio" id="l1800-4g0" name="l18G" value="4G blau blinkend">
        <label for="l1800-4g0">blau blinkend</label>
        <br>
        <input type="radio" id="l1800-4g1" name="l18G" value="4G blau dauerhaft an">
        <label for="l1800-4g1">blau dauerhaft an</label>
        <br>
        <input type="radio" id="l1800-4g2" name="l18G" value="4G blau flackernd">
        <label for="l1800-4g2">blau flackernd</label>
        <br>
        <input type="radio" id="l1800-4g3" name="l18G" value="4G blau blitzend">
        <label for="l1800-4g3">blau blitzend</label> 
        <br>
        <input type="radio" id="l1800-4g4" name="l18G" value="4G blau schnell blitzend">
        <label for="l1800-4g4">blau schnell blitzend</label>         
      </div>
    </div>
    
    <div class="row puffer pufferAdd">
      <div id="lan19-old1" class="col">
        <h4>Analog</h4>
        <input type="radio" id="l1800-analog" name="l18A" value="Analog aus">
        <label for="l1800-analog">aus</label>
        <br>
        <input type="radio" id="l1800-analog1" name="l18A" value="Analog blau blinkend">
        <label for="l1800-analog1">blau blinkend</label>
        <br>
        <input type="radio" id="l1800-analog2" name="l18A" value="Analog blau dauerhaft an">
        <label for="l1800-analog2">blau dauerhaft an</label>         
      </div>
      <div id="lan19-old2" class="col">
        <h4>ISDN</h4>
        <input type="radio" id="l1800-isdn" name="l18IS" value="ISDN aus">
        <label for="l1800-isdn">aus</label>
        <br>
        <input type="radio" id="l1800-isdn1" name="l18IS" value="ISDN blau blinkend">
        <label for="l1800-isdn1">blau blinkend</label>
        <br>
        <input type="radio" id="l1800-isdn2" name="l18IS" value="ISDN blau dauerhaft an">
        <label for="l1800-isdn2">blau dauerhaft an</label>   
        <br>
        <input type="radio" id="l1800-isdn3" name="l18IS" value="ISDN blau blitzend">
        <label for="l1800-isdn3">blau blitzend</label>       
      </div>
    </div>
      
    <div class="row puffer pufferAdd">
      <div class="col">
        <span id="lan19-wlan">
          <h4>WLAN</h4>
          <input type="radio" id="l1800-4WL" name="l18WL" value="WLAN aus">
          <label for="l1800-4WL">aus</label>
          <br>
          <input type="radio" id="l1800-wl0" name="l18WL" value="WLAN blau blinkend">
          <label for="l1800-wl0">blau blinkend</label>
          <br>
          <input type="radio" id="l1800-wlan1" name="l18WL" value="WLAN blau dauerhaft an">
          <label for="l1800-wlan1">blau dauerhaft an</label>
        </span>
        <span id="lan19-voip">
          <h4>VoIP</h4>
          <input type="radio" id="l1800-voip" name="l18VP" value="VoIP aus">
          <label for="l1800-voip">aus</label>
          <br>
          <input type="radio" id="l1800-voip1" name="l18VP" value="VoIP blau blinkend">
          <label for="l1800-voip1">blau blinkend</label>
          <br>
          <input type="radio" id="l1800-voip2" name="l18VP" value="VoIP blau dauerhaft an">
          <label for="l1800-voip2">blau dauerhaft an</label>        
        </span>
      </div>
    </div>
  </div>
</div>

<div id="lancomLedState-3" class="borderStyle">
  <div id="router-5 puffer">
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Power</h4>
        <input type="radio" id="l1790-out" name="l17P" value="Power aus">
        <label for="l1790-out">aus</label>
        <br>
        <input type="radio" id="l1790-green" name="l17P" value="Power grün dauerhaft an">
        <label for="l1790-green">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1790-green1" name="l17P" value="Power grün/ rot blinkend">
        <label for="l1790-green1">grün/ rot blinkend</label>   
        <br>
        <input type="radio" id="l1790-red" name="l17P" value="Power rot blinkend">
        <label for="l1790-red">rot blinkend</label>         
        <br>
        <input type="radio" id="l1790-iGreen" name="l17P" value="Power 1x grün invers blinkend">
        <label for="l1790-red">1x grün invers blinkend</label>         
        <br>
        <input type="radio" id="l1790-iGreen1" name="l17P" value="Power 2x grün invers blinkend">
        <label for="l1790-red">2x grün invers blinkend</label>         
        <br>
        <input type="radio" id="l1790-iGreen2" name="l17P" value="Power 3x grün invers blinkend">
        <label for="l1790-red">3x grün invers blinkend</label>         
      </div>
      <div class="col">
        <h4>DSL</h4>
        <input type="radio" id="l1790-dOut" name="l17D" value="DSL aus">
        <label for="l1790-dOut">aus</label>
        <br>
        <input type="radio" id="l1790-dGreen" name="l17D" value="DSL grün dauerhaft an">
        <label for="l1790-dGreen">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1790-dGreen1" name="l17D" value="DSL grün flackernd">
        <label for="l1790-dGreen1">grün flackernd</label>   
        <br>
        <input type="radio" id="l1790-dRed" name="l17D" value="DSL rot flackernd">
        <label for="l1790-dRed">rot flackernd</label>         
        <br>
        <input type="radio" id="l1790-dRed1" name="l17D" value="DSL rot/ orange blinkend">
        <label for="l1790-dRed1">rot/ orange blinkend</label>         
        <br>
        <input type="radio" id="l1790-dOrange" name="l17D" value="DSL orange blinkend">
        <label for="l1790-dOrange">orange blinkend</label>         
        <br>
        <input type="radio" id="l1790-dOrange1" name="l17D" value="DSL orange dauerhaft an">
        <label for="l1790-dOrange1">orange dauerhaft an</label>
        <br>
        <input type="radio" id="l1790-dGreen1" name="l17D" value="DSL grün blinkend">
        <label for="l1790-dGreen1">grün blinkend</label>                
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Online</h4>
        <input type="radio" id="l1790-oOut" name="l17O" value="Online aus">
        <label for="l1790-oOut">aus</label>
        <br>
        <input type="radio" id="l1790-oGreen" name="l17O" value="Online grün blinkend">
        <label for="l1790-oGreen">grün blinkend</label>
        <br>
        <input type="radio" id="l1790-oGreen1" name="l17O" value="Online grün dauerhaft an">
        <label for="l1790-oGreen1">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1790-oRed" name="l17O" value="Online rot dauerhaft an">
        <label for="l1790-oRed">rot dauerhaft an</label>   
      </div>
      <div class="col">
        <h4>ETH</h4>
        <input type="radio" id="l1790-eOut" name="l17E" value="ETH aus">
        <label for="l1790-eOut">aus</label>
        <br>
        <input type="radio" id="l1790-eGreen" name="l17E" value="ETH grün flackernd">
        <label for="l1790-eGreen">grün flackernd</label>
        <br>
        <input type="radio" id="l1790-eGreen1" name="l17E" value="ETH grün dauerhaft an">
        <label for="l1790-eGreen1">grün dauerhaft an</label>        
      </div> 
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>VPN</h4>
        <input type="radio" id="l1790-vOut" name="l17V" value="VPN aus">
        <label for="l1790-vOut">aus</label>
        <br>
        <input type="radio" id="l1790-vGreen" name="l17V" value="VPN grün blitzend">
        <label for="l1790-vGreen">grün blitzend</label>
        <br>
        <input type="radio" id="l1790-vGreen1" name="l17V" value="VPN grün dauerhaft an">
        <label for="l1790-vGreen1">grün dauerhaft an</label> 
      </div>
      <div class="col">
        <span id="l1790-wlan">
          <h4>WLAN</h4>
          <input type="radio" id="l1790-wOut" name="l17w" value="WLAN aus">
          <label for="l1790-wOut">aus</label>
          <br>
          <input type="radio" id="l1790-wGreen" name="l17w" value="WLAN grün blitzend">
          <label for="l1790-wGreen">grün blitzend</label>
          <br>
          <input type="radio" id="l1790-wGreen1" name="l17w" value="WLAN grün dauerhaft an">
          <label for="l1790-wGreen1">grün dauerhaft an</label> 
          <br>
          <input type="radio" id="l1790-wRed" name="l17w" value="WLAN rot blinkend">
          <label for="l1790-wRed">rot blinkend</label>
        </span>
        <span id="l1790-4g">
          <h4>4G</h4>
          <input type="radio" id="l1790-gOut" name="l17G" value="4G aus">
          <label for="l1790-gOut">aus</label>
          <br>
          <input type="radio" id="l1790-gGreen" name="l17G" value="WLAN grün flackernd">
          <label for="l1790-gGreen">grün flackernd</label>
          <br>
          <input type="radio" id="l1790-gGreen1" name="l17G" value="WLAN grün dauerhaft an">
          <label for="l1790-gGreen1">grün dauerhaft an</label> 
          <br>
          <input type="radio" id="l1790-gOrange" name="l17G" value="WLAN orange dauerhaft an">
          <label for="l1790-gOrange">orange dauerhaft an</label>
          <br>
          <input type="radio" id="l1790-gOrange1" name="l17G" value="WLAN orange blinkend">
          <label for="l1790-gOrange1">orange blinkend</label>
          <br>
          <input type="radio" id="l1790-gRed" name="l17G" value="WLAN rot dauerhaft an">
          <label for="l1790-gRed">rot dauerhaft an</label>
          <br>
          <input type="radio" id="l1790-gRed1" name="l17G" value="WLAN rot/ grün blinkend">
          <label for="l1790-gRed1">rot/ grün blinkend</label>
          <br>
          <input type="radio" id="l1790-gRed2" name="l17G" value="WLAN rot/ orange blinkend">
          <label for="l1790-gRed2">rot/ orange blinkend</label>
        </span>
      </div>
    </div>
  </div>
</div>

<div id="lancomLedState-4" class="borderStyle">
  <div id="router-6 puffer">
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Power</h4>
        <input type="radio" id="l1793-out" name="l1793P" value="Power aus">
        <label for="l1793-out">aus</label>
        <br>
        <input type="radio" id="l1793-green" name="l1793P" value="Power grün dauerhaft an">
        <label for="l1793-green">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1793-green1" name="l1793P" value="Power grün/ rot blinkend">
        <label for="l1793-green1">grün/ rot blinkend</label>   
        <br>
        <input type="radio" id="l1793-red" name="l1793P" value="Power rot blinkend">
        <label for="l1793-red">rot blinkend</label>         
        <br>
        <input type="radio" id="l1793-iGreen" name="l1793P" value="Power 1x grün invers blinkend">
        <label for="l1793-red">1x grün invers blinkend</label>         
        <br>
        <input type="radio" id="l1793-iGreen1" name="l1793P" value="Power 2x grün invers blinkend">
        <label for="l1793-red">2x grün invers blinkend</label>         
        <br>
        <input type="radio" id="l1793-iGreen2" name="l1793P" value="Power 3x grün invers blinkend">
        <label for="l1793-red">3x grün invers blinkend</label>  
      </div>
      <div class="col">
        <h4>DSL</h4>
        <input type="radio" id="l1793-dOut" name="l1793D" value="DSL aus">
        <label for="l1793-dOut">aus</label>
        <br>
        <input type="radio" id="l1793-dGreen" name="l1793D" value="DSL grün dauerhaft an">
        <label for="l1793-dGreen">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1793-dGreen1" name="l1793D" value="DSL grün flackernd">
        <label for="l1793-dGreen1">grün flackernd</label>   
        <br>
        <input type="radio" id="l1793-dRed" name="l1793D" value="DSL rot flackernd">
        <label for="l1793-dRed">rot flackernd</label>         
        <br>
        <input type="radio" id="l1793-dRed1" name="l1793D" value="DSL rot/ orange blinkend">
        <label for="l1793-dRed1">rot/ orange blinkend</label>         
        <br>
        <input type="radio" id="l1793-dOrange" name="l1793D" value="DSL orange blinkend">
        <label for="l1793-dOrange">orange blinkend</label>         
        <br>
        <input type="radio" id="l1793-dOrange1" name="l1793D" value="DSL orange dauerhaft an">
        <label for="l1793-dOrange1">orange dauerhaft an</label>
        <br>
        <input type="radio" id="l1793-dGreen1" name="l1793D" value="DSL grün blinkend">
        <label for="l1793-dGreen1">grün blinkend</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>Online</h4>
        <input type="radio" id="l1793-oOut" name="l1793O" value="Online aus">
        <label for="l1793-oOut">aus</label>
        <br>
        <input type="radio" id="l1793-oGreen" name="l1793O" value="Online grün blinkend">
        <label for="l1793-oGreen">grün blinkend</label>
        <br>
        <input type="radio" id="l1793-oGreen1" name="l1793O" value="Online grün dauerhaft an">
        <label for="l1793-oGreen1">grün dauerhaft an</label>
        <br>
        <input type="radio" id="l1793-oRed" name="l1793O" value="Online rot dauerhaft an">
        <label for="l1793-oRed">rot dauerhaft an</label>
      </div>
      <div class="col">
        <h4>Analog</h4>
        <input type="radio" id="l1793-aOut" name="l1793A" value="Analog aus">
        <label for="l1793-aOut">aus</label>
        <br>
        <input type="radio" id="l1793-aGreen" name="l1793A" value="Analog grün dauerhaft an">
        <label for="l1793-aGreen">grün dauerhaft an</label> 
        <br>
        <input type="radio" id="l1793-aOrange" name="l1793A" value="Analog orange blinkend">
        <label for="l1793-aOrange">grün flackernd</label>
        <br>
        <input type="radio" id="l1793-iGreen1" name="l1793A" value="Analog grün blickend">
        <label for="l1793-iGreen1">grün blickend</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>ISDN</h4>
        <input type="radio" id="l1793-iOut" name="l1793I" value="ISDN aus">
        <label for="l1793-iOut">aus</label>
        <br>
        <input type="radio" id="l1793-iGreen" name="l1793I" value="ISDN grün dauerhaft an">
        <label for="l1793-iGreen">grün dauerhaft an</label> 
        <br>
        <input type="radio" id="l1793-iGreen1" name="l1793I" value="ISDN grün flackernd">
        <label for="l1793-iGreen1">grün flackernd</label>
        <br>
        <input type="radio" id="l1793-iRed1" name="l1793I" value="ISDN rot flackernd">
        <label for="l1793-iRed1">rot flackernd</label>
        <br>
        <input type="radio" id="l1793-iOrange" name="l1793I" value="ISDN rot/ orange blinkend">
        <label for="l1793-iOrange">rot/ orange blinkend</label>
      </div>
      <div class="col">
        <h4>ETH</h4>
        <input type="radio" id="l1793-eOut" name="l1793E" value="ETH aus">
        <label for="l1793-eOut">aus</label>
        <br>
        <input type="radio" id="l1793-eGreen" name="l1793E" value="ETH grün flackernd">
        <label for="l1793-eGreen">grün flackernd</label>
        <br>
        <input type="radio" id="l1793-eGreen1" name="l1793E" value="ETH grün dauerhaft an">
        <label for="l1793-eGreen1">grün dauerhaft an</label> 
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>WLAN</h4>
        <input type="radio" id="l1793-wOut" name="l1793w" value="WLAN aus">
          <label for="l1793-wOut">aus</label>
          <br>
          <input type="radio" id="l1793-wGreen" name="l1793w" value="WLAN grün blinkend">
          <label for="l1793-wGreen">grün blinkend</label>
          <br>
          <input type="radio" id="l1793-wGreen1" name="l1793w" value="WLAN grün dauerhaft an">
          <label for="l1793-wGreen1">grün dauerhaft an</label> 
          <br>
          <input type="radio" id="l1793-wRed" name="l1793w" value="WLAN rot blinkend">
          <label for="l1793-wRed">rot blinkend</label>
      </div>
      <div class="col">
        <h4>VoIP</h4>
        <input type="radio" id="l1793-voOut" name="l1793VO" value="VoIP aus">
        <label for="l1793-voOut">aus</label>
        <br>
        <input type="radio" id="l1793-voRed" name="l1793VO" value="VoIP rot dauerhaft an">
        <label for="l1793-voRed">rot dauerhaft an</label>
        <br>
        <input type="radio" id="l1793-voGreen" name="l1793VO" value="VoIP grün dauerhaft an">
        <label for="l1793-voGreen">grün dauerhaft an</label> 
        <br>
        <input type="radio" id="l1793-voGreen1" name="l1793VO" value="VoIP rot oder grün invers blitzend">
        <label for="l1793-voGreen1">rot oder grün invers blitzend</label>
      </div>
    </div>
    <div class="row puffer pufferAdd">
      <div class="col">
        <h4>VPN</h4>
        <input type="radio" id="l1793-vOut" name="l1793V" value="VPN aus">
        <label for="l1793-vOut">aus</label>
        <br>
        <input type="radio" id="l1793-vGreen" name="l1793V" value="VPN grün blitzend">
        <label for="l1793-vGreen">grün blitzend</label>
        <br>
        <input type="radio" id="l1793-vGreen1" name="l1793V" value="VPN grün dauerhaft an">
        <label for="l1793-vGreen1">grün dauerhaft an</label> 
      </div>
    </div>
  </div>
</div>

<script>
  function showFritzBoxLedState() {
    hideAllLedDisplays();
    
    document.getElementById("router-questionLabel").style.display = "block";
    document.getElementById("fritzBoxLedState").style.display = "block";
  }

  function showLancom1926LedState(is5G, is4G) {
    hideAllLedDisplays();
    
    document.getElementById("router-questionLabel").style.display = "block";
    document.getElementById("lancomLedState-1").style.display = "block";
    
    if (is5G) {
      document.getElementById("l1926-5g").style.display = "block";
    }
    
    if (is4G) {
      document.getElementById("l1926-4g").style.display = "block";
    }
  }  

  function showLancom18LedState(hasWlan, hasOldCon, hasVoIp) {
    hideAllLedDisplays();
    
    document.getElementById("router-questionLabel").style.display = "block";
    document.getElementById("lancomLedState-2").style.display = "block";
    
    if (hasWlan) {
      document.getElementById("lan19-wlan").style.display = "block";
    }
    
    if (hasOldCon) {
      document.getElementById("lan19-old1").style.display = "block";
      document.getElementById("lan19-old2").style.display = "block";
    }
    
    if (hasVoIp) {
      document.getElementById("lan19-voip").style.display = "block";
    }
  }

  function showLancom17LedState(hasWlan, has4G) {
    hideAllLedDisplays();
    
    document.getElementById("router-questionLabel").style.display = "block";
    document.getElementById("lancomLedState-3").style.display = "block";
    
    if (hasWlan) {
      document.getElementById("l1790-wlan").style.display = "block";
    }
    
    if (has4G) {
      document.getElementById("l1790-4g").style.display = "block";
    }
  }

  function showLancom1793LedState() {
    hideAllLedDisplays();
    
    document.getElementById("router-questionLabel").style.display = "block";
    document.getElementById("lancomLedState-4").style.display = "block";
  }

  function hideAllLedDisplays() {
    document.getElementById("router-questionLabel").style.display = "none";
  
    document.getElementById("fritzBoxLedState").style.display = "none";
    document.getElementById("lancomLedState-1").style.display = "none";
    document.getElementById("lancomLedState-2").style.display = "none";
    document.getElementById("lancomLedState-3").style.display = "none";
    document.getElementById("lancomLedState-4").style.display = "none";
    
    document.getElementById("l1926-5g").style.display = "none";
    document.getElementById("l1926-4g").style.display = "none";
    
    document.getElementById("lan19-wlan").style.display = "none";
    document.getElementById("lan19-old1").style.display = "none";
    document.getElementById("lan19-old2").style.display = "none";
    document.getElementById("lan19-voip").style.display = "none";
    
    document.getElementById("l1790-wlan").style.display = "none";
    document.getElementById("l1790-4g").style.display = "none";
  }
</script>
