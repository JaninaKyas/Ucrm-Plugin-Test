<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interferences recording</title>    
    <link rel="stylesheet" href="public/css/bootstrap.min.css">
    <link rel="stylesheet" href="public/css/main.css">
  </head>
  <body>
    <h1 class="text-center fs-4" style="margin-top: 15px;">Störungsaufnahme</h1>
    
    <form id="recordingForm" method="post">
      <?php require(__DIR__ . '/search.php'); ?>
    </form>

    <script src="public/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" 
            crossorigin="anonymous"></script>
    <script src="public/js/main.js"></script>
  </body>    
</html>
