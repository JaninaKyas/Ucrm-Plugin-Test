<div id="contractSummary" class="borderBox">
</div>