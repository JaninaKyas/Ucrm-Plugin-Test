<?php

declare(strict_types = 1);

class CustomTable2 {
  private function getQueryWhere(string $search): string {
    $returnValue = '';
    
    if (!empty($search) && !is_null($search)) {
      $returnValue = "WHERE ctu.custom_number LIKE  '%" . $search . "%' OR"
                   . "      ctu.firstname     ILIKE '%" . $search . "%' OR"
                   . "      ctu.lastname      ILIKE '%" . $search . "%' OR"
                   . "      ctu.company       ILIKE '%" . $search . "%' OR"
                   . "      ctu.street        ILIKE '%" . $search . "%' OR" 
                   . "      ctu.house_number  ILIKE '%" . $search . "%' OR" 
                   . "      ctu.postcode      LIKE  '%" . $search . "%' OR"
                   . "      cp.name           LIKE  '%" . $search . "%' OR"
                   . "      cp.district       LIKE  '%" . $search . "%'";
    }
    
    return $returnValue;
  }
  
  function getAllUserBySearchParam(PDO $pdo, string $search): array {
    $where = $this->getQueryWhere($search);
    
    $query = "SELECT
                ctu.custom_number,
                ctu.firstname,
                ctu.lastname,
                ctu.company,
                ctu.street,
                ctu.house_number,
                ctu.postcode,
                ctu.place,
                CASE
                  WHEN cp.district IS NOT NULL THEN CONCAT (cp.name, ' OT ', cp.district)
                  ELSE cp.name
                END AS place_name,
                ctu.other_place,
                ctu.email,
                ctu.phone,
                ct.name AS technology,
                ctu.public_ip
              FROM custom_test_user      AS ctu
              JOIN custom_places         AS cp   ON ctu.place = cp.id
              JOIN custom_technik_x_user AS ctxu ON ctu.id    = ctxu.userid
              JOIN custom_technik        AS ct   ON ct.id     = ctxu.technikid " .
              $where
              . " ORDER BY ctu.custom_number, ctu.firstname, ctu.lastname";
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
    return ($result !== false) ? $result : [];
  }
}
