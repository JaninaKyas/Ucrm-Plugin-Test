<form id="chooseUser" method="post">
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>Kundennr.</th>
        <th>Kundenname</th>
        <th>Strasse</th>
        <th>Hsnr</th>
        <th>PLZ</th>
        <th>Ort</th>
        <th>Technik</th>
      </tr>
    </thead>
    <tbody>
    <?php
      foreach ($users as $data) {
        $uData = json_encode($data);
    ?>
      <tr>
        <td><?php echo $data["custom_number"]; ?></td>
        <td class="text-left">
        <?php                       
          if (!empty(trim($data["company"])) && trim($data["company"]) != '') {
            echo  "<button class=\"link-button\" type=\"submit\" name=\"loadUser\" value='". 
            $uData . "'>" . $data["company"] . "</button>";
          } else {
            echo "<button class=\"link-button\" type=\"submit\" name=\"loadUser\" value='". 
            $uData . "'>" . $data["lastname"] . ", " . $data["firstname"] . "</button>";
          }
        ?>
        </td>
        <td class="text-left"><?php echo $data["street"]; ?></td>
        <td><?php echo $data["house_number"];             ?></td>
        <td><?php echo $data["postcode"];                 ?></td>
        <td class="text-left">
          <?php
            if ($data["place"] != 20) {
              echo $data["place_name"];
            } else {
              echo $data["other_place"];
            }
          ?></td>
        <td><?php echo $data["technology"]; ?></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</form>
