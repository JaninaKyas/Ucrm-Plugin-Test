<?php
  $mainPath = str_replace("views/main/mStepProgressbar/layout", "", __DIR__);
?>

  <div id="multi-step-form-container">
    <ul class="form-stepper form-stepper-horizontal text-center mx-auto pl-0">
      <li class="form-stepper-active text-center form-stepper-list" step="1">
        <a class="mx-2">
          <span class="form-stepper-circle">
            <span>1</span>
          </span>
          <div class="label">Verfügbarkeit</div>
        </a>
      </li>

      <li class="form-stepper-unfinished text-center form-stepper-list" step="2">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>2</span>
          </span>
          <div class="label text-muted">
			<span id="step2Lable">Ergebnis</span>
		  </div>
        </a>
      </li>
		
      <li class="form-stepper-unfinished text-center form-stepper-list" step="3">
        <a class="mx-2">
          <span class="form-stepper-circle text-muted">
            <span>3</span>
          </span>
          <div class="label text-muted">
			<span id="step3Lable">Kundendaten</span>
		  </div>
        </a>
      </li>
    </ul>

    <form id="userAccountSetupForm" name="userAccountSetupForm" enctype="multipart/form-data" 
	      method="POST" class="templateBox">
      <section id="step-1" class="form-step">
        <div class="mt-3">
		  <?php require $mainPath . "views/internetAvailability/availability.php"; ?>
		</div>
        <div class="mt-3">
          <button class="button btn-navigate-form-step addressButton" type="button" 
				  step_number="2" btn_value="1" step_direction="1">Prüfen</button>
        </div>
      </section>

      <section id="step-2" class="form-step d-none templateBox">
		<div class="mt-3"><div id="ratesResult"></div></div>
        <div class="row mt-4">
	      <div class="col">
		  <button id="backBtnStep2" class="button btn-navigate-form-step addressButton"
				  type="button" step_number="1" step_direction="-1">
			<span id="btnLable1">Zurück</span>
		  </button>
			</div><div class="col">
          <button id="btnLable2" class="button btn-navigate-form-step addressButton"
				  type="button" step_number="3" step_direction="1">
			<span>Glasfaseranschluss</span>
		  </button>
			</div><div class="col">
          <button id="disForward" class="button btn-navigate-form-step addressButton"
				  type="button" step_number="3" step_direction="1">
		    <span id="btnLable3">Weiter</span>
			<span id="btnLable4">Anschluss - Anfrage</span>
		  </button>
			</div>
        </div>
      </section>
		
      <section id="step-3" class="form-step d-none templateBox">
		<div class="mt-3"><div id="step3Result"></div></div>
		  <div class="row mt-3">
			<div class="col">
		      <button class="button btn-navigate-form-step addressButton"
				      type="button" step_number="2" step_direction="-1">
			    <span id="btnLableS3">Zurück</span>
			  </button>
			</div>
			  
			<div class="col">  
		      <button class="button btn-navigate-form-step addressButton"
			  	      type="button" step_number="4" step_direction="-1">
			    <span id="btnLableS3">Weiter</span>
			  </button>
			</div>
		  </div>
	  </section>
    </form>
  </div>