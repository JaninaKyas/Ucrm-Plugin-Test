CREATE TABLE IF NOT EXISTS `contract_term` (
  `id`          INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `duration`    INT(2)     UNSIGNED NOT NULL DEFAULT 0,
  `term_option` CHAR(100)           NOT NULL DEFAULT '',
  `createDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)            NOT NULL DEFAULT '',
  `updateDate`  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)          NOT NULL DEFAULT 0,   
  PRIMARY KEY (id)
) ENGINE=INNODB;

INSERT INTO `contract_term` VALUES(null,  0, '',                              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_term` VALUES(null, 12, '',                              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_term` VALUES(null, 24, '(70,00 € Gutschrift Hardware)', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `contract_term` VALUES(null, 36, '',                              NOW(), 'JANINA', NOW(), 'JANINA', 0);