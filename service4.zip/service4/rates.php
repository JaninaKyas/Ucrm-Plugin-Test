<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if (isset($_POST)) {
	$content = array();
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);

	require_once __DIR__ . "/model/asb_availability_queries.php";
	require_once __DIR__ . "/model/expansion_area_queries.php";
	
	$isNewCon = ($infos["conKind"] == 1)? true : false;
	  
    $address = $infos["postalAddress"];
    if ($infos["techAddress"]["street"]  != ""
	 && $infos["techAddress"]["hnr"]     != ""
	 && $infos["techAddress"]["zipcode"] != ""
	 && $infos["techAddress"]["place"]   != "") {
	  $address = $infos["techAddress"];
	}
	  
	$asbAvailabilityQueries = new AsbAvailabilityQueries(
	  $address, $isNewCon, $infos["selTech"]
    );
	$tariffs = $asbAvailabilityQueries->getAllTariffByAddress();

	$expansionAreaQueries = new ExpansionAreaQueries();
	$isExAreaFttH = $expansionAreaQueries->isExpansionAreaFttH($address);
	  
	$templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company", "mail", "phone", "mobil"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode", "psPlace", "psDistrict"),
	  "conAddress"    => array("coStreet", "coHNr", "coZipcode", "coPlace", "coDistrict"),
	  "diffAddress"   => "dAddress"
	);
	  
	$populateValue = array("postalAddress" => $infos["postalAddress"]);
	  
    if ($infos["selTech"] == 2 && $isNewCon && $isExAreaFttH) {
	  $techAddress = array();
      if ($infos["techAddress"]["street"]  != ""
	   && $infos["techAddress"]["hnr"]     != ""
	   && $infos["techAddress"]["zipcode"] != ""
	   && $infos["techAddress"]["place"]   != "") {
	    $techAddress = $infos["techAddress"];
	  }
	  require_once __DIR__ . "/views/glassFibre/glass_fibre.php";
	  $glasFibre = new GlassFibre($templateData, $populateValue, $techAddress);
	  // path with FttH (expansion area)
	  $content = array(
		"ident"         => 1,
		"step2Lable"    => "Ergebnis",
		"step3Lable"    => "Kundendaten",
		"step4Lable"    => "Anschluss",
		"step5Lable"    => "Grundstück",
		"step6Lable"    => "Konto",
		"step7Lable"    => "AGB",
		"step8Lable"    => "Überblick",
		"step2Content"  => $glasFibre->buildExpansionAreaTemplate(),
		"step2BtnLable" => "Glasfaserhausanschluss",
		"show3Btn"      => false,
		"btnMenu"       => ""
	  );
	} else if (!empty($tariffs) && count($tariffs) > 0) {
	  $techAddress = array();
      if ($infos["techAddress"]["street"]  != ""
	   && $infos["techAddress"]["hnr"]     != ""
	   && $infos["techAddress"]["zipcode"] != ""
	   && $infos["techAddress"]["place"]   != "") {
	    $techAddress = $infos["techAddress"];
	  }
	  require_once __DIR__ . "/views/rates/tariff.php";
	  $tariffFormHtml = new Tariff($tariffs, $infos["postalAddress"], $techAddress);
	  // path to normal contract
      $content = array(
		"ident" => 2,
		"step2Lable"    => "Tarife",
		"step3Lable"    => "Kundendaten",
		"step4Lable"    => "Optionen",
		"step5Lable"    => "Konto",
		"step6Lable"    => "AGB",
		"step7Lable"    => "Überblick",
		"step8Lable"    => "Bestätigung",
		"step2Content"  => $tariffFormHtml->getTemplate(),
		"step2BtnLable" => "Weiter",
		"show3Btn"      => false,
		"btnMenu"       => ""
	  );
	} else {
	  if ($infos["selTech"] == 2) {
		require_once __DIR__ . "/views/glassFibre/glass_fibre.php";
		$glasFibre = new GlassFibre($templateData, $populateValue);
	    // path with FttH (no expansion area)
		$content = array(
		  "ident" => 3,
		  "step2Lable"    => "Ergebnis",
		  "step3Lable"    => "Kundendaten",
		  "step4Lable"    => "Anschluss",
		  "step5Lable"    => "Grundstück",
		  "step6Lable"    => "Konto",
		  "step7Lable"    => "AGB",
		  "step8Lable"    => "Bestätigung",
		  "step2Content"  => $glasFibre->buildDescription(),
		  "step2BtnLable" => "Anschluss - Anfrage",
		  "show3Btn"      => true,
		  "btnMenu"       => $glasFibre->buildButtonMenuTemplate()
		);
	  } else {
		require_once __DIR__ . "/views/connectionRequest/connection_request.php";  
		$conRequest = new ConnectionRequest($templateData, $populateValue);
		// default path -- connection request
		$content = array(
		  "ident" => 4,
		  "step2Lable"    => "Kundendaten",
		  "step3Lable"    => "Rückruf",
		  "step4Lable"    => "Tarife",
		  "step5Lable"    => "Konto",
		  "step6Lable"    => "AGB",
		  "step7Lable"    => "Überblick",
		  "step8Lable"    => "Bestätigung",
		  "step2Content"  => $conRequest->getTemplateStep2(),
		  "step2BtnLable" => "Weiter",
		  "show3Btn"      => false,
		  "btnMenu"       => ""
		);
	  }
	}

    echo json_encode($content);
  }
?>