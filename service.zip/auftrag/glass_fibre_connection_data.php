<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	$content       = array();
	$defaultValues = array();   

	require __DIR__ . "/model/connection_point_types_queries.php";
	require __DIR__ . "/model/house_intro_types_queries.php";
	require __DIR__ . "/model/commissioned_house_types_queries.php";
	require __DIR__ . "/views/glassFibre/glass_fibre.php";

	$conPointTypeQueries   = new ConPointTypeQueries();
	$houseIntroTypeQueries = new HouseIntroTypeQueries();
	$comHouseTypeQueries   = new ComHouseTypeQueries();

	$defaultValues["cptData"] = $conPointTypeQueries->getAllConPointTypes();
	$defaultValues["hitData"] = $houseIntroTypeQueries->getAllHouseIntroTypes();
	$defaultValues["chtData"] = $comHouseTypeQueries->getAllCommissionedHouseTypes();
	  
	$gfConnectionDataTemplate = new GlassFibre(array());
	$content["step4label"]   = "Anschluss";
	$content["step4content"] = $gfConnectionDataTemplate->getGlasFibreConnectionTemplate($defaultValues);
	  
	echo json_encode($content);
  }
?>