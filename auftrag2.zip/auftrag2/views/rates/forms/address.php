<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();
	public $disabled     = 'disabled';

    private $street   = '';
	private $hNr      = '';
	private $zipcode  = '';
	private $place    = '';
	private $district = '';
	
    private $tStreet   = '';
	private $tHNr      = '';
	private $tZipcode  = '';
	private $tPlace    = '';
	private $tDistrict = '';

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array(), 
								$disabled = 'disabled') {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
	  $this->disabled     = $disabled;
	  
	  if (!empty($this->values)) {
		if (array_key_exists("street", $this->values)) {
		  $this->street = $this->values["street"];
		}
		
		if (array_key_exists("hNr", $this->values)) {
		  $this->hNr = $this->values["hNr"];
		}
		
		if (array_key_exists("zipcode", $this->values)) {
		  $this->zipcode = $this->values["zipcode"];
		}
		
		if (array_key_exists("place", $this->values)) {
		  $this->place = $this->values["place"];
		}
		
		if (array_key_exists("district", $this->values)) {
		  $this->district = $this->values["district"];
		}
	  }
	  
	  if (!empty($this->techAddress)) {
		if (array_key_exists("street", $this->techAddress)) {
		  $this->tStreet = $this->techAddress["street"];
		}
		
		if (array_key_exists("hNr", $this->techAddress)) {
		  $this->tHNr = $this->techAddress["hNr"];
		}
		
		if (array_key_exists("zipcode", $this->techAddress)) {
		  $this->tZipcode = $this->techAddress["zipcode"];
		}
		
		if (array_key_exists("place", $this->techAddress)) {
		  $this->tPlace = $this->techAddress["place"];
		}
		
		if (array_key_exists("district", $this->techAddress)) {
		  $this->tDistrict = $this->techAddress["district"];
		}
	  }
	}
	  
	public function buildAddressTemplate(): string {		
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   value="' . $this->street . '" ' . $this->disabled . '>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   value="' . $this->hNr . '" ' . $this->disabled . '>
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   value="' . $this->zipcode . '" ' . $this->disabled . '
				   onkeypress="return /[0-9]/.test(event.key)">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   value="' . $this->place . '" ' . $this->disabled . '>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   value="' . $this->district . '" ' . $this->disabled . '>
		  </div>
		</div>
	  ';
	
	  if (in_array("psTae", $this->templateData)) {
		$returnValue .= '
	      <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Hauseingang / Wohnung</label>
		      <input type="text"
			         id="'   . $this->templateData[5] . '"
			  	     name="' . $this->templateData[5] . '"
				     class="form-control">
			</div>
		  </div>
		';
	  }
		
	  return $returnValue;
	}
	  
    public function buildTechAddressTemplate(): string {
	  $isEmpty = empty($this->techAddress);
	  $returnValue = '
	    <div class="row">
		  <div class="col">
		    <span class="fontTitle">
			  <input id="'   . $this->templateData[6] . '"
			         name="' . $this->templateData[6] . '"
					 type="checkbox"
					 onClick="displayTechAddress()">
			  Anschlussadresse (Angabe nur wenn abweichend von Postanschrift)
			</span>
		  </div>
		</div>
		
	    <span id="techAddress">
        <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse*</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   class="form-control requiredRC1"
				   value="' . $this->tStreet . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer*</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   class="form-control requiredRC1"
				   value="' . $this->tHNr . '"
				   onkeypress="return /[0-9a-zA-Z]/.test(event.key)"
				   onpaste="return false">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl*</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   class="form-control requiredRC1"
				   value="' . $this->tZipcode . '"
				   onkeypress="return /[0-9]/.test(event.key)"
				   onpaste="return false">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort*</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   class="form-control requiredRC1"
				   value="' . $this->tPlace . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   class="form-control"
				   value="' . $this->tDistrict . '">
		  </div>
		</div>
		
	      <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Hauseingang / Wohnung</label>
		      <input type="text"
			         id="'   . $this->templateData[5] . '"
			  	     name="' . $this->templateData[5] . '"
				     class="form-control">
			</div>
		  </div>
	    </span>
	  ';
		
	  return $returnValue;
	}
  }
?>