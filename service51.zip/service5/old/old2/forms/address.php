<?php
  class Address {
    public $street;
	public $houseNr;
	public $zipcode;
	public $place;
	public $district;
	public $country;
	public $appNr;
	public $showConType;
	  
	function __construct(string $sStreet, string $sHousNr, string $sZipcode, string $sPlace, string  $sDistrict = '', string $sCountry = '', string $sAppNr = '', bool $sShowConType = false) {
	  $this->street      = $sStreet;
	  $this->houseNr     = $sHousNr;
	  $this->zipcode     = $sZipcode;
	  $this->place       = $sPlace;
	  $this->district    = $sDistrict;
	  $this->country     = $sCountry;
	  $this->appNr       = $sAppNr;
	  $this->showConType = $sShowConType;
	}
	  
    public function getTemplate() {
	  $returnValue = '
	    <div class="addressBlock borderBox">
		  <div class="row">
		    <div class="col">
			  <label class="addressLabel">Strasse*</label>
			  <input id="'  . $this->street . '" name="' . $this->street . '" type="text" class="form-control">
			</div>

			<div class="col">
			  <label class="addressLabel">Hausnummer*</label>
			  <input id="'  . $this->houseNr . '" name="' . $this->houseNr . '" type="text" class="form-control">
			</div>
		  </div>
		  
		  <div class="row">
		    <div class="col">
			  <label class="addressLabel">Postleitzahl*</label>
			  <input id="'  . $this->zipcode . '" name="' . $this->zipcode . '" type="text" class="form-control">
			</div>
			
			<div class="col">
			  <label class="addressLabel">Ort*</label>
			  <input id="'  . $this->place . '" name ="' . $this->place . '" type="text" class="form-control">
			</div>
		  </div>
		  
		  <div class="row">
		    <div class="col">
			  <label class="addressLabel">Ortsteil</label>
			  <input id="'  . $this->district . '" name="'  . $this->district . '" type="text" class="form-control">
			</div>

			<div class="col">
			  <label class="addressLabel">Hauseingang / Wohnung</label>
			  <input id="'  . $this->appNr . '" name="'  . $this->appNr . '" type="text" class="form-control">
			</div>
		  </div>
	  ';
		
	  if (!empty($this->country) && $this->country != "") {
	    $returnValue .= '
		  <div class="row">
		    <div class="col">
			  <label class="addressLabel">Land*</label>
			  <input id="'  . $this->country . '" name="' . $this->country . '" type="text" class="form-control">
			</div>
		  </div>
		';
	  }
		
	  if ($this->showConType) {
	    $returnValue .= '
		  <div class="row">
		    <div class="col inpCheck inpCheckLabel">
			  Anschlussart
			</div>
			
			<div class="col inpCheck">
			  <input type="checkbox" name="conTypeFttH" value="1"> Glasfaser
			</div>
			
			<div class="col inpCheck">
			  <input type="checkbox" name="conTypeVDSL" value="2"> VDSL
			</div>
			
			<div class="col inpCheck">
			  <input type="checkbox" name="conTypeFunk" value="4"> Funk
            </div>
		  </div>
		';
	  }
		
	  $returnValue .= '</div>';
		
	  return $returnValue;
	}
  }
?>