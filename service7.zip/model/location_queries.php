<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class LocationQueries {	
	public function getIdByLocationData($place, $district = ''): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT id FROM location WHERE name LIKE \'' . $place . '\'';
   
		  if ($district != "") {
		    $query .= ' AND district LIKE \'' . $district . '\'';
		  }
			
		  $query .= ' LIMIT 1';
			
		  $result = $connection->query($query);
			
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }

		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
	public function saveLocationData($place, $district = ''): int {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = -1;
	  $config      = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
		  
		  $query = '
		    INSERT INTO location
            VALUES(
			  null,
			  \'' . $place             . '\',
			  \'' . $district          . '\',
               NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';
			

		  $returnValue = $connection->query($query);	
	
		  if ($returnValue != false) {
		    $returnValue = $connection->insert_id;
		  }

		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>