<?php

declare(strict_types = 1);

class CustomTable {  
  private function getQueryWhere($searchParams): string {
    $returnValue = 'WHERE';
    
    if (!empty($searchParams)) {
      if (!empty($searchParams[0]) && $searchParams[0] != "") {
        $returnValue = $returnValue . " ctu.custom_number LIKE '%" . $searchParams[0] . "%' AND";
      }

      if (!empty($searchParams[1]) && $searchParams[1] != "") {
        $returnValue = $returnValue . " ctu.firstname    ILIKE '%" . $searchParams[1] . "%' AND";
      }
      
      if (!empty($searchParams[2]) && $searchParams[2] != "") {
        $returnValue = $returnValue . " ctu.firstname    ILIKE '%" . $searchParams[2] . "%' AND";
      }
      
      if (!empty($searchParams[3]) && $searchParams[3] != "") {
        $returnValue = $returnValue . " ctu.company      ILIKE '%" . $searchParams[3] . "%' AND";
      }
      
      if (!empty($searchParams[4]) && $searchParams[4] != "") {
        $returnValue = $returnValue . " ctu.street       ILIKE '%" . $searchParams[4] . "%' AND"; 
      
        if (!empty($searchParams[5]) && $searchParams[5] != "") {
          $returnValue = $returnValue . " ctu.house_number ILIKE '%" . $searchParams[5] . "%' AND"; 
        }
      }
      
      if (!empty($searchParams[6]) && $searchParams[6] != "") {
        $returnValue = $returnValue . " ctu.postcode ILIKE '%" . $searchParams[7] . "%' AND";
      }
      
      if (!empty($searchParams[7]) && $searchParams[7] != "") {
        $returnValue = $returnValue . " cp.name      ILIKE '%" . $searchParams[7] . "%' AND";
      }
      
      if (!empty($searchParams[7]) && $searchParams[8] != "") {
        $returnValue = $returnValue . " cp.district  ILIKE '%" . $searchParams[8] . "%' AND";
      }
    }
    
    $returnValue = trim(substr($returnValue, 0, -3));
    
    return $returnValue;
  }
  
  function getAllUserBySearchParam(PDO $pdo, array $searchParams): array {
    $where = $this->getQueryWhere($searchParams);
    
    if (strlen($where) < 6) $where = '';
    
    $query = "SELECT
                ctu.custom_number,
                ctu.firstname,
                ctu.lastname,
                ctu.company,
                ctu.street,
                ctu.house_number,
                ctu.postcode,
                ctu.place,
                CASE
                  WHEN cp.district IS NOT NULL THEN CONCAT (cp.name, ' OT ', cp.district)
                  ELSE cp.name
                END AS place_name,
                ctu.other_place,
                ctu.email,
                ctu.phone,
                ct.name AS technology,
                ctu.public_ip
              FROM custom_test_user      AS ctu
              JOIN custom_places         AS cp   ON ctu.place = cp.id
              JOIN custom_technik_x_user AS ctxu ON ctu.id    = ctxu.userid
              JOIN custom_technik        AS ct   ON ct.id     = ctxu.technikid " .
              $where
              . " ORDER BY ctu.custom_number, ctu.firstname, ctu.lastname";
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  
    return ($result !== false) ? $result : [];
  }
}
