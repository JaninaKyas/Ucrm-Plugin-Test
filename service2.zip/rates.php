<?php
  if (isset($_POST)) {
	$content = array();
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);

	require_once __DIR__ . "/model/asb_availability_queries.php";
	require_once __DIR__ . "/model/expansion_area_queries.php";
	
	$isNewCon = ($infos["conKind"] == 1)? true : false;
	  
	$asbAvailabilityQueries = new AsbAvailabilityQueries($address, $isNewCon, $infos["selTech"]);
	$tariffs = $asbAvailabilityQueries->getAllTariffByAddress();

	$expansionAreaQueries = new ExpansionAreaQueries();
	$isExAreaFttH = $expansionAreaQueries->isExpansionAreaFttH($infos["postalAddress"]);
	  
	$templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company", "mail", "phone", "mobil"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode", "psPlace", "psDistrict"),
	  "conAddress"    => array("coStreet", "coHNr", "coZipcode", "coPlace", "coDistrict"),
	  "diffAddress"   => "dAddress"
	);
	  
	$populateValue = array("postalAddress" => $infos["postalAddress"]);
	  
	if (!empty($tariffs) && count($tariffs) > 0) {
	  if ($infos["selTech"] == 2 && $isNewCon && $isExAreaFttH) {
		require_once __DIR__ . "/views/glassFibre/glass_fibre.php";
		$glasFibre = new GlassFibre($templateData, $populateValue);
	    // path with FttH (expansion area)
		$content = array(
		  "ident"         => 1,
		  "step2Lable"    => "Ergebnis",
		  "step2Content"  => $glasFibre->buildExpansionAreaTemplate(),
		  "step2BtnLable" => "Glasfaserhausanschluss",
		  "show3Btn"      => false
		);
	  } else {
	    require_once __DIR__ . "/views/rates/tariff.php";
	    $tariffFormHtml = new Tariff($tariffs, $infos["postalAddress"]);
	    // path to normal contract
		$content = array(
		  "ident" => 2,
		  "step2Lable"    => "Tarife",
		  "step2Content"  => $tariffFormHtml->getTemplate(),
		  "step2BtnLable" => "Weiter",
		  "show3Btn"      => false
		);
	  }
	} else {
	  if ($infos["selTech"] == 2) {
		require_once __DIR__ . "/views/glassFibre/glass_fibre.php";
		$glasFibre = new GlassFibre($templateData, $populateValue);
	    // path with FttH (no expansion area)
		$content = array(
		  "ident" => 3,
		  "step2Lable"    => "Ergebnis",
		  "step2Content"  => $glasFibre->buildDescription(),
		  "step2BtnLable" => "Glasfaserhausanschluss",
		  "show3Btn"      => true
		);
	  } else {
        require_once __DIR__ . "/views/rates/tariff.php";
	    $tariffFormHtml = new Tariff($tariffs, $infos["postalAddress"]);
	    // default path -- connection request
		$content = array(
		  "ident" => 4,
		  "step2Lable"    => "Kundendaten",
		  "step2Content"  => $conRequest->getTemplateStep2(),
		  "step2BtnLable" => "Anschluss - Anfrage",
		  "show3Btn"      => false
		);
	  }
	}
	  
	/*if (!empty($infos["technologyAddress"])) {
	  $address = $infos["technologyAddress"];
	} else {
	  $address = $infos["defaultAddress"];
	}
	
	$isSameTechAddress = false;
	if ( !empty($infos["technologyAddress"]) 
	  && !empty($infos["oldTechAddress"]   ) 
	  && $infos["technologyAddress"] == $infos["oldTechAddress"]) {
	  $content["isSameTechAddress"] = true;
	}

    if (!empty($tariffs) && count($tariffs) > 0) {
	  if ($infos["selTech"] == 2 && $isNewCon && $isExAreaFttH) {
		require __DIR__ . "/views/glassFibre/glass_fibre.php";

		$templateData["diffAddress"] = 'dAddress';
		$templateData["conAddress"]  = array("coStreet", "coHNr", "coZipcode", "coPlace", "coDistrict");
		  
		$glasFibre = new GlassFibre($templateData, $populateValue);

	    $content = array(
		  "ident"           => 4,
		  "btnStep2"        => "disForward",
		  "step2Lable"      => "Ergebnis",
		  "step2"           => $glasFibre->buildExpansionAreaTemplate(),
		  "btnLable5"       => "Glasfaseranschluss",
		  "displayForward"  => "block",
		  "backBtnStep2"    => "block",
		  "sameTechAddress" => $isSameTechAddress,
		  "oldTechAddress"  => $infos["oldTechAddress"],
		  "techAddress"     => $infos["technologyAddress"]
	    );
	  } else {
	    // items for rate selection
	    require __DIR__ . "/views/rates/tariff.php";
	    $tariffFormHtml = new Tariff($tariffs, $address);
	    $content = array(
		  "ident"           => 1,
		  "btnStep2"        => "disForward",
		  "step2Lable"      => "Tarife",
		  "step2"           => $tariffFormHtml->getTemplate(),
		  "displayForward"  => "none",
		  "backBtnStep2"    => "none",
		  "sameTechAddress" => $isSameTechAddress,
		  "oldTechAddress"  => $infos["oldTechAddress"],
		  "techAddress"     => $infos["technologyAddress"]
	    );
	  }
	} else {
	  if ($infos["selTech"] == 2) {
		// fiberglass application
        require __DIR__ . "/views/glassFibre/glass_fibre.php";
		  
		$templateData["diffAddress"] = 'dAddress';
		$templateData["conAddress"]  = array("coStreet", "coHNr", "coZipcode", "coPlace", "coDistrict");
		
		$glasFibre = new GlassFibre($templateData, $populateValue);
		  
   	    $content = array(
		  "ident"           => 2,
		  "btnStep2FttH"    => "disFttH",
		  "btnStep2Reqs"    => "disRequest",
		  "step2Lable"      => "Ergebnis",
		  "step2"           => $glasFibre->buildDescription(),
		  "displayForward"  => "block",
		  "backBtnStep2"    => "block",
		  "sameTechAddress" => $isSameTechAddress,
		  "oldTechAddress"  => $infos["oldTechAddress"],
		  "techAddress"     => $infos["technologyAddress"]
		);
	  } else {
		// connection request order
		require __DIR__ . "/views/connectionRequest/connection_request.php";
		  
		$conRequest = new ConnectionRequest($templateData, $populateValue);
		 
        $content = array(
		  "ident"          => 3,
		  "btnStep2"       => "disForward",
		  "step2Lable"     => "Kundendaten",
		  "step2"          => $conRequest->getTemplateStep2(),
		  "displayForward" => "block",
		  "backBtnStep2"   => "block"
		);
	  }
	}*/

    echo json_encode($content);
  }
?>