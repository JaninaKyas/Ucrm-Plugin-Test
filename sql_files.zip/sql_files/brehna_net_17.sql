CREATE TABLE IF NOT EXISTS `address` (
  `id`          INT(11)   UNSIGNED NOT NULL AUTO_INCREMENT,
  `location_id` INT(11)   UNSIGNED NOT NULL,
  `street`      CHAR(100)          NOT NULL DEFAULT '',
  `houseNr`     CHAR(5)            NOT NULL DEFAULT '',
  `zipcode`     CHAR(10)           NOT NULL DEFAULT '',
  `createDate`  DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)           NOT NULL DEFAULT '',
  `updateDate`  DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)           NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)         NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (location_id) REFERENCES `location` (id)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS `debator` (
  `id`         INT(11)   UNSIGNED NOT NULL AUTO_INCREMENT,
  `address_id` INT(11)   UNSIGNED NOT NULL,
  `country_id` INT(11)   UNSIGNED NOT NULL,
  `fName`      CHAR(50)           NOT NULL DEFAULT '',
  `lName`      CHAR(50)           NOT NULL DEFAULT '',
  `iban`       CHAR(100)          NOT NULL DEFAULT '',
  `swift_bc`   CHAR(20)           NOT NULL DEFAULT '',
  `createDate` DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)           NOT NULL DEFAULT '',
  `updateDate` DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)           NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)         NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (address_id) REFERENCES `address`(id),
  FOREIGN KEY (country_id) REFERENCES `country`(id)
) ENGINE=INNODB;