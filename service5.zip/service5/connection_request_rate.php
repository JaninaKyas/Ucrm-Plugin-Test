<?php
  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	$content = array();
	  
	require_once __DIR__ . "/model/tariff_queries.php";
	require_once __DIR__ . "/views/connectionRequest/connection_request_rate.php";
	 
	$tariffQueries = new TariffQueries();
	$ratesData     = $tariffQueries->getAllRates();
	  
	$conRequest = new ConnectionRequest($ratesData);
	  
	$content["step4content"] = $conRequest->buildConnectionRequestRateTemplate();
	$content["step5content"] = $conRequest->buildConnectionRequestRateTemplate();
	  
	echo json_encode($content);
  }
?>