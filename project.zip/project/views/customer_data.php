<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views", "", __DIR__);

  require $dir . "/model/contract_type_queries.php";
  require $dir . "/model/legal_form_queries.php";

  $contractTypeQueries = new ContractTypeQueries();
  $legalFormQueries = new LegalFormQueries();

  $contractTypes = $contractTypeQueries->getAllTypes();
  $legalForms = $legalFormQueries->getAllLegalForms();
?>

<div id="errorRequiredFieldsEmpty" class="noDisplay">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Bitte füllen Sie alle Pflichtfelder aus.
    </div>
  </div>
</div>

<div id="infoChooseForm" class="noDisplay">
  <div class="row puffer infoBox">
	<div class="infoBoxContent">
      <img id="info"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/info.png"
	       alt="info"> Bitte wählen Sie aus, um welches Auftragsformular es sich handelt.
	</div>
  </div>
</div>

<div id="customerMain">
  <div id="customerMainHeader"  class="borderBox">
    <div class="row puffer">
      <div class="col">
	    <strong>Welches Auftragsformular suchen Sie?</strong>
      </div>
    </div>

    <div class="row puffer">
	  <div class="col">
		<input type="radio" name="orderForm" value="1" id="pk" 
			   onclick="displayFormContent()"> Privatkunden
	  </div>
		
	  <div class="col">
		<input type="radio" name="orderForm" value="2" id="pkSenior"
			   onclick="displayFormContent()"> Seniorentarif
	  </div>
		
	  <div class="col">
		<input type="radio" name="orderForm" value="3" id="gk"
			   onclick="displayFormContent()"> Business Complete
	  </div>
    </div>
  </div>
	
  <div id="customerMainBodyContent" class="borderBox distanceDown noDisplay">
    <div id="formTitel" class="borderBox">
      <div class="row puffer">
	    <div class="col">
	      <span id="pkTitle">
		    <h3 class="titleText">Auftragsformular Privatkunden</h3>
		  </span>
          <span id="pkSenTitle">
			<h3 class="titleText">Auftragsformular Seniorentarif</h3>
		  </span>
          <span id="gkTitle">
			<h3 class="titleText">Auftragsformular Business Complete</h3>
		  </span>
	    </div>
      </div>
  
      <div id="contractType" class="row puffer">
        <div class="col">
	      <input type="radio" id="contract" name="contractT" value="1"> <b><?php echo $contractTypes[0]['name']; ?></b>
        </div>
        
		<div class="col">
	      <input type="radio" id="change" name="contractT" value="2"> <b><?php echo $contractTypes[1]['name']; ?></b>
        </div>
    
		<div class="col">
	      <input type="radio" id="contractExtension" name="contractT" value="3"> <b><?php echo $contractTypes[2]['name']; ?></b>
        </div>
      </div>
    </div>
	 
	<div class="borderBox">
	  <div id="customerCompany">
        <div class="row puffer">
          <div class="col">
            Firma*
	        <input type="text" class="form-control" id="company" name="company"> 
          </div>
        </div>
	  </div>
	
	  <div id="person">
        <div class="row puffer">
          <div class="col">
	        <span id="fName1">
			  Vorname*
		    </span>
	        <span id="fName2">
			  Ansprechpartner - Vorname
    	    </span>
	        <input type="text" class="form-control" id="fName" name="fName">
          </div>
	
          <div class="col">
     	    <span id="lName1">
			  Nachname*
		    </span>
	        <span id="lName2">
			  Ansprechpartner - Nachname*
		    </span>
	        <input type="text" class="form-control required" id="lName" name="lName">
          </div>
        </div>
	  </div>
	</div>
	  
	<div class="borderBox">
	  <div id="customerPkValues">
        <div class="row puffer">
          <div class="col">
	        Geburtstag*
	        <input type="date" class="form-control" id="birthDate" name="birthDate">
	      </div>
			
	      <div class="col">
            Wohnungsnummer
	        <input type="text" class="form-control" id="wNr" name="wNr">
          </div>
        </div>
	  </div>
		
	  <div id="customerGkValues">
        <div class="row puffer">
          <div class="col">
	        Rechtsform*
	        <select id="legalForm" name="legalForm" class="form-select selectBox">
		      <option value="-1">...bitte auswählen...</option>
			  <?php
				foreach ($legalForms as $legalForm) {
				  echo   "<option value=\"" . $legalForm["id"] . "\">" . $legalForm["shortName"]
					   . "</option>";
				}
			  ?>
	        </select>
	      </div>
  
	      <div class="col">
	        Steuernummer / USt.ID.
	        <input type="text" class="form-control" id="taxId" name="taxId">
	      </div>
        </div>
	  </div>
	</div>
	
	<div class="borderBox">
      <div class="row puffer">
        <div class="col-8">
          Strasse*
	      <input type="text" class="form-control required" id="street" name="street">
        </div>
	
        <div class="col">
          Hausnummer*
	      <input type="text" class="form-control required" id="hNr" name="hNr">
        </div>
      </div>

      <div class="row puffer">
        <div class="col">
          Postleitzahl*
	      <input type="text" class="form-control required" id="postcode" name="postcode">
        </div>
	
        <div class="col">
          Ort*
	      <input type="text" class="form-control required" id="places" name="places">
        </div>
	
        <div class="col">
          Ortsteil
	      <input type="text" class="form-control" id="district" name="district">
        </div>
      </div>
	</div>  

    <div class="borderBox">
      <div class="row puffer">
        <div class="col">
	      Telefon*
	      <input type="tel" class="form-control required" id="phone" name="phone">
        </div>
	
        <div class="col">
          Mobiltelefon
	      <input type="tel" class="form-control" id="mobil" name="mobil">
        </div>
      </div>

      <div class="row puffer">
        <div class="col">
	      E-Mail*
	      <input type="email" class="form-control required" id="mail" name="mail">
        </div>
      </div>
	</div>
	  
	<div class="borderBox">
	  <div class="row puffer">
		  <div class="col">
			<input id="displayAdressAS" type="checkbox" onClick="displayConnectionAddress()">
		    <strong>Anschlussadresse (Angabe nur wenn abweichend von Postanschrift)</strong>
		  </div>
	  </div>

	  <span id="connectionAS" class="noDisplay">
        <div class="row puffer">
          <div class="col">
            Strasse*
	        <input type="text" class="form-control required2" id="streetAS" name="streetAS">
          </div>
  
          <div class="col">
            Hausnummer*
	        <input type="text" class="form-control required2" id="hNrAS" name="hNrAS">
          </div>
        </div>

        <div class="row puffer">
          <div class="col">
	        PLZ*
	        <input type="text" class="form-control required2" id="plzAS" name="plzAS">
          </div>
	
          <div class="col">
	        Ort*
	        <input type="text" class="form-control required2" id="placesAS" name="placesAS">
          </div>
	
          <div class="col">
	        Ortsteil
	        <input type="text" class="form-control" id="districtAS" name="districtAS">
          </div>
        </div>
      </span>
	</div>
  </div>
</div>