<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
	  
	public function buildAddressTemplate(): string {		
	  return '';
	}
  }
?>