<b>Was von dem Anschluss ist durch die Störung betroffen?</b>
<ul class="list-group">
  <li class="list-group-item">
    <input type="radio" id="ikdTotal" name="iKind" value="Komplettausfall" 
    onclick="showHideSubmenu(0)">
    <label for="ikdTotal">Komplettausfall</label>
  </li>
  <li class="list-group-item">
    <input type="radio" id="ikdPhone" name="iKind" value="Telefon" onclick="showHideSubmenu(1)">
    <label for="ikdPhone">Telefon</label>
    <span id="phoneSub">
      <ul class="list-group">
        <li class="list-group-item">
          <input type="radio" id="phone-total" name="ikPhone" value="Keine Telefonie">
          <label for="phone-total">Keine Telefonie</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="phone-inNoOut" name="ikPhone" value="Eingehende, aber keine ausgehende Anrufe">
          <label for="phone-inNoOut">Eingehende, aber keine ausgehende Anrufe</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="phone-outNoIn" name="ikPhone" value="Ausgehende, aber keine eingehende Anrufe">
          <label for="phone-outNoIn">Ausgehende, aber keine eingehende Anrufe</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="phone-crackle" name="ikPhone" value="Rauschen oder knacken in der Leitung">
          <label for="phone-crackle">Rauschen oder knacken in der Leitung</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="phone-lostConn" name="ikPhone" value="Regelmäßiger Verbindungsabbruch">
          <label for="phone-lostConn">Regelmäßiger Verbindungsabbruch</label>
        </li>
      </ul> 
    </span>   
  </li>
  <li class="list-group-item">
    <input type="radio" id="ikInternet" name="iKind" value="Internet" onclick="showHideSubmenu(2)">
    <label for="ikInternet">Internet</label>
    <span id="internetSub">
      <ul class="list-group">
        <li class="list-group-item">
          <input type="radio" id="internet-total" name="ikInternet" value="Kein Internet">
          <label for="internet-total">Kein Internet</label>        
        </li>
        <li class="list-group-item">
          <input type="radio" id="internet-slow" name="ikInternet" value="Internet zu langsam">
          <label for="internet-slow">Internet zu langsam</label>
        </li>
        <li class="list-group-item">
          <input type="radio" id="internet-lostConn" name="ikInternet" value="Regelmäßiger Verbindungsabbruch">
          <label for="internet-lostConn">Regelmäßiger Verbindungsabbruch</label>
        </li>
      </ul>
    </span>    
  </li>
  <li class="list-group-item">
    <input type="radio" id="ikTv" name="iKind" value="TV" onclick="showHideSubmenu(3)">
    <label for="ikTv">TV</label>
    <span id="tvSub">
      <ul class="list-group">
        <li class="list-group-item">
          <input type="radio" id="tv-media" name="ikTv" value="Mediathek">
          <label for="tv-media">Mediathek</label> 
        </li>
        <li class="list-group-item">
          <input type="radio" id="tv-screen" name="ikTv" value="Bildschirm">
          <label for="tv-screen">Bildschirm</label> 
        </li>
        <li class="list-group-item">
          <input type="radio" id="tv-sound" name="ikTv" value="Soundsystem - Echo">
          <label for="tv-sound">Soundsystem - Echo</label> 
        </li>
      </ul>
    </span>    
  </li>
</ul>

<div id="descDiv" class="form-group">
  <label for="description"><b>Fehlerbeschreibung aus Kundensicht</b></label>
  <textarea class="form-control" id="description" name="description" value="" rows="7"></textarea>
</div>

<script>
  function showHideSubmenu(kind) {
    switch (kind) {
      case 1  : 
        document.getElementById("phoneSub").style.display    = "block";
        document.getElementById("internetSub").style.display = "none";
        document.getElementById("tvSub").style.display       = "none";
        break;
      case 2  :
        document.getElementById("phoneSub").style.display    = "none";
        document.getElementById("internetSub").style.display = "block";
        document.getElementById("tvSub").style.display       = "none";
        break;
      case 3  :
        document.getElementById("phoneSub").style.display    = "none";
        document.getElementById("internetSub").style.display = "none";
        document.getElementById("tvSub").style.display       = "block";
        break;
      default :
        document.getElementById("phoneSub").style.display    = "none";
        document.getElementById("internetSub").style.display = "none";
        document.getElementById("tvSub").style.display       = "none";
    }
  }
</script>
