<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	$content = array();

	$content["step4label"]   = "Tarifauswahl";
	$content["step4content"] = "";
	  
	echo json_encode($content);
  }
?>