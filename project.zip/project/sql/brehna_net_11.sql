CREATE TABLE IF NOT EXISTS `net_type` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(100)           NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=INNODB;

INSERT INTO `net_type` VALUES(null, 'keine',                                                                                               NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `net_type` VALUES(null, 'Telefonate zu Teilnehmern innerhalb unseres Netzes',                                                  NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `net_type` VALUES(null, 'Allgemein bezieht sich im Regelfall auf das Festnetz, kann aber auch andere regionale Netze meinen.', NOW(), 'JANINA', NOW(), 'JANINA', 0);