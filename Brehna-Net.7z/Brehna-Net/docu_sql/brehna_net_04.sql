--
-- Tabellenstruktur für Tabelle `software`
--

CREATE TABLE IF NOT EXISTS `software` (
  `id`         INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(150)              NOT NULL DEFAULT '',
  `price`      DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `note`       CHAR(100)              NOT NULL DEFAULT '',
  `createDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)               NOT NULL DEFAULT '',
  `updateDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)             NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `software`
--

INSERT INTO `software` VALUES(null, '... bitte auswählen ...'             ,   0.00, '(BSI Zertifiziert bis 25 User, inkl. Service)', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `software` VALUES(null, 'B.net NextGen UTM-Firewall Appliance',  95.00, '(BSI Zertifiziert bis 25 User, inkl. Service)', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `software` VALUES(null, 'B.net NextGen UTM-Firewall Appliance', 170.00, '(BSI Zertifiziert bis 50 User, inkl. Service)', NOW(), 'JANINA', NOW(), 'JANINA', 0);