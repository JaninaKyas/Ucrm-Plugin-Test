<?php

// BEGIN iThemes Security - Diese Zeile nicht verändern oder entfernen
// iThemes Security Config Details: 2
define( 'DISALLOW_FILE_EDIT', true ); // Datei-Editor deaktivieren - Sicherheit > Einstellungen > WordPress-Optimierungen > Datei-Editor
define( 'FORCE_SSL_ADMIN', true ); // Redirect All HTTP Page Requests to HTTPS - Security > Settings > Enforce SSL
// END iThemes Security - Diese Zeile nicht verändern oder entfernen

define( 'ITSEC_ENCRYPTION_KEY', 'dXI1U1R9YHN6M2FIYTJkRCFWdTRrW1MtblcvKn1XRFUpckZeTSpdUFBbc1M2W19PLWZONVJWX09XM243Q1RAIA==' );

define('CONCATENATE_SCRIPTS', false);

define('WP_AUTO_UPDATE_CORE', 'minor');// This setting is required to make sure that WordPress updates can be properly managed in WordPress Toolkit. Remove this line if this WordPress website is not managed by WordPress Toolkit anymore.
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', "web2027_bnet_db" );

/** MySQL database username */
define( 'DB_USER', "bnetdbuser" );

/** MySQL database password */
define( 'DB_PASSWORD', "w1Gpc4?6" );

/** MySQL hostname */
define( 'DB_HOST', "localhost" );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '5vFNq$f5Ym~MkX4]LeV8GT4=&6jd7z+vH1NmB*&36`#w+]h3(s6 KtAGvV{:.EGU');
define('SECURE_AUTH_KEY', '+FxF-_RqQt=(?OI0;R71OPl:H}Zgl+3y%^OFflSZ{7f3$qyWPxe=.rxj~3fhQOF/');
define('LOGGED_IN_KEY', '>c]^i+Eu8t:|.,WS?3QtMG7OPuK/|04x#2t&MY$[>q7-(nyb2=]-OIW*}@,uRPyS');
define('NONCE_KEY', 'Tz#^hzHv<^%D+cF_BS!OY(@CDP;s>&|~;tx%K6V}/|^O*gD/yxB,Bw>$o{!?X&^P');
define('AUTH_SALT', 'SM@EZ5En+o<!$7S;H~cBB9v5rA=kR@vGpL;I`nBBG&[lCx)EBAm(c&(#F@c#BPLa');
define('SECURE_AUTH_SALT', '>v<XDFPC=JMxqv<Kcu7/.l:#`YKOSt%;hI/;o{^`;V:4zreXh%)=w}#B|Q]<sA7{');
define('LOGGED_IN_SALT', 'V<=5^ooIb0`?V(ZWT7L1TEf5Ikszo/M}Bm|Z>mZ* vBH.T)yN([6Y^Lw[=^gZNgE');
define('NONCE_SALT', '.XUS;{rf8GI-p30R$ivh+!F55DRQ`*{h[M 0O jF3wr:Ua>p!c|F4nWHR^d2j6.f');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'ihuaeui80_';


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
