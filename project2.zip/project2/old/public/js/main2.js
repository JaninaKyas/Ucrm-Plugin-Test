var currentPosition    = 0;
var currentFormType    = 0;
var oldFormType        = 0;
var isConAdressChecked = false;
var toPortNr           = false;
var maxInetSpeed       = 0;
var summaryHtml        = '';

function showTab(position) {
  var steps = document.getElementsByClassName("step");
  steps[position].style.display = "block";
	
  if (position == 0) {
    document.getElementById("prevBtn").style.display = "none";
	steps[0].style.display = "block";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
    
  if (position == (steps.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
	
  fixStepIndicator(position);
}

function fixStepIndicator(position) {
  var i = 0;
  var stepIndcators = document.getElementsByClassName("stepIndicator");
	
  for ( i = 0; i < stepIndcators.length ; i++) {
    stepIndcators[i].className = stepIndcators[i].className.replace("active", "");
  }
	
  stepIndcators[position].className += " active";
}

async function nextPrev(direction) {
  var steps = document.getElementsByClassName("step");

  document.getElementById("errorRequiredFieldsEmpty").style.display = "none";
  if (direction == 1 && !validateForm()) {
	 document.getElementById("errorRequiredFieldsEmpty").style.display = "block";
	 return false;
  }

  steps[currentPosition].style.display = "none";

  currentPosition = currentPosition + direction;

  if (currentPosition >= steps.length) {
	// TO-DO
	// create PDF
	// send mail
	// redirect first page

	/* $(document).ready(function() {
	  $.ajax({
		type: 'POST',
	    url: 'https://neu.brehna.net/auftragsautomatisierung/create_pdf.php',
		data: {"content": summaryHtml},
		success: function() {
		  console.log('success');
		}
	  });
	});*/
	  
    //document.getElementById("orderAuto").submit();
    return false;
  }
	
  // tariff
  if (currentPosition == 1 && direction == 1) {
    await displayTariff();
  }

  // options
  if (currentPosition == 2 && direction == 1) {
	displayOptions();
  }  
	
  // contract terms
  if (currentPosition == 3 && direction == 1) {
	displayContractTerms();
  }  
	
  // bank account
  if (currentPosition == 4 && direction == 1) {
	displayBankAccount();
  }  
	
  // agb
  if (currentPosition == 5 && direction == 1) {
	displayAgbConditionInfos();
  }

  // summary
  if (currentPosition == 6 && direction == 1) {
	await displaySummary();
  }
	
  showTab(currentPosition);
}

function validateForm() {
  document.getElementById("infoChooseForm").style.display = "none";
  document.getElementById("errorNotChooseTariff").style.display = "none";
  document.getElementById("errorNotChooseContractTerm").style.display = "none";
  document.getElementById("errorChooseNotNumerically").style.display = "none";
  document.getElementById("errorBankRequiredFields").style.display = "none";
  document.getElementById("errorNotConfirm").style.display = "none";
	
  var steps = document.getElementsByClassName("step");
  var requiredInputs = steps[currentPosition].getElementsByClassName("form-control required");
  var radioForm = document.querySelector('input[name="orderForm"]:checked');
  var tariffRadio = document.querySelector('input[name="choosenTariff"]:checked');
  var contractTermRadio = document.querySelector('input[name="contractTerm"]:checked');
  var numericallyRadio = document.querySelector('input[name="num1"]:checked');

  var agbCheck = document.getElementById("checkAGB");
  var dataProtectionCheck = document.getElementById("checkProcessData");

  var i = 0;
  var valid = true;

  if (isConAdressChecked) {
    var requiredInputs2 = steps[currentPosition].getElementsByClassName("form-control required2");
	  
    for (i = 0; i < requiredInputs2.length; i++) {
	  if (requiredInputs2[i].value == null || requiredInputs2[i].value.length == 0) {
	    valid = setValidateState(requiredInputs2[i]);	
	  }
    } 
  }
	
  if (radioForm === null) {
	document.getElementById("infoChooseForm").style.display = "block";
	return false;
  }

  // tariff
  if (maxInetSpeed > 0 && currentPosition == 1 && tariffRadio === null) {
	document.getElementById("errorNotChooseTariff").style.display = "block";
	return false;
  }

  // tariff options
  if (currentPosition == 2 && document.getElementById("to8").checked) {
    // current (old) phone provider
	if (document.getElementById("phoneProvider").value === null ||
		document.getElementById("phoneProvider").value === ''   ||
		document.getElementById("phoneProvider").value === 0)
	{
      valid = setValidateState(document.getElementById("phoneProvider"));
	}
	  
	// connection holder
	var requiredInputs5 = steps[currentPosition].getElementsByClassName("form-control required5");
	  
	for (i = 0; i < requiredInputs5.length; i++) {
	  if (requiredInputs5[i].value == null || requiredInputs5[i].value.length == 0) {
	    valid = setValidateState(requiredInputs5[i]);	
	  }
    }
	  
	// telephone numbers to be ported - specify at least one phone number	  
	if (document.getElementById("phoneOnkz1").value === null ||
	    document.getElementById("phoneOnkz1").value.length === 0) {
	  setValidateState(document.getElementById("fontPhone"));
	  valid = setValidateState(document.getElementById("phoneOnkz1"));
    }

	if (document.getElementById("phone1").value === null ||
	    document.getElementById("phone1").value.length === 0) {
	  setValidateState(document.getElementById("fontPhone"));
	  valid = setValidateState(document.getElementById("phone1"));
	}
  }
	
  // contract terms
  if (currentPosition == 3 && contractTermRadio === null) {
	document.getElementById("errorNotChooseContractTerm").style.display = "block";
	return false;
  }
	
  // bank account
  if (currentPosition == 4 && numericallyRadio === null) {
    document.getElementById("errorChooseNotNumerically").style.display = "block";
	return false;
  } else if (currentPosition == 4 && numericallyRadio !== null && numericallyRadio.value == 3) {
	var requiredInputs3 = steps[currentPosition].getElementsByClassName("form-control required3");
	  
	for (i = 0; i < requiredInputs3.length; i++) {
	  if (requiredInputs3[i].value == null || requiredInputs3[i].value.length == 0) {
	    valid = setValidateState(requiredInputs3[i]);	
	  }
    }
	  
	if (!valid) {
	  document.getElementById("errorBankRequiredFields").style.display = "block";
	}
  }

  // agb
  if (currentPosition == 5 && (!agbCheck.checked || !dataProtectionCheck.checked)) {
    document.getElementById("errorNotConfirm").style.display = "block";
    return false;
  }
	
  for (i = 0; i < requiredInputs.length; i++) {
	if (requiredInputs[i].value == null || requiredInputs[i].value.length == 0) {
	  valid = setValidateState(requiredInputs[i]);	
	}
  } 

  // check required fields after form type
  if (currentFormType == 1 || currentFormType == 2) {
    if (document.getElementById("fName").value == null || 
		document.getElementById("fName").value.length == 0)
	{
      valid = setValidateState(document.getElementById("fName"));
	}
	  
    if (document.getElementById("birthDate").value == null || 
		document.getElementById("birthDate").value.length == 0)
	{
      valid = setValidateState(document.getElementById("birthDate"));
	}
  } else if (currentFormType == 3) {
    if (document.getElementById("company").value == null || 
		document.getElementById("company").value.length == 0)
	{
      valid = setValidateState(document.getElementById("company"));
	}
	  
	if (document.getElementById("legalForm").value === -1) {
      valid = setValidateState(document.getElementById("legalForm"));
	}
  }
	
  if (valid) {
    document.getElementsByClassName("stepIndicator")[currentPosition].className += " finish";
  }
    
  return valid;  
}

function setValidateState(element) {
  element.className += " invalid";
  return false;
}

function displayFormContent() {	  
  document.getElementById("infoChooseForm").style.display = "none";
  document.getElementById("customerMainBodyContent").style.display = "block";
	  
  document.getElementById("pkTitle"   ).style.display = "none";
  document.getElementById("pkSenTitle").style.display = "none";
  document.getElementById("gkTitle"   ).style.display = "none";
	  
  document.getElementById("customerCompany").style.display = "none";
  document.getElementById("fName1").style.display = "none";
  document.getElementById("fName2").style.display = "none";
  document.getElementById("lName1").style.display = "none";
  document.getElementById("lName2").style.display = "none";
	  
  document.getElementById("customerPkValues").style.display = "none";
  document.getElementById("customerGkValues").style.display = "none";
  
  oldFormType = currentFormType;
  currentFormType = document.querySelector('input[name = orderForm]:checked').value;

  if (currentFormType == 1) {
	document.getElementById("pkTitle"   ).style.display = "block";	
    document.getElementById("fName1").style.display = "block";
	document.getElementById("lName1").style.display = "block";	
	document.getElementById("customerPkValues").style.display = "block";
  } else if (currentFormType == 2) {
	document.getElementById("pkSenTitle").style.display = "block";	
	document.getElementById("fName1").style.display = "block";
	document.getElementById("lName1").style.display = "block";	
	document.getElementById("customerPkValues").style.display = "block";
  } else if (currentFormType == 3) {
	document.getElementById("gkTitle"   ).style.display = "block";
	document.getElementById("customerCompany").style.display = "block";
	document.getElementById("fName2").style.display = "block";
	document.getElementById("lName2").style.display = "block";	
	document.getElementById("customerGkValues").style.display = "block";
  }
}

function displayAgbConditionInfos() {
  document.getElementById("pkAgb1").style.display = "none";  
  document.getElementById("pkAgb2").style.display = "none";
  document.getElementById("pkAgb3").style.display = "none";
  document.getElementById("pkContractCon1").style.display = "none";  
  document.getElementById("pkCancel1").style.display = "none";

  document.getElementById("gkAgb1").style.display = "none";
  document.getElementById("gkAgb2").style.display = "none";
  document.getElementById("gkContractCon1").style.display = "none";
  document.getElementById("gkCancel1").style.display = "none";
	
  if (currentFormType == 1) {
    document.getElementById("pkAgb1").style.display = "block";  
    document.getElementById("pkAgb2").style.display = "block";
    document.getElementById("pkContractCon1").style.display = "block";  
    document.getElementById("pkCancel1").style.display = "block";
  } else if (currentFormType == 2) {
    document.getElementById("pkAgb1").style.display = "block";
    document.getElementById("pkAgb3").style.display = "block";
    document.getElementById("pkContractCon1").style.display = "block";  
    document.getElementById("pkCancel1").style.display = "block";
  } else if (currentFormType == 3) {
    document.getElementById("gkAgb1").style.display = "block";
	document.getElementById("gkAgb2").style.display = "block";
    document.getElementById("gkContractCon1").style.display = "block";
	document.getElementById("gkCancel1").style.display = "block";
  }
}

function displayBankAccount() {
  document.getElementById("numerically1").style.display = "none";  
  document.getElementById("numerically2").style.display = "none";
	
  if (currentFormType == 1) {
    document.getElementById("numerically1").style.display = "block"; 
  } else if (currentFormType == 2 || currentFormType == 3) {
	document.getElementById("numerically2").style.display = "block"; 		 
  }
}

function displayContractTerms() {
  document.getElementById("pkTerm").style.display = "none"; 
  document.getElementById("pkSenTerm").style.display = "none"; 
  document.getElementById("gkTerm").style.display = "none";
	
  if (currentFormType == 1) {
    document.getElementById("pkTerm").style.display = "block";
  } else if (currentFormType == 2) {
    document.getElementById("pkSenTerm").style.display = "block";
  } else if (currentFormType == 3) {
    document.getElementById("gkTerm").style.display = "block";
  }
}

function displayOptions() {
  document.getElementById("pkHw").style.display = "none";
  document.getElementById("pkSenHw").style.display = "none";
  document.getElementById("gkHw").style.display = "none";
	
  document.getElementById("pkSv").style.display = "none";
  document.getElementById("pkSenSv").style.display = "none";
  document.getElementById("gkSv").style.display = "none";
	
  document.getElementById("contractOptionSw").style.display = "none";

  document.getElementById("pkTo").style.display = "none";
  document.getElementById("pkSenTo").style.display = "none";
  document.getElementById("gkTo").style.display = "none";

  if (currentFormType != oldFormType) {
	document.getElementById("contractOptionPhone").style.display = "none";
  }
	
  if (currentFormType == 1) {
    document.getElementById("pkHw").style.display = "block";
	document.getElementById("pkSv").style.display = "block";
	document.getElementById("pkTo").style.display = "block";
  } else if (currentFormType == 2) {
    document.getElementById("pkSenHw").style.display = "block";
	document.getElementById("pkSenSv").style.display = "block";
	document.getElementById("pkSenTo").style.display = "block";
  } else if (currentFormType == 3) {
    document.getElementById("gkHw").style.display = "block";
	document.getElementById("gkSv").style.display = "block";
	document.getElementById("contractOptionSw").style.display = "block";
	document.getElementById("gkTo").style.display = "block";
  }
}

function displaySepa(shift) {
  document.getElementById("sepa").style.display = "none";
	  
  if (shift == 1) {
   document.getElementById("sepa").style.display = "block";
  }
}

function displayFormPhoneNumberPortability(element) {	
  toPortNr = element.checked;
  document.getElementById("contractOptionPhone").style.display = "none";
	
  if (toPortNr) {
	document.getElementById("contractOptionPhone").style.display = "block";
  }
}

async function displayTariff() {
  var iMaxSpeed = await setMaxSpeed();
  maxInetSpeed = iMaxSpeed;
	
  document.getElementById("cGroup1").style.display = "none";
  document.getElementById("cGroup2").style.display = "none";
  document.getElementById("cGroup3").style.display = "none";
  document.getElementById("errorAdressNotFound").style.display = "none";
  document.getElementById("tariffCardBox").style.display = "none";

  if (iMaxSpeed > 0) {  
	document.getElementById("tariffCardBox").style.display = "block";
	  
    if (currentFormType == 1) {
      document.getElementById("cGroup1").style.display = "block";
	  hideAllChilds(document.getElementById("cGroup1"));
      showChilds(document.getElementById("cGroup1"), iMaxSpeed);
	} else if (currentFormType == 2) {
      document.getElementById("cGroup2").style.display = "block";
	  hideAllChilds(document.getElementById("cGroup2"));
	  showChilds(document.getElementById("cGroup2"), iMaxSpeed);
    } else if (currentFormType == 3) {
      document.getElementById("cGroup3").style.display = "block";
	  hideAllChilds(document.getElementById("cGroup3"));
	  showChilds(document.getElementById("cGroup3"), iMaxSpeed);
    }
  } else {
    document.getElementById("errorAdressNotFound").style.display = "block";
  }
}

async function setMaxSpeed() {
  var url  = 'https://neu.brehna.net/auftragsautomatisierung/get_max_speed.php';
  var sSpeed = '';
  var iMaxSpeed = 0;

  var street = (document.getElementById("streetAS").value)? document.getElementById("streetAS").value : document.getElementById("street").value;
  var hnr = (document.getElementById("hNrAS").value)? document.getElementById("hNrAS").value : document.getElementById("hNr").value;
  var plz = (document.getElementById("plzAS").value)? document.getElementById("plzAS").value : document.getElementById("postcode").value;
  var place = (document.getElementById("placesAS").value)? document.getElementById("placesAS").value : document.getElementById("places").value;
  var district = (document.getElementById("districtAS").value)? document.getElementById("districtAS").value : document.getElementById("district").value;
	
  let data     = {
    "street": street,
	"hnr": hnr,
	"plz": plz,
	"place": place,
	"district": district  
  }
  
  let params = {
    "method": "POST",
	"headers": {
	  "Content-Type": "application/json; charset=utf-8"
	},
	"body": JSON.stringify(data)
  }
  
  try {
    var response = await fetch(url, params).then(function(response){
      return response.json();
    });
	  
    if (response) {
	  sSpeed = response[0]["maxSpeed"];
  
      if (sSpeed) {
        iMaxSpeed = parseInt(sSpeed);
      }  
    }  
  } catch {
    console.error('Promise rejected');
  }

  return iMaxSpeed;
}

function hideAllChilds(parentElement) {
  var childs = parentElement.childNodes;
	
  for (var i = 0; i < childs.length; i++) {
    if (childs[i].tagName == 'DIV') {
	  childs[i].style.display = "none";
	}
  }
}

function showChilds(parentElement, iMaxSpeed) {
  var childs = parentElement.childNodes;
	
  for (var i = 0; i < childs.length; i++) {
    if (childs[i].tagName == 'DIV') {
      var childSpeed = childs[i].lastElementChild.value;
      if (childSpeed <= iMaxSpeed) {
		childs[i].style.display = "block";
	  }
	}
  }
}

function displayConnectionAddress() {	  
  isConAdressChecked = document.getElementById("displayAdressAS").checked;
  document.getElementById("connectionAS").style.display = "none";

  if (isConAdressChecked) {
    document.getElementById("connectionAS").style.display = "block";
  }
}

async function displaySummary() {
  var html = '';
  var url  = 'https://neu.brehna.net/auftragsautomatisierung/create_summary_html.php';
 
  var contractType = (document.querySelector('input[name="contractT"]:checked') === null)? 0 : document.querySelector('input[name="contractT"]:checked').value;
  var tariff = (document.querySelector('input[name="choosenTariff"]:checked') === null)? 0 : document.querySelector('input[name="choosenTariff"]:checked').value;
	
  // tariff options
  var optionsGen = getAllOptions(document.querySelectorAll("input[name='option']"  ), 1);
  var optionsHW  = getAllOptions(document.querySelectorAll("input[name='optionHW']"), 1);
  var optionsSV  = getAllOptions(document.querySelectorAll("input[name='optionSV']"), 1);
  var optionsSW  = getAllOptions(document.querySelectorAll("input[name='optionSW']"), 1);
	
  var contractTerm = (document.querySelector('input[name="contractTerm"]:checked') === null)? 0 : document.querySelector('input[name="contractTerm"]:checked').value;
  var termTxt = (contractTerm === 0)? '' : document.querySelector('input[name="contractTerm"]:checked').nextSibling.nodeValue;
	
  var num1 = (document.querySelector('input[name="num1"]:checked') === null)? 0 : document.querySelector('input[name="num1"]:checked').value;
  var numTxt = (num1 === 0)? '' : document.querySelector('input[name="num1"]:checked').nextSibling.nodeValue;

  var selected = document.getElementById("legalForm");
	
  let data = {
    'formType'         : currentFormType,
	'contractType'     : contractType,
	'company'          : document.getElementById("company").value,
	'salutation'       : document.getElementById("salutation").value,
    'fName'            : document.getElementById("fName").value,
	'lName'            : document.getElementById("lName").value,
	'legalForm'        : selected.value,
	'legalFormTxt'     : selected.options[selected.selectedIndex].text,
	'taxId'            : document.getElementById("taxId").value,
	'birthDay'         : document.getElementById("birthDate").value,
	'whg'              : document.getElementById("wNr").value,
	'street'           : document.getElementById("street").value,
	'hNr'              : document.getElementById("hNr").value,
	'plz'              : document.getElementById("postcode").value,
	'place'            : document.getElementById("places").value,
	'district'         : document.getElementById("district").value,
	'isConAddress'     : isConAdressChecked,
	'streetAS'         : document.getElementById("streetAS").value,
	'hNrAS'            : document.getElementById("hNrAS").value,
	'plzAS'            : document.getElementById("plzAS").value,
	'placeAS'          : document.getElementById("placesAS").value,
	'districtAS'       : document.getElementById("districtAS").value,
	'conPhone'         : document.getElementById("phone").value,
	'conMobil'         : document.getElementById("mobil").value,
	'conMail'          : document.getElementById("mail").value,
	'tariff'           : tariff,
    'optionsGen'       : optionsGen,
	'optionsHW'        : optionsHW,
	'optionsSV'        : optionsSV,
	'optionsSW'        : optionsSW,
	'isRNPortWish'     : toPortNr,
	'phoneProvider'    : document.getElementById("phoneProvider").value,
	'holderName'       : document.getElementById("holderName").value,
	'holderFName'      : document.getElementById("holderFName").value,
    'holderStreet'     : document.getElementById("holderStreet").value,
	'holderHNr'        : document.getElementById("holderHNr").value,
	'holderPLZ'        : document.getElementById("holderPLZ").value,
	'holderPlace'      : document.getElementById("holderPlace").value,
    'phoneOnkz1'       : document.getElementById("phoneOnkz1").value,
	'phoneOnkz2'       : document.getElementById("phoneOnkz2").value,
	'phoneOnkz3'       : document.getElementById("phoneOnkz3").value,
    'phone11'          : document.getElementById("phone1").value,
	'phone22'          : document.getElementById("phone2").value,
	'phone33'          : document.getElementById("phone3").value,
	'phone14'          : document.getElementById("phone4").value,
	'phone25'          : document.getElementById("phone5").value,
	'phone36'          : document.getElementById("phone6").value,
	'phone17'          : document.getElementById("phone7").value,
	'phone28'          : document.getElementById("phone8").value,
	'phone39'          : document.getElementById("phone9").value,
	'tkOnkz'           : document.getElementById("tkOnkz").value,
	'tkQueryPoint'     : document.getElementById("tkQueryPoint").value,
	'tkPhoneBlockFrom' : document.getElementById("tkPhoneBlockFrom").value,
	'tkPhoneBlockTo'   : document.getElementById("tkPhoneBlockTo").value,
	'contractTerm'     : contractTerm,
	'termTxt'          : termTxt,
	'num1'             : num1,
	'num1Txt'          : numTxt,
	'debName'          : document.getElementById("debatorName").value,
	'debStreet'        : document.getElementById("debatorStreet").value,
	'debHNr'           : document.getElementById("debatorHNr").value,
	'debPLZ'           : document.getElementById("debatorPlz").value,
	'debPlace'         : document.getElementById("debatorPlace").value,
	'debDistrict'      : document.getElementById("debatorDistrict").value,
	'debCountry'       : document.getElementById("debatorCountry").value,
	'debIBAN'          : document.getElementById("debatorIban").value,
	'debBIC'           : document.getElementById("debatorBic").value,
	'agb'              : document.querySelectorAll("input[name='checkAGB']").value,
	'dataProtection'   : document.querySelectorAll("input[name='checkProcessData']").value,
	'perVoiceChannel'  : document.getElementById("gkTOCnt1").value,
	'addVoiceChannel'  : document.getElementById("gkTOCnt2").value
  }

  let params = {
    "method": "POST",
	"headers": {
	  "Content-Type": "application/json; charset=utf-8"
	},
	"body": JSON.stringify(data)
  }
  
  try {
    var response = await fetch(url, params).then(function(response){
      return response.json();
    }).catch((error) => {
      console.log(error);
    });
	  
    if (response) {
	  html = response;

	  var summary = document.getElementById("contractSummary");
      
	  document.getElementById("contractSummary").insertAdjacentHTML('afterbegin', html);

	  if (summary.hasChildNodes() && summary.childElementCount == 2) {
        summary.removeChild(summary.children[1]);
	  }
		
	  summaryHtml = summary.innerHTML;
    }  
  } catch {
    console.error('Promise rejected');
  }
}

function getAllOptions(elements, returnType) {
  var returnValue = '';
	
  for (i = 0; i < elements.length; i++) {
    if (elements[i].checked) {
	  if (returnType === 1) {
		returnValue += elements[i].value + ",";
	  } else if (returnType === 2) {
		returnValue += elements[i].nextSibling.nodeValue + ",";		 
	  }
    }
  }
	
  return returnValue;
}