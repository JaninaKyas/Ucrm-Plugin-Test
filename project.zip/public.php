<?php

declare(strict_types=1);

use Ubnt\UcrmPluginSdk\Service\UcrmSecurity;

chdir(__DIR__);

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/helper/Service/ViewRender.php';
require __DIR__ . '/helper/Service/Http.php';
require __DIR__ . '/model/get_all_places.php';
require __DIR__ . '/model/get_custome_user_data.php';
require __DIR__ . '/model/get_custome_user_data2.php';

$security = UcrmSecurity::create();
$user = $security->getUser();

if (!$user || $user->isClient) {
  $http = new Http();
  $http->forbidden();
}

$pdo = require_once __DIR__ . '/model/connect_db.php';

$cPlaces = new CustomPlaces();
$places = $cPlaces->getAllPlaces($pdo);

$renderer = new ViewRender();
$renderer->render(
  __DIR__ . '/views/start_main.php',
  [
    'pdo'             => $pdo,
    'places'          => $places,
    'users'           => [],
    'user'            => []
  ]
);

?>
