CREATE TABLE IF NOT EXISTS `service` (
  `id`         INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(100)               NOT NULL DEFAULT '',
  `price`      DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `note`       CHAR(100)              NOT NULL DEFAULT '',
  `createDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)               NOT NULL DEFAULT '',
  `updateDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)             NOT NULL DEFAULT 0,  
  PRIMARY KEY (id)
) ENGINE=INNODB;

INSERT INTO `service` VALUES(null, 'IT-Sicherheitspaket und Updateservice je Endgerät',     9.95, '',                                                   NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Bereitstellungspreis Tarif/Anschluss',                  9.95, 'inkl. Techniker für Router/ Telefonie',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Bereitstellungspreis Tarif/Anschluss',                 75.00, 'inkl. Techniker für Router/ Telefonie',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Einrichtung Komfort',                                  79.00, 'max. 5 Endgeräte, Telefone und IT-Check AVM',        NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Kabel, Anschluss und Installation nach Kundenwunsch',   0.00, '',                                                   NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Einrichtungsentgelt',                                 100.00, '(inkl. B.net Routerkonfig)',                         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `service` VALUES(null, 'Einrichtungspauschale',                               100.00, '(TAE/ RJ45 Dose, Kabel & Installation, Einweisung)', NOW(), 'JANINA', NOW(), 'JANINA', 0);