--
-- Tabellenstruktur für Tabelle `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id`               INT(11)   UNSIGNED NOT NULL AUTO_INCREMENT,
  `postal_adress_id` INT(11)   UNSIGNED NOT NULL,
  `tech_address_id`  INT(11)   UNSIGNED NOT NULL,
  `legal_form_id`    INT(11)   UNSIGNED NOT NULL,
  `customerNr`       CHAR(100)          NOT NULL DEFAULT '',
  `fName`            CHAR(100)          NOT NULL DEFAULT '',
  `lName`            CHAR(100)          NOT NULL DEFAULT '',
  `company`          CHAR(100)          NOT NULL DEFAULT '',    
  `birthDate`        DATE               NOT NULL DEFAULT '1000-01-01',
  `taxNr`            CHAR(50)           NOT NULL DEFAULT '',
  `appartmentNr`     CHAR(50)           NOT NULL DEFAULT '',
  `phone`            CHAR(20)           NOT NULL DEFAULT '',
  `mobil`            CHAR(20)           NOT NULL DEFAULT '',
  `eMail`            CHAR(100)          NOT NULL DEFAULT '', 
  `createDate`       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`       CHAR(50)           NOT NULL DEFAULT '',
  `updateDate`       DATETIME           NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`       CHAR(50)           NOT NULL DEFAULT '',
  `isDeleted`        TINYINT(1)         NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (postal_adress_id) REFERENCES `address`(id),
  FOREIGN KEY (tech_address_id)  REFERENCES `address`(id),
  FOREIGN KEY (legal_form_id)    REFERENCES `legal_form`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;