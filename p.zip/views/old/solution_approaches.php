

Wie ist das Gerät mit dem Router verbunden?
per WLAN      (W)
per LAN-Kabel (L)


Wenn das Gerät per Kabel verbunden ist, stecken die Kabel fest oder sind diese locker? (L)
fest
locker

Haben Sie vor dem einschalten eine Änderung Ihrer Internetverbindung bemerkt? (W)
ja
nein

Haben Sie mehrere Geräte am WLAN angeschlossen? (W)
ja:
- Bitte trennen Sie einige Geräte vom WLAN und versuchen Sie bitte sich erneut mit Ihrer Mediathek zu verbinden.
- Besteht immer noch derselbe Fehler?
- ja
- nein
nein:

Haben Sie versucht Ihren Router neu zu starten?
ja
nein -> Starten Sie bitte Ihren Router neu.

Verwenden Sie die aktuellste Version von der Mediathek?

ja
nein -> Bitte aktualisieren Sie Ihre Mediathek und starten die Anwendung danach neu.

Haben Sie in Ihrem Browser der Mediathek den Cache und Cookies gelöscht?
ja
nein -> Bitte im Browser den Cache und Cookies löschen und danach bitte die Anwendung neu starten. Besteht das Problem immer noch?

Ist Ihnen gerade bekannt ob der Anbieter der Mediathek Wartungsarbeiten durchführt?
ja -> Dann haben Sie bitte noch ein bisschen Geduld und versuchen es später nocheinmal.
nein -> Ich werde jetzt für Sie schauen, ob der Anbieter dieser Mediathek gerade ein Update durchführt. Dazu brauche ich bitte den Namen. Wie lautet der Name Ihres Anbieters für diese Mediathek?

Haben Sie versucht auch auf anderen Geräten TV zu schauen?
ja
nein -> Falls Sie ein zweites Gerät haben, verbinden Sie dieses mit dem Internet und versuchen damit TV yu sehen. Besteht dassselbe Problem?


