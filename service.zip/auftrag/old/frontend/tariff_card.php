<?php

declare(strict_types = 1);

class TariffCard {	
  public function buildTariffCard(
    $id, $tName, $tTechnology, $tDownStream, $tUpStream, $tPrice, $category, $option, $classId, $divId
  ) {
?>

<div id=" <?php echo $divId; ?> " name="cGroup" class="borderBox">
  <div class="row puffer">
	<div class="col vlr">
	  <input type="radio" name="choosenTariff" value="<?php echo $id; ?>">
	  <span>
		<img id="internetImg" 
			 src="https://neu.brehna.net/auftragsautomatisierung/public/img/internet.png" 
			 alt="internet">
		  
		<?php
		   if (strpos($category, 'Telefon') != false) { 
		?>
		  <img id="phoneImg" 
			   src="https://neu.brehna.net/auftragsautomatisierung/public/img/phone.png" 
			   alt="phone">
		<?php } ?>
		  
	  </span>
	  <br>
	  <span class="pufferLeft"><b><?php echo $category; ?></b></span>
	</div>
	  
	<div class="col vlr smFont2">
	  <b><?php echo $tName; ?></b>
	  <br><br>
	  <?php
		if (!empty($tTechnology) && $tTechnology != '' && $tTechnology != null) {
		  echo $tTechnology . "<br><br>";
		}
	  ?>
	  <ul>
		  <li><b><?php echo $tDownStream; ?></b> MBit/s max. Download</li>
		  <li><b><?php echo $tUpStream; ?></b> MBit/s max. Upload</li>
	  </ul>	
      <?php
		if (!empty($option) && $option != '' && $option != null) {
		  echo "<br>";
	  ?>
	  <ul>
	  
	  <?php
		  $options = explode(",", $option);
          for ($i = 0; $i < count($options); $i++) {
      ?>
	  <li>
		<img id="check"
			 src="https://neu.brehna.net/auftragsautomatisierung/public/img/check-mark-1.png" 
			 alt="check"> <?php echo ltrim($options[$i]); ?>
	  </li>
	  <?php
		  }
		}
	  ?>
	  </ul>
	</div>
	  
	<div id="tPri" class="col">
	  <b>
	  <?php 
	    if (gettype($tPrice) == "string") {
		  $priceTariff = floatval($tPrice);
		  echo number_format($priceTariff, 2, ',', ' ');
		} else {
	      echo $tPrice;
		}
	  ?> € pro Monat</b>
	</div>
  </div>
	
  <input type="hidden" value="<?php echo $tDownStream; ?>">
</div>
	
<?php
  }
}

?>