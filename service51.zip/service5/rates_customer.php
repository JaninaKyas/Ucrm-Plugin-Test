<?php
  if (isset($_POST)) {
    $data  = file_get_contents("php://input");
    $infos = json_decode($data, true);

	require __DIR__ . "/views/rates/tariff.php";
	$tariffFormHtml  = new Tariff(array(), $infos, array());

	$content = array(
	  "step3Lable"    => "Kundendaten",
	  "step3"         => $tariffFormHtml->getCustomerTemplate(),
	  "caDiffAddress" => "none"  
    );
	  
	echo json_encode($content);
  } 
?>