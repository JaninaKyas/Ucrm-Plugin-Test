<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
	  
	public function buildAddressTemplate(): string {		
	  return '
	    <div class="row puffer left">
		  <div class="col">
		    Strasse*
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
				   name="' . $this->templateData[2] . '">
		  </div>

		  <div class="col">
		    Hausnummer*
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
				   name="' . $this->templateData[3] . '"
				   onkeypress="return /[0-9a-zA-Z]/.test(event.key)"
				   onpaste="return false">
		  </div>
		</div>
		
	    <div class="row puffer left">
		  <div class="col">
		    PLZ*
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
				   name="' . $this->templateData[3] . '"
				   onkeypress="return /[0-9]/.test(event.key)"
				   onpaste="return false">
		  </div>

		  <div class="col">
		    Ort*
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
				   name="' . $this->templateData[4] . '">
		  </div>
		</div>
	  ';
	}
  }
?>