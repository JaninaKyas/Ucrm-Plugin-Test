
<footer id="footer" class="footer__wrapper" >
  <div id="footer-widget-area" class="widget__wrapper" role="complementary" >
  <div class="container widget__container">
    <div class="row">
                      <div id="footer_one" class="col-md-4 col-12">
            <aside id="nav_menu-5" class="widget widget_nav_menu"><div class="menu-footermenue-container"><ul id="menu-footermenue" class="menu"><li id="menu-item-23" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23"><a href="https://neu.brehna.net/impressum/">Impressum</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-22"><a rel="privacy-policy" href="https://neu.brehna.net/datenschutz/">Datenschutz</a></li>
</ul></div></aside>          </div>
                  <div id="footer_two" class="col-md-4 col-12">
            <aside id="nav_menu-6" class="widget widget_nav_menu"><div class="menu-footermenue-mitte-container"><ul id="menu-footermenue-mitte" class="menu"><li id="menu-item-373" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-373"><a href="https://neu.brehna.net/agb/">AGB</a></li>
<li id="menu-item-374" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-43 current_page_item menu-item-374"><a href="https://neu.brehna.net/dokumente/" aria-current="page">Dokumente</a></li>
</ul></div></aside>          </div>
                  <div id="footer_three" class="col-md-4 col-12">
            <aside id="block-2" class="widget widget_block"><div class="socials">
<a href="https://www.instagram.com/brehnanet/" target="_blank">
<img decoding="async" src="https://neu.brehna.net/wp-content/uploads/2023/09/bnet-icon-ig.png"></a>
<a href="https://www.facebook.com/brehna.net" target="_blank">
<img decoding="async" src="https://neu.brehna.net/wp-content/uploads/2023/09/bnet-icon-facebook.png"></a>
<!--<a href="https://bewerte.brehna.net/" target="_blank">-->
<a href="https://search.google.com/local/writereview?placeid=ChIJRekp_AhopkcRZGyfExTbItg" target="_blank">
<img decoding="async" src="http://neu.brehna.net/wp-content/uploads/2023/09/bnet-icon-google-mybusiness.png"></a>
</div></aside>          </div>
                  </div>
  </div>
</div>
<div id="colophon" class="colophon " >
  <div class="container">
    <div class="colophon__row row flex-row justify-content-between">
      <div class="col-12 col-sm-auto">
              </div>
          </div>
  </div>
</div>
</footer>