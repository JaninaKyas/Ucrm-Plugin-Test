<?php
  declare(strict_types = 1);

  require __DIR__ . "/address.php";

  class Customer {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
	  
	public function buildCustomerTemplate(): string {
	  return '
		<div class="customerBlock">
	  ' . $this->buildSalutationSection() . '<hr>'
		. $this->buildAddressSection()    . '<hr>'
		. $this->buildContactSection()    . '<hr>'
		. $this->buildTechAddressSection()
		. '</div>';
	}
	  
	protected function buildSalutationSection(): string {		
	  $returnValue = '	  
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Anrede*</label>
		    <select id="'   . $this->templateData["personalData"][0] . '"
			        name="' . $this->templateData["personalData"][0] . '"
			  	    class="form-select selectBox">
			  <option vlaue="1" selected>Herr</option>
			  <option vlaue="2">Frau</option>
			</select>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Vorname*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][1] . '"
			  	   name="' . $this->templateData["personalData"][1] . '"
				   class="form-control required">
		  </div>

		  <div class="col">
		    <label class="addressLabel">Name*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][2] . '"
				   name="' . $this->templateData["personalData"][2] . '"
				   class="form-control required">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Firma (falls Auftrag als Geschäftskunde)</label>
			<input type="text"
			       class="form-control">
		  </div>
		</div>';
		
	  return $returnValue;
	}
	  
	protected function buildAddressSection(): string {
	  $address = new Address($this->templateData["postalAddress"], $this->values["postalAddress"]);
	  return $address->buildAddressTemplate();
	}
	  
	protected function buildContactSection(): string {
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Telefon*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][5] . '"
				   name="' . $this->templateData["personalData"][5] . '"
				   class="form-control required">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Mobil*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][6] . '"
				   name="' . $this->templateData["personalData"][6] . '"
				   class="form-control required">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">E-Mail*</label>
		    <input type="text"
			       id="'   . $this->templateData["personalData"][4] . '"
				   name="' . $this->templateData["personalData"][4] . '"
				   class="form-control required">
		  </div>
		</div>
	  ';
	  return $returnValue;
	}
	  
	protected function buildTechAddressSection(): string {
	  $address = new Address($this->templateData["connecAddress"]);
	  return $address->buildTechAddressTemplate();
	}
  }
?>