<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);

	require_once __DIR__ . "/views/rates/rate_konto.php";
	  
	$rateKonto = new RateKonto(array(), array(), array(), array());
	  
	$content = array(
	  "step6content" => $rateKonto->buildAGBTemplate()
	);

	echo json_encode($content);
  } 
?>