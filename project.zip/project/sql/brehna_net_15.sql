CREATE TABLE IF NOT EXISTS `country` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(30)            NOT NULL DEFAULT '',
  `code`       CHAR(4)             NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS `pricelist_phone_pk` (
  `id`          INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `country_id`  INT(11)       UNSIGNED NOT NULL,
  `net_type_id` INT(11)       UNSIGNED NOT NULL,
  `name`        CHAR(100)              NOT NULL DEFAULT '',
  `price`       DECIMAL(10,3)          NOT NULL DEFAULT 0.00,
  `isForFree`   TINYINT(1)             NOT NULL DEFAULT 0,
  `createDate`  DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`  CHAR(50)               NOT NULL DEFAULT '',
  `updateDate`  DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`  CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`   TINYINT(1)             NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (country_id)  REFERENCES country(id),
  FOREIGN KEY (net_type_id) REFERENCES net_type(id)
) ENGINE=INNODB;