<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class CustomerFttHRequestQueries {
    public function saveFttHRequestData(
	  $customerId, $postAddressId, $techAddressId, $debatorId, $conKindId, $selectedTechId, $rateId,
	  $mainNumId, $subNumId, $kindPointId, $cntUnits, $completeDate, $introHouseId, $introElse, 
	  $houseOwnerId
	): bool {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = false;
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'INSERT INTO address
		            VALUES(
					  null, '
			        . $customerId          . ', '
			        . $postAddressId       . ', '
			        . $techAddressId       . ', '
			        . $debatorId           . ', '
			        . $conKindId           . ', '
			        . $selectedTechId      . ', '
			        . $rateId              . ', '
			        . $mainNumId           . ', '
			        . $subNumId            . ', '
			        . $kindPointId         . ', '
			        . $cntUnits            . ', '
			        . '\'' . $completeDate . '\', '
			        . $introHouseId        . ', '
			        . '\'' . $introElse    . '\', '
			        . $houseOwnerId
			        . '1, 1, NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';

		  $result = $connection->query($query);
			
		  if ($returnValue != false) {
		    $returnValue = true;
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>