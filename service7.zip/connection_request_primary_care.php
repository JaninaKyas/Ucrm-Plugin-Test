<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	$content = array();
	  
	require_once __DIR__ . "/model/technology_queries.php";
	require_once __DIR__ . "/views/connectionRequest/connection_request_care.php";
	  
	$techQueries = new TechnologyQueries();
	$techKinds   = $techQueries->getAllTechKinds();
	  
	$conRequestCare = new ConnectionRequestCare($techKinds);
	  
	$content = array(
      "step5content" => $conRequestCare->getPrimaryCareTemplate()
	);

	echo json_encode($content);
  } 
?>