<?php

namespace RouterOS\Exceptions;

/**
 * Class StreamException
 *
 * @package RouterOS\Exceptions
 * @since   0.9
 */
class StreamException extends \Exception
{
}
