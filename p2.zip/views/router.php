<div id="router-1">
  Was für ein Router wird verwendet?
  <ul class="list-group">
    <li class="list-group-item">
      <input type="radio" id="fritzbox2" name="rKind" value="Fritz!Box 7590 AX" onClick="setRouterKind(1)">
      <label for="fritzbox2">Fritz!Box 7590 AX</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox3" name="rKind" value="Fritz!Box 7590" onClick="setRouterKind(1)">
      <label for="fritzbox3">Fritz!Box 7590</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox5" name="rKind" value="Fritz!Box 7530 AX" onClick="setRouterKind(1)">
      <label for="fritzbox5">Fritz!Box 7530 AX</label>
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox6" name="rKind" value="Fritz!Box 7530" onClick="setRouterKind(1)">
      <label for="fritzbox6">Fritz!Box 7530</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="fritzbox13" name="rKind" value="Fritz!Box 4040" onClick="setRouterKind(1)">
      <label for="fritzbox13">Fritz!Box 4040</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom" name="rKind" value="LANCOM 1926VAG-5G" onClick="setRouterKind(2)">
      <label for="lancom">LANCOM 1926VAG-5G</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom1" name="rKind" value="LANCOM 1926VAG-4G" onClick="setRouterKind(2)">
      <label for="lancom1">LANCOM 1926VAG-4G</label>    
    </li>  
    <li class="list-group-item">
      <input type="radio" id="lancom2" name="rKind" value="LANCOM 1926VAG" onClick="setRouterKind(2)">
      <label for="lancom2">LANCOM 1926VAG</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom3" name="rKind" value="LANCOM 1803VA-4G/1803VA" onClick="setRouterKind(2)">
      <label for="lancom3">LANCOM 1803VA-4G/1803VA</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom4" name="rKind" value="LANCOM 1800VAW-4G/1800VAW" onClick="setRouterKind(2)">
      <label for="lancom4">LANCOM 1800VAW-4G/1800VAW</label>    
    </li>   
    <li class="list-group-item">
      <input type="radio" id="lancom5" name="rKind" value="LANCOM 1800VA-4G/1800VA" onClick="setRouterKind(2)">
      <label for="lancom5">LANCOM 1800VA-4G/1800VA</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom6" name="rKind" value="LANCOM 1793VAW" onClick="setRouterKind(2)">
      <label for="lancom6">LANCOM 1793VAW</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="lancom7" name="rKind" value="LANCOM 1790VA-4G+" onClick="setRouterKind(2)">
      <label for="lancom7">LANCOM 1790VA-4G+</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom8" name="rKind" value="LANCOM 1790VAW" onClick="setRouterKind(2)">
      <label for="lancom8">LANCOM 1790VAW</label>    
    </li> 
    <li class="list-group-item">
      <input type="radio" id="lancom8" name="rKind" value="LANCOM 1790VA" onClick="setRouterKind(2)">
      <label for="lancom8">LANCOM 1790VA</label>    
    </li>
    <li class="list-group-item">
      <input type="radio" id="cOwnRouter" name="cOwnRouter" value="" onClick="setRouterKind(0)">
      <label for="cOwnRouter">Eigenhardware</label>
      <br>
      <div class="row puffer">
        <div class="col">
          <label for="cMail" class="form-label">Um welches Modell handelt es sich?</label>
          <input type="text" class="form-control" id="rModell" name="rModell" placeholder="Modell" value="">
        </div>
      </div>
    </li>            
  </ul>
</div>
