<?php
  if(isset($_POST)){
    $data = file_get_contents("php://input");
    $address = json_decode($data, true);
	  
	require_once __DIR__ . "/model/asb_availability_queries.php";
	header("Access-Control-Allow-Origin: *");
	  
	$asb = new AsbAvailabilityQueries();
	  
	$maxSpeed = $asb->getMaxDownloadStream(
	  $address["street"], $address["hnr"],  $address["plz"],  $address["place"],  $address["district"]);
	  
	echo json_encode($maxSpeed);
  }
?>