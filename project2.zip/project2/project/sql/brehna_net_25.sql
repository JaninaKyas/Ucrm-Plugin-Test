CREATE TABLE IF NOT EXISTS `asb_availability` (
  `id`                     INT(11)          UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_address_id`    INT(11)          UNSIGNED NOT NULL,
  `network_node_adress_id` INT(11)          UNSIGNED NOT NULL,
  `technology_id`          Int(11)          UNSIGNED NOT NULL,
  `down_stream`            Decimal(10, 2)   UNSIGNED NOT NULL DEFAULT 0.00,
  `up_stream`              Decimal(10, 2)   UNSIGNED NOT NULL DEFAULT 0.00,
  `kvz`                    CHAR(10)                  NOT NULL DEFAULT '',
  `onkz`                   CHAR(10)                  NOT NULL DEFAULT '',
  `asb`                    INT(11)                   NOT NULL DEFAULT 0,
  `createDate`             DATETIME                  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`             CHAR(50)                  NOT NULL DEFAULT '',
  `updateDate`             DATETIME                  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`             CHAR(50)                  NOT NULL DEFAULT '',
  `isDeleted`              TINYINT(1)                NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (customer_address_id)    REFERENCES address(id),
  FOREIGN KEY (network_node_adress_id) REFERENCES address(id),
  FOREIGN KEY (technology_id)          REFERENCES technology(id)
) ENGINE=INNODB;

CREATE TABLE IF NOT EXISTS `asb_availability_x_customer` (
  `id`                  INT(11)  UNSIGNED NOT NULL AUTO_INCREMENT,
  `customer_id`         INT(11)  UNSIGNED NOT NULL,
  `asb_availability_id` INT(11)  UNSIGNED NOT NULL,
  `ext_order_nr`        CHAR(11)          NOT NULL DEFAULT '',
  `double_wire_nr`      CHAR(11)          NOT NULL DEFAULT '',
  `switching_nr`        CHAR(50)          NOT NULL DEFAULT '',
  `line_design_dtag`    CHAR(50)          NOT NULL DEFAULT '',
  `isConnect`           TINYINT(1)        NOT NULL DEFAULT 0,
  `createDate`          DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`          CHAR(50)          NOT NULL DEFAULT '',
  `updateDate`          DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`          CHAR(50)          NOT NULL DEFAULT '',
  `isDeleted`           TINYINT(1)        NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (customer_id) REFERENCES customer(id)
) ENGINE=INNODB;