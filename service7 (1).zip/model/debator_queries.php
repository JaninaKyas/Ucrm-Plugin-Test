<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class DebatorQueries {	
    public function getIdByDebatorData($name, $street, $hnr, $plz, $place, $district, $country, $iban, $bic): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT d.id as id
		            FROM debator       AS d
					LEFT JOIN country  AS c ON d.country_id   = c.id
					LEFT JOIN address  AS a ON d.address_id   = a.id
					LEFT JOIN location AS l ON a.location_id  = l.id
					WHERE d.isDeleted = 0
					  AND
					      c.isDeleted  = 0
					  AND
					      a.isDeleted = 0
					  AND
					      l.isDeleted  = 0';
          
		  if ($name != "") {
		    $query  .= ' AND d.lName LIKE \'' . $name . '\' ';
		  }
			
		  if ($street != "") {
		    $query  .= ' AND a.street LIKE \'' . $street . '\' ';
		  }
			
		  if ($hnr != "") {
		    $query  .= ' AND a.houseNr LIKE \'' . $hnr . '\' ';
		  }
			
		  if ($plz != "") {
		    $query  .= ' AND a.zipcode LIKE \'' . $plz . '\' ';
		  }
			
		  if ($place != "") {
		    $query  .= ' AND l.name LIKE \'' . $place . '\' ';
		  }
			
		  if ($district != "") {
		    $query  .= ' AND l.district LIKE \'' . $district . '\' ';
		  }
			
		  if ($country != "") {
		    $query  .= ' AND c.name LIKE \'' . $country . '\' ';
		  }
			
		  if ($iban != "") {
		    $query  .= ' AND d.iban LIKE \'' . $iban . '\' ';
		  }
			
		  if ($bic != "") {
		    $query  .= ' AND d.swift_bc LIKE \'' . $bic . '\' ';
		  }
			
		  $result = $connection->query($query);
			
          if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
	public function saveNewDebator($addressId, $countryId, $name, $iban, $bic): int {
	  $returnValue = -1;
		
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");

		  $query = 'INSERT INTO debator
		            VALUES(
					  null, '
                    . $addressId   . ', '
			        . $countryId   . ', '
			        . '\'' . $name . '\', '
			        . '\'' . $iban . '\', '
			        . '\'' . $bic  . '\', '
			        . '1, NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';
			
		  $result = $connection->query($query);
			
		  if ($returnValue != false) {
		    $returnValue = $connection->insert_id;
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>