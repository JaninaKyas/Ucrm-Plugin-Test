<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  $dir = str_replace("/views", "", __DIR__);

  require $dir . "/model/numerically_queries.php";

  $numericallyQueries = new NumericallyQueries();
  $numericallyValues = $numericallyQueries->getAllNumericallyValues();
?>

<div id="errorChooseNotNumerically" class="noDisplay">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Bitte wählen Sie eine Zahlweise aus.
    </div>
  </div>
</div>

<div id="errorBankRequiredFields" class="noDisplay">
  <div class="row puffer errorBox">
    <div class="errorBoxContent">
      <img id="error"
           src="https://neu.brehna.net/auftragsautomatisierung/public/img/error-5.png"
	       alt="error"> Bitte füllen Sie alle Pflichtfelder aus.
    </div>
  </div>
</div>

<div id="contractDebator" class="borderBox">
  <div id="contractDebatorNumerically" class="borderBox">
    <div class="row puffer">
	  <div class="col">
		<strong>Zahlweise</strong>
	  </div>
	</div>

	<div id="numerically1" class="noDisplay">
	  <div class="row puffer">
	    <div class="col">
		  <input type="radio" id="num1" name="num1"
		  value="<?php echo $numericallyValues[0]["id"]; ?>"
		  onclick="displaySepa(0)"> <?php echo $numericallyValues[0]["name"]; ?>
		  <br>
		  <input type="radio" id="num2" name="num1"
		  value="<?php echo $numericallyValues[1]["id"]; ?>"
		  onclick="displaySepa(0)"> <?php echo $numericallyValues[1]["name"]; ?>
		  <br>
		  <input type="radio" id="num3" name="num1"
		  value="<?php echo $numericallyValues[2]["id"]; ?>"
		  onclick="displaySepa(1)"> <?php echo $numericallyValues[2]["name"]; ?>  
		</div>
	  </div>
	</div>
	
	<div id="numerically2" class="noDisplay">
	  <div class="row puffer">
	    <div class="col">
		  <input type="radio" id="num4" name="num1"
		  value="<?php echo $numericallyValues[3]["id"]; ?>"> <?php echo $numericallyValues[3]["name"]; ?>
		  <br>
		  <input type="radio" id="num5" name="num1"
		  value="<?php echo $numericallyValues[2]["id"]; ?>"
		  onclick="displaySepa(1)"> <?php echo $numericallyValues[2]["name"]; ?>  
		</div>
	  </div>
	</div>
  </div>
	
  <div id="sepa" class="borderBox noDisplay">
	<div id="sepaHeader">
	  <div class="row puffer">
	    <div class="col">
		  <span class="spanNewline">
		    <b>SEPA-Basis Lastschriftmandat</b>
		  </span>
		
		  <span class="spanNewline">Project66 IT Service & Design / Brehna.net</span>
		  <span class="spanNewline">Max-Planck-Str. 2, 06796 Brehna</span>
	    </div>
	  </div>
		
	  <div class="row puffer">
	    <div class="col">
		  <span class="spanNewline">
		    <b>Gläubiger-Identifikationsnummer</b>
		  </span>
		
		  <span class="spanNewline">
		    DE68ZZZ00002002280
		  </span>
	    </div>
	  </div>
		
	  <div class="row puffer">
	    <div class="col">
		  <span class="spanNewline">Project66 IT Service & Design / Brehna.net</span>
		  <span class="spanNewline">Max-Planck-Str. 2</span>
		  <span class="spanNewline">06796 Brehna</span>
	    </div>
		 
		<div class="col">
          <input type="checkbox" id="paymentRecurring" name="paymentRecurring"
		  value="1" checked> Wiederkehrende Zahlung
	    </div>
	  </div>
	</div>
	  
	<div id="sepaContent" class="borderbox">
	  <div class="row puffer">
		<div class="col">
		  Zahlungspflichtiger*
	      <input type="text" class="form-control required3" id="debatorName" name="debatorName">
		</div>
	  </div>

	  <div class="row puffer">
		<div class="col-8">
		  Zahlungspflichtige Strasse*
	      <input type="text" class="form-control required3" id="debatorStreet" name="debatorStreet">
		</div>
		  
		<div class="col">
		  Zahlungspflichtige Hausnummer*
	      <input type="text" class="form-control required3" id="debatorHNr" name="debatorHNr">
		</div>
	  </div>

	  <div class="row puffer">
		<div class="col">
		  Zahlungspflichtige Postleitzahl*
	      <input type="text" class="form-control required3" id="debatorPlz" name="debatorPlz">
		</div>
		  
		<div class="col">
		  Zahlungspflichtiger Ort*
	      <input type="text" class="form-control required3" id="debatorPlace" name="debatorPlace">
		</div>
		  
		<div class="col">
		  Zahlungspflichtiger Ortsteil
	      <input type="text" class="form-control" id="debatorDistrict" name="debatorDistrict">
		</div>
	  </div>

	  <div class="row puffer">
		<div class="col">
		  Zahlungspflichtiges Land*
	      <input type="text" class="form-control required3" id="debatorCountry" name="debatorCountry">
		</div>
	  </div>

	  <div class="row puffer">
		<div class="col">
		  Zahlungspflichtige IBAN*
	      <input type="text" class="form-control required3" id="debatorIban" name="debatorIban">
		</div>
	  </div>
		
	  <div class="row puffer">
		<div class="col">
		  Zahlungspflichtige SWIFT BIC*
	      <input type="text" class="form-control required3" id="debatorBic" name="debatorBic">
		</div>
	  </div>
    </div>
	  
	<div id="sepaContentNotice1" class="borderBox">
	  <div class="row puffer">
	    <div class="col">
	      <span class="spanNewline">
	        Ich ermächtige (Wir ermächtigen) Project66 IT-Service & Design / Brehna.net, Zahlungen
			von meinem (unseren) Konto mittels Lastschrift einzuziehen. Zugleich weise ich mein
			(weisen wir unser) Kreditinstitut an, die von Project66 auf mein (unsere) Konto 
			gezogenen Lastschriften einzulösen.
		  </span>
		</div>
	  </div>
	</div>
	  
    <div id="sepaContentNotice2" class="borderBox">
	  <div class="row puffer">
        <div class="col">
	      <span class="spanNewline"><b>Hinweise:</b></span>
		  <span class="spanNewline">
		    Ich kann / Wir können innerhalb von acht Wochen beginnend mit dem Belastungsdatum, die
		    Erstattung des belasteten Betrages verlangen. Es gelten dabei die mit meinem / unserem 
			Kreditinstitut vereinbarten Bedingungen.
		  </span>
		  <span class="spanNewline">
			<strong>
			  Bitte lassen Sie sich den Eingang des SEPA-Mandates von Ihrer Bank bestätigen.  
			</strong>
		  </span>
		</div>
	  </div>
	</div>
  </div>
</div>