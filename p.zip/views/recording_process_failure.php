<div class="form-header d-flex mb-4">
  <span class="stepIndicator">Kundendaten</span>
  <span class="stepIndicator">Gegenwärtigen Anschlussstatus</span>
  <span class="stepIndicator">Störung</span>
  <span class="stepIndicator">Router</span>
  <span class="stepIndicator">Lösungsansätze</span>
</div>

<div class="step"><?php require(__DIR__ . '/customer.php');           ?></div>
<div class="step"><?php require(__DIR__ . '/current_state_conn.php'); ?></div>
<div class="step"><?php require(__DIR__ . '/interference.php');       ?></div>
<div class="step">test 4</div>
  
<div class="form-footer d-flex">
  <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
  <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
</div>
