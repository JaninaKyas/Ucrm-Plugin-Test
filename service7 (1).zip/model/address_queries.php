<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class AddressQueries {	
	public function getIdByAddressData($street, $hnr, $plz, $place, $district = ''): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT ad.id AS id
		            FROM      address  AS ad
					LEFT JOIN location AS l   ON l.id = ad.location_id
					WHERE ad.isDeleted = 0
					  AND 
					    l.isDeleted     = 0
					  AND
					    ad.street LIKE \''  . $street . '\'
					  AND
					    ad.houseNr LIKE \'' . $hnr    . '\'
					  AND
					    ad.zipcode LIKE \'' . $plz    . '\'
					  AND
					    l.name LIKE \''     . $place  . '\'';

		  if ($district != '') {
		    $query .= ' AND l.district LIKE \'' . $district . '\'';
		  }
			
		  $result = $connection->query($query);
			
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
	public function saveNewAddress($street, $hnr, $plz, $locationId): int {
	  $returnValue = -1;
		
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");

		  $query = 'INSERT INTO address
		            VALUES(
					  null, '
			        . $locationId    . ', '
			        . '\'' . $street . '\', '
			        . '\'' . $hnr    . '\', '
			        . '\'' . $plz    . '\', '
			        . 'NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';
			
		  $result = $connection->query($query);
			
		  if ($returnValue != false) {
		    $returnValue = $connection->insert_id;
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>