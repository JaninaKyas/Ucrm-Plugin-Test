<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class ExpansionAreaQueries {
    public function isExpansionAreaFttH($address): bool {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue     = array();
	  $isExpansionFttH = false;
	  $config          = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT ea.id
		    FROM  expansion_area AS ea
			LEFT JOIN address    AS ad ON ad.id = ea.address_id
			LEFT JOIN location   AS  l ON l.id  = ad.location_id
			WHERE ea.technology_id = 2
			  AND
			    ad.isDeleted = 0
			  AND
			    ea.isDeleted = 0
			  AND
			    l.isDeleted  = 0
			  AND
			    ea.state_id  > 1
			  AND
			    ea.state_id  < 4";

	      if (array_key_exists('street', $address) && !empty($address["street"])) {
	        $query .= ' AND ad.street LIKE "' . $address["street"] . '"';
	      }
		
	      if (array_key_exists('hNr', $address) && !empty($address["hNr"])) {
	        $query .= ' AND ad.houseNr LIKE "' . $address["hNr"] . '"';
	      }
		
	      if (array_key_exists('zipcode', $address) && !empty($address["zipcode"])) {
	        $query .= ' AND ad.zipcode LIKE "' . $address["zipcode"] . '"';
	      }
		
	      if (array_key_exists('place', $address) && !empty($address["place"])) {
	        $query .= ' AND l.name LIKE "' . $address["place"] . '"';
	      }
		
	      if (array_key_exists('district', $address) && !empty($address["district"])) {
	        $query .= ' AND l.district LIKE "' . $address["district"] . '"';
	      }
			
		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  if (!empty($returnValue)) {
		    $isExpansionFttH = true;
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $isExpansionFttH;
	}
  }
?>