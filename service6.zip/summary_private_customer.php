<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	
	$topDiv = '
	  <div class="row puffer">
	    <div class="col"><strong>Auftrag Privatkunden</strong></div>

		<div class="col">
	      <img src="https://neu.brehna.net/auftrag/public/images/bnet-website-logo.png"
		       class="logo"
               style="max-width:250px;max-height:100px"	   
		       alt="logo">
		</div>
	  </div>
	  <hr>';
	  
	// own company address div
	$ownAddressDiv = '
	  <div class="row puffer left">
	    <div class="col">
		  Project66 IT Service & Design / Brehna.net<br>
		  Max-Planck-Str. 2<br>
		  06796 Brehna<br>
	    </div>
	  </div>';

	// customer address div
	$name      = '';
	$address   = '';
	$birthDate = '';
	$psTae     = '';
	$phone     = '';
	$mobil     = '';
	$mail      = '';
	if (array_key_exists("customer", $infos) && array_key_exists("postalAddress", $infos)) {
	  if (array_key_exists("company", $infos["customer"]) && $infos["customer"]["company"] != "") {
		$address = $infos["customer"]["company"] . "<br>";
	  }
		
	  if (array_key_exists("salut", $infos["customer"])) {
		$name = "Sehr geehrte ";
		if ($infos["customer"]["salut"] == "Herr") {
		  $name = "Sehr geehrter ";	
		}
		$name .= $infos["customer"]["salut"] . " " . $infos["customer"]["fName"]   . ' ' . $infos["customer"]["lName"] . ",<br>"; 
	  }	
		
      if (array_key_exists("fName", $infos["customer"]) && array_key_exists("lName", $infos["customer"])) {
		$address .= $infos["customer"]["fName"]   . ' ' . $infos["customer"]["lName"] . "<br>";
	  }

	  if (array_key_exists("street", $infos["postalAddress"]) && array_key_exists("hNr", $infos["postalAddress"])) {
		$address .= $infos["postalAddress"]["street"] . " " . $infos["postalAddress"]["hNr"] . "<br>";
	  }

	  if (array_key_exists("zipcode", $infos["postalAddress"]) && array_key_exists("place", $infos["postalAddress"])) {
		$address .= $infos["postalAddress"]["zipcode"] . " " . $infos["postalAddress"]["place"] . "<br>";
	  }

	  if (array_key_exists("district", $infos["postalAddress"]) && $infos["postalAddress"]["district"] != "") {
		$address .= "Ortsteil: " . $infos["postalAddress"]["district"] . "<br>";
	  }	

	  if (array_key_exists("birthDay", $infos["customer"])) {
        $birthDate = date_create($infos["customer"]["birthDay"]);
	  }
	  
	  if (array_key_exists("psTae", $infos["customer"]) && $infos["customer"]["psTae"] != "") {
        $psTae = $infos["customer"]["psTae"];
	  }
	  
	  if (array_key_exists("phone", $infos["customer"])) {
        $phone = $infos["customer"]["phone"];
	  }
	  
	  if (array_key_exists("mobil", $infos["customer"])) {
        $mobil = $infos["customer"]["mobil"];
	  }
	  
	  if (array_key_exists("mail", $infos["customer"])) {
        $mail = $infos["customer"]["mail"];
	  }
	}
	 
	$cusAddressDiv = '
	  <div class="row puffer left">
	    <div class="col">'
		  . $address .
	   '</div>
	  </div>';
	
	// subject div
	$orderDate  = date("d.m.Y");
	$subjectDiv = '
	  <div class="row puffer left">
	    <div class="col">
	      <strong>Ihre Auftragsbestellung vom ' . $orderDate . '</strong>
		</div>
	  </div>
	';
	
	// salutation div
	$salutationDiv = '
	  <div class="row puffer left">
	    <div class="col">' . $name . '</div>
	  </div>';
	
	// intro text div
	$introTxtDiv = '
	  <div class="row puffer left">
	    <div class="col">
		  vielen Dank für Ihre Bestellung vom ' . $orderDate . '. Wir freuen uns über Ihren Auftrag. 
		  Die Details entnehmen Sie bitte der folgenden Übersicht:
		</div>
	  </div>
	  <hr>';
	
	// personal customer data div
	$adressData = '
	  <div class="row puffer left">
	    <div class="col"><strong>Anschrift</strong></div>
		<div class="col">' . $address . '</div>
	  </div>
	  <hr>';

	$birthDateData = '
	    <div class="row puffer left">
	      <div class="col"><strong>Geburtsdatum</strong></div>
	      <div class="col">' . date_format($birthDate,"d.m.Y") . '</div>
	    </div>';
	
	$phoneData = '
	  <div class="row puffer left">
	    <div class="col"><strong>Telefon</strong></div>
	    <div class="col">' . $phone . '</div>
	  </div>';
	  
	$mobilData = '
        <div class="row puffer left">
	      <div class="col"><strong>Mobil</strong></div>
		  <div class="col">' . $mobil . '</div>
	    </div>
	  ';
	  
	$eMailData = '
	  <div class="row puffer left">
	    <div class="col"><strong>E-Mail</strong></div>
		<div class="col">' . $mail . '</div>
	  </div>';
	
	$html = $topDiv
	      . $ownAddressDiv
		  . $cusAddressDiv
		  . $subjectDiv
		  . $salutationDiv
		  . $introTxtDiv
		  . $adressData
		  . $birthDateData;
	
	if ($psTae != "") {
	  $html .= '<hr><div class="row puffer left">
	      <div class="col"><strong>Hauseingang/ Wohnung</strong></div>
	      <div class="col">' . $psTae . '</div>
	    </div><hr>'; 
	}
	
	$html .= $phoneData
	       . $mobilData
		   . $eMailData . '<hr>';
	
	$conAddress = '';
	$conTAE = '';
	if (array_key_exists("techAddress", $infos)) {
	  if (array_key_exists("isDiffAddress", $infos["techAddress"]) && $infos["techAddress"]["isDiffAddress"]) {
		if (array_key_exists("street", $infos["techAddress"]) && array_key_exists("hnr", $infos["techAddress"])) {
		  $conAddress = $infos["techAddress"]["street"] . ' ' . $infos["techAddress"]["hnr"] . '<br>';
		}
		
		if (array_key_exists("zipcode", $infos["techAddress"]) && array_key_exists("place", $infos["techAddress"])) {
		  $conAddress .= $infos["techAddress"]["zipcode"] . ' ' . $infos["techAddress"]["place"] . '<br>';
		}
		
		if (array_key_exists("district", $infos["techAddress"]) && $infos["techAddress"]["district"] != "") {
		  $conAddress .= 'Ortsteil: ' . $infos["techAddress"]["district"] . '<br>';
		}
		
		if (array_key_exists("conTae", $infos["techAddress"]) && $infos["techAddress"]["conTae"] != "") {
		  $conTAE = $infos["techAddress"]["conTae"];
		}
	  }
	}
	
	$pdConAddressDiv = "";
	if ($conAddress != "") {
	  $pdConAddressDiv = '
	    <div class="row puffer left">
	      <div class="col"><strong>Anschlussadresse</strong></div>
		  <div class="col">' . $conAddress . '  </div>
		</div><hr>';
	}
	
	if ($conTAE != "") {
	  $pdConAddressDiv .= '
	    <div class="row puffer left">
	      <div class="col"><strong>Hauseingang / Wohnung</strong></div>
		  <div class="col">' . $conTAE . '  </div>
		</div><hr>';
	}
	
	// rate data
	$card = '';
	if (array_key_exists("rateId", $infos)) {
	  require_once __DIR__ . "/model/tariff_queries.php";
	  require_once __DIR__ . "/views/rates/forms/rate_card.php";
	  
	  $tariffQueries = new TariffQueries();
      $tariffData    = $tariffQueries->getRateById($infos["rateId"]);
	  
	  $rateCard = new RateCard($tariffData[0]);
	  $card     = $rateCard->getRateCard(false);
	}
	
	// options
	$optionsDiv = '';
	if (array_key_exists("options", $infos)) {
	  require_once __DIR__ . "/model/tariff_options.php";
	  $options = new TariffOptionsQueries();
		
	  if (array_key_exists("ipAddress", $infos["options"]) && $infos["options"]["ipAddress"] > -1) {
		$opData = $options->getOptionsById($infos["options"]["ipAddress"]);
		
		$optionsDiv .= '<div class="row puffer left">
		  <div class="col"><strong>' . $opData[0]["name"] . '</strong></div>
		  <div class="col price">' . number_format($opData[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		</div>';
	  }
	  
	  $portingPhoneNr = '';
	  if (array_key_exists("phoneDefault", $infos["options"]) && $infos["options"]["phoneDefault"] > -1) {
		if (array_key_exists("cntAddSIP", $infos["options"]) && $infos["options"]["cntAddSIP"] > 0) {
		  $opData = $options->getOptionsById(5);
		  
		  $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>' . $opData[0]["name"] . '</strong></div>
		    <div class="col price">' . $infos["options"]["cntAddSIP"] . ' x ' . number_format($opData[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		  </div>';
		}  
		
		if (array_key_exists("cntAllnet", $infos["options"]) && $infos["options"]["cntAllnet"] > 0) {
		  $opData = $options->getOptionsById(6);
		  
		  $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>' . $opData[0]["name"] . '</strong></div>
		    <div class="col price">' . $infos["options"]["cntAllnet"] . ' x ' . number_format($opData[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		  </div>';
		}
	  }
		
	  if (array_key_exists("lineFee", $infos["options"])) {
		  $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>Leitungsgebühr</strong></div>
		    <div class="col price"> 4,00 € pro Monat</div>
		  </div>';
	  }
		
	  if (array_key_exists("deployPrice", $infos["options"])) {
		  $optionsDiv .= '<div class="row puffer left">
		    <div class="col">
			  <strong>Bereitstellungspreis Tarif/Anschluss</strong><br>
			  <span class="smFont">(inkl. Techniker für Router/ Telefonie)</span>
			</div>
		    <div class="col price">75,00 € einmalig</div>
		  </div>';
	  }
		
	  if (array_key_exists("serviceComfort", $infos["options"]) && $infos["options"]["serviceComfort"] > 0) {  
		require_once __DIR__ . "/model/service_queries.php";
		$serviceQueries = new ServiceQueries();
		$serviceData = $serviceQueries->getServiceById($infos["options"]["serviceComfort"]);
		
        $optionsDiv .= '<div class="row puffer left">
		    <div class="col">
			  <strong>' . $serviceData[0]["name"] . '</strong><br>
			  <span class="smFont">(' . $serviceData[0]["note"] . ')</span>
			</div>
		    <div class="col price">' . number_format($serviceData[0]["price"], 2, ',', ' ') . ' € einmalig</div>
		  </div>';
	  }
		
	  if (array_key_exists("tvOption", $infos["options"]) && $infos["options"]["tvOption"] > 0) {
			
	  }
		
	  if (array_key_exists("hardware", $infos["options"])) {
		require_once __DIR__ . "/model/hardware_queries.php";
        $hardwareQueries = new HardwareQueries();
        
		if (array_key_exists("hw-2", $infos["options"]["hardware"])) {
		  $hw = $hardwareQueries->getHardwareById($infos["options"]["hardware"]["hw-2"]);
		  
          $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>' . $hw[0]["name"] . '</strong></div>
		    <div class="col price">' . number_format($hw[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		  </div>';
		}
		
		if (array_key_exists("hw-3", $infos["options"]["hardware"])) {
		  $hw = $hardwareQueries->getHardwareById($infos["options"]["hardware"]["hw-3"]);
		  
          $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>' . $hw[0]["name"] . '</strong></div>
		    <div class="col price">' . number_format($hw[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		  </div>';
		}
	  }
	  
	  if (array_key_exists("selTech", $infos) && $infos["selTech"] > 0) {
		if ($infos["selTech"] == 2) {
          $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>UFiber Loco GPON</strong></div>
		    <div class="col price">0,00 € pro Monat</div>
		  </div>';
		} else if ($infos["selTech"] == 5) {
          $optionsDiv .= '<div class="row puffer left">
		    <div class="col"><strong>Funkempfänger</strong></div>
		    <div class="col price">0,00 € pro Monat</div>
		  </div>';
		}
	  }
	}
	
	// wish termin div
	$wishTermin = '';
	if (array_key_exists("wishTermin", $infos) && $infos['wishTermin'] != "") {
	  $wishData = date_create($infos['wishTermin']);

      $wishTermin = '
	    <div class="row puffer left">
		  <div class="col"><strong>gewünschter Vertrags- und Leistungsbeginn</strong></div>
		  <div class="col">' . date_format($wishData, "d.m.Y") . '</div>
		</div><hr>';	  
	}
	
	// contract term div
	$pdContractTermDiv = '';
	if (array_key_exists("duration", $infos)) {
	  require_once __DIR__ . "/model/contract_term_queries.php";
	  $contractTermQueries = new ContractTermQueries();
	  $conTerm = $contractTermQueries->getTermsPKById($infos["duration"]);
	  
	  $conTermStr = $conTerm[0]["duration"] . ' Monate';
	  
	  //if ($data[0]["term_option"] != "") {
		//$conTermStr .= ' (' . $data[0]["term_option"] . ')'; 
	  //}
	  
	  $pdContractTermDiv = '
	    <div class="row puffer left">
		  <div class="col"><strong>Vertragslaufzeit</strong></div>
		  <div class="col">min. ' . $conTermStr . '</div>
		</div>';
	}
	
	// sepa data
	$sepa = '';
	if (array_key_exists("sepaData", $infos)) {
	  if (array_key_exists("name", $infos["sepaData"])) {
		$sepa = $infos["sepaData"]["name"] . '<br>';
	  }
	  
	  if (array_key_exists("street", $infos["sepaData"]) && array_key_exists("hnr", $infos["sepaData"])) {
		$sepa .= $infos["sepaData"]["street"] . " " . $infos["sepaData"]["hnr"] . '<br>';
	  }
	  
	  if (array_key_exists("zipcode", $infos["sepaData"]) && array_key_exists("place", $infos["sepaData"])) {
		$sepa .= $infos["sepaData"]["zipcode"] . " " . $infos["sepaData"]["place"] . '<br>';
	  }
	  
	  if (array_key_exists("district", $infos["sepaData"]) && $infos["sepaData"]["district"] != "") {
		$sepa .= 'Ortsteil: ' . $infos["sepaData"]["district"] . '<br>'; 
	  }
	  
	  if (array_key_exists("country", $infos["sepaData"]) && $infos["sepaData"]["country"] != "") {
		$sepa .= $infos["sepaData"]["country"] . '<br>';  
	  }
	  
	  if (array_key_exists("iban", $infos["sepaData"])) {
		$sepa .= '<br>' . $infos["sepaData"]["iban"] . '<br>';
	  }

	  if (array_key_exists("bic", $infos["sepaData"])) {
		$sepa .= $infos["sepaData"]["bic"] . '<br>';  
	  }
	}
	
	$sepaDiv = '
	  <div class="row puffer left">
	    <div class="col"><strong>Konto</strong></div>
	    <div class="col">' . $sepa . '</div>
	  </div>';
	
	// send bill with post
	$invoicePostDiv = '';
	if (array_key_exists("invoicePost", $infos) && $infos["invoicePost"] > 0) {
	  require_once __DIR__ . "/model/numerically_queries.php";
	  $numQueries = new NumericallyQueries();
	  $numData    = $numQueries->getNumericallyById($infos["invoicePost"]);
	  
	  $invoicePostDiv = '
	    <div class="row puffer left">
		  <div class="col"><strong>Rechnungsversand per Post</strong></div>
		  <div class="col price">' . number_format($numData[0]["price"], 2, ',', ' ') . ' € pro Monat</div>
		</div><hr>';
	}
	
	// allowed confirm div
	$allowedConfirmDiv = '
		<div class="row puffer">
		  <div class="col center">Zustimmung zur Weiterverarbeitung Ihrer Daten liegt vor.</div>
		</div>
		
		<div class="row puffer">
		  <div class="col center">Zustimmung zu den AGB liegt vor.</div>
		</div>';
	
	// finsh text div
	$finshTxtDiv = '
	  <div class="row puffer left">
	    <div class="col">
		  Sie haben noch Fragen? Sie erreichen uns von Montag bis Freitag von 8.00 Uhr bis 17.00 Uhr 
		  unter (034954) 524 66 oder per E-Mail <a href="mailto:info@brehna.net">info@brehna.net</a>.
		  <br><br>
		  Wir freuen uns auf die Zusammenarbeit!
		  <br><br>
		  Mit freundlichen Grüßen
		  <br>
		</div>
	  </div>
	  <hr>';
	  
	// footer div
	$footerDiv = '
	  <div class="row puffer left">
	    <div class="col">
	      <img src="https://neu.brehna.net/auftrag/public/images/bnet-website-logo.png" class="logo2" 
		       alt="logo brehna.net">
		</div>
	  
	    <div class="col smFont">
		  Inhaber: Niels Rosenhahn<br>
		  Max-Planck-Straße 2<br>
		  06796 Sandersdorf-Brehna<br>
		  Ortsteil: Brehna<br>
		</div>
		
		<div class="col smFont">
		  Telefon: <br>(034954) 524-66<br>
		  Fax: <br>(034954) 524-67<br>
		  Web: <br>www.brehna.net<br>
		  E-Mail: <br>info@brehna.net<br>
		</div>
		
		<div class="col smFont">
		  Technischer Notdienst:<br>
		  (034954) 524-68<br>
		  Umsatzsteuer-ID:<br>
		  DE234728145<br>
		</div>
	  </div>';
	  
	$html .= $pdConAddressDiv
	       . $card              . '<hr>'
		   . $optionsDiv        . '<hr>'
		   . $wishTermin
		   . $pdContractTermDiv . '<hr>'
		   . $sepaDiv           . '<hr>'
		   . $invoicePostDiv
	       . $allowedConfirmDiv . '<hr>'
	       . $finshTxtDiv
		   . $footerDiv;
	  
	$content = array(
	  "step7content" => $html
	);
	
	echo json_encode($content);
  }
?>