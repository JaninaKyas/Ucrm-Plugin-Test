CREATE TABLE IF NOT EXISTS `tariff_x_technology` (
  `id`            INT(11)  UNSIGNED NOT NULL AUTO_INCREMENT,
  `tariff_id`     INT(11)  UNSIGNED NOT NULL,
  `technology_id` INT(11)  UNSIGNED NOT NULL,
  `createDate`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`    CHAR(50)          NOT NULL DEFAULT '',
  `updateDate`    DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`    CHAR(50)          NOT NULL DEFAULT '',
  `isDeleted`     TINYINT(1)        NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (tariff_id)     REFERENCES `tariff`(id),
  FOREIGN KEY (technology_id) REFERENCES `technology`(id)
) ENGINE=INNODB;

INSERT INTO `tariff_x_technology` VALUES(null, 1, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 1, 2, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 1, 4, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 2, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 2, 2, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 2, 4, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 3, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 3, 2, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 3, 4, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 4, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 4, 2, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 5, 4, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 5, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 6, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_x_technology` VALUES(null, 7, 1, NOW(), 'JANINA', NOW(), 'JANINA', 0);