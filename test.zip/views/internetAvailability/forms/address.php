<?php
  declare(strict_types = 1);

  class Address {
    public $street;
	public $houseNr;
	public $zipcode;
	public $place;
	public $district;
	public $country;
	public $appNr;
	public $showConType;
	  
	function __construct(string $sStreet, string $sHousNr, string $sZipcode, string $sPlace, string  $sDistrict = '', string $sCountry = '', string $sAppNr = '', bool $sShowConType = false) {
	  $this->street      = $sStreet;
	  $this->houseNr     = $sHousNr;
	  $this->zipcode     = $sZipcode;
	  $this->place       = $sPlace;
	  $this->district    = $sDistrict;
	  $this->country     = $sCountry;
	  $this->appNr       = $sAppNr;
	  $this->showConType = $sShowConType;
	}
	  
    public function getTemplate() {
	  $returnValue = '
	    <div class="row">
		  <div class="col left">
		    Ermitteln Sie mit unserer Verfügbarkeitsprüfung, welche Geschwindigkeiten an Ihrer Adresse möglich sind. Auf Grundlage dieser Daten können wir Ihnen den passenden Tarif anbieten.
		  </div>
		</div>
	  
	    <div class="addressBlock">
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Strasse*</label>
			  <input id="'  . $this->street . '" name="' . $this->street . '" type="text" class="form-control required">
			</div>

			<div class="col">
			  <label class="addressLabel">Hausnummer*</label>
			  <input id="'  . $this->houseNr . '" name="' . $this->houseNr . '" type="text" class="form-control required">
			</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Postleitzahl*</label>
			  <input id="'  . $this->zipcode . '" name="' . $this->zipcode . '" type="text" class="form-control required">
			</div>
			
			<div class="col">
			  <label class="addressLabel">Ort*</label>
			  <input id="'  . $this->place . '" name ="' . $this->place . '" type="text" class="form-control required">
			</div>
		  </div>
		  
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Ortsteil</label>
			  <input id="'  . $this->district . '" name="'  . $this->district . '" type="text" class="form-control">
			</div>';

      if (!empty($this->appNr) && $this->appNr != "") {
	    $returnValue .= '
		  <div class="col">
			<label class="addressLabel">Hauseingang / Wohnung</label>
			<input id="'  . $this->appNr . '" name="'  . $this->appNr . '" type="text" class="form-control">
			</div>
		  </div>
	  ';
	  }
		
	  if (!empty($this->country) && $this->country != "") {
	    $returnValue .= '
		  <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Land*</label>
			  <input id="'  . $this->country . '" name="' . $this->country . '" type="text" class="form-control required1">
			</div>
		  </div>
		';
	  }
		
	  if ($this->showConType) {
	    $returnValue .= '	
	      <div class="row">
		    <div class="col inpCheckLabel">
		      Bei dem gewünschten Anschluss handelt es sich um einen*
			</div>
		  </div>
		
		  <div class="row">  
		    <div class="col inpCheck">
		      <input type="radio" class="required2" name="conKind" value="1" onClick="displayContent(2)"> 
			  <span>Neuanschluss</span>
		    </div>
		  
		    <div class="col inpCheck">
		      <input type="radio" class="required2" name="conKind" value="2" onClick="displayContent(1)"> 
			  <span>Wechsel von einem anderen Anbieter</span>
		    </div>
		  </div>
 
          <div id="divOldCon">
		    <div class="row">
		      <div class="col inpCheckLabel">
			    Über welche Technoloie wurde der bestehende Anschluss an dieser Adresse versorgt:
			  </div>
		    </div>
		  
		    <div class="row">		  				  
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="2"> Glasfaser
			  </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="3"> VDSL
			  </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="5"> Funk
              </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="-1"> weiß ich nicht
              </div>
		    </div>
		  </div>
		  
		  <div id="divNewCon">
		    <div class="row">
			  <div class="col inpCheckLabel">
			    Gewünschte Anschlussart:
			  </div>
			</div>
			
		    <div class="row">		  				  
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="2"> Glasfaser
			  </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="3"> VDSL
			  </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="5"> Funk
              </div>
			
			  <div class="col inpCheck">
			    <input type="radio" name="checkConTech" value="-1"> keine Angabe
              </div>
		    </div>
		  </div>
		';
	  }
		
	  $returnValue .= '</div>';
		
	  return $returnValue;
	}
  }
?>