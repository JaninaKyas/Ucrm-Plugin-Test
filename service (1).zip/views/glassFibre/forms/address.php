<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();
	public $disabled     = 'disabled';

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array(), 
							    $disabled = 'disabled') {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
	  $this->disabled     = $disabled;
	}
	  
	public function buildAddressTemplate(): string {		
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   value="' . $this->values["street"] . '" ' . $this->disabled . '>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   value="' . $this->values["hNr"] . '" ' . $this->disabled . '>
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   value="' . $this->values["zipcode"] . '" ' . $this->disabled . '>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   value="' . $this->values["place"] . '" ' . $this->disabled . '>
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   value="' . $this->values["district"] . '" ' . $this->disabled . '>
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
	  
    public function buildTechAddressTemplate(): string {
	  $returnValue = '
	    <div class="row">
		  <div class="col">
		    <span class="fontTitle">
			  <input id="'   . $this->templateData[6] . '"
			         name="' . $this->templateData[6] . '"
					 type="checkbox"
					 onClick="displayTechAddress()">
			  Anschlussadresse (Angabe nur wenn abweichend von Postanschrift)
			</span>
		  </div>
		</div>
		
	    <span id="techAddress">
          <div class="row puffer">
		    <div class="col">
		      <label class="addressLabel">Strasse*</label>
		      <input type="text"
			         id="'   . $this->templateData[0] . '"
			  	     name="' . $this->templateData[0] . '"
				     class="form-control requiredF"
					 value="' . $this->techAddress["street"] . '">
		    </div>
		  
		    <div class="col">
		      <label class="addressLabel">Hausnummer*</label>
		      <input type="text"
			         id="'   . $this->templateData[1] . '"
			  	     name="' . $this->templateData[1] . '"
				     class="form-control requiredF"
					 value="' . $this->techAddress["hNr"] . '"
					 onkeypress="return /[0-9a-zA-Z]/.test(event.key)"
					 onpaste="return false">
		    </div>
		  </div>
		
		  <div class="row puffer">
		    <div class="col">
		      <label class="addressLabel">Postleitzahl*</label>
		      <input type="text"
			         id="'   . $this->templateData[2] . '"
			  	     name="' . $this->templateData[2] . '"
				     class="form-control requiredF"
					 value="' . $this->techAddress["zipcode"] . '"
					 onkeypress="return /[0-9]/.test(event.key)"
					 onpaste="return false">
		    </div>
		  
		    <div class="col">
		      <label class="addressLabel">Ort*</label>
		      <input type="text"
			         id="'   . $this->templateData[3] . '"
			  	     name="' . $this->templateData[3] . '"
				     class="form-control requiredF"
					 value="' . $this->techAddress["place"] . '">
		    </div>
		  
		    <div class="col">
		      <label class="addressLabel">Ortsteil</label>
		      <input type="text"
			         id="'   . $this->templateData[4] . '"
			  	     name="' . $this->templateData[4] . '"
				     class="form-control"
					 value="' . $this->techAddress["district"] . '">
		    </div>
		  </div>
	    </span>
	  ';
		
	  return $returnValue;
	}
  }
?>