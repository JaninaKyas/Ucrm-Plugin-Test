<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	  
	require_once __DIR__ . "/views/connectionRequest/connection_request_care.php";
	$request = new ConnectionRequestCare(array());
	  
	$content = array(
	  "step7content" => $request->buildMessageBoxWithAGBTemplate()
	);

	echo json_encode($content);
  } 
?>