<?php
  declare(strict_types = 1);

  require __DIR__ . "/forms/porting_phone_number.php";

  class PrivateCustomerOptions {
	public $templateData  = array();
	public $optionsValues = array();
	public $optionsString = '';
  
	public function __construct($newTemplateData, $newOptionsValues, $newOptionsString) {
	  $this->templateData  = $newTemplateData;
	  $this->optionsValues = $newOptionsValues;
	  $this->optionsString = $newOptionsString;
	}
	
	public function buildOptionsPKTemplate(): string {
	  return '<div class="fontTitle">Optionen</div>
	    <div class="rateOptionsBlock">'
        . $this->buildIPAddressChoiceTemplate() . '<hr>'
		. $this->buildPhoneDefaultTemplate()    . '<hr>' .
		'</div>
	  ';
	}
	  
	private function buildIPAddressChoiceTemplate(): string {
	  return '<div class="row puffer">
            <div class="col">
			  <label class="addressLabel">
			    Wählen Sie für Ihre IP-Adresse eine zusätzliche Option aus:
			  </label>
			</div>
          </div>
		  
		  <div class="row left">
		    <div class="col">
              <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][0] . '"
					 name="' . $this->templateData["ipAddress"][0] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[0]['id'] . '">
			  <span>' . $this->optionsValues[0]['name'] . '</span>
			  <br>
			  <input type="checkbox"
			         class="form-check-input"
					 id="' . $this->templateData["ipAddress"][1] . '"
					 name="' . $this->templateData["ipAddress"][1] . '"
					 onclick="chooseIPAddressOption()"
					 value="' . $this->optionsValues[1]['id'] . '">
			  <span>' . $this->optionsValues[1]['name'] . '</span>
			</div>
			
			<div class="col price">
			  <span>'
		      . number_format(floatval($this->optionsValues[0]['price']), 2, ',', ' ')
		      . ' pro Monat</span>
			  <br>
              <span>'
		      . number_format(floatval($this->optionsValues[1]['price']), 2, ',', ' ')
		      . ' pro Monat</span>
			</div>
		  </div>';
	}
	  
	private function buildPhoneDefaultTemplate(): string {		
	  return '<div class="row puffer left">
	    <div class="col">
		  <input type="checkbox"
		         class="form-check-input"
				 id="' . $this->templateData["ipAddress"][2] . '"
				 name="' . $this->templateData["ipAddress"][2] . '"
				 value="' . $this->optionsValues[2]['id'] . '">
		  <span class="addressLabel">' . $this->optionsValues[2]['name'] . '</span>
		  <br>
		  <span class="smFont">(' . $this->optionsValues[2]['note'] . ')</span>
		</div>
		
		<div class="col addressLabel price">
		  <span>'
		  . number_format(floatval($this->optionsValues[2]["price"]), 2, ',', ' ')
		  . ' pro Monat</span>
		</div>
		
		<div class="borderBoxSub">' . $this->buildSubMenuPhoneTemplate() . '</div>
	  </div>';
	}
	  
	private function buildSubMenuPhoneTemplate(): string {
	  return '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel2 smFont">' . $this->optionsValues[3]['name'] . '</label>
			<br>
		    <input type="text"
			       id="' . $this->templateData["ipAddress"][3] . '"
				   name="' . $this->templateData["ipAddress"][3] . '">
		  </div>
		  
		  <div class="col price"> je '
		  . number_format(floatval($this->optionsValues[3]["price"]), 2, ',', ' ')
		  . ' pro Monat</span>
		  </div>
		</div>
		
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel2 smFont">'
		      . $this->optionsValues[4]['name'] 
		      . ' (' . $this->optionsValues[4]['note']
		      . ')</label>
						<br>
		    <input type="text"
			       id="' . $this->templateData["ipAddress"][4] . '"
				   name="' . $this->templateData["ipAddress"][4] . '">
		  </div>
		  <div class="col price"> je '
		  . number_format(floatval($this->optionsValues[4]["price"]), 2, ',', ' ')
		  . ' pro Monat</span>
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <input type="checkbox"
		           class="form-check-input"
			  	   id="' . $this->templateData["ipAddress"][5] . '"
				   name="' . $this->templateData["ipAddress"][5] . '"
				   value="' . $this->optionsValues[7]['id'] . '">
		    <span class="addressLabel smFont">' . $this->optionsValues[7]['name'] . '</span>
		  </div>
		</div>
		
		<div class="row">
		  <div class="col">' . $this->buildPortingPhoneNumberTemplate() . '</div>
		</div>
	  ';
	}
	  
	private function buildPortingPhoneNumberTemplate(): string {
	  $portingPhone = new PortingPhoneNumber($this->templateData["phPorting"]);
      return $portingPhone->buildPortingPhoneNumberTemplate();
	}
  }
?>