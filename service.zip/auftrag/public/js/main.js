let data                 = {};
let displayAddress       = {};
let defaultAddress       = {};
let technologyAddress    = {};
let technologyOldAddress = {};

var isFormConRequest     = false;
var isValidConRequest    = true;
var isDisplayDiffAddress = false;
var isSameTechAddress    = false;

var choosenRateId        = 0;
var choosenPath          = -1;

var errorMsg             = document.getElementById("asbErrorMsg");

const navigateToFormStep = (stepNumber) => {	
  document.querySelectorAll(".form-step").forEach((formStepElement) => {
    formStepElement.classList.add("d-none");
  });

  document.querySelectorAll(".form-stepper-list").forEach((formStepHeader) => {
    formStepHeader.classList.add("form-stepper-unfinished");
    formStepHeader.classList.remove("form-stepper-active", "form-stepper-completed");
  });

  document.querySelector("#step-" + stepNumber).classList.remove("d-none");
  const formStepCircle = document.querySelector('li[step="' + stepNumber + '"]');

  formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-completed");
  formStepCircle.classList.add("form-stepper-active");

  for (let index = 0; index < stepNumber; index++) {
    const formStepCircle = document.querySelector('li[step="' + index + '"]');

    if (formStepCircle) {
      formStepCircle.classList.remove("form-stepper-unfinished", "form-stepper-active");
      formStepCircle.classList.add("form-stepper-completed");
    }
  }
};

document.querySelectorAll(".btn-navigate-form-step").forEach((formNavigationBtn) => {	
  formNavigationBtn.addEventListener("click", () => {
    const stepNumber    = parseInt(formNavigationBtn.getAttribute("step_number"));
	const stepDirection = parseInt(formNavigationBtn.getAttribute("step_direction"));
	const elementId     = formNavigationBtn.getAttribute("id");
	var   canChangeStep = true;
	
	// stepDirection === 1 -- forward; stepDirection === -1 -- backward
	if (stepDirection === 1) {
	  // step == 2
	  if (stepNumber === 2) {
	    canChangeStep = validateAvailibityForm();

        if (canChangeStep) {
		  executeAvailabilitySearch();
	    }
	  }
		
	  if (canChangeStep && stepNumber === 3) {		  
	    canChangeStep = isValidConRequest;
		  
        var cusError = document.getElementById("cusError");
        if (cusError != null && cusError != undefine) {
	      cusError.style.display = "none";
        }
	  }
		
	  if (canChangeStep && stepNumber === 4) {		  
		if (choosenPath == 1) {
          canChangeStep = validateCustomerData();
		  executeContractPK();
	    } else if (choosenPath == 2) {
		  // TO-DO	   
		} else {
		  // TO-DO
		}  
	  }
	} else {
	  if (stepNumber === 2) {
		var cusError = document.getElementById("cusError");
		if (cusError != null) {
		  cusError.style.display = "none";
		}  
	  }
	  
      resetRequiredFields();
	}
	
	if (canChangeStep) {
      navigateToFormStep(stepNumber);
	}
  });
});

function resetRequiredFields() {
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");
	
  for (i = 0; i < requiredInputs.length; i++) {
	requiredInputs[i].classList.remove("invalid");
  }
		  
  for (j = 0; j < requiredRadio.length; j++) {
	requiredRadio[j].parentNode.children[1].style.color = "#444";
  }
	
  errorMsg.style.display = "none";
	
  //technologyAddress = defaultAddress;
}

function validateAvailibityForm() {	
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control required");
  var requiredRadio  = document.getElementsByClassName("required2");

  for (i = 0; i < requiredInputs.length; i++) { 
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  for (j = 0; j < requiredRadio.length; j++) {
	if (requiredRadio[j].checked) {
	  returnValue = true;
	  break;
	} else {
	  requiredRadio[j].className += " invalid";
	  returnValue = false; 
	}
  }

  if (!returnValue) {
	errorMsg.classList.remove("d-none");
	errorMsg.style.display = "block";
  }

  return returnValue;
}

function validateConRequest() {
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control requiredAA");
	
  for (i = 0;i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }
	
  if (!returnValue) {
	document.getElementById("cusError").style.display = "block";  
  }

  return returnValue;
}

function validateCustomerData() {	
  var returnValue    = true;
  var requiredInputs = document.getElementsByClassName("form-control requiredRC");
	
  for (i = 0;i < requiredInputs.length; i++) {
    if (requiredInputs[i].value == null
	 || requiredInputs[i].value == ""
	 || requiredInputs[i].value.length == 0) {
	  if (returnValue) {
		returnValue = false; 
	  }

	  requiredInputs[i].className += " invalid";
	}
  }

  var cusError2 = document.getElementById("cusError2");
  if (cusError2 != null && !returnValue) {
	cusError2.style.display = "block";
  }
	
  return returnValue;
}

async function executeAvailabilitySearch(type = 1) {	
  var url           = "https://neu.brehna.net/auftrag/rates.php";
  var checkedBoxes  = document.querySelectorAll('input[name=checkConTech]:checked');
  var conKind       = document.querySelectorAll('input[name=conKind]:checked');
  var step2Lable    = document.getElementById("step2Lable");
  var step3Lable    = document.getElementById("step3Lable");
	
  technologyOldAddress = technologyAddress;
	
  if (type == 1) {	  
	defaultAddress = {
	  "street"   : document.getElementById("asbStreet").value,
	  "hNr"      : document.getElementById("asbHNr").value,
      "zipcode"  : document.getElementById("asbPlz").value,
	  "place"    : document.getElementById("asbPlace").value,
      "district" : document.getElementById("asbDistrict").value
    }
  } else {	  
	technologyAddress = {
	  "street"   : document.getElementById("caStreet").value,
	  "hNr"      : document.getElementById("caHNr").value,
      "zipcode"  : document.getElementById("caZipcode").value,
	  "place"    : document.getElementById("caPlace").value,
      "district" : document.getElementById("caDistrict").value
    }
  }
  
  data = {
    "defaultAddress"    : defaultAddress,
	"technologyAddress" : technologyAddress,
	"conKind"           : conKind[0].value,
	"selTech"           : checkedBoxes[0].value,
	"oldTechAddress"    : technologyOldAddress
  }
	
  displayAddress = data["defaultAddress"];
  displayAddress["technologyAddress"] = technologyAddress;
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(data)
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	  // display button "Weiter"
	  document.getElementById("disForward").style.display   = response["displayForward"];
	  // display button "Zurück" (bottom button)
	  document.getElementById("backBtnStep2").style.display = response["backBtnStep2"]
	  
	  choosenPath = response["ident"];
	  
	  console.log(response);
	  
	  switch(response["ident"]) {
	    case 1:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
	      displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;

		  break;
	    case 2:
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);

		  document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "block";
		  document.getElementById("btnLable3").style.display = "none";
		  document.getElementById("btnLable4").style.display = "block";

		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Kundendaten");
			  
		  isFormConRequest = false;
			  
		  break;
	    case 3:  
		  removeChildren(step2Lable);
		  setStepProgressbarLable(step2Lable, response["step2Lable"]);
		  displayStep2Content(response["step2"]);
		
	      document.getElementById("btnLable1").style.display = "block";
		  document.getElementById("btnLable2").style.display = "none";
		  document.getElementById("btnLable3").style.display = "block";
          document.getElementById("btnLable4").style.display = "none";
			
		  removeChildren(step3Lable);
	      setStepProgressbarLable(step3Lable, "Rückruf");
			  
		  isFormConRequest = true;
		  document.getElementById("cusError").style.display = "none";
			  
		  break;
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function loadStep3Content(elementId) {	
  var stepLabel  = document.getElementById("step2Lable").innerText;
  var step3      = document.getElementById("step3Result");
  var url        = '';
	
  let params = {
    "method": "POST",
    "headers": {
	  "Content-Type": "application/json; charset=utf-8"
    },
    "body": JSON.stringify(displayAddress)
  }
	
  if (stepLabel == 'Tarife') {
    // path to "Auftragsbestellung"
    url = "https://neu.brehna.net/auftrag/rates_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'disForward') {
    // path to "Glasfaserhausanschluss"
    url = "https://neu.brehna.net/auftrag/glass_fibre_customer.php";
  } else if (stepLabel == 'Ergebnis' && elementId == 'conAS') {
    // path to "Anschlussanfrage"
	url = "https://neu.brehna.net/auftrag/connection_request_customer.php";
  } else {
	// path to "Anschlussanfrage" -- recall
    url      = "https://neu.brehna.net/auftrag/recall.php";
  }
	
  try {
    var response = await fetch(url, params)
	  .then(function(response) {
	    return response.json();
	  })
	  .catch((error) => {
	    console.log(error)
	  });
	  
	if (response) {		
      // remove all children from parent
	  removeChildren(step3);
	  // display form
	  setStepProgressbarLable(step3, response["step3"]);

	  // display 
	  if ("displayTechAddress" in response) {
	    document.getElementById("techAddress").style.display = response["displayTechAddress"];
	  }
		
	  if ("checkTechAddress" in response) {
		document.getElementById("caDiffAddress").checked = response["checkTechAddress"];
	  }
		
	  // display page without error message when loading it for the first time
	  var cusError = document.getElementById("cusError");
	  if (cusError != null) {
		cusError.style.display = "none";
	  }
		
	  var cusError2 = document.getElementById("cusError2");
	  if (cusError2 != null) {
		cusError2.style.display = "none";
	  }
	}
  } catch {
    console.error('Promise rejected');
  }
}

async function executeContractPK() {
  var resultStep2 = document.getElementById("ratesResult"); 
  var stepLabel   = document.getElementById("step4Lable");
  var step4       = document.getElementById("step4Result");
  var url         = '';	

  if (isDisplayDiffAddress) {
	// remove old content
	removeChildren(resultStep2);
	  
	// performed new search and replaced old content from step 2
	await executeAvailabilitySearch(2);
	  
	// go back to step 2
	navigateToFormStep(2);
  }
}

function displayStep2Content(content) {	
  var step = document.getElementById("ratesResult");

  // remove children from parent element
  removeChildren(step);

  // inserts elements inside the element, before its first child
  setStepProgressbarLable(step, content);
}

function removeChildren(parent) {
  while(parent.hasChildNodes()) {
	parent.removeChild(parent.lastChild);
  }
}

function setStepProgressbarLable(parent, child) {
  parent.insertAdjacentHTML('afterbegin', child);
}

function forwardStep3(lable = "disForward") {	
  var isValid = validateConRequest();
  var errMsg  = document.getElementById("cusError2");
	
  if (errMsg != null) {
	errMsg.style.display = "none";
  }
	
  if (choosenPath == 2 || isValid) {
	navigateToFormStep(3);
    loadStep3Content(lable);	
  }
	
  if (choosenPath == 2) {
	return true; 
  }

  isValidConRequest = isValid;
	
  return isValidConRequest;
}

function backwardStep1() {
  navigateToFormStep(1);
  resetRequiredFields();
}

function displayTechAddress() {
  var isCheckedDiffAddress = document.getElementById("caDiffAddress").checked;
  document.getElementById("techAddress").style.display = "none";
	
  if (isCheckedDiffAddress) {
	document.getElementById("techAddress").style.display = "block";
  }
	
  isDisplayDiffAddress = isCheckedDiffAddress;
}

function arrays_equal(array1, array2) {
    return JSON.stringify(array1) == JSON.stringify(array2);
}