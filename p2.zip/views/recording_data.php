<?php
  if (isset($_POST) && (
       !empty($_POST['cNr']) 
    || !empty($_POST['cFirstname'])
    || !empty($_POST['cLastname'])
    || !empty($_POST['cCompany'])
    || !empty($_POST['cStreet'])
    || !empty($_POST['cHNr'])
    || !empty($_POST['cPLZ'])
    || !empty($_POST['cLocation'])
    || !empty($_POST['cOtherLoca1'])
    || !empty($_POST['cMail'])
    || !empty($_POST['cPhone'])
  )) {
    $searchParams = [
      'cNr'        => $_POST['cNr'],
      'fName'      => $_POST['cFirstname'], 
      'lName'      => $_POST['cLastname'],
      'company'    => $_POST['cCompany'],
      'street'     => $_POST['cStreet'],
      'hNr'        => $_POST['cHNr'],
      'plz'        => $_POST['cPLZ'],
      'pId'        => $_POST['cLocation'],
      'pOtherName' => $_POST['cOtherLoca1'],
      'mail'       => $_POST['cMail'],
      'phone'      => $_POST['cPhone']
    ];  
    $customTable = new CustomTable();
    $users = $customTable->getAllUserByCustomerNumber($pdo, $_POST['cNr'], $searchParams);
  }

  if (isset($_POST) && array_key_exists("loadUser", $_POST)) {
    $user = json_decode($_POST["loadUser"], true);
  }

  if (count($users) > 1) {
    require(__DIR__ . '/choose_user.php');
  } else {
    if (isset($_POST) && !array_key_exists("loadUser", $_POST)) {
      $user =(count($users) == 1)? $users[0] : []; 
    }
?>    

<h1 class="text-center fs-4" style="margin-top: 15px;">Störungsaufnahme</h1>

<form id="signUpForm" method="post">
  <?php 
    if (isset($_POST["search"]) && (empty($user) || is_null($user))) {
      require(__DIR__ . '/display_empty_message.php');
    } else if (isset($_POST["search"]) && (empty($_POST["cNr"]) || is_null($_POST["cNr"]))) {
      require(__DIR__ . '/display_no_search_params.php');
    }
  ?>
  
  <div class="form-header d-flex mb-4">
    <span class="stepIndicator">Kundendaten</span>
    <span class="stepIndicator">Störung</span>
    <span class="stepIndicator">Router</span>
    <span class="stepIndicator">Status der LED</span>
  </div>

  <div class="step">
    <div class="row">
      <div class="col-10">
        <label for="cNr" class="form-label">Kundennummer</label>
        <input type="text" class="form-control" id="cNr" name="cNr" placeholder="Kundennummer" 
       value="<?php if (!empty($user)) { echo trim($user["custom_number"]); } ?>" 
       onkeyup="enDisableButton(this)" onkeypress="return /[0-9]/.test(event.key)">                
      </div>
      <div class="col-auto">
        <button class="btn btn-primary btn-md" type="submit" id="search" name="search" value="search" style="margin-top: 40px;" disabled="true">Suche Kunde</button>
      </div>
    </div>
            
    <div class="row puffer">
      <div class="col">
        <label for="cFirstname" class="form-label">Vorname*</label>
        <input type="text" class="form-control required" id="cFirstname" name="cFirstname" placeholder="Vorname" 
       value="<?php if (!empty($user)) { echo trim($user["firstname"]); } ?>"
       onkeyup="enDisableButton(this)">               
      </div>
      <div class="col">
        <label for="cLastname" class="form-label">Nachname*</label>
        <input type="text" class="form-control required" id="cLastname" name="cLastname" placeholder="Nachname" 
       value="<?php if (!empty($user)) { echo trim($user["lastname"]); } ?>"
       onkeyup="enDisableButton(this)">               
      </div>
    </div>
            
    <div class="row puffer">
      <div class="col">
        <label for="cCompany" class="form-label">Firma (falls Meldung als Businesskunde)</label>
        <input type="text" class="form-control" id="cCompany" name="cCompany" placeholder="Firma" value="<?php if (!empty($user)) { echo trim($user["company"]); } ?>" onkeyup="enDisableButton(this)">            
      </div>
    </div>
            
    <div class="row puffer">
      <div class="col">
        <label for="cStreet" class="form-label">Strasse*</label>
        <input type="text" class="form-control required" id="cStreet" name="cStreet" placeholder="Strasse" value="<?php if (!empty($user)) { echo trim($user["street"]); } ?>" onkeyup="enDisableButton(this)">   
      </div>
      <div class="col">
        <label for="cHNr" class="form-label">Hausnummer*</label>
        <input type="text" class="form-control required" id="cHNr" name="cHNr" placeholder="Hausnummer" value="<?php if (!empty($user)) { echo trim($user["house_number"]); } ?>" onkeypress="return /[0-9a-zA-Z]/.test(event.key)"> 
      </div>
    </div>
            
    <div class="row puffer">
      <div class="col">
        <label for="cPLZ" class="form-label">Postleitzahl*</label>
        <input type="text" class="form-control required" id="cPLZ" name="cPLZ" placeholder="Postleitzahl" value="<?php if (!empty($user)) { echo trim($user["postcode"]); } ?>" onkeyup="enDisableButton(this)" onkeypress="return /[0-9]/.test(event.key)"> 
      </div>
      <div class="col">
        <label for="cLocation" class="form-label">Ort*</label>
        <select id="cLocation" name="cLocation" class="form-select" onchange="setVisibilityRow(this)">
          <option value="-1">... bitte auswählen ...</option>
          <?php                  
            foreach ($places as $place) {
              $placeName = $place["name"];
          
              if (!is_null($place["district"])) {
                $placeName = $placeName . " OT " . $place["district"]; 
              }
                      
              if (!empty($user) && $user["place"] == $place["id"]) {
                echo "<option value='" . trim($user["place"]) . "' selected>" . trim($placeName) . "</option>";
              } else {
                echo "<option value='" . trim($place["id"]) . "'>" . trim($placeName) . "</option>";
              }
            }
          ?>               
        </select>
      </div>
    </div>

    <?php if (!empty($user) && (!empty($user["other_place"]) || !is_null($user["other_place"]))) { ?>
    
    <div id="cRowOtherLoca" class="row"> 
      <div class="col"></div>
      <div class="col">
        <label for="cOtherLoca1" class="form-label">Anderer Ort*</label>
        <input type="text" class="form-control required" id="cOtherLoca1" name="cOtherLoca1" placeholder="Anderer Ort" value="<?php if (!empty($user)) { echo trim($user["other_place"]); } ?>" onkeyup="enDisableButton(this)">
      </div>
    </div>
        
    <?php } else { ?>
        
    <div id="cRowOtherLoca" class="row visibleRow"> 
      <div class="col"></div>
      <div class="col">
        <label for="cOtherLoca1" class="form-label">Anderer Ort*</label>
        <input type="text" class="form-control required" id="cOtherLoca1" name="cOtherLoca1" placeholder="Anderer Ort" value="<?php if (!empty($user)) { echo trim($user["other_place"]); } ?>" onkeyup="enDisableButton(this)">
      </div>
    </div>
        
    <?php } ?>
        
    <div class="row puffer">
      <div class="col">
        <label for="cMail" class="form-label">E-Mail*</label>
        <input type="text" class="form-control required" id="cMail" name="cMail" placeholder="E-Mail" value="<?php if (!empty($user)) { echo trim($user["email"]); } ?>" onkeyup="enDisableButton(this)">
      </div>
      <div class="col">
        <label for="cPhone" class="form-label">Telefon/Mobil*</label>
        <input type="text" class="form-control required" id="cPhone" name="cPhone" placeholder="Telefon/Mobil" value="<?php if (!empty($user)) { echo trim($user["phone"]); } ?>" onkeyup="enDisableButton(this)" onkeypress="return /[0-9+\/-]/.test(event.key)">
      </div>
    </div>
  </div>
    
  <div class="step"><?php require(__DIR__ . '/kind_of_disorder.php'); ?></div>

  <div class="step"><?php require(__DIR__ . '/router.php'); ?></div>
    
  <div class="step"></div>
    
  <!-- start previous / next buttons -->
  <div class="form-footer d-flex">
    <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
    <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
  </div>
  <!-- end previous / next buttons -->        
</form>
<script>
  var currentTab = 0; // Current tab is set to be the first tab (0)
  var interferenceKind = 0; // 1 - Telefon, 2 - Internet
  var routerKind = 0; // 1 - Fritzbox, 2 - Lancom
  showTab(currentTab); // Display the current tab
        
  function showTab(n) {
    // This function will display the specified tab of the form...
    var x = document.getElementsByClassName("step");
    x[n].style.display = "block";
        
    //... and fix the Previous/Next buttons:
    if (n == 0) {
      document.getElementById("prevBtn").style.display = "none";
    } else {
      document.getElementById("prevBtn").style.display = "inline";
    }
        
    if (n == (x.length - 1)) {
      document.getElementById("nextBtn").innerHTML = "Submit";
    } else {
      document.getElementById("nextBtn").innerHTML = "Next";
    }
        
    //... and run a function that will display the correct step indicator:
    fixStepIndicator(n)
  }
        
  function nextPrev(n) {
    // This function will figure out which tab to display
    var x = document.getElementsByClassName("step");
        
    // Exit the function if any field in the current tab is invalid:
    if (n == 1 && !validateForm()) return false;
          
    // Hide the current tab:
    x[currentTab].style.display = "none";
          
    // Increase or decrease the current tab by 1:
    currentTab = currentTab + n;
        
    // if you have reached the end of the form...  
    if (currentTab >= x.length) {
      // ... the form gets submitted:
      document.getElementById("signUpForm").submit();
      return false;
    }
          
    // Otherwise, display the correct tab:
    showTab(currentTab);
  }
        
  function validateForm() {
    // This function deals with validation of the form fields
    var x, y, i, valid = true;
    x = document.getElementsByClassName("step");
    y = x[currentTab].getElementsByClassName("form-control required");
        
    // A loop that checks every input field in the current tab:
    for (i = 0; i < y.length; i++) {        
      if (y[i].id == "cOtherLoca1" && document.getElementById("cRowOtherLoca").style.display == "block" && 
          y[i].value == "") {
        valid = setValidateState(y[i]);          
      } else if (y[i].id != "cOtherLoca1" && y[i].value == "") {
        valid = setValidateState(y[i]);
      }
    }  
          
    if (document.getElementById("cLocation").value == "-1") {
      valid = setValidateState(document.getElementById("cLocation"));
    }
          
    // If the valid status is true, mark the step as finished and valid:
    if (valid) {
      document.getElementsByClassName("stepIndicator")[currentTab].className += " finish";
    }
        
    return valid; // return the valid status
  }
        
  function fixStepIndicator(n) {
    // This function removes the "active" class of all steps...
    var i, x = document.getElementsByClassName("stepIndicator");
       
    for (i = 0; i < x.length; i++) {
      x[i].className = x[i].className.replace(" active", "");
    }
       
    //... and adds the "active" class on the current step:
    x[n].className += " active";
  }
      
  function setVisibilityRow(select) {
    var selectValue = select.value;
    var row = document.getElementById("cRowOtherLoca");
        
    if (selectValue === "20") {
      row.style.display = "block";
    } else {
      row.style.display = "none";
    }
  }
      
  function setValidateState(element) {
    // add an "invalid" class to the field:
    element.className += " invalid";
           
    // and set the current valid status to false
    return false;
  }
  
  function enDisableButton(element) {
    var isBtnDisabled = true;
    
    if (element.value.length >= 3) {
      isBtnDisabled = false;
    }
    
    document.getElementById('search').disabled = isBtnDisabled;
  }
  
  function setInterferenceKind(value) {
    interferenceKind = value;
    console.log(interferenceKind);
  }
  
  function setRouterKind(value) {
    routerKind = value;
    console.log(routerKind);
  }
</script>
<?php } ?> 
