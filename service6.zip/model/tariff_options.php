<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class TariffOptionsQueries {
    public function getAllOptionsRegardlessOfRateForPK(): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT
			  id,
			  name,
			  price,
			  note
			FROM tariff_option
			WHERE isDeleted         =  0
			  AND customer_class_id =  2
			  OR  id                = 15";

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
    public function getAllOptionsDependingOnRatesForPK(): string {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT GROUP_CONCAT(DISTINCT(top.name) SEPARATOR \", \") AS options
		    FROM      tariff_option          AS top
			LEFT JOIN tariff_x_tariff_option AS txtop ON txtop.tariff_option_id = top.id
			WHERE top.isDeleted         = 0
			  AND txtop.isDeleted       = 0
			  AND top.customer_class_id = 2";

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue[0]["options"];
	}
	  
	public function getTVOptionByAvailibity($address = array()): array {
      mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
		
		  $query = "SELECT
		      axt.id AS id,
			  axt.title AS title,
			  axt.price AS price
		    FROM address_x_television AS axt
			LEFT JOIN address  AS ad ON ad.id = axt.address_id
			LEFT JOIN location AS  l ON  l.id = ad.location_id" . $this->getWhereConditions($address);
			
		  $result = $connection->query($query);
			
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
	      mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }

      return $returnValue;
	}
	  
    public function getOptionsById($id): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT
			  id,
			  name,
			  price,
			  note
			FROM tariff_option
			WHERE isDeleted         =  0
			  AND id                = " . $id;

		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
	protected function getWhereConditions($address): string {
	  $returnValue = ' WHERE
          axt.isDeleted = 0
		AND
		  ad.isDeleted = 0';

	  if (array_key_exists('street', $address) && !empty($address["street"])) {
	    $returnValue .= ' AND ad.street LIKE "' . $address["street"] . '"';
	  }
		
	  if (array_key_exists('hNr', $address) && !empty($address["hNr"])) {
	    $returnValue .= ' AND ad.houseNr LIKE "' . $address["hNr"] . '"';
	  }
		
	  if (array_key_exists('zipcode', $address) && !empty($address["zipcode"])) {
	    $returnValue .= ' AND ad.zipcode LIKE "' . $address["zipcode"] . '"';
	  }
		
	  if (array_key_exists('place', $address) && !empty($address["place"])) {
	    $returnValue .= ' AND l.name LIKE "' . $address["place"] . '"';
	  }
		
	  if (array_key_exists('district', $address) && !empty($address["district"])) {
	    $returnValue .= ' AND l.district LIKE "' . $address["district"] . '"';
	  }
		
	  return $returnValue;
	}
  }
?>