<div class="borderStyle generally">

<div class="row puffer">
  <div class="col">
    <button type="button" class="btn btn-primary" id="loadDataWin" name="loadDataWin" value="loadDataWin">Lade Daten aus  WinBox
    </button>
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="down" class="form-label">Download (Mbps)</label>
    <input type="text" class="form-control" id="down" name="down" placeholder="Download" value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
  <div class="col">
    <label for="up" class="form-label">Upload (Mbps)</label>
    <input type="text" class="form-control" id="up" name="up" placeholder="Upload" value="" onkeypress="return /[0-9+\/-]/.test(event.key)">
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <label for="up" class="form-label">Verbindungszeit (Stunden)</label>
    <input type="text" class="form-control" id="duration" name="duration" placeholder="Verbindungszeit" value="">    
  </div>
</div>

<div class="row puffer">
  <div class="col">
    <b>Ping (ms)</b>
  </div>
  <div class="col">
    <input type="text" class="form-control" id="pingDown" name="pingDown" placeholder="Download" value="">
  </div>
  <div class="col">
    <input type="text" class="form-control" id="pingUp" name="pingUp" placeholder="Upload" value="">
  </div>
</div>

</div>
