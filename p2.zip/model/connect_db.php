<?php

declare(strict_types = 1);

require_once __DIR__ . '/config/config.php';

function connectDB() : PDO {
  $config = new ConfigDb();
    
  try {  
    $dsn = 'pgsql:host=' . $config->getDbHost()
         . ';port='      . $config->getDbPort()
         . ';dbname='    . $config->getDbName() . ';';
      
    return new PDO($dsn, $config->getDbUser(), $config->getDbPassword(), array(PDO::ATTR_PERSISTENT));
      
  } catch (PDOException $e) {
    die($e->getMessage());
  } 
}

return connectDB();
