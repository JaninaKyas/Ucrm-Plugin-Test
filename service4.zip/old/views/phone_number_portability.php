<div class="row puffer">
  <div class="col">
    <span>
	  <strong>Anbieterwechselauftrag von </strong> Project66 IT-Systemhaus (Brehna.net)
	</span>
  </div>
</div>

<div id="phonePortabilityContent" class="borderbox">
  <div class="row puffer">
    <div class="col-1">
	  <input type="checkbox" id="kueAS" id="1" checked disabled>
    </div>

    <div class="col-9">
	  <span class="spanNewline">
	    <strong>Kündiung von Anschlüssen beim Endkundenvertragspartner abgebend (EKPabg)</strong>
	  </span>
	  
	  <span class="spanNewline smFont">
	    (separate Kündigung beim bisherigen Anbieter nicht erforderlich)
	  </span>
	  
	  <span class="spanNewline smFont">
	    Hiermit künidge/n ich/wir den zu unten gemachten Angaben gehörenden Anschluss bei  
	  </span>
	  
	  <span class="spanNewline smFont">
	    zum nächst möglichen Termin.  
	  </span>
    </div>

    <div class="col-2">
	  <textarea id="phoneProvider" name="phoneProvider" rows="10" cols="10"></textarea>
    </div>
  </div>

  <div class="row puffer">
    <div class="col-1">
	  <input type="checkbox" id="takePhoneNr" id="1" checked disabled>
    </div>
	
    <div class="col-10">
	  <span class="spanNewline">
	    <strong>
		  Hiermit beauftrage/n ich/wir die Portierung (Mitnahme) der angegebenen Rufnummern.
		</strong>
	  </span>
    </div>
  </div>

  <div id="connectionHolderData" class="borderbox">
    <div class="row puffer">
      <div class="col">
	    Name / Firma*
	    <input type="text" class="form-control required5" id="holderName" name="holderName">
	  </div>
	  
      <div class="col">
	    Vorname*
	    <input type="text" class="form-control required5" id="holderFName" name="holderFName">
	  </div>
    </div>
	
    <div class="row puffer">
      <div class="col-8">
	    Strasse*
	    <input type="text" class="form-control required5" id="holderStreet" name="holderStreet">	  
	  </div>
	  
      <div class="col">
	    Hausnummer*
	    <input type="text" class="form-control required5" id="holderHNr" name="holderHNr">
	  </div>
    </div>
	
    <div class="row puffer">
      <div class="col">
	    PLZ*
	    <input type="text" class="form-control required5" id="holderPLZ" name="holderPLZ">	  
	  </div>
	  
      <div class="col">
	    Ort*
	    <input type="text" class="form-control required5" id="holderPlace" name="holderPlace">	
	  </div>
    </div>
  </div>
	
  <div class="row puffer">
    <div class="col-1">
	  <input type="checkbox" id="specifyPhoneNr" id="1" checked disabled>
    </div>
	
    <div class="col-10">
	  <span class="spanNewline">
	    <strong>alle Nr. der Anschlüsse portieren</strong>
	  </span>
    </div>
  </div>
	
  <div class="borderbox">
    <div class="row puffer">
	  <div class="col-3">
		<strong>Ortsnetzkennzahl</strong>
	  </div>
	
	  <div class="col">
		  <strong>Rufnummer/n <span id="fontPhone" class="smFont">(Achtung, es muss mindestens eine Rufnummer angegeben werden!)</span></strong>
	  </div>
    </div>
	  
	<div class="row puffer">
	  <div class="col-3">
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phoneOnkz1" name="phoneOnkz">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phoneOnkz2" name="phoneOnkz">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phoneOnkz3" name="phoneOnkz">
		</span>
	  </div>
		
	  <div class="col">
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone1" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone2" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone3" name="phone">
		</span>
	  </div>
		
	  <div class="col">
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone4" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone5" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone6" name="phone">
		</span>
	  </div>
		
	  <div class="col">
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone7" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone8" name="phone">
		</span>
		<span class="spanNewline">
		  <input type="text" class="form-control" id="phone9" name="phone">
		</span>
	  </div>
	</div>
  </div>
	
  <div class="borderbox">
	<div class="row puffer">
	  <div class="col">
		<strong>Telekommunikationsanlagen</strong>
	  </div>
	</div>
	  
	<div class="row puffer">
	  <div class="col">
		<div>
		  <strong>Durchwahl-RN</strong>
		  <br>
		  <input type="text" class="form-control" id="tkOnkz" name="tkOnkz">
		</div>
		  
		<div>
		  <br>
		  <strong>Abfragestelle</strong>
		  <input type="text" class="form-control" id="tkQueryPoint" name="tkQueryPoint">
		</div>
		  
		<div>
		  <br>
		  <strong>Rufnummernblock</strong>
		  <br><br>
		  <span class="spanNewline">von</span>
		  <input type="text" class="form-control" id="tkPhoneBlockFrom" name="tkPhoneBlockFrom">
		  <br>
		  <span class="spanNewline">bis</span>
		  <input type="text" class="form-control" id="tkPhoneBlockTo" name="tkPhoneBlockTo">
		</div>
	  </div>
	</div>
  </div>
</div>