<?php

declare(strict_types = 1);

class CustomTable {
  function getUserByCustomerNumber(string $customerNumber): array {    
    $pdo = require_once __DIR__ . '/connect_db.php';
    $query = 'SELECT customer_number, test_name, test_firstname, test_company FROM custom_table WHERE customer_number = \'' . $customerNumber . '\'';
    
    $stmt  = $pdo->prepare($query);
    $stmt->execute(); 

    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $pdo = null; // close db connection
    
    return ($result !== false) ? $result : [];
  }
}
