<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	
	require_once __DIR__ . "/views/confirm/confirm.php";
	require_once __DIR__ . "/views/confirm/mail_send.php";

	$confirm    = new Confirm($infos);
	$mailSend   = new MailSend($infos);
	
	$html = "";
	if ($infos["choosenPath"] == 4 || $infos["choosenSubPath"] == 2) {
	  require_once __DIR__ . "/model/customer_connection_requests_queries.php";
	  $ccrQueries = new CustomerConnectionRequestsQueries();
	  
	  // customer data
	  $salut   = "";
	  $fName   = "";
	  $lName   = "";
	  $company = "";
	  $phone   = "";
	  $mobil   = "";
	  $mail    = "";
	  if (array_key_exists("customer", $infos)) {
		if (array_key_exists("salut", $infos["customer"])) {
		  $salut = $infos["customer"]["salut"];
		}
		
		if (array_key_exists("fName", $infos["customer"])) {
		  $fName = $infos["customer"]["fName"];
		}
		
		if (array_key_exists("lName", $infos["customer"])) {
		  $lName = $infos["customer"]["lName"];
		}
		
		if (array_key_exists("company", $infos["customer"])) {
		  $company = $infos["customer"]["company"];
		}
		
		if (array_key_exists("phone", $infos["customer"])) {
		  $phone = $infos["customer"]["phone"];
		}
		
		if (array_key_exists("mobil", $infos["customer"])) {
		  $mobil = $infos["customer"]["mobil"];
		}
		
		if (array_key_exists("mail", $infos["customer"])) {
		  $mail = $infos["customer"]["mail"];
		}
	  }
	
      // address data	
	  $street   = "";
	  $hNr      = "";
	  $zipcode  = "";
	  $place    = "";
	  $district = "";
	  if (array_key_exists("postalAddress", $infos)) {
		if (array_key_exists("street", $infos["postalAddress"])) {
          $street = $infos["postalAddress"]["street"];
		}
		
		if (array_key_exists("hNr", $infos["postalAddress"])) {
          $hNr = $infos["postalAddress"]["hNr"];
		}
		
		if (array_key_exists("zipcode", $infos["postalAddress"])) {
          $zipcode = $infos["postalAddress"]["zipcode"];
		}
		
		if (array_key_exists("place", $infos["postalAddress"])) {
          $place = $infos["postalAddress"]["place"];
		}
		
		if (array_key_exists("district", $infos["postalAddress"])) {
          $district = $infos["postalAddress"]["district"];
		}
	  }
	  
	  $conKind      =  0;
	  $selTech      =  0;
	  $isWishRecall =  0;
	  $recallTermin = "";
	  if (array_key_exists("conKind", $infos)) {
		$conKind = $infos["conKind"];
	  }

	  if (array_key_exists("selTech", $infos)) {
		$selTech = $infos["selTech"];
	  }
	  
	  if (array_key_exists("recall", $infos)) {
		if (array_key_exists("isWish", $infos)) {
		  $isWishRecall = $infos["recall"]["isWish"];
		}
		
		if (array_key_exists("termin", $infos)) {
		  $recallTermin = $infos["recall"]["termin"];
		}
	  }
	  
	  $rate       = -1;
	  $careTech   = -1;
	  $isPhone    =  0;
	  $isPorting  =  0;
	  $careTermin = "";
	  $message    = "";
	  if (array_key_exists("conRequestRate", $infos)) {
		$rate = $infos["conRequestRate"];
	  }
	  
	  if (array_key_exists("techCare", $infos)) {
		$careTech = $infos["techCare"];
	  }
	  
	  if (array_key_exists("phone", $infos)) {
		$isPhone = $infos["phone"];
	  }

	  if (array_key_exists("porting", $infos)) {
		$isPorting = $infos["porting"];
	  }
	  
	  if (array_key_exists("careTermin1", $infos)) {
		$careTermin = $infos["careTermin1"];
	  }
	  
	  if (array_key_exists("message", $infos)) {
		$message = $infos["message"];
	  }
	  
	  $save = $ccrQueries->saveRequest(
	    $salut, $fName, $lName, $company, $street, $hNr, $zipcode, $place, $district, $phone, $mobil, $mail, $conKind,
		$selTech, $isWishRecall, $recallTermin, $rate, $careTech, $isPhone, $isPorting, $careTermin, $message 
	  );
	  
      if ($save) {
		if ($mailSend->sendMail()) {
		  $html = $confirm->buildConfirmRequest();
		}
	  }	  
	} else if ($infos["choosenPath"] == 1 || $infos["choosenSubPath"] == 1) {
	  require_once __DIR__ . "/model/address_queries.php";
	  require_once __DIR__ . "/model/location_queries.php";
	  require_once __DIR__ . "/model/customer_queries.php";
	  require_once __DIR__ . "/model/house_owner_queries.php";
	  require_once __DIR__ . "/model/debator_queries.php";
	  require_once __DIR__ . "/model/country_queries.php";
	  require_once __DIR__ . "/model/customer_ftth_request_queries.php";
		
	  $addressQueries             = new AddressQueries();
	  $locationQueries            = new LocationQueries();
      $customerQueries            = new CustomerQueries();
	  $houseOwnerQueries          = new HouseOwnerQueries();
	  $debatorQueries             = new DebatorQueries();
	  $countryQueries             = new CountryQueries();
	  $customerFttHRequestQueries = new CustomerFttHRequestQueries();
	  
	  
	  var_dump($infos); exit;
	  // save postal address
	  $postalAddressId = -1;
	  $locationId      = -1;
	  if (array_key_exists("postalAddress", $infos)) {
	    if ( array_key_exists("street", $infos["postalAddress"])
		  && array_key_exists("hNr", $infos["postalAddress"])
		  && array_key_exists("zipcode", $infos["postalAddress"])
		  && array_key_exists("place", $infos["postalAddress"])
		  && array_key_exists("district", $infos["postalAddress"])) {
		    $postalAddressId = $addressQueries->getIdByAddressData(
			  $infos["postalAddress"]["street"],
			  $infos["postalAddress"]["hNr"],
			  $infos["postalAddress"]["zipcode"],
			  $infos["postalAddress"]["place"],
			  $infos["postalAddress"]["district"]
			);
			
			if (empty($postalAddressId)) {
			  $locationId = $locationQueries->getIdByLocationData(
				$infos["postalAddress"]["place"],
			    $infos["postalAddress"]["district"]
			  );

			  if (empty($locationId)) {
			    $locationId = $locationQueries->saveLocationData(
				  $infos["postalAddress"]["place"],
			      $infos["postalAddress"]["district"]
			    );
			  }
		    }
			
			if (!empty($locationId) && $locationId > 0 && 
				(empty($postalAddressId) || empty($postalAddressId) == -1)) {
			  $postalAddressId = $addressQueries->saveNewAddress(
			    $infos["postalAddress"]["street"],
			    $infos["postalAddress"]["hNr"],
			    $infos["postalAddress"]["zipcode"],
				$locationId
			  );
			}
		  }
	    }
		
		// save technology address
		$techAddressId  = -1;
	    $techLocationId = -1;
		if ( array_key_exists("techAddress", $infos)
		  && array_key_exists("isDiffAddress", $infos["techAddress"])
	      && $infos["techAddress"]["isDiffAddress"]) {
			if ( array_key_exists("street", $infos["techAddress"])
		      && array_key_exists("hnr", $infos["techAddress"])
		      && array_key_exists("zipcode", $infos["techAddress"])
		      && array_key_exists("place", $infos["techAddress"])
		      && array_key_exists("district", $infos["techAddress"])) {
			    $techAddressId = $addressQueries->getIdByAddressData(
			      $infos["techAddress"]["street"],
			      $infos["techAddress"]["hnr"],
			      $infos["techAddress"]["zipcode"],
			      $infos["techAddress"]["place"],
			      $infos["techAddress"]["district"]
			    );
				
				if (empty($techAddressId)) {
			      $techLocationId = $locationQueries->getIdByLocationData(
				    $infos["techAddress"]["place"],
			        $infos["techAddress"]["district"]
			      );

			      if (empty($techLocationId)) {
			        $techLocationId = $locationQueries->saveLocationData(
				      $infos["techAddress"]["place"],
			          $infos["techAddress"]["district"]
			        );
			      }
		        }
				
                if (!empty($techLocationId) && $techLocationId > 0 && 
				    (empty($postalAddressId) || empty($postalAddressId) == -1)) {
			      $techAddressId = $addressQueries->saveNewAddress(
			        $infos["techAddress"]["street"],
			        $infos["techAddress"]["hnr"],
			        $infos["techAddress"]["zipcode"],
				    $techLocationId
			      );
			    }
		    }
		}
		
	    // save customer data
		$customerId = -1;
		if (array_key_exists("customer", $infos)) {
		  if ( array_key_exists("salut", $infos["customer"])
		    && array_key_exists("fName", $infos["customer"])
		    && array_key_exists("lName", $infos["customer"])
			&& array_key_exists("company", $infos["customer"])
			&& array_key_exists("phone", $infos["customer"])
			&& array_key_exists("mobil", $infos["customer"])
			&& array_key_exists("mail", $infos["customer"])) {
			
		  }
		}
		
	  $html = $confirm->buildConfirmFttH();
	} else if ($infos["choosenPath"] == 2) {
	  $html = $confirm->buildConfirmPK();
	}
	
	$content = array(
	  "step8content" => $html
	);
	
	echo json_encode($content);
  }
?>