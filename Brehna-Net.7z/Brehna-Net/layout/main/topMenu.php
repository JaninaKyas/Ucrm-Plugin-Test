          <a class="screen-reader-text skip-link" href="#content">Zum Inhalt springen</a>
    <div id="tc-sn" class="tc-sn side-nav__container d-none d-lg-block" >
    <nav class="tc-sn side-nav__nav" >
      <div class="tc-sn-inner">
        <div class="hamburger-toggler__container " >
  <button class="ham-toggler-menu czr-collapsed" data-toggle="sidenav" aria-expanded="false"><span class="ham__toggler-span-wrapper"><span class="line line-1"></span><span class="line line-2"></span><span class="line line-3"></span></span><span class="screen-reader-text">Menü</span></button>
</div>
<div class="nav__menu-wrapper side-nav__menu-wrapper" >
<ul id="main-menu" class="side-nav__menu side vertical-nav nav__menu flex-column nav"><li id="menu-item-116" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-116"><a href="https://brehna.net/news/" class="nav__link"><span class="nav__title">News</span></a></li>
<li id="menu-item-70" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-70"><a href="https://brehna.net/versorgungsgebiete/" class="nav__link"><span class="nav__title">Versorgungsgebiete</span></a></li>
<li id="menu-item-65" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65"><a href="https://brehna.net/privatkunden/" class="nav__link"><span class="nav__title">Privatkunden</span></a></li>
<li id="menu-item-59" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-59"><a href="https://brehna.net/geschaeftskunden/" class="nav__link"><span class="nav__title">Geschäftskunden</span></a></li>
<li id="menu-item-71" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children czr-dropdown current-active menu-item-71"><a href="#" class="nav__link"><span class="nav__title">Service</span></a>
<ul class="dropdown-menu czr-dropdown-menu">
	<li id="menu-item-74" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-74"><a href="https://brehna.net/anschluss-anfrage/" class="nav__link"><span class="nav__title">Anschluss – Anfrage</span></a></li>
	<li id="menu-item-67" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-67"><a href="https://brehna.net/support-anfrage/" class="nav__link"><span class="nav__title">Support – Anfrage</span></a></li>
	<li id="menu-item-56" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-43 current_page_item dropdown-item current-active menu-item-56"><a href="https://brehna.net/dokumente/" aria-current="page" class="nav__link"><span class="nav__title">Dokumente</span></a></li>
</ul>
</li>
<li id="menu-item-207" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-207"><a href="https://brehna.net/kontakt/" class="nav__link"><span class="nav__title">Kontakt</span></a></li>
<li id="menu-item-68" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children czr-dropdown menu-item-68"><a href="https://brehna.net/ueber-uns/" class="nav__link"><span class="nav__title">Über Uns</span></a>
<ul class="dropdown-menu czr-dropdown-menu">
	<li id="menu-item-60" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-60"><a href="https://brehna.net/geschichte-entstehung/" class="nav__link"><span class="nav__title">Geschichte &#038; Entstehung</span></a></li>
	<li id="menu-item-64" class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-64"><a href="https://brehna.net/partner/" class="nav__link"><span class="nav__title">Partner</span></a></li>
</ul>
</li>
</ul></div>      </div><!-- /.tc-sn-inner  -->
    </nav>
</div>
    
    <div id="tc-page-wrap" class="">

      <header class="tpnav-header__header tc-header sl-logo_left sticky-transparent border-top czr-submenu-fade czr-submenu-move" >
        <div class="primary-navbar__wrapper d-none d-lg-block desktop-sticky" >
  <div class="container">
    <div class="row align-items-center flex-row primary-navbar__row">
      <div class="branding__container col col-auto" >
  <div class="branding align-items-center flex-column ">
    <div class="branding-row d-flex align-self-start flex-row align-items-center">
      <div class="navbar-brand col-auto " >
  <a class="navbar-brand-sitelogo" href="https://brehna.net/"  aria-label="Brehna.net | Sei genial, bleib lokal!" >
    <img src="https://brehna.net/wp-content/uploads/2023/08/bnet-website-logo.png" alt="Zurück zur Startseite" class="" width="1500" height="500" style="max-width:250px;max-height:100px" data-no-retina>  </a>
</div>
      </div>
    <span class="header-tagline " >
  Sei genial, bleib lokal!</span>

  </div>
</div>
      <div class="primary-nav__container justify-content-lg-around col col-lg-auto flex-lg-column" >
  <div class="primary-nav__wrapper flex-lg-row align-items-center justify-content-end">
              <nav class="primary-nav__nav col" id="primary-nav">
          <div class="nav__menu-wrapper primary-nav__menu-wrapper justify-content-start czr-open-on-hover" >
</div>        </nav>
    <div class="primary-nav__utils nav__utils col-auto" >
    <ul class="nav utils flex-row flex-nowrap regular-nav">
      <li class="nav__search " >
  <a href="#" class="search-toggle_btn icn-search czr-overlay-toggle_btn"  aria-expanded="false"><span class="sr-only">Search</span></a>
        <div class="czr-search-expand">
      <div class="czr-search-expand-inner"><div class="search-form__container " >
  <form action="https://brehna.net/" method="get" class="czr-form search-form">
    <div class="form-group czr-focus">
            <label for="s-65e6ff3275316" id="lsearch-65e6ff3275316">
        <span class="screen-reader-text">Suche</span>
        <input id="s-65e6ff3275316" class="form-control czr-search-field" name="s" type="search" value="" aria-describedby="lsearch-65e6ff3275316" placeholder="Suche &hellip;">
      </label>
      <button type="submit" class="button"><i class="icn-search"></i><span class="screen-reader-text">Suche &hellip;</span></button>
    </div>
  </form>
</div></div>
    </div>
    </li>
<li class="hamburger-toggler__container " >
  <button class="ham-toggler-menu czr-collapsed" data-toggle="sidenav" aria-expanded="false"><span class="ham__toggler-span-wrapper"><span class="line line-1"></span><span class="line line-2"></span><span class="line line-3"></span></span><span class="screen-reader-text">Menü</span></button>
</li>
    </ul>
</div>  </div>
</div>
    </div>
  </div>
</div>    <div class="mobile-navbar__wrapper d-lg-none mobile-sticky" >
    <div class="branding__container justify-content-between align-items-center container" >
  <div class="branding flex-column">
    <div class="branding-row d-flex align-self-start flex-row align-items-center">
      <div class="navbar-brand col-auto " >
  <a class="navbar-brand-sitelogo" href="https://brehna.net/"  aria-label="Brehna.net | Sei genial, bleib lokal!" >
    <img src="https://brehna.net/wp-content/uploads/2023/08/bnet-website-logo.png" alt="Zurück zur Startseite" class="" width="1500" height="500" style="max-width:250px;max-height:100px" data-no-retina>  </a>
</div>
    </div>
      </div>
  <div class="mobile-utils__wrapper nav__utils regular-nav">
    <ul class="nav utils row flex-row flex-nowrap">
      <li class="nav__search " >
  <a href="#" class="search-toggle_btn icn-search czr-dropdown" data-aria-haspopup="true" aria-expanded="false"><span class="sr-only">Search</span></a>
        <div class="czr-search-expand">
      <div class="czr-search-expand-inner"><div class="search-form__container " >
  <form action="https://brehna.net/" method="get" class="czr-form search-form">
    <div class="form-group czr-focus">
            <label for="s-65e6ff32759ff" id="lsearch-65e6ff32759ff">
        <span class="screen-reader-text">Suche</span>
        <input id="s-65e6ff32759ff" class="form-control czr-search-field" name="s" type="search" value="" aria-describedby="lsearch-65e6ff32759ff" placeholder="Suche &hellip;">
      </label>
      <button type="submit" class="button"><i class="icn-search"></i><span class="screen-reader-text">Suche &hellip;</span></button>
    </div>
  </form>
</div></div>
    </div>
        <ul class="dropdown-menu czr-dropdown-menu">
      <li class="header-search__container container">
  <div class="search-form__container " >
  <form action="https://brehna.net/" method="get" class="czr-form search-form">
    <div class="form-group czr-focus">
            <label for="s-65e6ff3275c41" id="lsearch-65e6ff3275c41">
        <span class="screen-reader-text">Suche</span>
        <input id="s-65e6ff3275c41" class="form-control czr-search-field" name="s" type="search" value="" aria-describedby="lsearch-65e6ff3275c41" placeholder="Suche &hellip;">
      </label>
      <button type="submit" class="button"><i class="icn-search"></i><span class="screen-reader-text">Suche &hellip;</span></button>
    </div>
  </form>
</div></li>    </ul>
  </li>
<li class="hamburger-toggler__container " >
  <button class="ham-toggler-menu czr-collapsed" data-toggle="czr-collapse" data-target="#mobile-nav"><span class="ham__toggler-span-wrapper"><span class="line line-1"></span><span class="line line-2"></span><span class="line line-3"></span></span><span class="screen-reader-text">Menü</span></button>
</li>
    </ul>
  </div>
</div>
<div class="mobile-nav__container " >
   <nav class="mobile-nav__nav flex-column czr-collapse" id="mobile-nav">
      <div class="mobile-nav__inner container">
      <div class="nav__menu-wrapper mobile-nav__menu-wrapper czr-open-on-click" >
<ul id="mobile-nav-menu" class="mobile-nav__menu vertical-nav nav__menu flex-column nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-116"><a href="https://brehna.net/news/" class="nav__link"><span class="nav__title">News</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-70"><a href="https://brehna.net/versorgungsgebiete/" class="nav__link"><span class="nav__title">Versorgungsgebiete</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-65"><a href="https://brehna.net/privatkunden/" class="nav__link"><span class="nav__title">Privatkunden</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-59"><a href="https://brehna.net/geschaeftskunden/" class="nav__link"><span class="nav__title">Geschäftskunden</span></a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children czr-dropdown current-active menu-item-71"><span class="display-flex nav__link-wrapper align-items-start"><a href="#" class="nav__link"><span class="nav__title">Service</span></a><button data-toggle="czr-dropdown" aria-haspopup="true" aria-expanded="false" class="caret__dropdown-toggler czr-btn-link"><i class="icn-down-small"></i></button></span>
<ul class="dropdown-menu czr-dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-74"><a href="https://brehna.net/anschluss-anfrage/" class="nav__link"><span class="nav__title">Anschluss – Anfrage</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-67"><a href="https://brehna.net/support-anfrage/" class="nav__link"><span class="nav__title">Support – Anfrage</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-43 current_page_item dropdown-item current-active menu-item-56"><a href="https://brehna.net/dokumente/" aria-current="page" class="nav__link"><span class="nav__title">Dokumente</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-207"><a href="https://brehna.net/kontakt/" class="nav__link"><span class="nav__title">Kontakt</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children czr-dropdown menu-item-68"><span class="display-flex nav__link-wrapper align-items-start"><a href="https://brehna.net/ueber-uns/" class="nav__link"><span class="nav__title">Über Uns</span></a><button data-toggle="czr-dropdown" aria-haspopup="true" aria-expanded="false" class="caret__dropdown-toggler czr-btn-link"><i class="icn-down-small"></i></button></span>
<ul class="dropdown-menu czr-dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-60"><a href="https://brehna.net/geschichte-entstehung/" class="nav__link"><span class="nav__title">Geschichte &#038; Entstehung</span></a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page dropdown-item menu-item-64"><a href="https://brehna.net/partner/" class="nav__link"><span class="nav__title">Partner</span></a></li>
</ul>
</li>
</ul></div>      </div>
  </nav>
</div></div>

<SCRIPT SRC="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></SCRIPT>
		  
</header>