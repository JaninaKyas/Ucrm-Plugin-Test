CREATE TABLE IF NOT EXISTS `customer_class` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(150)           NOT NULL DEFAULT '',
  `shortName`  CHAR(5)             NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4;

INSERT INTO `customer_class` VALUES (NULL, '... bitte auswählen ...',      '', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `customer_class` VALUES (NULL,            'Privatkunden',    'PK', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `customer_class` VALUES (NULL,                'Senioren',  'S-PK', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `customer_class` VALUES (NULL,         'Geschäftskunden',    'GK', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `customer_class` VALUES (NULL,       'Business Complete', 'BC-GK', NOW(), 'JANINA', NOW(), 'JANINA', 0);

ALTER TABLE `tariff_option` ADD `customer_class_id` INT(11) UNSIGNED NOT NULL DEFAULT '1' AFTER `parent_id`;

ALTER TABLE `tariff_option`
ADD CONSTRAINT `customer_class_id`
FOREIGN KEY   (`customer_class_id`)
REFERENCES     `customer_class`(`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;
  
UPDATE `tariff_option` SET `parent_id` = '4' WHERE `tariff_option`.`id` = 5;
UPDATE `tariff_option` SET `parent_id` = '4' WHERE `tariff_option`.`id` = 6;

UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 2;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 3;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 4;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 5;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 6;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 7;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 8;

UPDATE `tariff_option` SET `name` = 'Rufnummernmitnahme zu Brehna.net' WHERE `tariff_option`.`id` = 15;

UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 16;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 17;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 18;
UPDATE `tariff_option` SET `customer_class_id` = '2' WHERE `tariff_option`.`id` = 19;

UPDATE `tariff_option` SET `name` = 'Telefonie Standard', `note` = 'inkl. 1 SIP Sprachkanal, 1 Rufnummer, Festnetzflat DE' WHERE `tariff_option`.`id` = 4
UPDATE `tariff_option` SET `name` = 'Allnetflatrate', `note` = 'Alle Fest- und Mobilnetze in Deutschland je Sprachkanal' WHERE `tariff_option`.`id` = 6
UPDATE `tariff_option` SET `name` = 'zusätzlicher SIP Sprachkanal, Rufnummer, inkl. DE Flat' WHERE `tariff_option`.`id` = 5
