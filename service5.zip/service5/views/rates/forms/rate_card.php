<?php
  declare(strict_types = 1);

  class RateCard {
    public $rate = array();
	  
	public function __construct($newRate) {
	  $this->rate = $newRate;
	}
	  
    public function getRateCard(): string {
	  $returnValue  = '<div class="borderBox"><div id="div' . $this->rate["rateId"] . '" class="row puffer">';
	  $returnValue .= $this->getFirstCol();		
	  $returnValue .= $this->getSecondCol();
	  $returnValue .= $this->getThirdCol();
	  $returnValue .= '</div>';
	  $returnValue .= $this->getFourthCol($this->rate["rateId"]) . "</div>";
		
	  return $returnValue;
	}
	  
	protected function getFirstCol(): string {
	  $returnValue = '
   	    <div class="col addressLabel">
		  <span>
	  ';
		
	  if ($this->rate["catId"] == 2 || $this->rate["catId"] == 5) {		  
	    $returnValue .= '
		  <img id="internetImg" 
			 src="http://localhost/service5/public/images/internet.png" 
			 alt="internet">
		';
	  }
		
	  if ($this->rate["catId"] == 3 || $this->rate["catId"] == 5) {
	    $returnValue .= '
		  <img id="phoneImg" 
			 src="http://localhost/service5/public/images/phone.png" 
			 alt="phone">
		';
	  }
		
	  $returnValue .= '
	      </span>
		  <br>
		  <span>' . $this->rate["catName"] . '</span>
	    </div>
	  ';
		
	  return $returnValue;
	}
	  
	protected function getSecondCol(): string {
	  $returnValue = '
	    <div class="col dirLeft"><span class="rateTitle">' . $this->rate["rate"] . '</span>
		  <br><br>
		  <ul>
		    <li>' . $this->rate["dStream"] . ' MBit/s max. Download</li>
			<li>' . $this->rate["uStream"] . ' MBit/s max. Upload</li>
		  </ul>
	  ';
		
      if ($this->rate["options"] != "") {
		$returnValue .= '<ul>';
		  
	    $options = explode(",", $this->rate["options"]);
		for ($i = 0; $i < count($options); $i++) {
		  $returnValue .= '
		    <li>
			  <img id="check"
			       src="http://localhost/service5/public/images/check-mark-1.png" 
			       alt="check"> ' . $options[$i] . '
			</li>
		  ';
		}
		  
		$returnValue .= '</ul>';
	  }

	  $returnValue .= '</div>';
		
	  return $returnValue;
	}
	  
	protected function getThirdCol(): string {
	  $returnValue  = '<div class="col addressLabel1">';		
	  
	  $returnValue .= number_format(floatval($this->rate["monthPrice"]), 2, ',', ' ') . ' € pro Monat</div>';
	  
	  return $returnValue;
	}
	  
	protected function getFourthCol($id): string {
	  return '<div class="row">
	      <div class="col">
            <button class="button btn-navigate-form-step addressButton"
				    type="button"
					step_number="1"
					step_direction="-1"
					onClick="backwardToStep1()">
			  <span id="btnLable1">Zurück</span>
			</button>
		  </div>
			
		  <div class="col">
		    <button class="button btn-navigate-form-step addressButton"
				    type="button"
					step_number="3"
					step_direction="1"
					onClick="setchoosenRate(' . $id . ')">
		      <span>Tarif auswählen</span>
			</button>
		  </div>
	    </div>';
	}
  }
?>