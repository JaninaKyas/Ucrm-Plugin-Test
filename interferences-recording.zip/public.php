<?php

require_once __DIR__ . '/vendor/autoload.php';

$api = \Ubnt\UcrmPluginSdk\Service\UcrmApi::create();
$security = \Ubnt\UcrmPluginSdk\Service\UcrmSecurity::create();

$user = $security->getUser();
if (! $user || ! $user->hasViewPermission(\Ubnt\UcrmPluginSdk\Security\PermissionNames::SCHEDULING_MY_JOBS)) {
    die('You do not have permission to view this page.');
}

$jobs = $api->get(
    'scheduling/jobs',
    [
        'statuses' => [0],
        'assignedUserId' => $user->userId,
    ]
);

echo 'The following jobs are open and assigned to you:<br>';
echo '<ul>';
foreach ($jobs as $job) {
    echo sprintf('<li>%s</li>', htmlspecialchars($job['title'], ENT_QUOTES));
}
echo '</ul>';

echo '<br><br><br><h4>TEST DATABASE WITH OWN VALUES</h4>';

phpinfo();

# $dbConnect = pg_connect("host=172.18.251.135 port=5432 dbname=unms user=ucrm password=QZi64gDdTaCe5LDxm4ssyeEvZCX1HiyeKDUtRz1CQWUwVNYF");

# $result=pg_query('SELECT custom_table.id, custom_table.test_name FROM custom_table');

# var_dump(pg_fetch_all($result));

# pg_close();


