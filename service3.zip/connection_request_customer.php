<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	$content = array();

    $templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company",
		  					   "mail", "phone", "mobil", "birthDay"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode",
							   "psPlace", "psDistrict", "psTae")
	);
	  
	require __DIR__ . "/views/connectionRequest/connection_request.php";
	$conRequest = new ConnectionRequest($templateData, $infos);
	  
	$content = array(
	  "step3Lable" => "Kundendaten",
	  "step3"      => $conRequest->getTemplateStep2()
	);

	echo json_encode($content);
  } 
?>