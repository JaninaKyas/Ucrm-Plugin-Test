<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class TariffQueries {
    public function getAllTariffData(): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT 
                      tariff.id                                                as id, 
                      tariff.name                                              as name, 
                      tariff.price                                             as price, 
                      tariff.note                                              as downStream, 
                      tariff.power_down                                        as upStream,
					  tariff.customer_class                                    as cClassType,
                      category.name                                            as category, 
                      GROUP_CONCAT(Distinct technology.name    SEPARATOR ', ') as techName,
                      GROUP_CONCAT(Distinct tariff_option.name SEPARATOR ', ') as tOptions
                    FROM tariff 
                    JOIN category                    ON category.id = tariff.category_id
                    LEFT JOIN tariff_x_technology    ON tariff_x_technology.tariff_id = tariff.id
                    LEFT JOIN technology             ON tariff_x_technology.technology_id = technology.id
                    LEFT JOIN tariff_x_tariff_option ON tariff_x_tariff_option.tariff_id = tariff.id
                    LEFT JOIN tariff_option          ON tariff_option.id = tariff_x_tariff_option.tariff_option_id
                    WHERE
                      tariff.isDeleted = 0 
                    AND
                      category.isDeleted = 0
                    GROUP BY id, name, price, upStream, downStream, category";
		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
    public function getAllTariffDataById($id): array {
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT 
                      tariff.id                                                as id, 
                      tariff.name                                              as name, 
                      tariff.price                                             as price, 
                      tariff.note                                              as downStream, 
                      tariff.power_down                                        as upStream,
					  tariff.customer_class                                    as cClassType,
                      category.name                                            as category, 
                      GROUP_CONCAT(Distinct technology.name    SEPARATOR ', ') as techName,
                      GROUP_CONCAT(Distinct tariff_option.name SEPARATOR ', ') as tOptions
                    FROM tariff 
                    JOIN category                    ON category.id = tariff.category_id
                    LEFT JOIN tariff_x_technology    ON tariff_x_technology.tariff_id = tariff.id
                    LEFT JOIN technology             ON tariff_x_technology.technology_id = technology.id
                    LEFT JOIN tariff_x_tariff_option ON tariff_x_tariff_option.tariff_id = tariff.id
                    LEFT JOIN tariff_option          ON tariff_option.id = tariff_x_tariff_option.tariff_option_id
                    WHERE
                      tariff.isDeleted = 0 
                    AND
                      category.isDeleted = 0
					AND
					  tariff.id = " . $id . "
                    GROUP BY id, name, price, upStream, downStream, category";
		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }

	  return $returnValue[0];
	}
  }
?>