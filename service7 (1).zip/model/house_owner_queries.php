<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class HouseOwnerQueries {
   public function getIdByHouseOwnerData(
	 $fName, $lName, $company, $street, $hnr, $plz, $place, $district, $hrNumber, $mail, $phone, $mobil,
	 $fStreet, $fHNr, $fZipcode, $fPlace, $fDistrict
   ): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = 'SELECT ho.id as id
		            FROM house_owner   AS ho
					LEFT JOIN address  AS a  ON ho.address_id       = a.id
					LEFT JOIN location AS l  ON a.location_id       = l.id
					LEFT JOIN address  AS ad ON ho.floor_address_id = ad.id
					LEFT JOIN location AS ld  ON ad.location_id     = ld.id
					WHERE ho.isDeleted = 0
					  AND
					    a.isDeleted    = 0
					  AND
					    l.isDeleted    = 0
					  AND
					    ad.isDeleted   = 0
					  AND
					    ld.isDeleted   = 0';
		
		  if ($fName != "") {
		    $query .= ' AND ho.fName LIKE \'' . $fName . '\' ';
		  }
			
		  if ($lName != "") {
		    $query .= ' AND ho.lName LIKE \'' . $lName . '\' ';
		  }
			
		  if ($company != "") {
		    $query .= ' AND ho.company LIKE \'' . $company . '\' ';
		  }
			
		  if ($hrNumber != "") {
		    $query .= ' AND ho.hr_number LIKE \'' . $hrNumber . '\' ';
		  }
			
		  if ($mail != "") {
		    $query .= ' AND ho.mail LIKE \'' . $mail . '\' ';
		  }
			
		  if ($phone != "") {
		    $query .= ' AND ho.phone LIKE \'' . $phone . '\' ';
		  }
			
		  if ($mobil != "") {
		    $query .= ' AND ho.mobil LIKE \'' . $mobil . '\' ';
		  }
			
		  if ($street != "") {
		    $query .= ' AND a.street LIKE \'' . $street . '\' ';
		  }
			
		  if ($hnr != "") {
		    $query .= ' AND a.houseNr LIKE \'' . $hnr . '\' ';
		  }
			
		  if ($plz != "") {
		    $query .= ' AND a.zipcode LIKE \'' . $plz . '\' ';
		  }
			
		  if ($place != "") {
		    $query .= ' AND l.name LIKE \'' . $place . '\' ';
		  }
			
		  if ($district != "") {
		    $query .= ' AND l.district LIKE \'' . $district . '\' ';
		  }
			
		  if ($fStreet != "") {
		    $query .= ' AND ad.street LIKE \'' . $fStreet . '\' ';
		  }
			
		  if ($fHNr != "") {
		    $query .= ' AND ad.houseNr LIKE \'' . $fHNr . '\' ';
		  }
			
		  if ($fZipcode != "") {
		    $query .= ' AND ad.zipcode LIKE \'' . $fZipcode . '\' ';
		  }
			
		  if ($fPlace != "") {
		    $query .= ' AND ld.name LIKE \'' . $fPlace . '\' ';
		  }
			
		  if ($fDistrict != "") {
		    $query .= ' AND ld.district LIKE \'' . $fDistrict . '\' ';
		  }
			
		  $result = $connection->query($query);
			
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
	  
	public function saveNewHouseOwner(
	  $title, $fName, $lName, $company, $addressId, $fAddressId, $hrNumber, $fFloor, $fFloorKind,
	  $fDFloor, $mail, $phone, $mobil
	): int {
	  $returnValue = -1;
		
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");

		  $query = 'INSERT INTO address
		            VALUES(
					  null, '
			        . '\'' . $title      . '\', '
			        . '\'' . $fName      . '\', '
			        . '\'' . $lName      . '\', '
			        . '\'' . $company    . '\', '
			        . $addressId         . ', '
			        . $fAddressId        . ', '
			        . '\'' . $hrNumber   . '\', '
			        . '\'' . $fFloor     . '\', '
			        . '\'' . $fFloorKind . '\', '
			        . '\'' . $fDFloor    . '\', '
			        . '\'' . $mail       . '\', '
			        . '\'' . $mobil      . '\', '
			        . '\'' . $phone      . '\', '
			        . 'NOW(), \'JANINA\', NOW(), \'JANINA\', 0)';
			
		  $result = $connection->query($query);
			
		  if ($returnValue != false) {
		    $returnValue = $connection->insert_id;
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>