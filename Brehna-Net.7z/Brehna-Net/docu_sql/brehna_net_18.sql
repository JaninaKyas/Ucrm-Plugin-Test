--
-- Tabellenstruktur für Tabelle `tariff_x_tariff_option`
--

CREATE TABLE IF NOT EXISTS `tariff_x_tariff_option` (
  `id`               INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tariff_id`        INT(11) UNSIGNED NOT NULL,
  `tariff_option_id` INT(11) UNSIGNED NOT NULL,
  `count_nr`         INT(11) UNSIGNED NOT NULL DEFAULT 0,
  `createDate`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser`       CHAR(50)         NOT NULL DEFAULT '',
  `updateDate`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser`       CHAR(50)         NOT NULL DEFAULT '',
  `isDeleted`        TINYINT(1)       NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  FOREIGN KEY (tariff_id)        REFERENCES `tariff`(id),
  FOREIGN KEY (tariff_option_id) REFERENCES `tariff_option`(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;