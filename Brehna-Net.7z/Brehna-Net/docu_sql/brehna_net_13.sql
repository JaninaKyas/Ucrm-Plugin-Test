--
-- Tabellenstruktur für Tabelle `tariff_option`
--

CREATE TABLE IF NOT EXISTS `tariff_option` (
  `id`         INT(11)       UNSIGNED NOT NULL AUTO_INCREMENT,
  `parent_id`  INT(11)                NOT NULL DEFAULT -1,  
  `name`       CHAR(150)              NOT NULL DEFAULT '',
  `price`      DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `price_sen`  DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `price_gk`   DECIMAL(10,2)          NOT NULL DEFAULT 0.00,
  `note`       CHAR(150)              NOT NULL DEFAULT '',
  `downstream` INT(5)        UNSIGNED NOT NULL DEFAULT 0,
  `upstream`   INT(5)        UNSIGNED NOT NULL DEFAULT 0,
  `createDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)               NOT NULL DEFAULT '',
  `updateDate` DATETIME               NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)               NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)             NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `tariff_option`
--

INSERT INTO `tariff_option` VALUES (null, '... bitte auswählen ...', 0.00, 0.00,0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'IPv4 Adresse dynamisch',  4.95, 0.00,0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'IPv4 Adresse fix',       14.00, 0.00,0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Telefonie Standard inkl. 1 SIP Sprachkanal, 1 Rufnummer, Festnetzflat DE' ,  4.95,  0.00,  0.00, '',                                      0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'zusätzlicher SIP Sprachkanal, Rufnummer, inkl. DE FLAT'                   ,  7.90,  7.90,  9.50, '',                                      0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Allnetflatrate (Alle Festt- und Mobilnetze in Deutschland je Sprachkanal)', 19.00, 19.00, 25.00, '',                                      0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Leitungsgebühr Fremdnetze (TAL Miete VDSL/ LWL/ Bitstream)'               ,  4.00,  0.00,  0.00, '',                                      0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'TV-Anschluss DVB-S/ C'                                                    ,  4.50,  0.00,  0.00, '(verfügbar in 06188 Landsberg/ Queis)', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Fremdnetzgebühr TAL-Miete'       , 0.00,  4.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Fremdnetzgebühr DE/ DTAG/ EXTERN', 0.00, 14.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Business Speed 200'            , 20.00, 0.00, 0.00, '(für MAXX und Glasfaser)', 200,  50, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Business Speed 400'            , 40.00, 0.00, 0.00, '(für MAXX und Glasfaser)', 400,  50, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Business Speed 800'            , 80.00, 0.00, 0.00, '(für MAXX und Glasfaser)', 800, 100, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Feste öffentliche IPv4-Adresse', 12.00, 0.00, 0.00, ''                        ,   0,   0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Rufnummernmitnahme zu Brehna.net bei Telefonie', 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'inkl. Internetflatrate'       , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'keine Volumenbeschränkung'    , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Providernetz IPv4/ v6-Adresse', 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'VPN fähig'                    , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '1 VoIP Sprachkanal'           , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '1 Rufnummer'                  , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Festnetzflat Deutschland'     , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Standard Tarife inkl. Internetflatrate'             , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'öffentliche IP'                                     , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '12h Service'                                        , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Tarif max. = bis zu 95 / 35 MBit/s bei VDSL und LWL', 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, 'Plus Tarife inkl. Internetflatrate', 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '8h Prem. Service'                  , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '2 VoIP Sprachkanäle'               , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `tariff_option` VALUES (null, '3 Rufnummern'                      , 0.00, 0.00, 0.00, '', 0, 0, 0, NOW(), 'JANINA', NOW(), 'JANINA', 0);