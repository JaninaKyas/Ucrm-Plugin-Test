<?php

declare(strict_types=1);

use Ubnt\UcrmPluginSdk\Service\UcrmSecurity;

chdir(__DIR__);

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/helper/Service/ViewRender.php';
require __DIR__ . '/helper/Service/Http.php';
require __DIR__ . '/model/get_custome_user_data.php';

$security = UcrmSecurity::create();
$user = $security->getUser();

if (!$user || $user->isClient) {
  $http = new Http();
  $http->forbidden();
}

$renderer = new ViewRender();
$renderer->render(
  __DIR__ . '/views/search.php',
  // __DIR__ . '/views/test.php',
   [ 'result' => [], ]
);

?>
