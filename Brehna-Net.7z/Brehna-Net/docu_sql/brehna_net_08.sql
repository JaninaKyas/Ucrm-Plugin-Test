--
-- Tabellenstruktur für Tabelle `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id`         INT(11)    UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       CHAR(150)           NOT NULL DEFAULT '',
  `district`   CHAR(150)           NOT NULL DEFAULT '',
  `createDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createUser` CHAR(50)            NOT NULL DEFAULT '',
  `updateDate` DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updateUser` CHAR(50)            NOT NULL DEFAULT '',
  `isDeleted`  TINYINT(1)          NOT NULL DEFAULT 0,
  PRIMARY KEY (id)
) ENGINE=INNODB;

--
-- Daten für Tabelle `location`
--

INSERT INTO `location` VALUES(null, '... bitte auswählen ...',          '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, '(Anderer)',                        '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Brehna',                           '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Kabelsketal',                      '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Dammendorf',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Kneipe',        NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Oppin',         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Petersdorf',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Queis',         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Petersberg',                       '',              NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Brachstedt',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Hohen',         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Landsberg',                        'Wurp',          NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Sandersdorf-Brehna',               'Glebitzsch',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Sandersdorf-Brehna',               'Köckern',       NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Wiedemar',                         'Pohritzsch',    NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Zörbig',                           'Prussendorf',   NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Zörbig',                           'Quetzdölsdorf', NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Zörbig',                           'Rieda',         NOW(), 'JANINA', NOW(), 'JANINA', 0);
INSERT INTO `location` VALUES(null, 'Zörbig',                           'Schrenz',       NOW(), 'JANINA', NOW(), 'JANINA', 0);