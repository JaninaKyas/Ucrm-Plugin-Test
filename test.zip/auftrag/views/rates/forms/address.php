<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();
	public $techAddress  = array();

    public function __construct($newTemplateData, $newValues = array(), $newTechAddress = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	  $this->techAddress  = $newTechAddress;
	}
	  
	public function buildAddressTemplate(): string {		
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse*</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   class="form-control requiredRC"
				   value="' . $this->values["street"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer*</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   class="form-control required"
				   value="' . $this->values["hNr"] . '">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl*</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   class="form-control requiredRC"
				   value="' . $this->values["zipcode"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort*</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   class="form-control requiredRC"
				   value="' . $this->values["place"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   class="form-control"
				   value="' . $this->values["district"] . '">
		  </div>
		</div>
	  ';
	
	  if (in_array("psTae", $this->templateData)) {
		$returnValue .= '
	      <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Hauseingang / Wohnung</label>
		      <input type="text"
			         id="'   . $this->templateData[5] . '"
			  	     name="' . $this->templateData[5] . '"
				     class="form-control">
			</div>
		  </div>
		';
	  }
		
	  return $returnValue;
	}
	  
    public function buildTechAddressTemplate(): string {
	  $isEmpty = empty($this->techAddress);
	  $returnValue = '
	    <div class="row">
		  <div class="col">
		    <span class="fontTitle">
			  <input id="'   . $this->templateData[6] . '"
			         name="' . $this->templateData[6] . '"
					 type="checkbox"
					 onClick="displayTechAddress()">
			  Anschlussadresse (Angabe nur wenn abweichend von Postanschrift)
			</span>
		  </div>
		</div>
		
	    <span id="techAddress">
        <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse*</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   class="form-control requiredRC1"
				   value="' . $this->techAddress["street"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer*</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   class="form-control requiredRC1"
				   value="' . $this->techAddress["hNr"] . '">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl*</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   class="form-control requiredRC1"
				   value="' . $this->techAddress["zipcode"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort*</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   class="form-control requiredRC1"
				   value="' . $this->techAddress["place"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   class="form-control"
				   value="' . $this->techAddress["district"] . '">
		  </div>
		</div>
		
	      <div class="row puffer">
		    <div class="col">
			  <label class="addressLabel">Hauseingang / Wohnung</label>
		      <input type="text"
			         id="'   . $this->templateData[5] . '"
			  	     name="' . $this->templateData[5] . '"
				     class="form-control">
			</div>
		  </div>
	    </span>
	  ';
		
	  return $returnValue;
	}
  }
?>