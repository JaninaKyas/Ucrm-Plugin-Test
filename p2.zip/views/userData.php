<?php    
  $path = substr(__DIR__, 0, -6);
  require_once($path . '/model/get_custome_user_data.php');
  $customTable = new CustomTable();
  // $result = $customTable->getUserByCustomerNumber($_POST['cusNrInput']);
        
  var_dump($_GET['cNr']);
?> 
