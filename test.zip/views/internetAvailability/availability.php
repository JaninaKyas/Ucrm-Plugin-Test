<?php
  declare(strict_types = 1);

  require __DIR__ . "/forms/address.php";

  $asbAddress = new Address('asbStreet', 'asbHNr', 'asbPlz', 'asbPlace', 'asbDistrict', '', '', true);
?>
<div class="centerForm">
  <div id="asbErrorMsg" class="d-none">
	<div class="row">
	  <div class="col">
		<div class="alert alert-danger" role="alert">
		  <img id="errorImg"
			   src="https://neu.brehna.net/auftrag/public/images/error-5.png" alt="errorMsg">
		  <span>Bitte füllen Sie alle Pflichtfelder aus.</span>
		</div>
	  </div>
	</div>
  </div>

  <div class="fontTitle">PRÜFEN SIE DIE VERFÜGBARKEIT</div>
  <form id="asbCheck" method="POST">
	<?php echo $asbAddress->getTemplate(); ?>
  </form>
</div>