Was von dem Anschluss ist durch die Störung betroffen?
<ul class="list-group">
  <li class="list-group-item">
    <input type="radio" id="complete" name="iKind" value="Komplettausfall" onClick="setInterferenceKind(0)">
    <label for="complete">Komplettausfall</label>
  </li>
  <li class="list-group-item">
    <input type="radio" id="phone1" name="iKind" value="Telefon" onClick="setInterferenceKind(1)">
    <label for="phone1">Telefon</label>    
  </li>
  <li class="list-group-item">
    <input type="radio" id="internet" name="iKind" value="Internet" onClick="setInterferenceKind(2)">
    <label for="internet">Internet</label>    
  </li>
  <li class="list-group-item">
    <input type="radio" id="tv" name="iKind" value="TV" onClick="setInterferenceKind(0)">
    <label for="tv">TV</label>
  </li>
</ul>

<div id="descDiv" class="form-group">
  <label for="description">Fehlerbeschreibung aus Kundensicht</label>
  <textarea class="form-control" id="description" name="description" value="" rows="7"></textarea>
</div>
