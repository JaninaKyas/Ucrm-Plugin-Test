<?php
  declare(strict_types = 1);

  require_once __DIR__ . "/forms/rate_card.php";

  class Tariff extends RateCard {
    public $rates = array();
	  
	public function __construct($newRates) {
	  $this->rates = $newRates;
	}
	  
	public function getTemplate(): string {
	  $returnValue = '
	    <div>
		  <div class="fontTitle">Tarifauswahl</div>
	  ';
	
	  for ($i = 0; $i < count($this->rates); $i++) {
	    $rateCard = new RateCard($this->rates[$i]);
		$returnValue .= $rateCard->getRateCard();
	  }
		
	  $returnValue .= '</div>';
		
	  return $returnValue;
	}
  }
?>