<?php
  ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL);

  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);
	$content = array();
	  
	require __DIR__ . "/model/tariff_options.php";
	require __DIR__ . "/views/rates/forms/options/private_customer_options.php";
	
	$rateOptionsQueries = new TariffOptionsQueries();
	$optionReRate = $rateOptionsQueries->getAllOptionsRegardlessOfRateForPK();
	$optionDeRate = $rateOptionsQueries->getAllOptionsDependingOnRatesForPK();
	  
	$templateData = array(
	  "ipAddress" => array("ipDynamic", "ipFix", "phDefault", "phSip", "phAllnet")
	);
	  
	$rateOptionsTemplate = new PrivateCustomerOptions($templateData, $optionReRate, $optionDeRate);
	$content["step4content"] = $rateOptionsTemplate->buildOptionsPKTemplate();
	  
	echo json_encode($content);
  }
?>