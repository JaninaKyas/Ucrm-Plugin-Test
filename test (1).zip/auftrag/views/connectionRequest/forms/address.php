<?php
  declare(strict_types = 1);

  class Address {
	public $templateData = array();
	public $values       = array();

    public function __construct($newTemplateData, $newValues = array()) {
      $this->templateData = $newTemplateData;
	  $this->values       = $newValues;
	}
	  
	public function buildAddressTemplate(): string {		
	  $returnValue = '
	    <div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Strasse*</label>
		    <input type="text"
			       id="'   . $this->templateData[0] . '"
			  	   name="' . $this->templateData[0] . '"
				   class="form-control required"
				   value="' . $this->values["street"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Hausnummer*</label>
		    <input type="text"
			       id="'   . $this->templateData[1] . '"
			  	   name="' . $this->templateData[1] . '"
				   class="form-control required"
				   value="' . $this->values["hNr"] . '">
		  </div>
		</div>
		
		<div class="row puffer">
		  <div class="col">
		    <label class="addressLabel">Postleitzahl*</label>
		    <input type="text"
			       id="'   . $this->templateData[2] . '"
			  	   name="' . $this->templateData[2] . '"
				   class="form-control required"
				   value="' . $this->values["zipcode"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ort*</label>
		    <input type="text"
			       id="'   . $this->templateData[3] . '"
			  	   name="' . $this->templateData[3] . '"
				   class="form-control required"
				   value="' . $this->values["place"] . '">
		  </div>
		  
		  <div class="col">
		    <label class="addressLabel">Ortsteil</label>
		    <input type="text"
			       id="'   . $this->templateData[4] . '"
			  	   name="' . $this->templateData[4] . '"
				   class="form-control"
				   value="' . $this->values["district"] . '">
		  </div>
		</div>
	  ';
		
	  return $returnValue;
	}
  }
?>