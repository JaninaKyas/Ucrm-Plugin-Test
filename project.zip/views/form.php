<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Interferences recording</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!--script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script-->
    <style>      
      .puffer {
        padding: 10px 0 10px 0;
      }
      
      #otherLoca {
        display: none;
      }
      
      body{
        font-family: 'Open Sans', sans-serif;
      }
      #signUpForm {
          max-width: 90%;
          background-color: #ffffff;
          margin: 40px auto;
          padding: 40px;
          box-shadow: 0px 6px 18px rgb(0 0 0 / 9%);
          border-radius: 12px;
      }
      #signUpForm .form-header {
        gap: 5px;
        text-align: center;
        font-size: .9em;
      }
      #signUpForm .form-header .stepIndicator {
        position: relative;
        flex: 1;
        padding-bottom: 30px;
      }
      #signUpForm .form-header .stepIndicator.active {
        font-weight: 600;
      }
      #signUpForm .form-header .stepIndicator.finish {
        font-weight: 600;
        color: #009688;
      }
      #signUpForm .form-header .stepIndicator::before {
        content: "";
        position: absolute;
        left: 50%;
        bottom: 0;
        transform: translateX(-50%);
        z-index: 9;
        width: 20px;
        height: 20px;
        background-color: #d5efed;
        border-radius: 50%;
        border: 3px solid #ecf5f4;
      }
      #signUpForm .form-header .stepIndicator.active::before {
        background-color: #a7ede8;
        border: 3px solid #d5f9f6;
      }
      #signUpForm .form-header .stepIndicator.finish::before {
        background-color: #009688;
        border: 3px solid #b7e1dd;
      }
      #signUpForm .form-header .stepIndicator::after {
        content: "";
        position: absolute;
        left: 50%;
        bottom: 8px;
        width: 100%;
        height: 3px;
        background-color: #f3f3f3;
      }
      #signUpForm .form-header .stepIndicator.active::after {
        background-color: #a7ede8;
      }
      #signUpForm .form-header .stepIndicator.finish::after {
        background-color: #009688;
      }
      #signUpForm .form-header .stepIndicator:last-child:after {
        display: none;
      }
      #signUpForm input {
        padding: 15px 20px;
        width: 100%;
        font-size: 1em;
        border: 1px solid #e3e3e3;
        border-radius: 5px;
      }
      #signUpForm input:focus {
        border: 1px solid #009688;
        outline: 0;
      }
      #signUpForm input.invalid {
        border: 1px solid #ffaba5;
      }
      #signUpForm .step {
        display: none;
      }
      #signUpForm .form-footer{
        overflow:auto;
        gap: 20px;
      }
      #signUpForm .form-footer button{
        background-color: #009688;
        border: 1px solid #009688 !important;
        color: #ffffff;
        border: none;
        padding: 13px 30px;
        font-size: 1em;
        cursor: pointer;
        border-radius: 5px;
        flex: 1;
        margin-top: 5px;
      }
      #signUpForm .form-footer button:hover {
        opacity: 0.8;
      }  
      #signUpForm .form-footer #prevBtn {
        background-color: #fff;
        color: #009688;
      }
      
      #cLocation {
        height: 56px;
      }
      
      #cRowOtherLoca {
        display: none;
      }
    </style>
  </head>
  <body>
    <?php    
      if (isset($_POST["search"])) {     
        $path = substr(__DIR__, 0, -6);
        require_once($path . '/model/get_custome_user_data.php');
        $customTable = new CustomTable();        
        $result = $customTable->getUserByCustomerNumber($_POST['cNr']);
      }
    ?> 
    
    <h1 class="text-center fs-4" style="margin-top: 15px;">Störungsaufnahme</h1>
    <form id="signUpForm" method="post">
        <!-- start step indicators -->
        <div class="form-header d-flex mb-4">
            <span class="stepIndicator">Kundendaten</span>
            <span class="stepIndicator">Leitungsprüfung</span>
            <span class="stepIndicator">Termin vereinbaren</span>
        </div>
        <!-- end step indicators -->
    
        <!-- Kundendaten -->
        <div class="step">
            <div class="row">
              <div class="col-10">
                <label for="cNr" class="form-label">Kundennummer</label>
                <input type="text" class="form-control" id="cNr" name="cNr" placeholder="Kundennummer" value="<?php if (array_key_exists('customer_number', $result) && !is_null($result['customer_number'])) { echo trim($result['customer_number']); } ?>">                
              </div>
              <div class="col-auto">
                <button class="btn btn-primary btn-md" type="submit" id="search" name="search" value="search" style="margin-top: 40px;">Lade Kunde</button>
              </div>
            </div>
            
            <div class="row puffer">
              <div class="col">
                <label for="cFirstname" class="form-label">Vorname*</label>
                <input type="text" class="form-control required" id="cFirstname" placeholder="Vorname"  value="<?php if (array_key_exists('test_firstname', $result) && !is_null($result['test_firstname'])) { echo trim($result['test_firstname']); } ?>">               
              </div>
              <div class="col">
                <label for="cLastname" class="form-label">Nachname*</label>
                <input type="text" class="form-control required" id="cLastname" placeholder="Nachname"  value="<?php if (array_key_exists('test_name', $result) && !is_null($result['test_name'])) { echo trim($result['test_name']); } ?>">               
              </div>
            </div>
            
            <div class="row puffer">
              <div class="col">
                <label for="cCompany" class="form-label">Firma (falls Meldung als Businesskunde)</label>
                <input type="text" class="form-control" id="cCompany" placeholder="Firma"  value="<?php if (array_key_exists('test_company', $result) && !is_null($result['test_company'])) { echo trim($result['test_company']); } ?>">            
              </div>
            </div>
            
            <div class="row puffer">
              <div class="col">
                <label for="cStreet" class="form-label">Strasse*</label>
                <input type="text" class="form-control required" id="cStreet" placeholder="Strasse">   
              </div>
              <div class="col">
                <label for="cHNr" class="form-label">Hausnummer*</label>
                <input type="text" class="form-control required" id="cHNr" placeholder="Hausnummer"> 
              </div>
            </div>
            
            <div class="row puffer">
              <div class="col">
                <label for="cPLZ" class="form-label">Postleitzahl*</label>
                <input type="text" class="form-control required" id="cPLZ" placeholder="Postleitzahl"> 
              </div>
              <div class="col">
                <label for="cLocation" class="form-label">Ort*</label>
                <select id="cLocation" class="form-select" onchange="setVisibilityRow(this)">
                  <option value="-1">... bitte auswählen ...</option>
                  <?php                  
                    foreach ($places as $place) {
                      $placeName = $place["name"];
                      
                      if (!is_null($place["district"])) {
                        $placeName = $placeName . " OT " . $place["district"]; 
                      }
                      
                      echo "<option value='" . $place["id"] . "'>" . $placeName . "</option>";
                    }
                  ?>
                  <option value="-2">(Anderer)</option>                
                </select>
              </div>
            </div>

            <div id="cRowOtherLoca" class="row">
              <div class="col"></div>
              <div class="col">
                <label for="cOtherLoca1" class="form-label">Anderer Ort*</label>
                <input type="text" class="form-control required" id="cOtherLoca1" placeholder="Anderer Ort">
              </div>
            </div>
        
            <div class="row puffer">
              <div class="col">
                <label for="cMail" class="form-label">E-Mail*</label>
                <input type="text" class="form-control required" id="cMail" placeholder="E-Mail">
              </div>
              <div class="col">
                <label for="cPhone" class="form-label">Telefon/Mobil*</label>
                <input type="text" class="form-control required" id="cPhone" placeholder="Telefon/Mobil">
              </div>
            </div>
        </div>
    
        <!-- Leitungsprüfung -->
        <div class="step"></div>
    
        <!-- Termin vereinbaren -->
        <div class="step"></div>
    
        <!-- start previous / next buttons -->
        <div class="form-footer d-flex">
            <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
            <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
        </div>
        <!-- end previous / next buttons -->
    </form>
    
    <script>
      var currentTab = 0; // Current tab is set to be the first tab (0)
      showTab(currentTab); // Display the current tab
        
      function showTab(n) {
        // This function will display the specified tab of the form...
        var x = document.getElementsByClassName("step");
        x[n].style.display = "block";
        
        //... and fix the Previous/Next buttons:
        if (n == 0) {
          document.getElementById("prevBtn").style.display = "none";
        } else {
          document.getElementById("prevBtn").style.display = "inline";
        }
        
        if (n == (x.length - 1)) {
          document.getElementById("nextBtn").innerHTML = "Submit";
        } else {
          document.getElementById("nextBtn").innerHTML = "Next";
        }
        
        //... and run a function that will display the correct step indicator:
        fixStepIndicator(n)
      }
        
      function nextPrev(n) {
        // This function will figure out which tab to display
        var x = document.getElementsByClassName("step");
        
        // Exit the function if any field in the current tab is invalid:
        if (n == 1 && !validateForm()) return false;
          
        // Hide the current tab:
        x[currentTab].style.display = "none";
          
        // Increase or decrease the current tab by 1:
        currentTab = currentTab + n;
        
        // if you have reached the end of the form...  
        if (currentTab >= x.length) {
          // ... the form gets submitted:
          document.getElementById("signUpForm").submit();
          return false;
        }
          
        // Otherwise, display the correct tab:
        showTab(currentTab);
      }
        
      function validateForm() {
        // This function deals with validation of the form fields
        var x, y, i, valid = true;
        x = document.getElementsByClassName("step");
        y = x[currentTab].getElementsByClassName("form-control required");
        
        // A loop that checks every input field in the current tab:
        for (i = 0; i < y.length; i++) {
          console.log(y[i]);
          console.log(y[i].style.display);
        
          if (y[i].id == "cOtherLoca1" && document.getElementById("cRowOtherLoca").style.display == "block" && y[i].value == "") {
            valid = setValidateState(y[i]);          
          } else if (y[i].id != "cOtherLoca1" && y[i].value == "") {
            valid = setValidateState(y[i]);
          } else if (y[i].id == "cLocation" && y[i].value === "-1") {
            valid = setValidateState(y[i]);
          }
        }
          
        // If the valid status is true, mark the step as finished and valid:
        if (valid) {
          document.getElementsByClassName("stepIndicator")[currentTab].className += " finish";
        }
        
        return valid; // return the valid status
      }
        
      function fixStepIndicator(n) {
        // This function removes the "active" class of all steps...
        var i, x = document.getElementsByClassName("stepIndicator");
       
        for (i = 0; i < x.length; i++) {
          x[i].className = x[i].className.replace(" active", "");
        }
       
        //... and adds the "active" class on the current step:
        x[n].className += " active";
      }
      
      function setVisibilityRow(select) {
        var selectValue = select.value;
        var row = document.getElementById("cRowOtherLoca");
        
        if (selectValue === "-2") {
          row.style.display = "block";
        } else {
          row.style.display = "none";
        }
      }
      
      function setValidateState(element) {
        // add an "invalid" class to the field:
        element.className += " invalid";
           
        // and set the current valid status to false
        return false;
      }  
    </script>    
  </body>    
</html>
