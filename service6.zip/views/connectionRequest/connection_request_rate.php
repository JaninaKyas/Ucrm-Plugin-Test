<?php  
  declare(strict_types = 1);

  class ConnectionRequest {
	public $rates = array();
	  
	public function __construct($newRates) {
      $this->rates = $newRates;
	}
	  
	public function buildConnectionRequestRateTemplate(): string {
	  $returnValue = '<div class="row puffer left">
	    <div class="col">
		  <strong>Welchen Tarif suchen Sie?</strong>
		</div>
		
		<div class="col">
		  <select id="conRequestRate" name="conRequestRate">';
		  
		if (!empty($this->rates)) {
		  for ($i=0;$i < count($this->rates); $i++) {
		    $returnValue .= '<option value="' . $this->rates[$i]["rateId"] . '">' . $this->rates[$i]["rate"] . '</option>';	
		  }
		}
		
		$returnValue .= '  
		  </select>
		</div>
	  </div>';
	  
	  return $returnValue;
	}
  }
?>