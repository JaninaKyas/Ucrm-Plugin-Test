<div class="container d-flex justify-content-center align-items-center">

<div class="progresses">


                    <div class="steps">
                      <span><i class="fa fa-check"></i></span>
                    </div>

                    <span class="line"></span>

                    <div class="steps">
                      <span><i class="fa fa-check"></i></span>
                    </div>


                    <span class="line"></span>

                    <div class="steps">
                      <span class="font-weight-bold">3</span>
                    </div>
                     
                   </div>    
    
</div>
