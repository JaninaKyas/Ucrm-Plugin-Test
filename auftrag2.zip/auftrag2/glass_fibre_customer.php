<?php
  if (isset($_POST)) {
    $data    = file_get_contents("php://input");
    $infos   = json_decode($data, true);

    $templateData = array(
	  "personalData"  => array("salutation", "fName", "lName", "company",
		  					   "mail", "phone", "mobil", "birthDay"),
	  "postalAddress" => array("psStreet", "psHNr", "psZipcode",
							   "psPlace", "psDistrict", "psTae"),
	  "connecAddress" => array("caStreet", "caHNr", "caZipcode", "caPlace",
		 					   "caDistrict", "conTae", "caDiffAddress")
	);
	  
	require __DIR__ . "/views/glassFibre/glass_fibre.php";
	$glassFibre = new GlassFibre($templateData, $infos, array());
	  
	$content = array(
	  "step3Lable"    => "Kundendaten",
	  "step3"         => $glassFibre->getGlasFibreTemplate(),
	  "caDiffAddress" => "none"
	);

	echo json_encode($content);
  } 
?>