<?php
  require_once __DIR__ . '/config/config_mysql.php';

  class AsbAvailabilityQueries {
    public function getMaxDownloadStream($street, $hnr, $plz, $place, $district): array {
	  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
	  
	  $returnValue = array();
	  $config = new ConfigDb();
		
	  try {
	    $connection = mysqli_connect(
		  $config->getDbHost() . ":" . $config->getDbPort(),
		  $config->getDbUser(),
		  $config->getDbPassword(),
		  $config->getDbName()
		);
		  
		if ($connection != false) {		  
		  $connection->set_charset("utf8");
			
		  $query = "SELECT MAX(asb.down_stream) as maxSpeed
		            FROM asb_availability AS asb
					LEFT JOIN address  AS a ON a.id          = asb.address_id 
					LEFT JOIN location AS l ON a.location_id = l.id
					WHERE asb.isDeleted = 0";
			
		  if (!empty($street) && $street != "") {
		    $query = $query . " AND a.street LIKE '" . $street . "'";
		  }
			
		  if (!empty($hnr) && $hnr != "") {
		    $query = $query . " AND a.houseNr LIKE '" . $hnr . "'";
		  }
			
		  if (!empty($plz) && $plz != "") {
		    $query = $query . " AND a.zipcode LIKE '" . $plz . "'";
		  }
		
		  if (!empty($place) && $place != "") {
		    $query = $query . " AND l.name LIKE '" . $place . "'";
		  }
			
		  if (!empty($district) && $district != "") {
		    $query = $query . " AND l.district LIKE '" . $district . "'";
		  }
			
		  $result = $connection->query($query);
		  
		  if ($result != false) {
		    $returnValue = $result->fetch_all(MYSQLI_ASSOC);
		  }
			
		  mysqli_close($connection);
		}
	  } catch (Exception $e) {
	    die($e->getMessage());
	  }
		
	  return $returnValue;
	}
  }
?>