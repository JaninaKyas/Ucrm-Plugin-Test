<html lang="de-DE" class="no-js">
  <?php require_once __DIR__ . "/views/main/head.php"; ?>
  <body class="nb-3-3-4 nimble-has-local-data-skp__post_page_43 nimble-no-group-site-tmpl-skp__all_page page-template-default page page-id-43 wp-custom-logo wp-embed-responsive sek-hide-rc-badge czr-link-hover-underline header-skin-light footer-skin-light czr-no-sidebar tc-center-images czr-full-layout sn-right-mc_slide_top customizr-pro-2-4-7 czr-sticky-footer">
    <?php require_once __DIR__ . "/views/main/sidebar.php"; ?>
    <div id="tc-page-wrap" class="">
      <?php require_once __DIR__ . "/views/main/header.php"; ?>
      <div id="main-wrapper" class="section">
        <div class="container" role="main">
          <div class="flex-row row column-content-wrapper">
            <div id="content" class="col-12 article-container">
			  <?php require_once __DIR__ . "/views/main/main.php"; ?>
			</div>
          </div><!-- .column-content-wrapper -->
        </div><!-- .container -->
      </div><!-- #main-wrapper -->
      <?php require_once __DIR__ . "/views/main/footer.php"; ?>
    </div><!-- end #tc-page-wrap -->
    <?php require_once __DIR__ . "/views/main/scripts.php"; ?>
  </body>
</html>
